<?php

namespace App\Http\Requests;

use App\Models\Gst;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StoreGstRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('gst_create');
    }

    public function rules()
    {
        return [
            'gst_percentage' => [
                'nullable',
                'integer',
            ],
        ];
    }
}