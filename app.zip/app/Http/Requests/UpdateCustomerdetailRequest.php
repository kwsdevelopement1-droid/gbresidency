<?php

namespace App\Http\Requests;

use App\Models\Customerdetail;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class UpdateCustomerdetailRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('customerdetail_edit');
    }

    public function rules()
    {
        return [
            'customer_ids_id' => [
                'required',
                'integer',
            ],
            'check_in' => [
                'required',
                'date_format:' . config('panel.date_format') . ' ' . config('panel.time_format'),
            ],
            'check_out' => [
                'required',
                'date_format:' . config('panel.date_format') . ' ' . config('panel.time_format'),
            ],
        ];
    }
}