<?php

namespace App\Http\Requests;

use App\Models\Customer;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StoreCustomerRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('customer_create');
    }

    public function rules()
    {
        return [
            'guest_type' => [
                'required',
            ],
            'guest_name' => [
                'string',
                'required',
            ],
            'country_code' => [
                'string',
                'required',
            ],
            'phone_number' => [
                'string',
                'required',
            ],
            'guest_gstin' => [
                'string',
                'nullable',
            ],
            'seg' => [
                'required',
            ],
            'total_adult' => [
                'required',
                'integer',
            ],
            'total_child' => [
                'required',
                'integer',
            ],
            'country_id' => [
                'required',
                'integer',
            ],
            'nationality_id' => [
                'required',
                'integer',
            ],
            'address' => [
                'required',
            ],
            'pincode' => [
                'string',
                'nullable',
            ],
            'id_proof' => [
                'required',
            ],
            'id_proof_number' => [
                'string',
                'required',
            ],
            'room_type_id' => [
                'required',
                'integer',
            ],
            'no_fo_room' => [
                'required',
                'integer',
            ],
           
            'rate_code' => [
                'integer',
                'nullable',
            ],
            'dicount_price' => [
                'integer',
                'nullable',
            ],
            'select_rooms.*' => [
                'integer',
            ],
            'select_rooms' => [
                'required',
                'array',
            ],
            'user_ids_id' => [
                'integer',
                'nullable',
            ],
           
        ];
    }
}