<?php

namespace App\Http\Requests;

use App\Models\Roomtype;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StoreRoomtypeRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('roomtype_create');
    }

    public function rules()
    {
        return [
            'name' => [
                'string',
                'required',
                'unique:roomtypes',
            ],
        ];
    }
}