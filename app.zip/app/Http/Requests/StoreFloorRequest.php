<?php

namespace App\Http\Requests;

use App\Models\Floor;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StoreFloorRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('floor_create');
    }

    public function rules()
    {
        return [
            'name' => [
                'string',
                'required',
            ],
            'select_rooms.*' => [
                'integer',
            ],
            'select_rooms' => [
                'required',
                'array',
            ],
            'select_room_type_id' => [
                'required',
                'integer',
            ],
        ];
    }
}