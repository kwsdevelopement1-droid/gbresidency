<?php

namespace App\Http\Requests;

use App\Models\Checkout;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StoreCheckoutRequest extends FormRequest
{
    // public function authorize()
    // {
    //     return Gate::allows('checkout_create');
    // }

    public function rules()
    {
        return [
            'remining_time' => [
                'string',
                'nullable',
            ],
            'payment_method' => [
                'string',
                'nullable',
            ],
            // 'amount' => [
            //     'required',
            // ],
            'customer_ids_id' => [
                'required',
                'integer',
            ],
        ];
    }
}