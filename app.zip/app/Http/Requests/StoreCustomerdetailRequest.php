<?php

namespace App\Http\Requests;

use App\Models\Customerdetail;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StoreCustomerdetailRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('customerdetail_create');
    }

    public function rules()
    {
        return [
            'customer_ids_id' => [
                'required',
                'integer',
            ],
            'payment_method' => [
                'required',
            ],
            'check_in' => [
                'required',
            ],
            'days' => [
                'integer',
                'required',
            ],
            'check_out' => [
                'required',
            ],
        ];
    }
}