<?php

namespace App\Http\Requests;

use App\Models\AdvanceAmount;
use Gate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Response;

class StoreAdvanceAmountRequest extends FormRequest
{
    public function authorize()
    {
        return Gate::allows('advance_amount_create');
    }

    public function rules()
    {
        return [
            'customer_ids_id' => [
                'required',
                'integer',
            ],
            'advance_amount' => [
                'required',
            ],
            'payment_method' => [
                'required',
            ],
        ];
    }
}