<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class AdminOnly
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, string $permission = null): Response
    {
        $user = Auth::user();

        // Check if user is authenticated
        if (!$user) {
            return redirect()->route('login')->with('error', 'Please login to access this page.');
        }

        // Check if user has Admin role
        $isAdmin = $user->roles->contains('title', 'Admin');

        if (!$isAdmin) {
            abort(403, 'Access Denied - Admin privileges required');
        }

        // If specific permission is provided, check for that permission
        if ($permission && !$user->can($permission)) {
            abort(403, 'Access Denied - Insufficient permissions');
        }

        return $next($request);
    }
}
