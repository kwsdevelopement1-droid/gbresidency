<?php

namespace App\Http\Controllers\Backend;




use App\Http\Controllers\Controller;
use App\Models\AdvanceAmount;
use App\Models\Checkout;
use App\Models\CheckoutOld;
use App\Models\Checkout24_25;
use App\Models\Checkout25_26;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Customer;
use App\Models\Country;
use App\Models\Room;

use App\Models\Gst;
use App\Models\ExtraBed;
use Illuminate\Support\Str;

use App\Models\Floor;
use Gate;
use Illuminate\Support\Facades\DB;



class ReportsController extends Controller
{

    public function OccupancyReportindex()
    {
        $report = null;
        $data = "";
        $from_date =  Carbon::now()->startOfDay();
        $to_date = Carbon::now()->endOfDay();

        // $customers = Customer::whereDate('created_at', $collection_date)->with([
        //     'customerDetail', 'discount_ids', 'checkOut', 'advanceAmount', 'country', 'nationality',
        //     'room_type', 'select_rooms', 'houseguest', 'refund', 'user_ids', 'extraBedsData'
        // ])->orderBy('created_at', 'asc')->get();
        $customers = Customer::getCustomersWithRelatedInfo($from_date, $to_date);
        $reportTime = Carbon::now()->format('d-m-Y H:i:s');

        return view('backend.report_occupancy', compact('customers', 'data', 'from_date', 'to_date', 'reportTime'));
    }
    public function OccupancyReportFillter(Request $request)
    {
        $data = $request->all();

        // Retrieve the customer data
        // $collection_date = Carbon::createFromFormat('d-m-Y', $request->collection_date)->startOfDay()->format('Y-m-d');
        $from_date = Carbon::createFromFormat('d-m-Y', $request->from_date)->startOfDay()->format('Y-m-d H:i:s');
        $to_date = Carbon::createFromFormat('d-m-Y', $request->to_date)->endOfDay()->format('Y-m-d H:i:s');

        // $customers = Customer::whereDate('created_at', $collection_date)->with([
        //     'customerDetail', 'discount_ids', 'checkOut', 'advanceAmount', 'country', 'nationality',
        //     'room_type', 'select_rooms', 'houseguest', 'refund', 'user_ids', 'extraBedsData'
        // ])->orderBy('created_at', 'asc')->get();
        $customers = Customer::getCustomersWithRelatedInfo($from_date, $to_date);
        $reportTime = Carbon::now()->format('d-m-Y H:i:s');

        return view('backend.report_occupancy', compact('customers', 'data', 'from_date', 'to_date', 'reportTime'));
    }


    public function CheckInReportindex()
    {
        $report = null;
        $data = "";
        $from_date =  Carbon::now()->startOfDay();
        $to_date = Carbon::now()->endOfDay();


        // $customers = Customer::whereHas('customerDetail', function ($detailQuery) use ($from_date, $to_date) {
        //     $detailQuery->whereBetween('check_in', [$from_date, $to_date]);
        // })
        // ->where('status', '!=', 8)
        //     ->get();
        
        $customers = Customer::whereHas('customerDetail', function ($q) use ($from_date, $to_date) {
            $q->whereBetween('check_in', [$from_date, $to_date]);
        })
        ->with(['customerDetail','select_rooms'])
        ->get();

        $reportTime = Carbon::now()->format('d-m-Y H:i:s');

        return view('backend.report_checkin', compact('customers', 'data', 'from_date', 'to_date', 'reportTime'));
    }
    public function CheckInReportFillter(Request $request)
    {
        $data = $request->all();
        $from_date = Carbon::createFromFormat('d-m-Y', $request->from_date)->startOfDay()->format('Y-m-d H:i:s');
        $to_date = Carbon::createFromFormat('d-m-Y', $request->to_date)->endOfDay()->format('Y-m-d H:i:s');

        $customers =
            Customer::whereHas('customerDetail', function ($detailQuery) use ($from_date, $to_date) {
                $detailQuery->whereBetween('check_in', [$from_date, $to_date]);
        })->where('status', '!=', 8)
            ->get();
        $reportTime = Carbon::now()->format('d-m-Y H:i:s');

        return view('backend.report_checkin', compact('customers', 'data', 'from_date', 'to_date', 'reportTime'));
    }
    
    
    public function CheckOutReportindex()
    {
        $report = null;
        $data = "";
        $from_date =  Carbon::now()->startOfDay();
        $to_date = Carbon::now()->endOfDay();


        $customers = Customer::whereHas('checkout', function ($detailQuery) use ($from_date, $to_date) {
            $detailQuery->whereBetween('created_at', [$from_date, $to_date]);
        })
            ->get();

        $reportTime = Carbon::now()->format('d-m-Y H:i:s');

        return view('backend.report_checkout', compact('customers', 'data', 'from_date', 'to_date', 'reportTime'));
    }
    public function CheckOutReportFillter(Request $request)
{
    $data = $request->all();
    $from_date = Carbon::createFromFormat('d-m-Y', $request->from_date)->startOfDay()->format('Y-m-d H:i:s');
    $to_date = Carbon::createFromFormat('d-m-Y', $request->to_date)->endOfDay()->format('Y-m-d H:i:s');

    // Get checkouts from the current table
    $currentCheckouts = DB::table('checkouts')
        ->select('id', 'customer_ids_id', 'created_at', 'updated_at')
        ->whereBetween('created_at', [$from_date, $to_date]);

    // Get checkouts from the old checkouts table
    $oldCheckouts = DB::table('checkouts_old')
        ->select('id', 'customer_ids_id', 'created_at', 'updated_at')
        ->whereBetween('created_at', [$from_date, $to_date]);

    // Get checkouts from the checkout24_25 table
    $checkouts24_25 = DB::table('checkouts_24-25')
        ->select('id', 'customer_ids_id', 'created_at', 'updated_at')
        ->whereBetween('created_at', [$from_date, $to_date]);
        
    // Get checkouts from the checkout24_25 table
    $checkouts25_26 = DB::table('checkouts_25-26')
        ->select('id', 'customer_ids_id', 'created_at', 'updated_at')
        ->whereBetween('created_at', [$from_date, $to_date]);

    // Union all checkouts
    $allCheckouts = $oldCheckouts // Starting with old checkouts as in your original
        ->union($currentCheckouts)
        ->union($checkouts24_25)
        ->union($checkouts25_26)
        ->get();

    // Get customers with checkout data
   $customers = Customer::whereIn('id', $allCheckouts->pluck('customer_ids_id'))
    ->with(['checkout', 'checkoutOld', 'checkout24_25','checkout25_26', 'customerDetail', 'select_rooms']) // Eager load relationships
    ->get()
    ->sortBy(function ($customer) {
        // Get the earliest created_at from available checkout relationships
        $checkoutDate = $customer->checkout ? $customer->checkout->created_at : null;
        $checkout24_25Date = $customer->checkout24_25 ? $customer->checkout24_25->created_at : null;
        $checkout25_26Date = $customer->checkout25_26 ? $customer->checkout25_26->created_at : null;
        $checkoutOldDate = $customer->checkoutOld ? $customer->checkoutOld->created_at : null;

        // Return the earliest non-null date, or a fallback if all are null
        if ($checkoutDate) {
            return $checkoutDate;
        } elseif ($checkout24_25Date) {
            return $checkout24_25Date;
        } elseif ($checkout25_26Date) {
            return $checkout25_26Date;
        } elseif ($checkoutOldDate) {
            return $checkoutOldDate;
        }
        return ''; // Fallback for customers with no checkout data
    });

    $reportTime = Carbon::now()->format('d-m-Y H:i:s');

    return view('backend.report_checkout', compact('customers', 'data', 'from_date', 'to_date', 'reportTime'));
}

    public function CreditCardCollectionReportindex()
    {
        $from_date = Carbon::now()->startOfDay();
        $to_date = Carbon::now()->endOfDay();

        // Query Checkout, CheckoutOld, and Checkout24_25
        $checkout = Checkout::whereIn('payment_method', [2, 4])
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();

        $checkoutOld = CheckoutOld::whereIn('payment_method', [2, 4])
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();

        $checkout24_25 = Checkout24_25::whereIn('payment_method', [2, 4])
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();
            
        $checkout25_26 = Checkout25_26::whereIn('payment_method', [2, 4])
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();

        // Merge, sort by created_at, and reindex
        $report = collect()
            ->merge($checkout)
            ->merge($checkoutOld)
            ->merge($checkout24_25)
            ->merge($$checkout25_26)
            ->sortBy(function ($item) {
                return Carbon::parse($item->created_at)->timestamp;
            })
            ->values();

        // AdvanceAmount query (unchanged)
        $advreport = AdvanceAmount::whereIn('payment_method', [2, 4])
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids')
            ->get();

        $reportTime = Carbon::now()->format('d-m-Y H:i:s');
        $data = "";

        return view('backend.report_credit_card_collection', compact('report', 'advreport', 'data', 'from_date', 'to_date', 'reportTime'));
    }

    public function CreditCardCollectionReportFillter(Request $request)
    {
        $data = $request->all();

        // Format dates
        $from_date = Carbon::createFromFormat('d-m-Y', $request->from_date)->startOfDay()->format('Y-m-d H:i:s');
        $to_date = Carbon::createFromFormat('d-m-Y', $request->to_date)->endOfDay()->format('Y-m-d H:i:s');

        // Query Checkout, CheckoutOld, and Checkout24_25
        $checkout = Checkout::whereIn('payment_method', [2, 4])
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();

        $checkoutOld = CheckoutOld::whereIn('payment_method', [2, 4])
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();

        $checkout24_25 = Checkout24_25::whereIn('payment_method', [2, 4])
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();
            
        $checkout25_26 = Checkout25_26::whereIn('payment_method', [2, 4])
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();

        // Merge, sort by created_at, and reindex
        $report = collect()
            ->merge($checkout)
            ->merge($checkoutOld)
            ->merge($checkout24_25)
            ->merge($checkout25_26)
            ->sortBy(function ($item) {
                return Carbon::parse($item->created_at)->timestamp;
            })
            ->values();

        // AdvanceAmount query (unchanged)
        $advreport = AdvanceAmount::whereIn('payment_method', [2, 4])
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids')
            ->get();

        $reportTime = Carbon::now()->format('d-m-Y H:i:s');

        return view('backend.report_credit_card_collection', compact('report', 'advreport', 'data', 'from_date', 'to_date', 'reportTime'));
    }
    
    
   public function CreditBillCollectionReportindex()
    {
        $from_date = Carbon::now()->startOfDay();
        $to_date = Carbon::now()->endOfDay();

        // Query Checkout, CheckoutOld, and Checkout24_25
        $checkout = Checkout::where('payment_method', 3)
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();

        $checkoutOld = CheckoutOld::where('payment_method', 3)
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();

        $checkout24_25 = Checkout24_25::where('payment_method', 3)
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();
            
        $checkout25_26 = Checkout25_26::where('payment_method', 3)
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();

        // Merge, sort by created_at, and reindex
        $report = collect()
            ->merge($checkout)
            ->merge($checkoutOld)
            ->merge($checkout24_25)
            ->merge($checkout25_26) 
            ->sortBy(function ($item) {
                return Carbon::parse($item->created_at)->timestamp;
            })
            ->values();

        $reportTime = Carbon::now()->format('d-m-Y H:i:s');
        $data = "";

        return view('backend.report_credit_bill_collection', compact('report', 'data', 'from_date', 'to_date', 'reportTime'));
    }

    public function CreditBillCollectionReportFillter(Request $request)
    {
        $data = $request->all();

        // Format dates
        $from_date = Carbon::createFromFormat('d-m-Y', $request->from_date)->startOfDay()->format('Y-m-d H:i:s');
        $to_date = Carbon::createFromFormat('d-m-Y', $request->to_date)->endOfDay()->format('Y-m-d H:i:s');

        // Query Checkout, CheckoutOld, and Checkout24_25
        $checkout = Checkout::where('payment_method', 3)
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();

        $checkoutOld = CheckoutOld::where('payment_method', 3)
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();

        $checkout24_25 = Checkout24_25::where('payment_method', 3)
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();
            
        $checkout25_26 = Checkout25_26::where('payment_method', 3)
            ->whereBetween('created_at', [$from_date, $to_date])
            ->with('customer_ids', 'extraBeds')
            ->get();

        // Merge, sort by created_at, and reindex
        $report = collect()
            ->merge($checkout)
            ->merge($checkoutOld)
            ->merge($checkout24_25)
            ->merge($checkout25_26)
            ->sortBy(function ($item) {
                return Carbon::parse($item->created_at)->timestamp;
            })
            ->values();

        $reportTime = Carbon::now()->format('d-m-Y H:i:s');

        return view('backend.report_credit_bill_collection', compact('report', 'data', 'from_date', 'to_date', 'reportTime'));
    }
    
    


    public function DailyCollectionReportindex()
    {
        $report = null;
        $reportOld=null;
        $data = "";
        $from_date =  Carbon::now()->startOfDay();
        $to_date = Carbon::now()->endOfDay();

        $report = Checkout::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();
        $reportOld = CheckoutOld::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();

        $reportTime = Carbon::now()->format('d-m-Y H:i:s');

        return view('backend.report_daily_collection', compact('report','reportOld', 'data', 'from_date', 'to_date', 'reportTime'));
    }
    public function DailyCollectionReportFillter(Request $request)
    {
        $data = $request->all();

        // Retrieve the customer data
        $from_date = Carbon::createFromFormat('d-m-Y', $request->from_date)->startOfDay()->format('Y-m-d H:i:s');
        $to_date = Carbon::createFromFormat('d-m-Y', $request->to_date)->endOfDay()->format('Y-m-d H:i:s');



        $report = Checkout::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();
        $reportOld = CheckoutOld::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();
        $reportTime = Carbon::now()->format('d-m-Y H:i:s');

        return view('backend.report_daily_collection', compact('report', 'reportOld','data', 'from_date', 'to_date', 'reportTime'));
    }

    public function ExcelCollectionReportindex()
    {
        $report = null;
        $reportOld = null;
        $data = "";

        $from_date =  Carbon::now()->startOfDay();
        $to_date = Carbon::now()->endOfDay();

        $report = Checkout::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();
        $reportOld = CheckoutOld::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();
        $report24_25 = Checkout24_25::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();
        $report25_26 = Checkout25_26::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();


        $reportTime = Carbon::now()->format('d-m-Y H:i:s');

        return view('backend.report_excel_collection', compact('report', 'reportOld','report24_25','report25_26','data', 'from_date', 'to_date', 'reportTime'));
    }
    public function ExelCollectionReportFillter(Request $request)
    {
        $data = $request->all();

        // Retrieve the customer data
        $from_date = Carbon::createFromFormat('d-m-Y', $request->from_date)->startOfDay()->format('Y-m-d H:i:s');
        $to_date = Carbon::createFromFormat('d-m-Y', $request->to_date)->endOfDay()->format('Y-m-d H:i:s');

        $report = Checkout::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();
        $reportOld = CheckoutOld::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();
        $report24_25 = Checkout24_25::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();
        $report25_26 = Checkout25_26::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();
        $reportTime = Carbon::now()->format('d-m-Y H:i:s');

        return view('backend.report_excel_collection', compact('report','reportOld','report24_25','report25_26', 'data', 'from_date', 'to_date', 'reportTime'));
    }
    public function HighBalanceReportindex()
    {
        $customers = Customer::where('status', 1)->with([
            'customerDetail', 'discount_ids', 'checkOut', 'advanceAmount', 'country', 'nationality',
            'room_type', 'select_rooms', 'houseguest', 'refund', 'user_ids', 'extraBedsData'
        ])->orderBy('created_at', 'asc')->get();

        $reportTime = Carbon::now()->format('d-m-Y H:i:s');

        return view('backend.report_high_balance', compact('customers', 'reportTime'));
    }



    public function secondUPdf(Request $req, $id)
    {
        // $this->authorize('admin-reports');

        // Enhanced domain detection (same as CheckoutController)
        $currentDomain = request()->getHost();
        $httpHost = request()->getHttpHost();
        $serverName = request()->server('SERVER_NAME') ?? '';
        
        // Check multiple domain indicators to determine the branch
        $isGBResidency = 
            str_contains(strtolower($currentDomain), 'gbresidency') ||
            str_contains(strtolower($httpHost), 'gbresidency') ||
            str_contains(strtolower($serverName), 'gbresidency') ||
            str_contains(strtolower($currentDomain), 'gb-residency') ||
            str_contains(strtolower($httpHost), 'gb-residency') ||
            str_contains(strtolower($serverName), 'gb-residency');
            
        $strPrefix = $isGBResidency ? 'GBR' : 'APL';
        
        // Get the current financial year (same logic as CheckoutController)
        $createdAt = now();
        $currentYear = (int)date('y', strtotime($createdAt));
        if ($createdAt->format('m') >= 4) {
            $currentYear++;
        }
        $previousYear = $currentYear - 1;
        $currentFinancialYear = "{$previousYear}-{$currentYear}";
        
        // Try to find the customer ID - comprehensive search
        $cust_id = null;
        $searchAttempts = [];
        
        // Check if it's an M-series bill (zero amount bills)
        if (Str::contains(Str::lower($id), 'm')) {
            $searchStr = $id;
            $searchAttempts[] = "M-series: {$searchStr}";
            $cust_id = Checkout::where('bill_no', 'LIKE', '%' . $searchStr . '%')->value('customer_ids_id');
        } else {
            // Define all possible search patterns
            $searchPatterns = [
                // Current financial year patterns
                $strPrefix . '/' . $currentFinancialYear . '/' . $id,
                // Previous financial year patterns  
                $strPrefix . '/24-25/' . $id,
                $strPrefix . '/23-24/' . $id,
                $strPrefix . '/22-23/' . $id,
                // Alternative prefix patterns
                ($strPrefix === 'GBR' ? 'APL' : 'GBR') . '/' . $currentFinancialYear . '/' . $id,
                ($strPrefix === 'GBR' ? 'APL' : 'GBR') . '/24-25/' . $id,
                ($strPrefix === 'GBR' ? 'APL' : 'GBR') . '/23-24/' . $id,
            ];
            
            // Search in all tables with all patterns
            $tables = [
                ['model' => Checkout::class, 'name' => 'checkouts'],
                ['model' => CheckoutOld::class, 'name' => 'checkouts_old'],
                ['model' => Checkout24_25::class, 'name' => 'checkouts_24-25'],
            ];
            
            foreach ($tables as $table) {
                if ($cust_id) break;
                
                foreach ($searchPatterns as $pattern) {
                    $searchAttempts[] = "{$table['name']}: {$pattern}";
                    
                    // Try exact match first
                    $cust_id = $table['model']::where('bill_no', $pattern)->value('customer_ids_id');
                    
                    if (!$cust_id) {
                        // Try LIKE match
                        $cust_id = $table['model']::where('bill_no', 'LIKE', '%' . $pattern . '%')->value('customer_ids_id');
                    }
                    
                    if ($cust_id) {
                        $searchAttempts[] = "FOUND in {$table['name']} with pattern: {$pattern}";
                        break 2; // Break out of both loops
                    }
                }
            }
        }

        // If still no customer found, return error with comprehensive debug info
        if (!$cust_id) {
            \Log::error('Duplicate Bill Search Failed - Comprehensive', [
                'bill_id' => $id,
                'domain' => $currentDomain,
                'prefix_used' => $strPrefix,
                'financial_year' => $currentFinancialYear,
                'search_attempts' => $searchAttempts,
                'is_m_series' => Str::contains(Str::lower($id), 'm')
            ]);
            
            return response()->json([
                'error' => 'No records found for bill number: ' . $id,
                'debug' => [
                    'searched_patterns' => $searchAttempts,
                    'prefix' => $strPrefix,
                    'financial_year' => $currentFinancialYear,
                    'tables_searched' => ['checkouts', 'checkouts_old', 'checkouts_24-25'],
                    'suggestion' => 'Try using the radio buttons (OLD or 24-25) for older bills'
                ]
            ], 404);
        }

        $customer = Customer::with([
            'customerDetail', 'discount_ids', 'checkOut', 'checkOutOld','Checkout24_25','advanceAmount', 'country', 'nationality',
            'room_type', 'select_rooms', 'extraBedsData',
        ])->find($cust_id);

        if (!$customer) {
            return response()->json(['error' => 'Customer not found for bill number: ' . $id], 404);
        }

        $gst = Gst::withTrashed()->latest()->first();
        $extra_count1 = ExtraBed::where('guest_id', $id)->count();

        return view('backend.check_out_bill_duplicate', compact('customer', 'gst'));
    }

    public function secondUPdfOld(Request $req, $id)
    {
        // $this->authorize('admin-reports');

        $strPrefix = 'GBR'; // Simplified prefix since both conditions were the same
        
        // Enhanced search logic
        $searchStr = Str::contains(Str::lower($id), 'm') ? $id : '%' . $id . '%';

        // Search with multiple patterns
        $cust_id = CheckoutOld::where(function($query) use ($id, $searchStr, $strPrefix) {
                $query->where('bill_no', 'LIKE', $searchStr)
                    ->orWhere('bill_no', 'LIKE', '%' . str_replace('/', '-', $id) . '%')
                    ->orWhere('bill_no', 'LIKE', $strPrefix . '/24-25/' . $id . '%');
            })
            ->value('customer_ids_id');

        if (!$cust_id) {
            return response()->json([
                'error' => 'No records found for bill number: ' . $id,
                'suggestion' => 'Please check the bill number or try a different search term.'
            ], 404);
        }

        $customer = Customer::with([
            'customerDetail', 'discount_ids', 'checkOutOld', 'advanceAmount', 
            'country', 'nationality', 'room_type', 'select_rooms', 'extraBedsData',
        ])->find($cust_id);

        if (!$customer) {
            return response()->json(['error' => 'Customer not found for bill number: ' . $id], 404);
        }

        $gst = Gst::withTrashed()->latest()->first();
        return view('backend.check_out_bill_duplicate_old', compact('customer', 'gst'));
    }

    
    
    public function secondUPdf24_25(Request $req, $id)
    {
        // $this->authorize('admin-reports');

        $strPrefix = 'GBR'; // Simplified prefix
        
        // Enhanced search logic
        $searchStr = Str::contains(Str::lower($id), 'm') ? $id : '%' . $id . '%';

        // Search with multiple patterns
        $cust_id = Checkout24_25::where(function($query) use ($id, $searchStr, $strPrefix) {
                $query->where('bill_no', 'LIKE', $searchStr)
                    ->orWhere('bill_no', 'LIKE', '%' . str_replace('/', '-', $id) . '%')
                    ->orWhere('bill_no', 'LIKE', $strPrefix . '/24-25/' . $id . '%');
            })
            ->value('customer_ids_id');

        if (!$cust_id) {
            return response()->json([
                'error' => 'No records found for bill number: ' . $id,
                'suggestion' => 'Please check the bill number or try a different search term.'
            ], 404);
        }

        $customer = Customer::with([
            'customerDetail', 'discount_ids', 'Checkout24_25', 'advanceAmount', 
            'country', 'nationality', 'room_type', 'select_rooms', 'extraBedsData',
        ])->find($cust_id);

        if (!$customer) {
            return response()->json(['error' => 'Customer not found for bill number: ' . $id], 404);
        }

        $gst = Gst::withTrashed()->latest()->first();
        return view('backend.check_out_bill_duplicate_24_25', compact('customer', 'gst'));
    }
    
        
        public function secondUPdf25_26(Request $req, $id)
        {
            // $this->authorize('admin-reports');
    
            $strPrefix = 'GBR'; // Simplified prefix
            
            // Enhanced search logic
            $searchStr = Str::contains(Str::lower($id), 'm') ? $id : '%' . $id . '%';
    
            // Search with multiple patterns
            $cust_id = Checkout25_26::where(function($query) use ($id, $searchStr, $strPrefix) {
                    $query->where('bill_no', 'LIKE', $searchStr)
                        ->orWhere('bill_no', 'LIKE', '%' . str_replace('/', '-', $id) . '%')
                        ->orWhere('bill_no', 'LIKE', $strPrefix . '/25-26/' . $id . '%');
                })
                ->value('customer_ids_id');
    
            if (!$cust_id) {
                return response()->json([
                    'error' => 'No records found for bill number: ' . $id,
                    'suggestion' => 'Please check the bill number or try a different search term.'
                ], 404);
            }
    
            $customer = Customer::with([
                'customerDetail', 'discount_ids', 'Checkout25_26', 'advanceAmount', 
                'country', 'nationality', 'room_type', 'select_rooms', 'extraBedsData',
            ])->find($cust_id);
    
            if (!$customer) {
                return response()->json(['error' => 'Customer not found for bill number: ' . $id], 404);
            }
    
            $gst = Gst::withTrashed()->latest()->first();
            return view('backend.check_out_bill_duplicate_25_26', compact('customer', 'gst'));
        }


    public function GetRoomStatus()
    {


        $info = DB::table('floors')->where('floors.deleted_at', null)
            ->select('floors.id', 'floors.name')
            ->selectRaw('COUNT(rooms.id) AS total_rooms')
            ->selectRaw('SUM(CASE WHEN rooms.status = 0 THEN 1 ELSE 0 END) AS available_rooms')
            ->selectRaw('SUM(CASE WHEN rooms.status = 1 THEN 1 ELSE 0 END) AS blocked_rooms')
            ->selectRaw('SUM(CASE WHEN rooms.status = 2 THEN 1 ELSE 0 END) AS dirty_rooms')
            ->leftJoin('floor_room', 'floors.id', '=', 'floor_room.floor_id')
            ->leftJoin('rooms', 'floor_room.room_id', '=', 'rooms.id')
            ->groupBy('floors.id', 'floors.name')
            ->get();

        foreach ($info as $floor) {
            $floor->vacant_rooms = $floor->total_rooms - ($floor->available_rooms + $floor->blocked_rooms + $floor->dirty_rooms);
            $floor->total = $floor->available_rooms + $floor->blocked_rooms + $floor->dirty_rooms + $floor->vacant_rooms;
        }

        // $floor
        // $floors = Floor::with(['select_rooms', 'select_room_type'])->where('select_room_type_id', 2)->get();
        // return  $floors;

        $customers = Customer::with('room_type', 'extraBedsData')->where('status', 1)->whereHas('select_rooms', function ($query) {
            $query->havingRaw('COUNT(*) <= 1');
        })->with('select_rooms:id')->get();

        // Assuming $customers is an array containing customers' details
        $roomTypeIdCounts = [];
        $houseGuestCounts = [];
        $forignGuestCounts = [];
        $forignGuestPax = [];
        $guestArray = [];

        foreach ($customers as $customer) {
            $roomTypeId = $customer->room_type_id;
            $count = count($customer['select_rooms']);
            $roomTypeIdCounts[$roomTypeId] = ($roomTypeIdCounts[$roomTypeId] ?? 0) + $count;
            // $houseGuestCounts[$roomTypeId] = ($houseGuestCounts[$roomTypeId] ?? 0) + ($customer->rate_code == '2') ? $count : 0;
            if ($customer->rate_code == '2') {
                $houseGuestCounts[$roomTypeId] = ($houseGuestCounts[$roomTypeId] ?? 0) +  $count;
                array_push($guestArray, $customer->room_type_id);
            }

            if ($customer->seg == '2') {
                $forignGuestCounts[$roomTypeId] =  ($forignGuestCounts[$roomTypeId] ?? 0) +  $count;
                $pax = $customer->total_adult + count($customer->extra_beds_data ?? []);
                if ($customer->total_adult > $customer->room_type->max_person) {
                    $pax = $customer->room_type->max_person +
                        count($customer->extra_beds_data ?? []);
                }

                $forignGuestPax[$roomTypeId] = ($forignGuestPax[$roomTypeId] ?? 0) + $pax;

                // $forignGuestPax[$roomTypeId] += ;
            }
        }


        $booked = $customers->pluck('room_type_id')->toArray();

        $customersWithMultipleRooms = Customer::where('status', 1)->whereHas('select_rooms', function ($query) {
            $query->havingRaw('COUNT(*) >= 2');
        })->with('select_rooms:id')->get();
        $multiple_book = $customersWithMultipleRooms->flatMap(function ($customer) {
            return $customer->select_rooms->pluck('id');
        })->unique()->toArray();

        foreach ($customersWithMultipleRooms as $customer) {
            $roomTypeId = $customer->room_type_id;
            $count = count($customer['select_rooms']);
            $roomTypeIdCounts[$roomTypeId] = ($roomTypeIdCounts[$roomTypeId] ?? 0) + $count;

            // $forignGuestCounts[$roomTypeId] = ($forignGuestCounts[$roomTypeId] ?? 0) + ($customer->seg == '2') ? $count : 0;
            if ($customer->rate_code == '2') {
                $houseGuestCounts[$roomTypeId] = ($houseGuestCounts[$roomTypeId] ?? 0) +  $count;
                array_push($guestArray, $customer->room_type_id);
            }
            if ($customer->seg == '2') {
                $forignGuestCounts[$roomTypeId] =  ($forignGuestCounts[$roomTypeId] ?? 0) +  $count;
                $pax = $customer->total_adult + count($customer->extra_beds_data ?? []);
                if ($customer->total_adult > $customer->room_type->max_person) {
                    $pax = $customer->room_type->max_person +
                        count($customer->extra_beds_data ?? []);
                }

                $forignGuestPax[$roomTypeId] = ($forignGuestPax[$roomTypeId] ?? 0) + $pax;

                // $forignGuestPax[$roomTypeId] += ;
            }

            // $forignGuestCounts[$roomTypeId] += ($customer->seg == '2') ? 1 : 0;
        }

        //  return $multiple_book;

        $floors = $info;

        /* return response()->json([
            'floors' => $info,
            'counts' => $roomTypeIdCounts,
            'houseGuest' => $houseGuestCounts,
            'foreignGuest' => $forignGuestCounts,
            'foreignPax' => $forignGuestPax,
            // 'multiple_book' => count($multiple_book),
            // 'single' => count($booked),
            // 'booked' => $booked,
            // 'cust' => $customers,

        ]); */

        return view('backend.report_room_status', compact('floors', 'roomTypeIdCounts', 'houseGuestCounts', 'forignGuestCounts', 'forignGuestPax', 'guestArray'));
    }


    public function GuestFolioIndex()
    {

        $message = "";

        return view('backend.guest_folio', compact(
            'message'
        ));
    }

    public function GuestFolioFilter(Request $request)
    {

        $room_no = $request->input('room_no');

        $room = Room::where('name', $room_no)->get()->first();

        $customer = Customer::where('status', 1)->with(['customerDetail', 'advanceAmount', 'country', 'nationality', 'room_type', 'select_rooms', 'extraBedsData'])
            ->whereHas('select_rooms', function ($query) use ($room) {
                $query->where('id', $room->id);
            })
            ->first();



        if ($customer) {
            // return response()->json(['message' => 'Data received successfully', 'data' => $customer]);
            $gst = Gst::withTrashed()->latest()->first();
            return view('backend.guest_folio_report', compact('customer', 'gst'));
        } else {
            $message = "No Data Found";

            return view('backend.guest_folio', compact(
                'message'
            ));
        }
    }
}
