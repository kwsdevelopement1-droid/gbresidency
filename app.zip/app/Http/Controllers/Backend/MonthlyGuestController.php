<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyAdvanceAmountRequest;
use App\Http\Requests\StoreAdvanceAmountRequest;
use App\Http\Requests\UpdateAdvanceAmountRequest;
use App\Models\AdvanceAmount;
use App\Models\Customer;
use App\Models\Country;
use App\Models\Floor;
use App\Models\Room;
use App\Models\Gst;
use App\Models\Discount;
use App\Models\MonthlyGuests;
use App\Models\Roomtype;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class MonthlyGuestController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('advance_amount_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $monthlyGuests = MonthlyGuests::whereHas('customer_ids', function ($query) {
            $query->where('status', 1);
        })->orderBy('id', 'desc')->get();


        /*  $monthlyGuests = MonthlyGuests::with(['customer_ids' => function ($query) {
            $query->where('status', 1);
        }])->orderBy('id', 'desc')->get(); */

        return view('backend.monthly_guest.index', compact('monthlyGuests'));
    }

    public function create()
    {
        abort_if(Gate::denies('advance_amount_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');



        return view('backend.monthly_guest.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'customer_ids_id' => 'required',
            'rate' => 'required',
            'room_id' => 'required',
            'room_name' => 'required',

        ], [
            'customer_ids_id.unique' => 'Monthly Customer already exist'
        ]);

        $data = $request->except('_token');
        // Mass assigment
        MonthlyGuests::create($data);


        return redirect()->route('backend.monthly-guests.index')->withSuccess('Monthly Guest has been created successfully!');;
    }

    public function edit(string $id)
    {
        abort_if(Gate::denies('advance_amount_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $monthlyGuests = MonthlyGuests::find($id);
        $monthlyGuests->load('customer_ids');
        // dd($monthlyGuests);

        return view('backend.monthly_guest.edit', compact('monthlyGuests'));
    }

    public function update(Request $request, string $id)
    {
        $request->validate([
            'customer_ids_id' => 'required',
            'rate' => 'required',
            'room_id' => 'required',
            'room_name' => 'required',

        ]);

        $data = $request->except('_token');
        $guest = MonthlyGuests::find($id);

        $guest->update($data);

        return redirect()->route('backend.monthly-guests.index')->withSuccess('Monthly Guest has been Updated successfully!');;;
    }

    public function show(string $id)
    {
        // abort_if(Gate::denies('advance_amount_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $monthlyguest = MonthlyGuests::find($id);
        dd($monthlyguest);
        return view('admin.advanceAmounts.show', compact('advanceAmount'));
    }

    public function destroy(string $id)
    {
        abort_if(Gate::denies('advance_amount_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $guest = MonthlyGuests::find($id);
        $guest->delete();

        return back();
    }

    public function massDestroy(MassDestroyAdvanceAmountRequest $request)
    {
        $advanceAmounts = AdvanceAmount::find(request('ids'));

        foreach ($advanceAmounts as $advanceAmount) {
            $advanceAmount->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
