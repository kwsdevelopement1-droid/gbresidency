<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\onlinerooms; 
use App\Models\onlinereservation; 
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage; 
use App\Models\blockcheckindate;
class OnlinereservationController extends Controller
{
    public function Roomlistindex(){
        $rooms= onlinerooms::all();
        return view('backend.online_reservation.index',compact('rooms'));
    }
    
     public function createroom(){
        
        return view('backend.online_reservation.Create');
    }
    
    
    
  public function storeroom(Request $request)
{
    // dd($request);
     try {
        $validatedData = $request->validate([
            'roomname' => 'required|string|max:255',
            'roomprice' => 'required|numeric',
            'reservationprice' => 'required|numeric',
            'overview' => 'required|string',
            'singleImageInput' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp',
            'galleryImageInput.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp',
        ], [
            'singleImageInput.image' => 'The single image must be an image file.',
            'singleImageInput.mimes' => 'The single image must be a file of type: jpeg, png, jpg, gif, webp.',
            'singleImageInput.max' => 'The single image may not be greater than 10 MB.',
            'galleryImageInput.*.image' => 'Each gallery image must be an image file.',
            'galleryImageInput.*.mimes' => 'Each gallery image must be a file of type: jpeg, png, jpg, gif, webp.',
            'galleryImageInput.*.max' => 'Each gallery image may not be greater than 15 MB.',
        ]);

        // Proceed with your logic here if validation passes
        // For example: save data, process files, etc.

    } catch (\Illuminate\Validation\ValidationException $e) {
        // Capture and handle validation errors
        return redirect()->back()->withErrors($e->errors())->withInput();
    }

    $room = new onlinerooms();
    $room->roomname = $request->roomname;
    $room->roomprice = $request->roomprice;
    $room->reservationprice = $request->reservationprice;
    $room->no_tax = $request->no_tax;
    $room->overview = $request->overview;

    // Store single image
    if ($request->hasFile('singleImageInput')) {
        $singleImage = $request->file('singleImageInput');
        $singleImageName = 'single_' . time() . '_' . $singleImage->getClientOriginalName();
        $singleImage->storeAs('public/siteimages', $singleImageName);
        $room->single_image = $singleImageName;
    }

    // Store gallery images
    $galleryImageNames = [];
    if ($request->hasFile('galleryImageInput')) {
        foreach ($request->file('galleryImageInput') as $key => $galleryImage) {
            $galleryImageName = 'gallery_' . time() . '_' . $key . '_' . $galleryImage->getClientOriginalName();
            $galleryImage->storeAs('public/siteimages', $galleryImageName);
            $galleryImageNames[] = $galleryImageName;
        }
    }

    // Assign gallery image names to corresponding columns
    for ($i = 0; $i < count($galleryImageNames); $i++) {
        $room->{"galleryimg_" . ($i + 1)} = $galleryImageNames[$i];
    }

    $room->save();

    return redirect()->back()->with('success', 'Room created successfully.');
}

public function roomdestroy($id)
{
    
    $room = onlinerooms::findOrFail($id);
    $room->delete();
    return redirect()->back()->with('success', 'Room deleted successfully.');
}



public function editroom(onlinerooms $room)
{
    $galleryImages = [
        'galleryimg_1' => $room->galleryimg_1,
        'galleryimg_2' => $room->galleryimg_2,
        'galleryimg_3' => $room->galleryimg_3,
        'galleryimg_4' => $room->galleryimg_4,
        'galleryimg_5' => $room->galleryimg_5,
    ];
    return view('backend.online_reservation.edit', compact('room','galleryImages'));
}




public function updateonlineroom(Request $request, $id)
    {


      try {
        $validatedData = $request->validate([
            'roomname' => 'required|string|max:255',
            'roomprice' => 'required|numeric',
            'reservationprice' => 'required|numeric',
            'overview' => 'required|string',
            'singleImageInput' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp',
            'galleryImageInput.*' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp',
        ], [
            'singleImageInput.image' => 'The single image must be an image file.',
            'singleImageInput.mimes' => 'The single image must be a file of type: jpeg, png, jpg, gif, webp.',
            'singleImageInput.max' => 'The single image may not be greater than 10 MB.',
            'galleryImageInput.*.image' => 'Each gallery image must be an image file.',
            'galleryImageInput.*.mimes' => 'Each gallery image must be a file of type: jpeg, png, jpg, gif, webp.',
            'galleryImageInput.*.max' => 'Each gallery image may not be greater than 15 MB.',
        ]);

        // Proceed with your logic here if validation passes
        // For example: save data, process files, etc.

    } catch (\Illuminate\Validation\ValidationException $e) {
        // Capture and handle validation errors
        return redirect()->back()->withErrors($e->errors())->withInput();
    }



        $room = onlinerooms::find($id);
        $room->roomname = $request->roomname;
        $room->roomprice = $request->roomprice;
        $room->reservationprice = $request->reservationprice;
        $room->no_tax = $request->no_tax;
        $room->overview = $request->overview;

        // Store single image
        if ($request->hasFile('singleImageInput')) {
            $singleImage = $request->file('singleImageInput');
            $singleImageName = 'single_' . time() . '_' . $singleImage->getClientOriginalName();
            $singleImage->storeAs('public/siteimages', $singleImageName);
            $room->single_image = $singleImageName;
        }

        // Store gallery images
        $galleryImageNames = [];
        if ($request->hasFile('galleryImageInput')) {
            foreach ($request->file('galleryImageInput') as $key => $galleryImage) {
                $galleryImageName = 'gallery_' . time() . '' . $key . '' . $galleryImage->getClientOriginalName();
                $galleryImage->storeAs('public/siteimages', $galleryImageName);
                $galleryImageNames[] = $galleryImageName;
            }
        }

        // Assign gallery image names to corresponding columns
        for ($i = 0; $i < count($galleryImageNames); $i++) {
            $room->{"galleryimg_" . ($i + 1)} = $galleryImageNames[$i];
        }

        $room->save();

        return redirect()->back()->with('success', 'Room updated successfully.');
    }

   public function OnlinePaymentindex(){
        $rooms= onlinereservation::where('status','1')
        ->orderBy('created_at', 'DESC')
        ->get();
        return view('backend.online_payment_registeration.index',compact('rooms'));
    }
    
    
    
    
    public function approve($id)
{
    $booking = onlinereservation::findOrFail($id);
    $booking->status = 2; 
    $booking->save();

    
    return redirect()->back()->with('success', 'Booking Approved successfully.');
}

public function cancel($id)
{
    $booking = onlinereservation::findOrFail($id);
    $booking->status = 3; 
    $booking->save();

    
    return redirect()->back()->with('success', 'Booking Cancelled successfully.');
}


public function Onlineapprovedlist()
{
     $rooms = onlinereservation::whereIn('status', [2, 4])
    ->orderBy('created_at', 'DESC')
    ->get();
        return view('backend.online_payment_registeration.approved_list',compact('rooms'));
}


 public function onlineblockcheckin(){
     
     $blocks = blockcheckindate::all();
        
        return view('backend.block_checkin.index',compact('blocks'));
    }
    
    public function createblockdate(){
        
        return view('backend.block_checkin.Create');
    }
    
    public function storeblockdate(Request $req){
        
        $model = new blockcheckindate();
        $model->reason = $req->input('reason');
        $model->blockdate = $req->input('blockdate');
        $model->save();
        
        
        return redirect()->route('backend.onlineblockcheckin');
        
    }
    
    public function destroy($id)
{
    
    blockcheckindate::destroy($id);

    return redirect()->back()->with('success', 'Block deleted successfully.');
}



}
