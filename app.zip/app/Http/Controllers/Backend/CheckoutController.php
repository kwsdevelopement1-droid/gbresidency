<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyCheckoutRequest;
use App\Http\Requests\StoreCheckoutRequest;
use App\Http\Requests\UpdateCheckoutRequest;
use App\Models\Checkout;
use App\Models\Customer;
use App\Models\ExtraBed;
use App\Models\Room;
use Illuminate\Support\Str;

use Gate;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckoutController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('checkout_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $checkouts = Checkout::with(['customer_ids'])->get();

        return view('admin.checkouts.index', compact('checkouts'));
    }

    public function create()
    {
        // abort_if(Gate::denies('checkout_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $customer_ids = Customer::pluck('guest_type', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('admin.checkouts.create', compact('customer_ids'));
    }

    public function store(StoreCheckoutRequest $request)
    {
        $checkout = Checkout::create($request->all());

        // Enhanced domain detection
        $currentDomain = request()->getHost();
        $httpHost = request()->getHttpHost();
        $serverName = request()->server('SERVER_NAME') ?? '';
        
        // Check multiple domain indicators to determine the branch
        $isGBResidency = 
            str_contains(strtolower($currentDomain), 'gbresidency') ||
            str_contains(strtolower($httpHost), 'gbresidency') ||
            str_contains(strtolower($serverName), 'gbresidency') ||
            str_contains(strtolower($currentDomain), 'gb-residency') ||
            str_contains(strtolower($httpHost), 'gb-residency') ||
            str_contains(strtolower($serverName), 'gb-residency');
            
        $strPrefix = $isGBResidency ? 'GBR' : 'APL';

        // Log the domain information for debugging
        \Log::info('Bill Generation', [
            'current_domain' => $currentDomain,
            'http_host' => $httpHost,
            'server_name' => $serverName,
            'is_gb_residency' => $isGBResidency,
            'prefix_used' => $strPrefix,
            'request_data' => $request->except(['_token', 'password']) // Exclude sensitive data
        ]);

        // Get the current financial year
        $createdAt = now();
        $year = (int)$createdAt->format('y');

        if ($createdAt->format('m') >= 4) {
            $financialYear = $year . '-' . ($year + 1);
        } else {
            $financialYear = ($year - 1) . '-' . $year;
        }

        if ($checkout->total_amount != 0.00) {
            // First, try to get the highest bill number for the current prefix and financial year
            // $bills = Checkout::where('bill_no', 'LIKE', "GBR/{$financialYear}/%")
            $bills = Checkout::where('bill_no', 'LIKE', "{$strPrefix}/{$financialYear}/%")
                ->where('total_amount', '!=', 0)
                ->pluck('bill_no');

            // Find the highest bill number
            $maxNumber = 0;
            foreach ($bills as $bill) {
                $parts = explode('/', $bill);
                if (count($parts) === 3) {
                    $number = (int)end($parts);
                    $maxNumber = max($maxNumber, $number);
                }
            }
            
            // If no bills found for GBR, check APL as fallback (for migration purposes)
            if ($maxNumber === 0) {
                $aplBills = Checkout::where('bill_no', 'LIKE', "APL/{$financialYear}/%")
                    ->where('total_amount', '!=', 0)
                    ->pluck('bill_no');
                
                foreach ($aplBills as $bill) {
                    $parts = explode('/', $bill);
                    if (count($parts) === 3) {
                        $number = (int)end($parts);
                        $maxNumber = max($maxNumber, $number);
                    }
                }
            }
            
            $bill_no = $maxNumber + 1;
            $billNumber = "GBR/{$financialYear}/{$bill_no}";
        } else {
            // For zero amount bills (M series) - check both M and MGBR prefixes for continuity
            $mBills = Checkout::where(function($query) {
                    $query->where('bill_no', 'LIKE', 'M%')
                          ->where('bill_no', 'NOT LIKE', '%/%'); // Exclude regular bills with slashes
                })
                ->where('total_amount', '==', 0)
                ->pluck('bill_no');

            $maxMNumber = 0;
            foreach ($mBills as $bill) {
                // Extract number from both 'M32' and 'MGBR32' formats
                if (preg_match('/M(?:GBR)?(\d+)/', $bill, $matches)) {
                    $number = (int)$matches[1];
                    $maxMNumber = max($maxMNumber, $number);
                }
            }
            
            $bill_no = $maxMNumber + 1;
            // Use simple M prefix for continuity (M32 → M33)
            $billNumber = "M{$bill_no}";
        }

        // Update the checkout with the generated bill number
        $checkout->update(['bill_no' => $billNumber]);

        // Update customer status and room status
        Customer::find($request->customer_ids_id)->update([
            'status' => 2,
            'total_amount' => $request->total_amount,
            'payment_method' => $request->payment_method,
        ]);
        
        Room::whereIn('id', $request->room_ids)->update(['status' => 2]);

        // Process extra beds if any
        $extraIds = json_decode($request->extraIds ?? '[]');
        $extraTotalCost = json_decode($request->extraTotalCost ?? '[]');
        $extraDays = json_decode($request->extraDays ?? '[]');
        $extraCheckOutTimeVal = json_decode($request->extraCheckOutTime ?? '[]', true);

        for ($i = 0; $i < count($extraIds); $i++) {
            ExtraBed::find($extraIds[$i])->update([
                'checkin_status' => 1,
                'checkout_date' => Carbon::parse($extraCheckOutTimeVal[$i])->format('Y-m-d H:i:s'),
                'totalcost' => $extraTotalCost[$i],
                'totaldays' => $extraDays[$i],
            ]);
        }
        
        // Use tariff and extra_person_cost values directly from frontend calculation
        $tariff = (float)($request->tariff ?? 0);
        $extraPersonCost = (float)($request->extra_person_cost ?? 0);
        
        // Debug logging
        \Log::info('Checkout values received', [
            'tariff_raw' => $request->tariff,
            'extra_person_cost_raw' => $request->extra_person_cost,
            'tariff_parsed' => $tariff,
            'extra_person_cost_parsed' => $extraPersonCost,
            'total_amount' => $request->total_amount
        ]);

        $checkout->update([
            'tariff' => $tariff,
            'extra_person_cost' => $extraPersonCost,
        ]);


        return response()->json([
            'message' => 'Check-Out Updated successfully', 
            'bill_no' => $billNumber,
            'branch' => $strPrefix,
            'debug' => [
                'domain' => $currentDomain,
                'financial_year' => $financialYear,
                'bill_count' => count($bills ?? [])
            ]
        ]);
    }

    public function edit(Checkout $checkout)
    {
        abort_if(Gate::denies('checkout_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $customer_ids = Customer::pluck('guest_type', 'id')->prepend(trans('global.pleaseSelect'), '');

        $checkout->load('customer_ids');

        return view('admin.checkouts.edit', compact('checkout', 'customer_ids'));
    }

    public function update(UpdateCheckoutRequest $request, Checkout $checkout)
    {
        $checkout->update($request->all());
        Customer::find($request->customer_ids_id)->update(['status' => 2]);
        Room::whereIn('id', $request->room_ids)->update(['status' => 2]);

        return redirect()->route('admin.checkouts.index');
    }

    public function show(Checkout $checkout)
    {
        abort_if(Gate::denies('checkout_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $checkout->load('customer_ids');

        return view('admin.checkouts.show', compact('checkout'));
    }

    public function destroy(Checkout $checkout)
    {
        abort_if(Gate::denies('checkout_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $checkout->delete();

        return back();
    }

    public function massDestroy(MassDestroyCheckoutRequest $request)
    {
        $checkouts = Checkout::find(request('ids'));

        foreach ($checkouts as $checkout) {
            $checkout->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
