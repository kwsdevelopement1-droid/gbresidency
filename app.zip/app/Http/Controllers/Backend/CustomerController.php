<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyCustomerRequest;
use App\Http\Requests\StoreCustomerRequest;
use App\Http\Requests\UpdateCustomerRequest;
use App\Models\Country;
use App\Models\Customer;
use App\Models\Floor;
use App\Models\Room;
use App\Http\Requests\StoreAdvanceAmountRequest;
use App\Models\AdvanceAmount;
use App\Models\Customerdetail;
use App\Models\ExtraBed;
use App\Models\Houseguest;
use Gate;
use Carbon\Carbon;
use GuzzleHttp\Promise\Create;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CustomerController extends Controller
{


    public function store(StoreCustomerRequest $request)
    {
        // return $request->select_rooms;
        $data=$request->all();
        $data['check_in'] = Carbon::createFromFormat('d-m-Y H:i', $request->check_in)->format('Y-m-d H:i:s');

        // $data['check_in'] = Carbon::createFromFormat('m/d/Y h:i A', $request->check_in)->format('Y-m-d H:i:s');
        // $data['check_in'] = Carbon::now()->format('Y-m-d H:i:s');
        $data['check_out'] = Carbon::createFromFormat('d-m-Y H:i', $request->check_out)->format('Y-m-d H:i:s');
        $data['status'] = 1;
        if ($request->country_id != 95) {
            if ($request->visa_exp_date !== null) {
                $data['visa_exp_date'] = Carbon::createFromFormat('d-m-Y', $request->visa_exp_date)->format('Y-m-d');
            }

            if ($request->pr_exp_date !== null) {
                $data['pr_exp_date'] = Carbon::createFromFormat('d-m-Y', $request->pr_exp_date)->format('Y-m-d');
            }
        }

        $customer = Customer::create($data);

        $customer->select_rooms()->sync($request->input('select_rooms', []));

        $data['customer_ids_id'] = $customer->id;
        if ($request->rate_code != 2) {
            if (($request->max_person * $request->no_fo_room) < $request->total_adult) {
                $no_of_extra_person = $request->total_adult - ($request->max_person * $request->no_fo_room);
                $extraData['guest_id'] = $customer->id;
                $extraData['room_id'] = $request->select_rooms[0];
                $extraData['room_number'] = $request->select_rooms[0];
                $extraData['price'] = $request->extra_price;
                $extraData['checkin_date'] = Carbon::createFromFormat('d-m-Y H:i', $request->check_in)->format('Y-m-d H:i:s');
                $extraData['totalcost'] = $request->extra_price * $request->days;
                $extraData['totaldays'] = $request->days;

                for (
                    $i = 0;
                    $i < $no_of_extra_person;
                    $i++
                ) {
                    ExtraBed::Create($extraData);
                }
            }
        }

        $customerdetail = Customerdetail::create($data);
        if($request->rate_code==2){
        $houseguest = Houseguest::create($data);
        }

        return response()->json(['message' => 'Check In Successfully added','data' => $customer]);
    }
    public function advancestore(StoreAdvanceAmountRequest $request)
    {
        $advanceAmount = AdvanceAmount::create($request->all());

        return response()->json(['message' => 'Check In Successfully added','data' => $advanceAmount]);
    }

    public function edit(Customer $customer)
    {
        abort_if(Gate::denies('customer_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $select_rooms = Room::pluck('name', 'id');

        $customer->load('country', 'nationality', 'room_type', 'select_rooms');

        return view('backend.customers.edit', compact('countries', 'customer', 'nationalities', 'room_types', 'select_rooms'));
    }

    public function update(UpdateCustomerRequest $request, Customer $customer)
    {
        $data = $request->all();
        // return  $data;
        $data['check_in'] = Carbon::createFromFormat('d-m-Y H:i', $request->check_in)->format('Y-m-d H:i:s');

        $data['check_out'] = Carbon::createFromFormat('d-m-Y H:i', $request->check_out)->format('Y-m-d H:i:s');

        $customer->update($data);

        return response()->json(['message' => 'Check In Successfully Updated','data' => $customer]);

    }

    public function show(Customer $customer)
    {
        abort_if(Gate::denies('customer_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $customer->load('country', 'nationality', 'room_type', 'select_rooms');

        return view('backend.customers.show', compact('customer'));
    }

    public function destroy(Customer $customer)
    {
        abort_if(Gate::denies('customer_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $customer->delete();

        return back();
    }

    public function massDestroy(MassDestroyCustomerRequest $request)
    {
        $customers = Customer::find(request('ids'));

        foreach ($customers as $customer) {
            $customer->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
