<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyFloorRequest;
use App\Http\Requests\StoreFloorRequest;
use App\Http\Requests\UpdateFloorRequest;
use App\Models\Country;
use App\Models\Customer;
use App\Models\Floor;
use App\Models\Room;
use App\Models\Gst;
use App\Models\Discount;
use App\Models\Roomtype;
use NumberFormatter;
use App\Models\RoomStatus;
use App\Models\ModificationCheckin;
use setasign\Fpdi\Fpdi;
use setasign\Fpdi\Fpdf\Fpdf;
use Gate;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckInController extends Controller
{


    public function secondUPdf($id)
    {
 // Path to the existing PDF file
 $customer = Customer::with(['customerDetail','country','nationality', 'room_type', 'select_rooms'])
 ->find($id);
 $lastCustomerDetail = $customer->customerDetail->last();
 $payment_method = '';
 
 foreach (Customer::PAYMENT_METHOD_SELECT as $key => $label) {
    if ($key == $lastCustomerDetail->payment_method) {
        // Match found, you can perform further operations here
        $payment_method = $label;
    }
}

$roomNames = ''; // Initialize an empty string to store room names

// Access the "select_rooms" relation and then loop through each related room
foreach ($customer->select_rooms as $room) {
    // Append the name of each room to the existing value of $roomNames
    $roomNames .= $room->name . ', '; // Concatenate room names with comma separator
}

// Remove the trailing comma and space from the end of the string
$roomNames = rtrim($roomNames, ', ');

// Now $roomNames will contain a comma-separated list of all room names
// echo $roomNames;



    
 if (!$customer) {
     // Handle the case when the employee is not found
     return response()->json(['error' => 'Employee not found'], 404);
 }
 
 $pdfPath = public_path('pdf/Apl_second_bill.pdf');
 
 if (!file_exists($pdfPath)) {
     // Handle the case when the PDF file is not found
     return response()->json(['error' => 'PDF file not found'], 404);
 }    
 // Load the existing PDF
 $pdf = new Fpdi();
 $pdf->setSourceFile($pdfPath);
 $templateId = $pdf->importPage(1);


 
        // Add text to the PDF at specified positions
        $size = $pdf->getTemplateSize($templateId);
    
        if ($size[0] > $size[1]) {
            $pdf->AddPage('L', array($size[0], $size[1]));
        } else {
            $pdf->AddPage('P', array($size[0], $size[1]));
        }
        $pdf->useTemplate($templateId);
        $pdf->SetFont('Arial', 'B', 12);


        $pdf->SetXY(30, 48);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0, 'GPR/24-25/' . sprintf("%03d", $customer->id));
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(160, 58.5);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,substr($roomNames, 0, 20));

        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);
// Create a Carbon instance representing the date and time
$dateAndTime = Carbon::now();

// Separate the date and time components
$date = $dateAndTime->format('d-m-Y'); // Format: DD-MM-YYYY
$time = $dateAndTime->format('H:i:s A'); 
        $pdf->SetXY(155, 48);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$date . '   ' . $time);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(30, 58);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$customer->guest_name);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(160, 66.5);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,substr($customer->room_type->name, 0, 56));
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);
        
        
        $pdf->SetXY(160, 75);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,substr($customer->total_adult +  $customer->total_child, 0, 56));
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(30, 66.5);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,substr($customer->address, 0, 54));
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(30, 83);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$customer->guest_gstin);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(30, 91);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$customer->nationality->name);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

         // Assuming $lastCustomerDetail->check_in is a string in 'Y-m-d H:i:s' format
         $dateAndTime_check_in = Carbon::createFromFormat('Y-m-d H:i:s', $lastCustomerDetail->check_in);
        
         // Separate the date and time components
         $date_check_in = $dateAndTime_check_in->format('d-m-Y'); // Format: DD-MM-YYYY
         $time_check_in = $dateAndTime_check_in->format('H:i:s A'); // Format: HH:MM:SS AM/PM
        
         
          // Assuming $lastCustomerDetail->check_in is a string in 'Y-m-d H:i:s' format
        $dateAndTime_check_out = Carbon::createFromFormat('Y-m-d H:i:s', $lastCustomerDetail->check_out);
        
        // Separate the date and time components
        $date_check_out = $dateAndTime_check_out->format('d-m-Y'); // Format: DD-MM-YYYY
        $time_check_out = $dateAndTime_check_out->format('H:i:s A'); // Format: HH:MM:SS AM/PM
        $pdf->SetXY(30, 99);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$date_check_in);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(160, 99);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$time_check_in);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(30, 107.5);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$date);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(160, 107.5);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$time);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(160, 86.5);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$customer->country_code . '   ' . $customer->phone_number);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);
        $pdf->SetXY(41, 126.5);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,substr($roomNames, 0, 20));


        $differenceInDays = $dateAndTime_check_out->diffInDays($dateAndTime_check_in);
        $differenceInDaysCount = '';
        if($differenceInDays==0){
            $differenceInDaysCount = 1;
        }
        else{
            $differenceInDaysCount = $differenceInDays;


        }
$pdf->SetXY(153.5, 126.5);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$differenceInDaysCount);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(116.5, 126.5);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$customer->room_type->price);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);


        $pdf->SetXY(185, 126.5);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$customer->price);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);


$totalPrice = $customer->price;

   // Calculate GST (5% of total price)
        $gst = round($totalPrice * 0.05);

        // Calculate CGST and SGST (each 6% of GST)
        $cgst = round($totalPrice * 0.025);
        $sgst = round($totalPrice * 0.025);

        $pdf->SetXY(185, 152);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$cgst);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(185, 160);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$sgst);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(185, 175);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,'0.00');
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(185, 182);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$customer->price + $gst);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);


        $pdf->SetXY(185, 188);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$customer->customerDetail->sum('advance_amount'));
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);


        $pdf->SetXY(185, 193);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,($customer->price+$gst)-$customer->customerDetail->sum('advance_amount'));
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);
        $amountDifference = $customer->price - $customer->customerDetail->sum('advance_amount');

        // Create a new NumberFormatter instance to spell out the number in words
        $numberFormatter = new NumberFormatter('en_IN', NumberFormatter::SPELLOUT);
        
        // Convert the number into words
        $amountInWords = ucwords($numberFormatter->format($amountDifference));
        
        $pdf->SetXY(41, 201);
  //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
  $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
  $pdf->Cell(0, 0,$amountInWords);
  $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
  $pdf->SetFont('Arial', '', 10);

        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);
        // $output = $pdf->Output('S'); // Get the PDF content from output buffer
        //         $encodedPdf = base64_encode($output); // Encode the PDF content to base64
        // return response()->json(['encodedPdf' => $encodedPdf]);
        $output = $pdf->Output('S'); // Get the PDF content from output buffer

// Save the PDF to a public directory
$filename = 'document.pdf'; // Define the filename
$publicPath = public_path('pdf'); // Define the public directory path
$pdfPath = $publicPath . '/' . $filename; // Define the full path to the PDF file

// Create the public directory if it doesn't exist
if (!file_exists($publicPath)) {
    mkdir($publicPath, 0755, true);
}

// Write the PDF content to the file
file_put_contents($pdfPath, $output);

// Return the public URL to the saved PDF file
$pdfUrl = url('pdf/' . $filename);
return response()->json(['pdfUrl' => $pdfUrl]);

    }
    public function advanceUPdf($id)
    {
        // Set Content-Type header for PDF
header('Content-Type: application/pdf');

// Set Content-Disposition header to inline for viewing in the browser
header('Content-Disposition: inline; filename="document.pdf"');
 // Path to the existing PDF file
 $customer = Customer::with(['customerDetail','country','nationality', 'room_type', 'select_rooms'])
 ->find($id);
 $lastCustomerDetail = $customer->customerDetail->last();
 $payment_method = '';
 
 foreach (Customer::PAYMENT_METHOD_SELECT as $key => $label) {
    if ($key == $lastCustomerDetail->payment_method) {
        // Match found, you can perform further operations here
        $payment_method = $label;
    }
}
$roomNames = ''; // Initialize an empty string to store room names

// Access the "select_rooms" relation and then loop through each related room
foreach ($customer->select_rooms as $room) {
    // Append the name of each room to the existing value of $roomNames
    $roomNames .= $room->name . ', '; // Concatenate room names with comma separator
}

// Remove the trailing comma and space from the end of the string
$roomNames = rtrim($roomNames, ', ');

// Now $roomNames will contain a comma-separated list of all room names
// echo $roomNames;





    
 if (!$customer) {
     // Handle the case when the employee is not found
     return response()->json(['error' => 'Employee not found'], 404);
 }
 
 $pdfPath = public_path('pdf/Apl_first_bill.pdf');
 
 if (!file_exists($pdfPath)) {
     // Handle the case when the PDF file is not found
     return response()->json(['error' => 'PDF file not found'], 404);
 }    
 // Load the existing PDF
 $pdf = new Fpdi();
 $pdf->setSourceFile($pdfPath);
 $templateId = $pdf->importPage(1);


 
        // Add text to the PDF at specified positions
        $size = $pdf->getTemplateSize($templateId);
    
        if ($size[0] > $size[1]) {
            $pdf->AddPage('L', array($size[0], $size[1]));
        } else {
            $pdf->AddPage('P', array($size[0], $size[1]));
        }
        $pdf->useTemplate($templateId);
        $pdf->SetFont('Arial', 'B', 12);
        
         $pdf->SetXY(35, 52.5);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 14); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0, sprintf("%03d", $customer->id));
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

// Create a Carbon instance representing the date and time
$dateAndTime = Carbon::now();

// Separate the date and time components
$date = $dateAndTime->format('d-m-Y'); // Format: DD-MM-YYYY
$time = $dateAndTime->format('H:i:s A'); 

        $pdf->SetXY(175, 53);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0, $date);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);


        $pdf->SetXY(175, 61);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0, $time);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

        $pdf->SetXY(70, 95);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
                $pdf->Cell(0, 0,$customer->guest_name);

        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10); // Reset font size to default (optional, if you want to revert to the default font size)
       
       
       
        $pdf->SetXY(155, 108);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0, $roomNames);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10); 
       
        $pdf->SetXY(83, 136);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,$payment_method);
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10); 


        // Assuming $lastCustomerDetail->check_in is a string in 'Y-m-d H:i:s' format
        $dateAndTime_check_in = Carbon::createFromFormat('Y-m-d H:i:s', $lastCustomerDetail->check_in);
        
        // Separate the date and time components
        $date_check_in = $dateAndTime_check_in->format('d-m-Y'); // Format: DD-MM-YYYY
        $time_check_in = $dateAndTime_check_in->format('H:i:s A'); // Format: HH:MM:SS AM/PM
        

$pdf->SetXY(175, 180);
//$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
$pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
$pdf->Cell(0, 0, $date_check_in);
$pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
$pdf->SetFont('Arial', '', 10);


$pdf->SetXY(175, 188);
//$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
$pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
$pdf->Cell(0, 0, $time_check_in);
$pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
$pdf->SetFont('Arial', '', 10);
$amountDifference = $customer->customerDetail->sum('advance_amount');

// Create a new NumberFormatter instance to spell out the number in words
$numberFormatter = new NumberFormatter('en_IN', NumberFormatter::SPELLOUT);

// Convert the number into words
$amountInWords = ucwords($numberFormatter->format($amountDifference));




$pdf->SetXY(40, 122);
//$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
$pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
$pdf->Cell(0, 0, $customer->customerDetail->sum('advance_amount'));
$pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
$pdf->SetFont('Arial', '', 10);
       
$pdf->SetXY(183, 121);
        //$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
        $pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
        $pdf->Cell(0, 0,substr($customer->total_adult +  $customer->total_child, 0, 56));
        $pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
        $pdf->SetFont('Arial', '', 10);

$pdf->SetXY(67, 122);
//$pdf->SetTextColor(255, 0, 0); // Set text color to red (RGB: 255, 0, 0)
$pdf->SetFont('Arial', 'B', 10); // Set font family, style (B for bold), and size (12)
$pdf->Cell(0, 0, $amountInWords);
$pdf->SetTextColor(0, 0, 0); // Reset text color to black (optional, if you want to revert to the default color)
$pdf->SetFont('Arial', '', 10);
        // $output = $pdf->Output('S'); // Get the PDF content from output buffer
        //         $encodedPdf = base64_encode($output); // Encode the PDF content to base64
        // return response()->json(['encodedPdf' => $encodedPdf]);

        $output = $pdf->Output('S'); // Get the PDF content from output buffer

        // Save the PDF to a public directory
        $filename = 'document1.pdf'; // Define the filename
        $publicPath = public_path('pdf'); // Define the public directory path
        $pdfPath = $publicPath . '/' . $filename; // Define the full path to the PDF file
        
        // Create the public directory if it doesn't exist
        if (!file_exists($publicPath)) {
            mkdir($publicPath, 0755, true);
        }
        
        // Write the PDF content to the file
        file_put_contents($pdfPath, $output);
        
        // Return the public URL to the saved PDF file
        $pdfUrl = url('pdf/' . $filename);
        return response()->json(['pdfUrl' => $pdfUrl]);

    }
    public function index()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');

        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $discount = Discount::latest()->first();
        return view('backend.check_in', compact('floors','countries', 'nationalities', 'room_types','discount'));
    }


    public function check_out()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $gst = Gst::withTrashed()->latest()->first();
        
        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.check_out', compact('floors','countries', 'nationalities', 'room_types','gst'));
    }


    public function room_cancelation()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.room_cancelation', compact('floors','countries', 'nationalities', 'room_types'));
    }


    public function check_store()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.check_out', compact('floors','countries', 'nationalities', 'room_types'));
    }


    public function bill_index()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Roomtype::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.bill_statement', compact('floors','countries', 'nationalities', 'room_types'));
    }

    


    public function modification_index()
    {
        // abort_if(Gate::denies('modification_checkin_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.modification_check_in', compact('floors','countries', 'nationalities', 'room_types'));

    }

    public function ajax_data_price(Request $request)
    {
        $rooms = $request->input('select_rooms');
        // $roomsArray = is_array($rooms) ? $rooms : explode(',', $rooms);
    
        $price = Floor::find($rooms);
        
        if ($price !== null) {
            return response()->json(['message' => 'Modification successfully Updated', 'data' => $price]);
        } else {
            return response()->json(['message' => 'No data found']);
        }
    }
    public function ajax_data_phone_no(Request $request)
    {
        $phone_number = $request->input('phone_number');
    
        $customer = Customer::where('phone_number', $phone_number)->latest()->first();
    
        if ($customer !== null) {
            return response()->json(['message' => 'Modification successfully Updated', 'data' => $customer]);
        } else {
            return response()->json(['message' => 'No data found']);
        }
    }
    
    public function storecancelation(Request $request)
    {
        Customer::find($request->customers_ids_id)->update(['status' => 3]);

        return response()->json(['message' => 'Cancellation Updated successfully']);
    }

    
    public function ajax_data(Request $request)
    {
        
        
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $room_type_id = $request->input('room_type_id');
    
        $floors = Floor::with(['select_rooms', 'select_room_type'])->find($room_type_id);
        $customers = Customer::where('status',1)->whereHas('select_rooms', function ($query) {
            $query->havingRaw('COUNT(*) <= 1');
        })->with('select_rooms:id')->get();
        
        
        $booked = $customers->flatMap(function ($customer) {
            return $customer->select_rooms->pluck('id');
        })->unique()->toArray();
        
        $customersWithMultipleRooms = Customer::where('status',1)->whereHas('select_rooms', function ($query) {
            $query->havingRaw('COUNT(*) >= 2');
        })->with('select_rooms:id')->get();
        
        $multiple_book = $customersWithMultipleRooms->flatMap(function ($customer) {
            return $customer->select_rooms->pluck('id');
        })->unique()->toArray();
        
        if ($floors) {
            return response()->json(['message' => 'Data received successfully', 'data' => $floors,'booked' => $booked, 'multiple_book' => $multiple_book]);
        } else {
            return response()->json(['message' => 'No data found']);
        }
    }



    // public function ajax_data_bill_no(Request $request)
    // {
        
        
    //     // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
    //     $bill_no = $request->input('bill_no');

    //     $customers = Customer::where('status',1)->with(['customerDetail','advanceAmount','country','nationality', 'room_type', 'select_rooms'])
    //     ->whereHas('advanceAmount', function ($query) use ($advanceAmount) {
    //         $query->whereIn('id', $bill_no);
    //     })
    //     ->first();
    



    
    //     $floors = Floor::with(['select_rooms', 'select_room_type'])->find($room_type_id);
    //     $customers = Customer::where('status',1)->whereHas('select_rooms', function ($query) {
    //         $query->havingRaw('COUNT(*) <= 1');
    //     })->with('select_rooms:id')->get();
        
        
    //     $booked = $customers->flatMap(function ($customer) {
    //         return $customer->select_rooms->pluck('id');
    //     })->unique()->toArray();
        
    //     $customersWithMultipleRooms = Customer::where('status',1)->whereHas('select_rooms', function ($query) {
    //         $query->havingRaw('COUNT(*) >= 2');
    //     })->with('select_rooms:id')->get();
        
    //     $multiple_book = $customersWithMultipleRooms->flatMap(function ($customer) {
    //         return $customer->select_rooms->pluck('id');
    //     })->unique()->toArray();
        
    //     if ($floors) {
    //         return response()->json(['message' => 'Data received successfully', 'data' => $floors,'booked' => $booked, 'multiple_book' => $multiple_book]);
    //     } else {
    //         return response()->json(['message' => 'No data found']);
    //     }
    // }



    public function ajax_data_modification(Request $request)
    {
        $rooms = $request->input('select_rooms');

// Check if $rooms is a string and convert it to an array if needed
if (is_string($rooms)) {
    $rooms = explode(',', $rooms);
}

$customers = Customer::where('status',1)->with(['customerDetail','advanceAmount','country','nationality', 'room_type', 'select_rooms'])
    ->whereHas('select_rooms', function ($query) use ($rooms) {
        $query->whereIn('id', $rooms);
    })
    ->first();

   
        
        if ($customers) {
            return response()->json(['message' => 'Data received successfully', 'data' => $customers]);
        } else {
            return response()->json(['message' => 'No data found']);
        }
    }
    
    
    }
