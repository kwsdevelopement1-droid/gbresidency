<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Gate;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;
use App\Models\Customer;
use App\Models\Floor;
use App\Models\Room;
use App\Models\Gst;
use App\Models\User;
use App\Models\Customerdetail;
use App\Models\Discount;
use App\Models\Checkout;
use App\Models\ExtraBed;
use App\Models\checkout_bill_dup;
use Illuminate\Support\Str;
use PDF;




class AdminController extends Controller
{
    public function GetDuplicateAdvanceReciept(Request $req)
    {
        $data = $req;

        $id = $data->cust_id;
        $recordId = $data->id;

        $customer = Customer::with([
            'customerDetail', 'discount_ids', 'checkOut', 'advanceAmount' => function ($query) use ($recordId) {
                $query->where('id', $recordId);
            },
            'country', 'nationality', 'room_type', 'select_rooms', 'houseguest',
        ])->find($id);

        /*
        $customer = Customer::with([
            'customerDetail', 'discount_ids', 'checkOut', 'advanceAmount', 'country', 'nationality', 'room_type', 'select_rooms', 'houseguest',
        ])->where('advanceAmount.id', $recordId)->find($id);*/
        $gst = Gst::withTrashed()->latest()->first();
        $extra_count1 = ExtraBed::where('guest_id', $id)->count();

        // Pass the customer data to the view
        //  return $customer;
        $viewContent = View::make('backend.advance_bill_duplicate', compact('customer', 'gst', 'extra_count1'))->render();
        //  return view('backend.check_in_bill', compact('customer','gst'));
        return response()->json(['html' => $viewContent, 'data' => $customer]);
    }
}
