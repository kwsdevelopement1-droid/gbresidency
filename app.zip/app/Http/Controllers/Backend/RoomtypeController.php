<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyRoomtypeRequest;
use App\Http\Requests\StoreRoomtypeRequest;
use App\Http\Requests\UpdateRoomtypeRequest;
use App\Models\Roomtype;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RoomtypeController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('roomtype_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $roomtypes = Roomtype::all();

        return view('backend.roomtypes.index', compact('roomtypes'));
    }

    public function create()
    {
        abort_if(Gate::denies('roomtype_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('backend.roomtypes.create');
    }

    public function store(StoreRoomtypeRequest $request)
    {
        $roomtype = Roomtype::create($request->all());

        return redirect()->route('backend.roomtypes.index');
    }

    public function edit(Roomtype $roomtype)
    {
        abort_if(Gate::denies('roomtype_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('backend.roomtypes.edit', compact('roomtype'));
    }

    public function update(UpdateRoomtypeRequest $request, Roomtype $roomtype)
    {
        $roomtype->update($request->all());

        return redirect()->route('backend.roomtypes.index');
    }

    public function show(Roomtype $roomtype)
    {
        abort_if(Gate::denies('roomtype_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('backend.roomtypes.show', compact('roomtype'));
    }

    public function destroy(Roomtype $roomtype)
    {
        abort_if(Gate::denies('roomtype_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $roomtype->delete();

        return back();
    }

    public function massDestroy(MassDestroyRoomtypeRequest $request)
    {
        $roomtypes = Roomtype::find(request('ids'));

        foreach ($roomtypes as $roomtype) {
            $roomtype->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }
}