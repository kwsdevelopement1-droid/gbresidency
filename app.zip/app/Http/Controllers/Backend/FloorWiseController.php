<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyFloorRequest;
use App\Http\Requests\StoreFloorRequest;
use App\Http\Requests\UpdateFloorRequest;
use App\Models\Floor;
use App\Models\Room;
use App\Models\Roomtype;
use App\Models\Customer;
use App\Models\RoomStatus;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class FloorWiseController extends Controller
{
    public function index()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::with(['select_rooms', 'select_room_type'])->where('select_room_type_id',1)->get();
        $customers = Customer::where('status',1)->whereHas('select_rooms', function ($query) {
            $query->havingRaw('COUNT(*) <= 1');
        })->with('select_rooms:id')->get();
        
        
        $booked = $customers->flatMap(function ($customer) {
            return $customer->select_rooms->pluck('id');
        })->unique()->toArray();
        
        $customersWithMultipleRooms = Customer::where('status',1)->whereHas('select_rooms', function ($query) {
            $query->havingRaw('COUNT(*) >= 2');
        })->with('select_rooms:id')->get();
        
        $multiple_book = $customersWithMultipleRooms->flatMap(function ($customer) {
            return $customer->select_rooms->pluck('id');
        })->unique()->toArray();
        
        return view('backend.floor_wise', [
            'floors' => $floors,
            'booked' => $booked,
            'multiple_book' => $multiple_book,
        ]);
    }

  
}