<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ExtraBed;
use Carbon\Carbon;
use Exception;

class ExtraBedController extends Controller
{

    public function check_in(Request $request)
    {
        try {
            if ($request->rate_code != 2) {
                if ($request->no_extra > 0) {
                    $no_of_extra_person = $request->no_extra;
                    $extraData['guest_id'] = $request->customer_ids_id;
                    $extraData['room_id'] = $request->select_room;
                    $extraData['room_number'] = $request->select_room_name;
                    $extraData['price'] = $request->price;
                    
                     if (auth()->user() && auth()->user()->roles()->first()->id == 1) {
                    $extraData['checkin_date'] = Carbon::createFromFormat('d-m-Y H:i', $request->check_in)->format('Y-m-d H:i:s');
                } else {
                    $extraData['checkin_date'] = Carbon::createFromFormat('d-m-Y H:i', $request->extra_checkin_date)->format('Y-m-d H:i:s');
                }
                
                   
                    $extraData['totalcost'] = $request->price;
                    $extraData['totaldays'] = 1;

                    for (
                        $i = 0;
                        $i < $no_of_extra_person;
                        $i++
                    ) {
                        ExtraBed::Create($extraData);
                    }
                }
            }
            return response()->json(['message' => 'Extra Bed Added Successfully']);
        } catch (Exception $e) {

            return false;
        }
    }

    public function check_out_extra(Request $request)
    {

        $data = $request;

        try {
            if ($data != null) {
                $extraData['checkout_date'] = Carbon::now()->format('Y-m-d H:i:s');
                $extraData['totalcost'] = $data->cost;
                $extraData['totaldays'] = $data->days;
                $extraData['checkin_status'] = 0;

                ExtraBed::where('id', $data->id)->update($extraData);
                $extrabed_data = ExtraBed::find($data->id);
                $extrabed_data1
                    = ExtraBed::where('guest_id', $extrabed_data->guest_id)->get();
                return response()->json(['message' => 'Extra Bed Checkout Successfully', 'data' => $extrabed_data1]);
            } else {
                return response()->json(['message' => 'Not Able to update', 'data' => $data]);
            }
        } catch (Exception $e) {
            // report($e);

            return response()->json(['message' => 'Not Able to update', 'data' => $e]);
        }
    }

    public function deleteExtraBed(Request $request, $id)
    {
        $request->validate([
            'delete_reason' => 'required|string|max:255',
        ]);

        $extraBed = ExtraBed::findOrFail($id);
        
        // Soft delete the extra bed
        $extraBed->update([
            'deleted_reason' => $request->delete_reason,
            'deleted_at' => now()
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Extra bed removed successfully'
        ]);
    }

    public function destroy(Request $request, $id)
    {
        $request->validate([
            'reason' => 'required|string|max:255',
        ]);

        $extraBed = ExtraBed::findOrFail($id);

        // store deleted_reason in database before soft delete
        $extraBed->deleted_reason = $request->reason;
        $extraBed->save();       
        
        // Log the deletion reason before deleting
        \Log::info("Extra bed deleted: ID {$id}, Reason: {$request->reason}, User: " . (auth()->user()->id ?? 'unknown'));
        
        // Actually delete the record from database
        $extraBed->delete();

        return response()->json([
            'success' => true,
            'message' => 'Extra bed deleted successfully'
        ]);
    }
}
    

