<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyUserRequest;
use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Models\Role;
use App\Models\User;
use App\Models\Room;
use App\Models\Customer;
use App\Models\AdvanceAmount;
use Gate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
use Carbon\Carbon;


class EditadvanceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $yesterday = Carbon::yesterday()->startOfDay();
        $today = Carbon::today()->endOfDay();

        // Retrieve AdvanceAmount records with associated Customer details
        $reports = AdvanceAmount::with('customer_ids')->whereBetween('created_at', [$yesterday, $today])->get();

        $data = "pooba";
        return view('backend.edit_advance.index', compact('reports'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $report = AdvanceAmount::with('customer_ids')->find($id);
        return view('backend.edit_advance.edit', compact('report'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        // $id = $request->id;
        $data = $request->all();
        $adv =  AdvanceAmount::find($id);
        if ($adv) {
            $adv->update([
                'advance_amount' => $request->input('advance_amount'),
                'payment_method' => $request->input('payment_method'),
            ]);
        }
        return  redirect()->route('backend.edit_advance.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $post = AdvanceAmount::find($id);
        $post->delete();
        return  redirect()->route('backend.edit_advance.index');
    }
}
