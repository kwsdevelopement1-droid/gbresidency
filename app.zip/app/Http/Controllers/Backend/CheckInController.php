<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyFloorRequest;
use App\Http\Requests\StoreFloorRequest;
use App\Http\Requests\UpdateFloorRequest;
use App\Models\Country;
use App\Models\Customer;
use App\Models\Floor;
use App\Models\Room;
use App\Models\Gst;
use App\Models\User;
use App\Models\Customerdetail;
use App\Models\Discount;
use App\Models\AdvanceAmount;
use App\Models\AdvanceAmountOld;
use App\Models\Checkout;
use App\Models\Roomtype;
use App\Models\CustomerRoom;
use App\Models\ExtraBed;
use NumberFormatter;
use App\Models\RoomStatus;
use App\Models\Refuntamount;
use App\Models\ModificationCheckin;
use App\Models\TransferDetails;
use setasign\Fpdi\Fpdi;
use setasign\Fpdi\Fpdf\Fpdf;
use Gate;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\DB;

class CheckInController extends Controller
{


    public function secondUPdf(Request $req, $id)
    {
        // Retrieve the customer data
        $customer = Customer::with([
            'customerDetail', 'discount_ids', 'checkOut', 'advanceAmount', 'country', 'nationality',
            'room_type', 'select_rooms', 'extraBedsData',
        ])->find($id);
        $gst = Gst::withTrashed()->latest()->first();
        $extra_count1 = ExtraBed::where('guest_id', $id)->count();
        $numDays = $req->numDays;
        $totalRent = $req->totalRent;
        $totalExtraCost = $req->totalExtraCost;
        $totalExtraDays = $req->totalExtraDays;


        // Pass the customer data to the view
        //  return $customer;
        $viewContent = View::make('backend.check_out_bill', compact('customer', 'gst', 'numDays', 'totalRent', 'totalExtraCost', 'totalExtraDays', 'extra_count1'))->render();

        // Return the view content as response
        return response()->json(['html' => $viewContent]);
    }
    public function advanceUPdf($id)
    {
        // Retrieve the customer data
        $customer = Customer::with([
            'customerDetail', 'discount_ids', 'checkOut', 'advanceAmount', 'country', 'nationality', 'room_type', 'select_rooms', 'houseguest',
        ])->find($id);
        $gst = Gst::withTrashed()->latest()->first();
        $extra_count1 = ExtraBed::where('guest_id', $id)->count();

        // Pass the customer data to the view
        //  return $customer;
        $viewContent = View::make('backend.check_in_bill', compact('customer', 'gst', 'extra_count1'))->render();
        //  return view('backend.check_in_bill', compact('customer','gst'));
        return response()->json(['html' => $viewContent, 'data' => $customer]);
    }

    public function CashierReportindex()
    {
        $users = User::pluck('name', 'id');
        return view('backend.cashierreport', compact('users'));
    }

    public function AdvanceReportindex()
    {
        $users = User::pluck('name', 'id');
        $report = null;
        $reportOld = null;
        $data = "poobalan";
        $to_date =  Carbon::now()->format('Y-m-d');
        $from_date = Carbon::now()->format('Y-m-d');
        $reportTime = Carbon::now()->format('d-m-Y H:i:s');
        return view('backend.report_advance', compact('users', 'report','reportOld', 'data', 'to_date', 'from_date', 'reportTime'));
    }
    public function AdvanceReportFillter(Request $request)
    {
        $data = $request->all();

        // Retrieve the customer data
        $from_date = Carbon::createFromFormat('d-m-Y', $request->check_in)->startOfDay()->format('Y-m-d H:i:s');
        $to_date = Carbon::createFromFormat('d-m-Y', $request->check_out)->endOfDay()->format('Y-m-d H:i:s');

        if ($request->user_ids == 'ALL') {
            $report = AdvanceAmount::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();
            $reportOld = AdvanceAmountOld::whereBetween('created_at', [$from_date, $to_date])->with('customer_ids')->get();
        } else {
        $report = AdvanceAmount::whereBetween('created_at', [$from_date, $to_date])->where('user_ids_id', $request->user_ids)->with('customer_ids')->get();
        $reportOld = AdvanceAmountOld::whereBetween('created_at', [$from_date, $to_date])->where('user_ids_id', $request->user_ids)->with('customer_ids')->get();
        }
        $reportTime = Carbon::now()->format('d-m-Y H:i:s');
        //whereBetween('created_at', [$request->check_in, $request->check_out])->

        $users = User::pluck('name', 'id');


        return view('backend.report_advance', compact('users', 'report', 'reportOld','data', 'from_date', 'to_date', 'reportTime'));
    }


    public function ForeignersGuestListindex()
    {
        $users = Country::pluck('name', 'id');
        return view('backend.foreignersguestlist', compact('users'));
    }
public function forignReportFillter(Request $request)
{
    $data = $request->all();
    $user_ids = $request->input('user_ids');
    
    // dd($request);

    // Validate Date Inputs to prevent "Unexpected Data" errors
    try {
        $checkIn = !empty($request->check_in) ? Carbon::createFromFormat('d-m-Y', trim($request->check_in))->startOfDay() : null;
        $checkOut = !empty($request->check_out) ? Carbon::createFromFormat('d-m-Y', trim($request->check_out))->endOfDay() : null;
    } catch (\Exception $e) {
        return back()->withErrors(['date_error' => 'Invalid date format. Please use DD-MM-YYYY.']);
    }

    // Query Builder
    $builder = Customer::with([
        'customerDetail',
        'discount_ids',
        'checkOut' => function ($query) {
            $query->latest('created_at'); // Ensure latest checkOut is retrieved first
        },
        'checkOutOld',
        'Checkout24_25',
        'advanceAmount',
        'country',
        'nationality',
        'room_type',
        'select_rooms',
        'houseguest',
        'refund',
        'user_ids'
    ]);

    // Filter by User ID
    if ($request->has('user_ids') && $request->filled('user_ids')) {
        if ($user_ids != 'ALL') {
            $builder->where('user_ids_id', $user_ids)
                ->orWhereHas('checkOut', function ($query) use ($user_ids) {
                    $query->where('user_ids_id', $user_ids);
                })
                ->orWhereHas('checkOutOld', function ($query) use ($user_ids) {
                    $query->where('user_ids_id', $user_ids);
                })
                ->orWhereHas('Checkout24_25', function ($query) use ($user_ids) {
                    $query->where('user_ids_id', $user_ids);
                })
                ->orWhereHas('advanceAmount', function ($query) use ($user_ids) {
                    $query->where('user_ids_id', $user_ids);
                });
        }
    }

    // Filter by Date Range
    if ($checkIn && $checkOut) {
    $builder->whereBetween('created_at', [$checkIn, $checkOut]);
}

    // Filter by Country
    if ($request->has('country_id') && $request->filled('country_id')) {
        $country_id = $request->input('country_id');
        if ($country_id == 'all') {
            $builder->whereHas('country', function ($query) {
                $query->where('id', '!=', 95);
            });
        } else {
            $builder->whereHas('country', function ($query) use ($country_id) {
                $query->where('id', $country_id);
            });
        }
    }

    // Fetch Results
    $reports = $builder->orderBy('id', 'desc')->get();

    return view('backend.foreignersguestlist_data', compact('reports', 'data'));
}

    public function CashierReportFillter(Request $request)
    {
        $data = $request->all();
        $user_ids = $request->input('user_ids');
        $checkIn = Carbon::createFromFormat('d-m-Y', $request->check_in)->startOfDay();
        $checkOut = Carbon::createFromFormat('d-m-Y', $request->check_out)->endOfDay();

        // Retrieve the customer data
        $builder = Customer::with([
            'customerDetail', 'discount_ids', 'checkOut', 'checkOutOld','Checkout24_25', 'Checkout25_26','advanceAmount', 'country', 'nationality',
            'room_type', 'select_rooms', 'houseguest', 'refund', 'user_ids'
        ]);

        // Apply filters if conditions are met
        if ($request->has('user_ids') && $request->filled('user_ids')) {
            $user_ids = $request->input('user_ids');
            if ($user_ids  != 'ALL') {
                // $builder->whereHas('user_ids', function ($query) use ($user_ids) {
                //     $query->where('id', $user_ids);
                // });

                $builder->where('user_ids_id', $user_ids)
                ->orWhereHas('checkOut', function ($query) use ($user_ids) {
                    $query->where('user_ids_id', $user_ids);
                })
                ->orWhereHas('checkOutOld', function ($query) use ($user_ids) {
                    $query->where('user_ids_id', $user_ids);
                })
                ->orWhereHas('Checkout24_25', function ($query) use ($user_ids) {
                    $query->where('user_ids_id', $user_ids);
                })
                ->orWhereHas('Checkout25_26', function ($query) use ($user_ids) {
                    $query->where('user_ids_id', $user_ids);
                })
                ->orWhereHas('advanceAmount', function ($query) use ($user_ids) {
                    $query->where('user_ids_id', $user_ids);
                });

            }
        }

        if (
            $request->has('check_in') && $request->has('check_out') &&
            $request->filled('check_in') && $request->filled('check_out')
        ) {

            // Parse the check_in and check_out dates with the correct format
            $checkIn = Carbon::createFromFormat('d-m-Y', $request->check_in)->startOfDay();
            $checkOut = Carbon::createFromFormat('d-m-Y', $request->check_out)->endOfDay();

            // Add conditions for check_in and check_out dates
            $builder->where(function ($query) use ($checkIn, $checkOut) {
                $query->whereHas('checkOut', function ($q) use ($checkIn, $checkOut) {
                    $q->whereBetween('created_at', [$checkIn, $checkOut]);
                })->orwhereHas('checkOutOld', function ($q) use ($checkIn, $checkOut) {
                    $q->whereBetween('created_at', [$checkIn, $checkOut]);
                })
                ->orwhereHas('Checkout24_25', function ($q) use ($checkIn, $checkOut) {
                    $q->whereBetween('created_at', [$checkIn, $checkOut]);
                })
                ->orwhereHas('Checkout25_26', function ($q) use ($checkIn, $checkOut) {
                    $q->whereBetween('created_at', [$checkIn, $checkOut]);
                })
                    ->orWhereHas('advanceAmount', function ($q) use ($checkIn, $checkOut) {
                        $q->whereBetween('created_at', [$checkIn, $checkOut]);
                    });
            });
        }



        if ($request->has('country_id') && $request->filled('country_id')) {
            $country_id = $request->input('country_id');
            $builder = Customer::where('seg', 2)->where('status', 1)->orWhereBetween('created_at', [$checkIn, $checkOut])
            ->with([
                'customerDetail', 'discount_ids', 'checkOut', 'checkOutOld','Checkout24_25', 'advanceAmount', 'country', 'nationality',
                'room_type', 'select_rooms', 'houseguest', 'refund', 'user_ids'
            ]);
            if ($country_id == 'all') {
                $builder->whereHas('country', function ($query) use ($country_id) {
                    $query->where('id', '!=', 95);
                });
            } else {
                $builder->whereHas('country', function ($query) use ($country_id) {
                    $query->where('id', $country_id);
                });
            }
        }

        $reports = $builder->orderBy('id', 'desc')->get();
        
        $allCheckouts = [];

        foreach ($reports as $customer) {
        
            if ($customer->checkOut) {
                $allCheckouts[] = $customer->checkOut;
            }
        
            if ($customer->checkOutOld) {
                $allCheckouts[] = $customer->checkOutOld;
            }
        
            if ($customer->Checkout24_25) {
                $allCheckouts[] = $customer->Checkout24_25;
            }
        
            if ($customer->Checkout25_26) {   // 🔥 IMPORTANT
                $allCheckouts[] = $customer->Checkout25_26;
            }
        }
        // Pass the customer data to the view
        //  return $customer;

        $query = $builder->getQuery();

        // Get the SQL query
        $sql = $query->toSql();


        if ($request->has('country_id') && $request->filled('country_id')) {


            $viewContent = View::make('backend.foreignersguestlist_data', compact('reports', 'data'))->render();
        }

        if ($request->has('user_ids') && $request->filled('user_ids')) {

            // $chkBuilder = Checkout::with('customer_ids')->whereBetween('created_at', [$checkIn, $checkOut]);
            // $advBuilder = AdvanceAmount::with('customer_ids')->whereBetween('created_at', [$checkIn, $checkOut]);
            // if ($user_ids != 'ALL') {
            //     $advBuilder = $advBuilder->where('user_ids_id', $user_ids);
            //     $chkBuilder = $chkBuilder->where('user_ids_id', $user_ids);
            // }

            // $advReports = $advBuilder->get();
            // $checkOutReports = $chkBuilder->get();


            $viewContent = View::make('backend.cashierreport_data', compact('reports', 'data',  'user_ids', 'sql'))->render();
            $viewContent = View::make('backend.cashierreport_data', compact(
                'reports',
                'allCheckouts', // 🔥 ADD THIS
                'data',
                'user_ids',
                'sql'
            ))->render();
        }
        //  return view('backend.check_in_bill', compact('customer','gst'));
        return response()->json(['html' => $viewContent]);
    }
    public function index()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');

        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $discount = Discount::latest()->first();
        return view('backend.check_in', compact('floors', 'countries', 'nationalities', 'room_types', 'discount'));
    }
    public function groupCheckIn(Request $request)
    {
        abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $roomIds = $request->room_ids;

        $floors = Floor::pluck('name', 'id');

        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $discount = Discount::latest()->first();
        return view('backend.check_in_post', compact('floors', 'countries', 'nationalities', 'room_types', 'discount', 'roomIds'));
    }


    public function check_out()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $gst = Gst::withTrashed()->latest()->first();

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.check_out', compact(
            'floors',
            'countries',
            'nationalities',
            'room_types',
            'gst'
        ));
    }


    public function extent_index()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $gst = Gst::withTrashed()->latest()->first();

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.extent', compact('floors', 'countries', 'nationalities', 'room_types', 'gst'));
    }

    public function extent_store(Request $request)
    {
        $data = $request->all();
        // $data['check_in'] = Carbon::createFromFormat('m/d/Y h:i A', $request->check_in)->format('Y-m-d H:i:s');
        // $data['check_in'] = Carbon::now()->format('Y-m-d H:i:s');
        $data['check_in'] = Carbon::createFromFormat('d-m-Y H:i', $request->check_in)->format('Y-m-d H:i:s');

        $data['check_out'] = Carbon::createFromFormat('d-m-Y H:i', $request->check_out)->format('Y-m-d H:i:s');
        $customerdetail = Customerdetail::create($data);
        Customer::find($request->customer_ids_id)->update(['price' => $request->total_price]);
        return response()->json(['message' => 'Extend Successfully added', 'data' => $customerdetail]);
    }
    public function room_status_index()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $gst = Gst::withTrashed()->latest()->first();

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.room_status', compact('floors', 'countries', 'nationalities', 'room_types', 'gst'));
    }

    public function room_status_store(Request $request)
    {
        // Assuming $request->room_ids is an array of room IDs
        // Assuming $request->status is the status you want to update the rooms to

        // Use the update method with whereIn
        Room::whereIn('id', $request->room_ids)->update(['status' => $request->status]);

        // Assuming Room model represents your rooms table
        // Assuming 'status' is a column in your rooms table

        return response()->json(['message' => 'Room Status Successfully updated']);
    }

    public function room_cancelation()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.room_cancelation', compact('floors', 'countries', 'nationalities', 'room_types'));
    }


    public function check_store()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.check_out', compact('floors', 'countries', 'nationalities', 'room_types'));
    }


    public function bill_index()
    {
        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Roomtype::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.bill_statement', compact('floors', 'countries', 'nationalities', 'room_types'));
    }




    public function modification_index()
    {
        // abort_if(Gate::denies('modification_checkin_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $discount = Discount::latest()->first();



        return view('backend.modification_check_in', compact('floors', 'countries', 'nationalities', 'room_types', 'discount'));
    }

    public function ajax_data_price(Request $request)
    {
        $rooms = $request->input('select_rooms');
        // $roomsArray = is_array($rooms) ? $rooms : explode(',', $rooms);

        $price = Floor::find($rooms);

        if ($price !== null) {
            return response()->json(['message' => 'Modification successfully Updated', 'data' => $price]);
        } else {
            return response()->json(['message' => 'No data found']);
        }
    }
    public function ajax_data_phone_no(Request $request)
    {
        $phone_number = $request->input('phone_number');

        $customer = Customer::where('phone_number', $phone_number)->latest()->first();

        if ($customer !== null) {
            return response()->json(['message' => 'Modification successfully Updated', 'data' => $customer]);
        } else {
            return response()->json(['message' => 'No data found']);
        }
    }

    public function storecancelation(Request $request)
    {
        Customer::find($request->customers_ids_id)->update(['status' => 3]);

        if ($request->amount && $request->amount > 0) {
            Refuntamount::create($request->all());
        }
        return response()->json(['message' => 'Cancellation Updated successfully']);
    }


    public function ajax_data(Request $request)
    {


        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $room_type_id = $request->input('room_type_id');

        $floors = Floor::with(['select_rooms', 'select_room_type'])->find($room_type_id);
        $customers = Customer::where('status', 1)->whereHas('select_rooms', function ($query) {
            $query->havingRaw('COUNT(*) <= 1');
        })->with('select_rooms:id')->get();


        $booked = $customers->flatMap(function ($customer) {
            return $customer->select_rooms->pluck('id');
        })->unique()->toArray();

        $booked =
            array_values($booked);

        $customersWithMultipleRooms = Customer::where('status', 1)->whereHas('select_rooms', function ($query) {
            $query->havingRaw('COUNT(*) >= 2');
        })->with('select_rooms:id')->get();

        $multiple_book = $customersWithMultipleRooms->flatMap(function ($customer) {
            return $customer->select_rooms->pluck('id');
        })->unique()->toArray();
        
        $multiple_book= array_values($multiple_book);


        if ($floors) {
            return response()->json(['message' => 'Data received successfully', 'data' => $floors, 'booked' => $booked, 'multiple_book' => $multiple_book]);
        } else {
            return response()->json(['message' => 'No data found']);
        }
    }



    public function ajax_data_bill_no(Request $request)
    {


        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $formatted_bill_no = $request->input('bill_no');
        $bill_no = sprintf("%03d", $formatted_bill_no);

        $advanceAmount = AdvanceAmount::find($bill_no);

        $customers_data = Customer::where('status', 1)
            ->with(['customerDetail', 'advanceAmount', 'country', 'nationality', 'room_type', 'select_rooms', 'extraBedsData'])
        ->find($advanceAmount->customer_ids_id);





        $floors = Floor::with(['select_rooms', 'select_room_type'])->find($customers_data->room_type->id);
        $customers = Customer::where('status', 1)->whereHas('select_rooms', function ($query) {
            $query->havingRaw('COUNT(*) <= 1');
        })->with('select_rooms:id')->get();


        $booked = $customers->flatMap(function ($customer) {
            return $customer->select_rooms->pluck('id');
        })->unique()->toArray();
        $booked =
            array_values($booked);

        $customersWithMultipleRooms = Customer::where('status', 1)->whereHas('select_rooms', function ($query) {
            $query->havingRaw('COUNT(*) >= 2');
        })->with('select_rooms:id')->get();

        $multiple_book = $customersWithMultipleRooms->flatMap(function ($customer) {
            return $customer->select_rooms->pluck('id');
        })->unique()->toArray();

        if ($floors) {
            return response()->json([
                'message' => 'Data received successfully', 'data' => $floors, 'booked' => $booked, 'multiple_book' => $multiple_book, 'customers_data' => $customers_data
            ]);
        } else {
            return response()->json(['message' => 'No data found']);
        }
    }
    //New Function for Room number search
    public function ajax_data_room_no(Request $request)
    {


        // abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $formatted_room_no = $request->input('room_no');
        $room_no =
        $request->input('room_no'); //sprintf("%03d", $formatted_room_no);

        $room = Room::where('name', $room_no)->get()->first();
        if (!$room)
            return response()->json(['message' => 'No data found']);

        $customer_room = DB::table('customer_room')->where('room_id', $room->id)->orderBy(
            'customer_id',
            'desc'
        )->get()->first(); //CustomerRoom::where('room_id', $room_no)->latest();
        // $advanceAmount = AdvanceAmount::where('customer_ids_id', $customer_room->customer_id)->get();

        $customers = Customer::where('status', 1)->whereHas('select_rooms', function ($query) {
            $query->havingRaw('COUNT(*) <= 1');
        })->with('select_rooms:id')->get();

        $customerIds = CustomerRoom::where('room_id', $room->id)->pluck('customer_id');

        // Retrieve Customer records where status is 1 and customer_id is in the $customerIds array
        $customers_dataTemp = Customer::whereIn('id', $customerIds)->where('status', 1)->latest('created_at')
            ->first();

        $customers_data = null;
        $extra_beds = null;
        if ($customers_dataTemp) {
            $customers_data = Customer::where('status', 1)
                ->with(['customerDetail', 'advanceAmount', 'country', 'nationality', 'room_type', 'select_rooms', 'extraBedsData'])
            ->find($customers_dataTemp->id);

            if ($customers_data) {
                $floors = Floor::with(['select_rooms', 'select_room_type'])->find($customers_data->room_type->id);


                $booked = $customers->flatMap(function ($customer) {
                    return $customer->select_rooms->pluck('id');
                })->unique()->toArray();
                $booked =
                    array_values($booked);

                $customersWithMultipleRooms = Customer::where('status', 1)->whereHas('select_rooms', function ($query) {
                    $query->havingRaw('COUNT(*) >= 2');
                })->with('select_rooms:id')->get();

                $multiple_book = $customersWithMultipleRooms->flatMap(function ($customer) {
                    return $customer->select_rooms->pluck('id');
                })->unique()->toArray();
                $multiple_book
                = array_values($multiple_book);

                // $extra_beds = ExtraBed::where('guest_id', $customers_data->id);

                if ($floors) {
                    return response()->json([
                        'message' => 'Data received successfully', 'data' => $floors, 'booked' => $booked, 'multiple_book' => $multiple_book, 'customers_data' => $customers_data,
                    ]);
                } else {
                    return response()->json(['message' => 'No data found']);
                }
            }
            // if ($customer_room) {
            //     return response()->json([
            //         'message' => 'Data received successfully', 'floors' => $floors, 'data' => $customers_data, 'customer' => $customers,
            //     ]);
            // } else {
            //     return response()->json(['message' => 'No data found']);
            // }
        } else {
            return response()->json(['message' => 'No data found']);
        }
    }


    public function ajax_data_modification(Request $request)
    {
        $rooms = $request->input('select_rooms');

        // Check if $rooms is a string and convert it to an array if needed
        if (is_string($rooms)) {
            $rooms = explode(',', $rooms);
        }

        $customers = Customer::where('status', 1)->with(['customerDetail', 'advanceAmount', 'country', 'nationality', 'room_type', 'select_rooms', 'extraBedsData', 'monthlyguest'])
            ->whereHas('select_rooms', function ($query) use ($rooms) {
                $query->whereIn('id', $rooms);
            })
            ->first();



        if ($customers) {
            return response()->json(['message' => 'Data received successfully', 'data' => $customers]);
        } else {
            return response()->json(['message' => 'No data found']);
        }
    }

    public function showExtraCheckIn()
    {
        $floors = Floor::pluck('name', 'id');

        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $discount = Discount::latest()->first();

        return view('backend.extra_check_in', compact('floors', 'countries', 'nationalities', 'room_types', 'discount'));
    }

    public function showExtraCheckOut()
    {
        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $gst = Gst::withTrashed()->latest()->first();

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.extra_check_out', compact(
            'floors',
            'countries',
            'nationalities',
            'room_types',
            'gst'
        ));
    }

    public function RoomTransferIndex()
    {
        abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $gst = Gst::withTrashed()->latest()->first();

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $customers_data = null;
        $room_no = "";

        return view('backend.room_transfer', compact(
            'floors',
            'countries',
            'nationalities',
            'room_types',
            'gst',
            'customers_data',
            'room_no'
        ));
    }
    public function RoomTransferFilter(Request $request)
    {
        abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::get();
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $gst = Gst::withTrashed()->latest()->first();

        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $room_no =
            $request->input('room_no'); //sprintf("%03d", $formatted_room_no);

        $room = Room::where('name', $room_no)->get()->first();
        if (!$room)
            return response()->json(['message' => 'No data found']);

        // $customer_room = DB::table('customer_room')->where('room_id', $room->id)->orderBy(
        //     'customer_id',
        //     'desc'
        // )->get()->first();


        $customerIds = CustomerRoom::where('room_id', $room->id)->pluck('customer_id');

        // Retrieve Customer records where status is 1 and customer_id is in the $customerIds array
        $customers_dataTemp = Customer::whereIn('id', $customerIds)->where('status', 1)->latest('created_at')
            ->first();

        $customers_data = null;
        $extra_beds = null;
        if ($customers_dataTemp) {
            $customers_data = Customer::where('status', 1)
                ->with(['customerDetail', 'advanceAmount', 'country', 'nationality', 'room_type', 'select_rooms', 'extraBedsData'])
                ->find($customers_dataTemp->id);



            if ($customers_data) {
                // $floors = Floor::with(['select_rooms', 'select_room_type'])->find($customers_data->room_type->id);

                $extra_beds = ExtraBed::where('guest_id', $customers_data->id)->where('checkin_status', 0)->get();

                /*  if ($floors) {
                return response()->json([
                    'message' => 'Data received successfully', 'data' => $floors, 'booked' => $booked, 'multiple_book' => $multiple_book, 'customers_data' => $customers_data,
                ]);
            } else {
                return response()->json(['message' => 'No data found']);
            } */
            }
        }


        return view('backend.room_transfer', compact(
            'floors',
            'countries',
            'nationalities',
            'room_types',
            'gst',
            'extra_beds',
            'customers_data',
            'room_no'
        ));
        // return response()->json(['message' => 'Room Transfer Successfull!', 'customerIds' => $customerIds, 'customers_dataTemp' => $customers_dataTemp, 'room' => $room, 'data' => $customers_data,  'customer_room' => $customer_room]);
    }

    public function RoomTransferSubmit(Request $request)
    {
        abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');



        $data = $request->all();

        $guestID = $request->cust_id;
        $newPrice = $request->to_room_price;
        $newRoom = $request->to_room_id;
        $newRoomName = $request->to_room_name;
        $newTotalCost = $request->to_room_extra;



        Customer::find($guestID)->update(['price' => $request->to_room_price, 'room_type_id' => $request->to_room_type]);

        CustomerRoom::where('customer_id', $guestID)->update(['room_id' => $request->to_room_id]);

        Room::find($request->from_room_id)->update(['status' => 2]);
        Room::find($newRoom)->update(['status' => 0]);

        $transferEntry = TransferDetails::create($data);



        $countOldPax = $request->from_room_max + $request->from_room_extra;

        $newExtraBed =         $countOldPax - $request->to_room_extra;


        $previousRoomBeds = $request->from_room_max;
        $newRoomBeds = $request->to_room_max;
        $extraBedsAdjustment = 0;

        if ($newRoomBeds < $previousRoomBeds) {
            //update old first and then  need new extrabed created
            // $extraBeds = ExtraBed::where('guest_id', $request->cust_id)
            //     ->where('status', 0)
            //     ->get();

            // // Update each found ExtraBed record
            // foreach ($extraBeds as $extraBed) {
            //     // Update the ExtraBed record
            //     $extraBed->update([
            //         'room_id' => $newRoom,
            //         'room_no' => $newRoomName,
            //         'price' => $newPrice,
            //         'total_cost' => $newTotalCost,

            //     ]);
            // }
            $newExtraCount = $countOldPax - $request->to_room_max -  $request->from_room_extra;
            $newData = [];

            // Fill the array with the data for the new ExtraBed records
            for ($i = 0; $i < $newExtraCount; $i++) {
                $data[] = [
                    'guest_id' => $guestID,
                    'room_id' => $newRoom,
                    'room_no' => $newRoomName,
                    'price' => $newPrice,
                    'checkin_date' => $request->check_in,
                    'total_cost' => $newTotalCost,
                    'checkin_status' => 0,
                    'totalcost' => $newPrice,
                    'tataldays' => 1,
                    'ramarks' => "transfer new",
                    // Add other fields as needed
                ];
            }

            // Insert the data into the database
            ExtraBed::insert($newData);
        } else  if ($newRoomBeds > $previousRoomBeds) {
            $newExtraCount = $countOldPax - $request->to_room_max;
            // $extraBedsAdjustment = 0;
            if ($newExtraCount < 0) {
                $newExtraCount = 0;
                // $extraBedsAdjustment = $request->from_room_extra - $newExtraCount;
            }
            $newPax = $countOldPax > $request->to_room_max ? $request->to_room_max : $countOldPax;

            // if ($extraBedsAdjustment > 0) {
            // Delete extra bed entries
            ExtraBed::where('guest_id', $request->cust_id)->where('checkin_status', 0)->orderBy('created_at', 'asc')->take($newExtraCount)->delete();
            Customer::find($guestID)->update(['total_adult' => $newPax]);
            // $extraBeds = ExtraBed::where('guest_id', $request->cust_id)
            //     ->where('status', 0)
            //     ->get();

            // // Update each found ExtraBed record
            // foreach ($extraBeds as $extraBed) {
            //     // Update the ExtraBed record
            //     $extraBed->update([
            //         'room_id' => $newRoom,
            //         'room_no' => $newRoomName,
            //         'price' => $newPrice,
            //         'total_cost' => $newTotalCost,

            //     ]);
            // }
            // }
        }
        $extraBeds = ExtraBed::where('guest_id', $request->cust_id)
            ->where('checkin_status', 0)
            ->get();

        // Update each found ExtraBed record
        foreach ($extraBeds as $extraBed) {
            $extraBed->timestamps = false;

            // Update the ExtraBed record
            $extraBed->update([
                'room_id' => $newRoom,
                'room_no' => $newRoomName,
                'price' => $request->to_room_extra,
                'total_cost' => $newTotalCost,


            ]);
        }






        return response()->json(['message' => 'Room Transfer Successfull!', 'data' => $data, 'extraBedsAdjustment' => $extraBedsAdjustment, 'newRoomBeds' => $newRoomBeds, 'previousRoomBeds' => $previousRoomBeds]);
    }
}
