<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Checkout;
use App\Models\CheckoutOld;
use App\Models\Checkout24_25;
use App\Models\Customer;
use App\Models\Room;
use Gate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
use Carbon\Carbon;

class PostCheckoutEditController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        abort_if(Gate::denies('post_checkout_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden - Admin Only');

        $startDate = Carbon::now()->subDays(30)->startOfDay();
        $endDate = Carbon::now()->endOfDay();

        $currentCheckouts = Checkout::with(['customer_ids'])
            ->whereBetween('created_at', [$startDate, $endDate])
            ->orderBy('created_at', 'desc')
            ->get();

        $oldCheckouts = CheckoutOld::with(['customer_ids'])
            ->whereBetween('created_at', [$startDate, $endDate])
            ->orderBy('created_at', 'desc')
            ->get();

        $checkout24_25 = Checkout24_25::with(['customer_ids'])
            ->whereBetween('created_at', [$startDate, $endDate])
            ->orderBy('created_at', 'desc')
            ->get();

        $allCheckouts = collect()
            ->merge($currentCheckouts->map(function($item) {
                $item->table_source = 'checkouts';
                return $item;
            }))
            ->merge($oldCheckouts->map(function($item) {
                $item->table_source = 'checkouts_old';
                return $item;
            }))
            ->merge($checkout24_25->map(function($item) {
                $item->table_source = 'checkouts_24-25';
                return $item;
            }))
            ->sortByDesc('created_at');

        return view('backend.post_checkout_edit.index', compact('allCheckouts'));
    }

    public function edit($table, $id)
    {
        abort_if(Gate::denies('post_checkout_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden - Admin Only');

        $checkout = $this->getCheckoutByTable($table, $id);
        
        if (!$checkout) {
            return redirect()->route('backend.post-checkout-edit.index')
                ->with('error', 'Checkout record not found.');
        }

        $paymentMethods = Checkout::PAYMENT_METHOD_SELECT;
        
        return view('backend.post_checkout_edit.edit', compact('checkout', 'paymentMethods', 'table'));
    }

    public function update(Request $request, $table, $id)
    {
        abort_if(Gate::denies('post_checkout_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden - Admin Only');

        $request->validate([
            'guest_name' => 'required|string|max:255',
            'phone_number' => 'required|string|max:15',
            'guest_gstin' => 'nullable|string|max:15',
            'tariff' => 'required|numeric|min:0',
            'extra_person_cost' => 'nullable|numeric|min:0',
            'total_amount' => 'required|numeric|min:0',
            'advance_amount' => 'required|numeric|min:0',
            'balance_amount' => 'required|numeric',
            'payment_method' => 'required|in:1,2,3,4',
            'cgst' => 'nullable|numeric|min:0',
            'sgst' => 'nullable|numeric|min:0',
            'igst' => 'nullable|numeric|min:0',
            'remarks' => 'nullable|string|max:500',
            'edit_reason' => 'required|string|max:500'
        ]);

        $checkout = $this->getCheckoutByTable($table, $id);
        
        if (!$checkout) {
            return redirect()->route('backend.post-checkout-edit.index')
                ->with('error', 'Checkout record not found.');
        }

        $originalData = $checkout->toArray();
        
        // Update customer information
        if ($checkout->customer_ids) {
            $originalCustomerData = $checkout->customer_ids->toArray();
            
            $checkout->customer_ids->update([
                'guest_name' => $request->guest_name,
                'phone_number' => $request->phone_number,
                'guest_gstin' => $request->guest_gstin,
            ]);
            
            // Log customer data changes
            $this->logCustomerEdit($checkout->customer_ids, $originalCustomerData, $request->edit_reason, auth()->user()->id);
        }

        // Update checkout information
        $checkout->update([
            'tariff' => $request->tariff,
            'extra_person_cost' => $request->extra_person_cost,
            'total_amount' => $request->total_amount,
            'advance_amount' => $request->advance_amount,
            'balance_amount' => $request->balance_amount,
            'payment_method' => $request->payment_method,
            'cgst' => $request->cgst,
            'sgst' => $request->sgst,
            'igst'=> $request->igst,
            'remarks' => $request->remarks,
        ]);

        $this->logCheckoutEdit($checkout, $originalData, $request->edit_reason, auth()->user()->id);

        return redirect()->route('backend.post-checkout-edit.index')
            ->with('success', 'Checkout record updated successfully.');
    }
    
    private function getCheckoutByTable($table, $id)
    {
        switch ($table) {
            case 'checkouts':
                return Checkout::with(['customer_ids', 'user_ids', 'extraBeds'])->find($id);
            case 'checkouts_old':
                return CheckoutOld::with(['customer_ids', 'user_ids', 'extraBeds'])->find($id);
            case 'checkouts_24-25':
                return Checkout24_25::with(['customer_ids', 'user_ids', 'extraBeds'])->find($id);
            default:
                return null;
        }
    }

    private function logCheckoutEdit($checkout, $originalData, $reason, $userId)
    {
        DB::table('checkout_edit_logs')->insert([
            'checkout_id' => $checkout->id,
            'table_name' => $checkout->table_source ?? 'checkouts',
            'original_data' => json_encode($originalData),
            'updated_data' => json_encode($checkout->toArray()),
            'edit_reason' => $reason,
            'edited_by' => $userId,
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }
    
    private function logCustomerEdit($customer, $originalData, $reason, $userId)
    {
        DB::table('checkout_edit_logs')->insert([
            'checkout_id' => $customer->id,
            'table_name' => 'customers',
            'original_data' => json_encode($originalData),
            'updated_data' => json_encode($customer->toArray()),
            'edit_reason' => $reason,
            'edited_by' => $userId,
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }
}
