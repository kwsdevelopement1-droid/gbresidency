<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyUserRequest;
use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Models\Role;
use App\Models\User;
use App\Models\Room;
use App\Models\Customer;
use App\Models\AdvanceAmount;
use App\Models\Checkout;
use Gate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
use Carbon\Carbon;

class EditsettlementController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $yesterday = Carbon::yesterday()->startOfDay();
        $today = Carbon::today()->endOfDay();

        $reports = Checkout::with('customer_ids')->whereBetween('created_at', [$yesterday, $today])->get();


        return view('backend.edit_settlement.index', compact('reports'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $report = Checkout::with('customer_ids')->find($id);
        return view('backend.edit_settlement.edit', compact('report'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        abort_if(Gate::denies('financial_edit_settlement'), Response::HTTP_FORBIDDEN, '403 Forbidden - Admin Only');

        $data = $request->validate([
            'balance_amount' => 'required|numeric',
            'payment_method' => 'required|in:1,2,3,4',
        ]);

        $checkout = Checkout::findOrFail($id);
        
        // Update the checkout record with the new values
        $checkout->update([
            'balance_amount' => $data['balance_amount'],
            'payment_method' => $data['payment_method'],
        ]);

        return redirect()->route('backend.edit_settlement.index')
            ->with('success', 'Settlement amount updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
