<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\callreservation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Floor;
use App\Models\Room;
use App\Models\crfloor;


use Carbon\Carbon;


class CallreservationController extends Controller
{
    public function call_reservation_list(){
        
        // $callreservations = callreservation::orderBy('checkin_datetime', 'desc')->get();
        $callreservations = callreservation::where('status',0)->orderBy('checkin_datetime', 'asc')->get();
        return view('backend.call_Reservation.index', compact('callreservations'));
    }
    
     public function call_reservation_list_all(){
        
        // $callreservations = callreservation::orderBy('checkin_datetime', 'desc')->get();
        $callreservations = callreservation::orderBy('checkin_datetime', 'asc')->get();
        return view('backend.call_Reservation.all', compact('callreservations'));
    }
    
 public function call_reservation_create()
{
    // Fetch floors and their associated rooms
    // $floors = DB::table('floors')
    //     ->join('floor_room', 'floors.id', '=', 'floor_room.floor_id')
    //     ->join('rooms', 'floor_room.room_id', '=', 'rooms.id')
    //     ->select('floors.id as floor_id', 'floors.name as floor_name', 'rooms.id as room_id', 'rooms.name as room_name')
    //     ->get()
    //     ->groupBy('floor_id'); 
        // Group by floor_id for easy access in the view
        
        // dd($floors);
        
        
        $floors = crfloor::all();
        
        // dd($floors);
        

    return view('backend.call_Reservation.Create', compact('floors'));
}

   
   
   
   public function call_reservation_create_save(Request $request)
{
//   dd( $request);
  
     $floorString = collect($request->floor_count)
        ->map(function ($count, $floor) {
            return "$floor: $count";
        })
        ->join(', ');
    $booking_by = auth()->user()->name;
    
    $callreservation = new callreservation();
    $callreservation->guest_name = $request->input('guest_name');
    $callreservation->contact_no = $request->input('contact_no');
    // $callreservation->guest_details = $request->input('guest_details');
    $callreservation->reference = $request->input('reference');
    $callreservation->checkin_datetime = $request->input('checkin_datetime');
    $callreservation->checkout_datetime = $request->input('checkout_datetime');
    $callreservation->place = $request->input('Place');
   
    $callreservation->rooms = $floorString;
    $callreservation->booking_by = $booking_by;
    $callreservation->status = '0';
    $callreservation->save();

    return redirect()->route('backend.call_reservation_list')->with('success', 'Reservation Added successfully');
}

public function editReservation($id)
{
    // Fetch reservation by ID
    $reservation = callreservation::findOrFail($id);
    
    // dd($reservation->rooms);

    // Fetch floors and associated rooms
     $floors = crfloor::all();
        
        

    return view('backend.call_Reservation.edit', compact('reservation', 'floors'));
}

public function updateReservation(Request $request, $id)
{
    
    
// dd($request->status);
    $reservation = callreservation::findOrFail($id);

    $floorString = collect($request->floor_count)
        ->map(function ($count, $floor) {
            return "$floor: $count";
        })
        ->join(', ');

    $reservation->guest_name = $request->input('guest_name');
    $reservation->contact_no = $request->input('contact_no');
    // $reservation->guest_details = $request->input('guest_details');
    $reservation->reference = $request->input('reference');
    $reservation->checkin_datetime = $request->input('checkin_datetime');
    $reservation->checkout_datetime = $request->input('checkout_datetime');
    $reservation->place = $request->input('Place');
    $reservation->alloted_rooms = $request->input('alloted_rooms');
    $reservation->rooms = $floorString;
    
    if($request->status == 1){
         $reservation->status = 1;
    }
    elseif($request->status == 2){
         $reservation->status = 2;
    }
    else{
    $reservation->status = 0;
    }
    
    
    $reservation->save();

    return redirect()->route('backend.call_reservation_list')->with('success', 'Reservation updated successfully');
}






public function checkRoomConflicts(Request $request)
{
    $floorId = $request->floor_name;
    $checkin = $request->checkin_datetime;
    $checkout = $request->checkout_datetime;

    // Fetch reservations that overlap with the given time range
    $conflicts = DB::table('callreservations')
        ->where('floors', 'like', "%\"$floorId\"%") // Match the selected floor
        ->where(function ($query) use ($checkin, $checkout) {
            $query->whereBetween('checkin_datetime', [$checkin, $checkout])
                  ->orWhereBetween('checkout_datetime', [$checkin, $checkout])
                  ->orWhereRaw('? BETWEEN checkin_datetime AND checkout_datetime', [$checkin])
                  ->orWhereRaw('? BETWEEN checkin_datetime AND checkout_datetime', [$checkout]);
        })
        ->select('rooms', 'checkin_datetime', 'checkout_datetime') // Use the 'rooms' column
        ->get();

    // Parse the results for room conflicts
    $conflictedRooms = [];
    foreach ($conflicts as $conflict) {
        $rooms = json_decode($conflict->rooms, true); // Decode the JSON array
        foreach ($rooms as $room) {
            $conflictedRooms[] = [
                'room' => $room,
                'checkin' => $conflict->checkin_datetime,
                'checkout' => $conflict->checkout_datetime
            ];
        }
    }

    return response()->json($conflictedRooms);
}


public function destroy($id)
{
    // Find the reservation by ID
    $reservation = CallReservation::findOrFail($id);

    // Delete the reservation
    $reservation->delete();

    // Redirect back with a success message
    return redirect()->route('backend.call_reservation_list')->with('success', 'Reservation deleted successfully.');
}




}
