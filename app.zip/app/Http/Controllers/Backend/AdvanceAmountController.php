<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyAdvanceAmountRequest;
use App\Http\Requests\StoreAdvanceAmountRequest;
use App\Http\Requests\UpdateAdvanceAmountRequest;
use App\Models\AdvanceAmount;
use App\Models\Customer;
use App\Models\Country;
use App\Models\Floor;
use App\Models\Room;
use App\Models\Gst;
use App\Models\Discount;
use App\Models\Roomtype;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdvanceAmountController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('advance_amount_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::pluck('name', 'id');
        $countries = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $nationalities = Country::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');
        $gst = Gst::withTrashed()->latest()->first();
        
        $room_types = Floor::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.advance_amount', compact('floors','countries', 'nationalities', 'room_types','gst'));


    }

    public function create()
    {
        abort_if(Gate::denies('advance_amount_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $customer_ids = Customer::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('admin.advanceAmounts.create', compact('customer_ids'));
    }

    public function store(StoreAdvanceAmountRequest $request)
    {
        $advanceAmount = AdvanceAmount::create($request->all());

        return response()->json(['message' => 'Advance Amount Successfully added']);
    }

    public function edit(AdvanceAmount $advanceAmount)
    {
        abort_if(Gate::denies('advance_amount_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $customer_ids = Customer::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $advanceAmount->load('customer_ids');

        return view('admin.advanceAmounts.edit', compact('advanceAmount', 'customer_ids'));
    }

    public function update(UpdateAdvanceAmountRequest $request, AdvanceAmount $advanceAmount)
    {
        $advanceAmount->update($request->all());

        return redirect()->route('admin.advance-amounts.index');
    }

    public function show(AdvanceAmount $advanceAmount)
    {
        abort_if(Gate::denies('advance_amount_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $advanceAmount->load('customer_ids');

        return view('admin.advanceAmounts.show', compact('advanceAmount'));
    }

    public function destroy(AdvanceAmount $advanceAmount)
    {
        abort_if(Gate::denies('advance_amount_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $advanceAmount->delete();

        return back();
    }

    public function massDestroy(MassDestroyAdvanceAmountRequest $request)
    {
        $advanceAmounts = AdvanceAmount::find(request('ids'));

        foreach ($advanceAmounts as $advanceAmount) {
            $advanceAmount->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }
}