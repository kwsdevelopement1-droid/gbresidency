<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyFloorRequest;
use App\Http\Requests\StoreFloorRequest;
use App\Http\Requests\UpdateFloorRequest;
use App\Models\Floor;
use App\Models\Room;
use App\Models\Roomtype;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class FloorController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('floor_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floors = Floor::with(['select_rooms', 'select_room_type'])->get();

        return view('backend.floors.index', compact('floors'));
    }

    public function create()
    {
        abort_if(Gate::denies('floor_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $select_rooms = Room::pluck('name', 'id');

        $select_room_types = Roomtype::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        return view('backend.floors.create', compact('select_room_types', 'select_rooms'));
    }

    public function store(StoreFloorRequest $request)
    {
        $floor = Floor::create($request->all());
        $floor->select_rooms()->sync($request->input('select_rooms', []));

        return redirect()->route('backend.floors.index');
    }

    public function edit(Floor $floor)
    {
        abort_if(Gate::denies('floor_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $select_rooms = Room::pluck('name', 'id');

        $select_room_types = Roomtype::pluck('name', 'id')->prepend(trans('global.pleaseSelect'), '');

        $floor->load('select_rooms', 'select_room_type');

        return view('backend.floors.edit', compact('floor', 'select_room_types', 'select_rooms'));
    }

    public function update(UpdateFloorRequest $request, Floor $floor)
    {
        $floor->update($request->all());
        $floor->select_rooms()->sync($request->input('select_rooms', []));

        return redirect()->route('backend.floors.index');
    }

    public function show(Floor $floor)
    {
        abort_if(Gate::denies('floor_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floor->load('select_rooms', 'select_room_type');

        return view('backend.floors.show', compact('floor'));
    }

    public function destroy(Floor $floor)
    {
        abort_if(Gate::denies('floor_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $floor->delete();

        return back();
    }

    public function massDestroy(MassDestroyFloorRequest $request)
    {
        $floors = Floor::find(request('ids'));

        foreach ($floors as $floor) {
            $floor->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }
}