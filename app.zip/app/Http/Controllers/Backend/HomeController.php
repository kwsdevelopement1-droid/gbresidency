<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyCustomerRequest;
use App\Http\Requests\StoreCustomerRequest;
use App\Http\Requests\UpdateCustomerRequest;
use App\Models\Country;
use App\Models\Customer;
use App\Models\Floor;
use App\Models\ModificationCheckin;
use Gate;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class HomeController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('customer_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $customers = Customer::where('status', 1)->with([
            'customerDetail', 'discount_ids', 'checkOut', 'advanceAmount', 'country', 'nationality',
            'room_type', 'select_rooms', 'houseguest', 'refund', 'user_ids', 'extraBedsData'
        ])->orderBy('created_at', 'asc')->get();

        // $customers = Customer::with(['country','customerDetail', 'nationality', 'room_type', 'select_rooms'])
        // ->orderBy('created_at', 'desc')
        // ->get();

        // $modificationCheckins = ModificationCheckin::with(['customer_ids', 'romms'])->orderBy('created_at', 'desc')
        // ->get();
        // return $customers;
        return view('backend.home', compact('customers'));
    }





}
