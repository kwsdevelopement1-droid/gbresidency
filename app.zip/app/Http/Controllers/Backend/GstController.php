<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyGstRequest;
use App\Http\Requests\StoreGstRequest;
use App\Http\Requests\UpdateGstRequest;
use App\Models\Gst;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class GstController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('gst_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $gsts = Gst::all();

        return view('admin.gsts.index', compact('gsts'));
    }

    public function create()
    {
        abort_if(Gate::denies('gst_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.gsts.create');
    }

    public function store(StoreGstRequest $request)
    {
        $gst = Gst::create($request->all());

        return redirect()->route('admin.gsts.index');
    }

    public function edit(Gst $gst)
    {
        abort_if(Gate::denies('gst_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.gsts.edit', compact('gst'));
    }

    public function update(UpdateGstRequest $request, Gst $gst)
    {
        $gst->update($request->all());

        return redirect()->route('admin.gsts.index');
    }

    public function show(Gst $gst)
    {
        abort_if(Gate::denies('gst_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.gsts.show', compact('gst'));
    }

    public function destroy(Gst $gst)
    {
        abort_if(Gate::denies('gst_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $gst->delete();

        return back();
    }

    public function massDestroy(MassDestroyGstRequest $request)
    {
        $gsts = Gst::find(request('ids'));

        foreach ($gsts as $gst) {
            $gst->delete();
        }

        return response(null, Response::HTTP_NO_CONTENT);
    }
}