<?php

namespace App\Http\Controllers\HomeSakthi;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\URL;
use App\Models\onlinerooms; 
use Illuminate\Http\Request;
use App\Models\onlineuser; 
use App\Models\blockcheckindate;
use App\Models\onlinereservation;
use App\Models\favourite;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;


class CustomerHomeController extends Controller
{
    public function index()
    {
        $rooms = DB::table('onlinerooms')
            ->limit(4)
            ->get();
        //$rooms= onlinerooms::all();->orderBy('roomname', 'asc')
        
        return view('customer.index',compact('rooms'));
    }

    public function seeall()
    {
        $rooms= onlinerooms::all();
        
        return view('customer.hotel_listing',compact('rooms'));
    }
    
    
    

    public function room_detail(onlinerooms $room)
    {
         $available_rooms= onlinerooms::all();
         
         $isFavorite = Auth::guard('onlineusers')->check() && 
                       favourite::where('user_id', Auth::guard('onlineusers')->id())
                              ->where('room_id', $room->id)
                              ->exists();
        
        return view('customer.hotel_details',compact('room','available_rooms','isFavorite'));
    }
    
    
     public function my_account()
    {
          $User = Auth::guard('onlineusers')->user();
        return view('customer.my_account',compact('User'));
    }
    
    
    public function checkEmail(Request $request)
    {
        $email = $request->input('email');
        $exists = onlineuser::where('email', $email)->exists();

        return response()->json(['exists' => $exists]);
    }
    
    
    public function my_account_save(Request $request)
    {
       
        $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:15',
            'profile' => 'required',
        ]);


        if ($request->hasFile('profile') && $request->file('profile')->isValid()) {
           
            $small_img_1 = uniqid() . time() . '.' . $request->file('profile')->extension();
            $image = url('/') . '/profiles/' . $small_img_1;

            $request->file('profile')->move(public_path('profiles'), $small_img_1);
           
        } else {
            // Handle the case when the file is not uploaded or not valid
            $errorMessage = "Error uploading the file.";
            return redirect()->back()->with('error', $errorMessage);
        }
                 $User = Auth::guard('onlineusers')->user();
         $User->name=$request->input('name');
         $User->phone=$request->input('phone');
         $User->profile=$image;
        $User->save();

        
        return redirect()->back()->with('success', 'Updated successful!');
    }
    
      public function settings()
    {
          
        return view('customer.setting');
    }
    public function settings_save(Request $request)
{
    // dd($request);
    // Validate the request data
    $request->validate([
        'old_password' => 'required',
        'new_password' => 'required|min:8|confirmed',
    ]);

    $user = Auth::guard('onlineusers')->user();

    // Check if the entered old password matches the stored password
    if (!Hash::check($request->old_password, $user->password)) {
    //   dd($request->old_password);
        return redirect()->back()->with('error', 'Old password does not match.');
    }
//   dd($request->new_password);
    // Update the user's password
    $user->password = Hash::make($request->new_password);
    $user->save();

    return redirect()->back()->with('success', 'Password updated successfully!');
}
    
   public function privacy()
    {
        return view('customer.privacy');
    }
    
     public function terms()
    {
        return view('customer.terms');
    }
    
     public function cancelpolicy()
    {
        return view('customer.cancelpolicy');
    }
    
    
    
    public function booking(onlinerooms $room)
    {
        $blockdates = blockcheckindate::all();
        return view('customer.booking_details_1',compact('room','blockdates'));
    }

    public function booking_bill()
    {
        return view('customer.booking_details_3');
    }
    
    public function favorites()
    {
        $favoriteRoomIds = favourite::where('user_id', auth('onlineusers')->id())
                                ->pluck('room_id')
                                ->toArray();
        $rooms = Onlinerooms::whereIn('id', $favoriteRoomIds)->get();
        
        return view('customer.favorites',compact('rooms'));
    }
    
     public function register(Request $request)
    {
       
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:onlineusers',
            'phone' => 'required|string|max:15',
            'password' => 'required|string|min:4|confirmed',
        ]);

        
        $user = new onlineuser([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'password' => Hash::make($request->password),
        ]);

       
        $user->save();

        
        return redirect()->back()->with('success', 'Registration successful!');
    }
    
    public function login(Request $request)
    {
        /*$request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
        ]);

        $credentials = $request->only('email', 'password');

        if (Auth::guard('onlineusers')->attempt($credentials, $request->filled('remember'))) {
            $request->session()->regenerate();

          return back();
        
        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ]);*/
        
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email',
            'password' => 'required|string|min:6',
        ]);

        $credentials = $request->only('email', 'password');
        
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        if (Auth::guard('onlineusers')->attempt($credentials, $request->filled('remember'))) {
            $request->session()->regenerate();
            return response()->json(['success' => true, 'message' => 'Login successful.']);
          //return back();
        
        }
        return response()->json(['success' => false, 'message' => 'Invalid credentials.'], 401);
    }



// public function onlinereservation(onlinerooms $room, Request $request)
// {
//     $validator = Validator::make($request->all(), [
//         'Checkindate' => 'required|date',
//         'checkintime' => 'required|date_format:H:i',
//         'checkoutdate' => 'required|date',
//         'checkouttime' => 'required|date_format:H:i',
//         'billing_address' => 'required|string|max:255',
//         'billing_city' => 'required|string|max:100',
//         'billing_state' => 'required|string|max:100',
//         'billing_zip' => 'required|string|max:20',
//         'billing_country' => 'required|string|max:100',
//     ]);

//     if ($validator->fails()) {
//         return redirect()->back()->withErrors($validator)->withInput();
//     }

//     try {
//         $User = Auth::guard('onlineusers')->user();

//         $model = new onlinereservation();
//         $model->username = $User->name;
//         $model->email = $User->email;
//         $model->phone = $User->phone;
//         $model->roomtype = $room->roomname;
//         $model->reservationcharge = $room->reservationprice;
//         $model->Checkindate = $request->input('Checkindate');
//         $model->checkintime = $request->input('checkintime');
//         $model->checkoutdate = $request->input('checkoutdate');
//         $model->checkouttime = $request->input('checkouttime');
//         $model->billing_address = $request->input('billing_address');
//         $model->billing_city = $request->input('billing_city');
//         $model->billing_state = $request->input('billing_state');
//         $model->billing_zip = $request->input('billing_zip');
//         $model->billing_country = $request->input('billing_country');
//         $model->save();

//         $order_id = 'APL' . $model->id;
//         $amount = $model->reservationcharge;
//         $currency = 'INR';

//         // CCAvenue credentials
//         $merchantId = config('payment.ccavenue.merchant_id');
//         $accessCode = config('payment.ccavenue.access_code');
//         $workingKey = config('payment.ccavenue.working_key');

//         $redirect_url = route('HomeSakthi.paysuccess');
//         $cancel_url = route('HomeSakthi.paycancel');

//         $merchant_data = [
//             'tid' => uniqid(),
//             'merchant_id' => $merchantId,
//             'order_id' => $order_id,
//             'amount' => $amount,
//             'currency' => $currency,
//             'redirect_url' => $redirect_url,
//             'cancel_url' => $cancel_url,
//             'billing_name' => $model->username,
//             'billing_address' => $model->billing_address,
//             'billing_city' => $model->billing_city,
//             'billing_state' => $model->billing_state,
//             'billing_zip' => $model->billing_zip,
//             'billing_country' => $model->billing_country,
//             'billing_tel' => $model->phone,
//             'billing_email' => $model->email,
//             'language' => 'EN',
//         ];

//         $checksum = $this->calculateChecksum($merchant_data, $workingKey);

//         $form = '<form id="ccavenuForm" method="post" action="https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction">';
//         foreach ($merchant_data as $key => $value) {
//             $form .= '<input type="hidden" name="' . $key . '" value="' . $value . '">';
//         }
//         $form .= '<input type="hidden" name="checksum" value="' . $checksum . '">';
//         $form .= '<input type="hidden" name="access_code" value="' . $accessCode . '">'; // Add access_code here
//         $form .= '</form>';

//         $script = '<script>document.getElementById("ccavenuForm").submit();</script>';

//         return response($form . $script);
//     } catch (\Exception $e) {
//         return redirect()->back()->with('error', 'Reservation failed: ' . $e->getMessage());
//     }
// }

// private function calculateChecksum($merchant_data, $workingKey)
// {
//     ksort($merchant_data);
//     $queryString = http_build_query($merchant_data);
//     $checksum = hash_hmac('sha256', $queryString, $workingKey);
//     return $checksum;
// }







    
     public function paysuccess(Request $request){
         
          $encResponse = $request->input('encResp');

        // Decrypt the response using your working key
        $workingKey = config('payment.ccavenue.working_key'); 
        $decryptedData = $this->decryptCC($encResponse, $workingKey);

        // Parse the decrypted response
        parse_str($decryptedData, $response);
        
       if (isset($response['order_status']) && $response['order_status'] == 'Failure') {
        return redirect()->route('HomeSakthi.paycancel');
    }
       
        else{
        
         DB::table('onlinereservations')
            ->where('id', $response['merchant_param1'])
            ->update([
                'status' => 4,
                'order_id' => $response['order_id'],
                'booking_date' => $response['trans_date']
            ]);
        
        $detail = DB::table('onlinereservations')
            ->where('id', $response['merchant_param1'])->first();     
            
        
        
        return view('customer.paysuccess',compact('response','detail'));
        
    }
     }
    
    public function paycancel(){
        
         return view('customer.paycancel');
        
    }
    
    
    
    
    
    public function onlinereservation(onlinerooms $room, Request $request)
{
    
    
    
    
    
    
    
    
    
    $User = Auth::guard('onlineusers')->user();

        $model = new onlinereservation();
        $model->user_id = $User->id;
        $model->username = $User->name;
        $model->email = $User->email;
        $model->phone = $User->phone;
        $model->roomtype = $room->roomname;
        $model->roomimage = $room->single_image;
        $model->reservationcharge = $room->reservationprice;
        $model->Checkindate = $request->input('Checkindate');
        $model->checkintime = $request->input('checkintime');
        $model->checkoutdate = $request->input('checkoutdate');
        $model->checkouttime = $request->input('checkouttime');
        $model->billing_address = $request->input('billing_address');
        $model->billing_city = $request->input('billing_city');
        $model->billing_state = $request->input('billing_state');
        $model->billing_zip = $request->input('billing_zip');
        $model->billing_country = $request->input('billing_country');
        $model->idproof = $request->input('idproof');
        $model->save();


      $room_id = $room->id; 

      $order_id = 'GBR' . $model->id;
      $amount = $model->reservationcharge;
      
      $booking_date = Carbon::now()->format('d/m/Y H:i:s');
      
      
      
       DB::table('onlinereservations')
            ->where('id', $model->id)
            ->update([
                'status' => 1,
                'order_id' => $order_id,
                'booking_date' => $booking_date
                
            ]);
            
            
    return redirect()->route('HomeSakthi.payment_details');
    
}


public function ccapayment($data){
    
    
    
    
    $model = onlinereservation::where('id',$data)->first();
    $currency = 'INR';
    

    $input['amount'] = $model->reservationcharge;
    $input['order_id'] = $model->order_id;
    $input['currency'] = $currency;
    $input['billing_name'] = $model->username;
    $input['billing_address'] = $model->billing_address;
    $input['billing_city'] = $model->billing_city;
    $input['billing_state'] = $model->billing_state;
    $input['billing_zip'] = $model->billing_zip;
    $input['billing_country'] = $model->billing_country;
    $input['billing_tel'] = $model->phone;
    $input['billing_email'] = $model->email;
    $input['merchant_param1'] =  $model->id;
    $input['redirect_url'] = route('HomeSakthi.paysuccess');
    $input['cancel_url'] = route('HomeSakthi.paycancel');
    $input['language'] = "EN";
    $input['merchant_id'] = config('payment.ccavenue.merchant_id');

    $merchant_data = "";

    $working_key = config('payment.ccavenue.working_key'); 
    $access_code = config('payment.ccavenue.access_code'); 

  //dd($working_key , $access_code);
   
    foreach ($input as $key => $value) {
        $merchant_data .= $key . '=' . $value . '&';
    }

    $encrypted_data = $this->encryptCC($merchant_data, $working_key);
    $url = config('payment.ccavenue.url') . '/transaction/transaction.do?command=initiateTransaction&encRequest=' . $encrypted_data . '&access_code=' . $access_code;




    return redirect($url);
}


public function encryptCC($plainText, $key)
{
    $key = $this->hextobin(md5($key));
    $initVector = pack("C*", 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f);
    $openMode = openssl_encrypt($plainText, 'AES-128-CBC', $key, OPENSSL_RAW_DATA, $initVector);
    $encryptedText = bin2hex($openMode);
    return $encryptedText;
}

public function decryptCC($encryptedText, $key)
{
    $key = $this->hextobin(md5($key));
    $initVector = pack("C*", 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f);
    $encryptedText = $this->hextobin($encryptedText);
    $decryptedText = openssl_decrypt($encryptedText, 'AES-128-CBC', $key, OPENSSL_RAW_DATA, $initVector);
    return $decryptedText;
}

public function pkcs5_padCC($plainText, $blockSize)
{
    $pad = $blockSize - (strlen($plainText) % $blockSize);
    return $plainText . str_repeat(chr($pad), $pad);
}

public function hextobin($hexString)
{
    $length = strlen($hexString);
    $binString = "";
    $count = 0;
    while ($count < $length) {
        $subString = substr($hexString, $count, 2);
        $packedString = pack("H*", $subString);
        if ($count == 0) {
            $binString = $packedString;
        } else {
            $binString .= $packedString;
        }

        $count += 2;
    }
    return $binString;
}

   
   
   
   
   public function payment_details(){
       
        $User = Auth::guard('onlineusers')->user();
       
       $bookings = onlinereservation::where('user_id',$User->id)
       
       ->orderBy('created_at', 'DESC')
       ->get();
       
       return view('customer.payment_details',compact('bookings'));
       
   }
   
   public function showReceipt(Request $req)
{
    $id = $req->input('id');
    
$booking = OnlineReservation::where('id', $id)->first();
    
    return view('customer.bill_receipt', compact('booking'));
}



public function favoritestore(Request $request)
    {
        $user = Auth::guard('onlineusers')->user();
        $roomId = $request->input('room_id');

        // Add or remove favorite
        $favorite = favourite::firstOrCreate([
            'user_id' => $user->id,
            'room_id' => $roomId,
        ]);

        if (!$favorite->wasRecentlyCreated) {
            $favorite->delete(); 
        }

        return response()->json([
            'success' => true,
            'is_favorite' => $favorite->wasRecentlyCreated,
        ]);
    }

}
