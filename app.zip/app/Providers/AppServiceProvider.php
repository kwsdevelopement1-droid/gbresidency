<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Database\Events\QueryExecuted;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Only listen in debug/local to avoid verbose logging in production
        if (config('app.debug')) {
            DB::listen(function (QueryExecuted $query) {
                // Safely convert bindings to string (some bindings might be objects)
                $bindings = array_map(function ($b) {
                    if (is_null($b)) return 'null';
                    if (is_bool($b)) return $b ? 'true' : 'false';
                    if (is_scalar($b)) return (string) $b;
                    // DateTime or other objects
                    if (is_object($b) && method_exists($b, '__toString')) {
                        return (string) $b;
                    }
                    if ($b instanceof \DateTimeInterface) {
                        return $b->format('Y-m-d H:i:s');
                    }
                    return json_encode($b);
                }, $query->bindings);

                Log::debug(
                    'Query: ' . $query->sql
                    . ' [' . implode(', ', $bindings) . ']'
                    . ' (' . $query->time . ' ms)'
                );
            });
        }
    }
}
