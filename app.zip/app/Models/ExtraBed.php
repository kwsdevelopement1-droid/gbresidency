<?php



namespace App\Models;



use DateTimeInterface;

use Illuminate\Database\Eloquent\Factories\HasFactory;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\SoftDeletes;



class ExtraBed extends Model

{
    use SoftDeletes, HasFactory;


    protected $table = 'extra_bed';


    protected $fillable = [

        'room_id',

        'room_no',

        'guest_id',

        'price',

        'checkin_date',

        'checkout_date',

        'checkin_status',
        'totalcost',
        'totaldays',
        'deleted_reason'

    ];


    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];


    protected function serializeDate(DateTimeInterface $date)

    {

        return $date->format('Y-m-d H:i:s');
    }
}
