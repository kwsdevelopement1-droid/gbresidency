<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

    
    class favourite extends Model
{
    protected $fillable = ['user_id' , 'room_id'];

    
    public function onlineuser()
    {
        return $this->belongsTo(onlineuser::class, 'user_id');
    }

  
    public function onlinerooms()
    {
        return $this->belongsTo(onlinerooms::class, 'room_id');
    }

}
