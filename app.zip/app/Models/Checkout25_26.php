<?php

namespace App\Models;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Checkout25_26 extends Model
{
    use SoftDeletes, HasFactory;

    public $table = 'checkouts_25-26';
    // protected $table = 'checkouts_25-26';

    public const PAYMENT_METHOD_SELECT = [
        '1' => 'Cash',
        '2' => 'Card',
        '3' => 'Credit',
        '4' => 'UPI',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'remining_time',
        'remarks',
        'payment_method',
        'cgst',
        'sgst',
        'total_amount',
        'advance_amount',
        'balance_amount',
        'customer_ids_id',
        'user_ids_id',
        'created_at',
        'updated_at',
        'deleted_at',
        'bill_no',

    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function getPaymentMethodNameAttribute()
    {
        return self::PAYMENT_METHOD_SELECT[$this->payment_method] ?? null;
    }

    public function extraBeds()
    {
        // return $this->belongsTo(Customer::class, 'customer_ids_id');
        return $this->hasMany(ExtraBed::class, 'guest_id', 'customer_ids_id');
    }
    public function getTotalCostAttribute()
    {
        // Calculate the sum of totalcost from related ExtraBed instances
        return $this->extraBeds()->sum('totalcost');
    }
    public function getEPTotalDaysAttribute()
    {
        // Calculate the sum of totalcost from related ExtraBed instances
        return $this->extraBeds()->sum('totaldays');
    }
    public function getEPCountAttribute()
    {
        // Calculate the sum of totalcost from related ExtraBed instances
        return $this->extraBeds()->count();
    }

    public function customerDetail()
    {
        // return $this->belongsTo(Customer::class, 'customer_ids_id');
        return $this->belongsTo(Customerdetail::class, 'customer_ids_id', 'customer_ids_id');
    }
    public function getDiscountAttribute()
    {
        $rent = $this->customer_ids->room_type->price * $this->numDays;
        $discountprice = $rent; // + $customer->checkOut->TotalCost; //$customer->room_type->price; Poobalan
        $discountPercentage = $this->customer_ids->discount_ids->dicount ?? 0; // Assuming discount is nullable
        $discountAmount = ($discountprice * $discountPercentage) / 100;
        $discountprice = $discountAmount;
        return $discountprice;

    }
    public function getNumDaysAttribute()
    {
        // Try to get check_in from customerDetail relationship, fallback to customer_ids->customerDetail
        $checkInDate = null;
        if ($this->customerDetail && !is_null($this->customerDetail->check_in)) {
            $checkInDate = $this->customerDetail->check_in;
        } elseif ($this->customer_ids && $this->customer_ids->customerDetail->last()) {
            $checkInDate = $this->customer_ids->customerDetail->last()->check_in;
        }
        if ($checkInDate && $this->created_at) {
            // Convert the timestamp to a datetime object
            $createdAtDate = \Carbon\Carbon::parse($this->created_at);
            $checkInDateCarbon = \Carbon\Carbon::parse($checkInDate);
            
            // Check if new grace rule applies (for bookings on or after 2025-09-29)
            $newRuleDate = \Carbon\Carbon::parse('2025-09-29');
            $graceHours = $checkInDateCarbon->gte($newRuleDate) ? 2 : 1;

            // Calculate total hours
            $totalMinutes = $checkInDateCarbon->diffInMinutes($createdAtDate);
            $totalHours = $totalMinutes / 60;
            
            // Calculate full days and remainder hours
            $fullDays = floor($totalHours / 24);
            $remainderHours = $totalHours - ($fullDays * 24);
            
            // Apply grace logic to remainder hours (applies to each day)
            $additionalCharge = 0;
            
            if ($checkInDateCarbon->gte($newRuleDate)) {
                // New rule (≥2025-09-29): 2-hour grace period
                if ($remainderHours > 1) {
                    // >25 hours total: charge full next day
                    $additionalCharge = 1;
                } else {
                    // 0-25 hours total: no penalty (within 1-hour grace)
                    $additionalCharge = 0;
                }
            } else {
                // Old rule (<2025-09-29): 1-hour grace period
                if ($remainderHours > 1) {
                    // >25 hours total: charge full next day
                    $additionalCharge = 1;
                } else {
                    // 0-25 hours total: no penalty
                    $additionalCharge = 0;
                }
            }
            
            $numDays = $fullDays + $additionalCharge;

            return $numDays > 0 ? $numDays : 1;
        } else {
            // Handle cases where there's no check-in date or created_at timestamp
            return null;
        }
    }

    /**
     * Calculate late fee (20% of room rent) ONLY within grace period
     * After grace period, full day charge is applied via numDays calculation
     */
    public function getLateFeeAttribute()
    {
        $checkInDate = optional($this->customerDetail)->check_in;
        if (!$checkInDate) {
            return 0;
        }

        $checkInDateCarbon = \Carbon\Carbon::parse($checkInDate);
        $newRuleDate = \Carbon\Carbon::parse('2025-09-29');
        
        // Only apply late fee for bookings with new grace rule
        if (!$checkInDateCarbon->gte($newRuleDate)) {
            return 0;
        }

        $createdAtDate = \Carbon\Carbon::parse($this->created_at);
        $totalHours = $createdAtDate->diffInHours($checkInDate);
        
        $baseHours = 24;
        $graceEndHours = $baseHours + 2; // 26 hours total
        
        // Apply 20% late fee ONLY if checkout is within grace period (24-26 hours)
        // After 26 hours, full day charge applies (no separate late fee)
        if ($totalHours > $baseHours && $totalHours <= $graceEndHours) {
            $roomPrice = optional($this->customer_ids->room_type)->price ?? 0;
            return $roomPrice * 0.20; // 20% of room rent
        }

        return 0;
    }

    public function hasNewGraceRule()
    {
        $checkInDate = optional($this->customerDetail)->check_in;
        if (!$checkInDate) {
            return false;
        }

        $checkInDateCarbon = \Carbon\Carbon::parse($checkInDate);
        $newRuleDate = \Carbon\Carbon::parse('2025-09-29');
        
        return $checkInDateCarbon->gte($newRuleDate);
    }
    public function getBillNumberAttribute()
    {
        // $createdAt = $this->created_at;
        // $currentYear = date('y', strtotime($createdAt));
        // if ($createdAt->format('m') >= 4) {
        //     $currentYear++;
        // }
        // $previousYear = $currentYear - 1;
        // $billNumber = "APL/{$previousYear}-{$currentYear}/{$this->id}";
        return $this->bill_no;
    }

    public function customer_ids()
    {
        // return $this->belongsTo(Customer::class, 'customer_ids_id');
        return $this->belongsTo(Customer::class, 'customer_ids_id')->with(['customerDetail',  'country', 'nationality', 'room_type', 'select_rooms']);
    }

    public function user_ids()
    {
        return $this->belongsTo(User::class, 'user_ids_id');
    }
}
