<?php

namespace App\Models;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Refuntamount extends Model
{
    use SoftDeletes, HasFactory;

    public $table = 'refuntamounts';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'amount',
        'user_ids_id',
        'customers_ids_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function user_ids()
    {
        return $this->belongsTo(User::class, 'user_ids_id');
    }

    public function customers_ids()
    {
        return $this->belongsTo(Customer::class, 'customers_ids_id');
    }
}