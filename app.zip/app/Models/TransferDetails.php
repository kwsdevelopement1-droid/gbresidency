<?php

namespace App\Models;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TransferDetails extends Model
{
    use  HasFactory;

    public $table = 'transfer_details';

    protected $dates = [
        'created_at',
        'updated_at',

    ];


    protected $fillable = [
        'cust_id',
        'from_room_id',
        'from_room_name',
        'from_room_type',
        'from_room_max',
        'from_room_adults',
        'from_room_extra',
        'to_room_type',
        'to_room_id',
        'to_room_name',
        'to_room_max',
        'to_room_price',
        'to_room_extra',
        'room_type_id',
        'user_ids_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
}
