<!DOCTYPE html>
<html>

<head>
    <title>APL Check Out Bill</title>
    <style type="text/css" media="print">
        @page {
            size: A4;
            color: #000;
            size: auto;
            margin-left: 20px;
            margin-right: 20px;
            margin-top: 5px;
            margin-bottom: 5px;
        }
    </style>
    <style>
        @media print {
            .rnd-tab {
                margin-left: 65%;
            }

        }

        .printButton {
            cursor: pointer;
            background: #bc1b1b;
            color: #fff;
            width: 100px;
            border: none;
            border-radius: 2px;
            height: 28px;
            font-size: 20px;
        }

        * {
            font-family: 'Times New Roman';
        }

        .widget {
            float: left;
            /* border: 1px solid #ccc;  */
            box-sizing: border-box;
            padding-left: 20px;
            padding-right: 20px;
        }

        .widget-1 {
            width: 20%;
            /* 20% width for Widget 1 */
        }

        .widget-2 {
            width: 60%;
            /* 50% width for Widget 2 */
        }

        .widget-3 {
            width: 20%;
            /* 30% width for Widget 3 */
        }

        .widget img {
            max-width: 100%;
            height: auto;
        }

        .clear {
            clear: both;
            /* Clear the float to prevent overlapping content */
        }

        .widget-4 {
            width: 45%;
            /* 20% width for Widget 1 */
        }

        .widget-5 {
            width: 20%;
            /* 50% width for Widget 2 */
        }

        .widget-6 {
            width: 35%;
            /* 30% width for Widget 3 */
        }

        .inline {
            display: inline;
            /* Display elements inline */
        }

        .inlineright {
            display: inline;
            text-align: right;
            /* Display elements inline */
        }

        .widget-7 {
            width: 70%;
            /* 20% width for Widget 1 */
        }

        .widget-8 {
            width: 20%;
            /* 50% width for Widget 2 */
        }

        .rnd-tab {
            margin-left: 60%;
        }

        hr.new2 {
            border-top: 2px dashed rgb(0, 0, 0);
        }


        .address {
            display: flex;
            align-items: flex-start;
        }

        .address .label {
            min-width: 100px;
            /* Adjust as needed */
            margin-right: 10px;
        }

        .address .value {
            flex-grow: 1;
            word-wrap: break-word;
            margin-left: -8px;
        }

        .th {
            font-weight: 300;
        }



        .widget-11 {
            width: 30%;
            /* 50% width for Widget 2 */
        }

        .widget-12 {
            width: 25%;
            /* 50% width for Widget 2 */
        }

        .widget-13 {
            width: 12%;
            /* 50% width for Widget 2 */
        }

        .widget-14 {
            width: 43%;
            /* 50% width for Widget 2 */
        }

        .widget-15 {
            width: 100%;
            /* 50% width for Widget 2 */
        }

        .back-button {
            display: inline-block;
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }

        .back-button:hover {
            background-color: #45a049;
        }


        table.without_border {

            border-color: white;
            width: 100%;
        }

        tr.without_border {
            border-color: white;

            border: none;
        }


         @page {
            size: A4;
            color: #000;

            margin-left: 20px;
            margin-right: 20px;
            margin-top: 5px;
            margin-bottom: 5px;
        }

        html,
        div.content {
            width: 210mm;
            height: 297mm;
            margin: auto;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
        }

        .center-me {
            display: flex;
            justify-content: center;
            align-items: center;

            height: 150px;
        }

        .firstTD {
            width: 15%;
        }

        .secondTD {
            width: 2%;
        }

        .thirdTD {
            width: 35%;

        }

        .gap {
            width: 11%;
            /* background-color: #45a049 */
        }

        .fourthTD {
            width: 15%;

        }

        .fifthTD {
            width: 2%;
        }

        .sixthTD {
            width: 30%;
        }
    </style>
    <script>
        console.log("I am here");
        console.log(JSON.stringify($req));
    </script>
</head>
<!-- <body style="padding-left:20%; padding-right:20%;"> -->

<body>

    <div style="margin-top: 20px;" id="content">
        <div class="widget widget-1 center-me">
            <img src="{{ asset('assets/img/amma-1.png') }}" alt="amma" height="160" width="115">
        </div>


        <div class="widget widget-2">
            <div style="text-align: center; line-height: 10px;">
                <p style="font-weight: 400; font-size: 18px;">Om Sakthi</p>
                <p style="font-weight: 800; font-size: 22px;"> <b>ADHIPARASAKTHI LODGING</b></p>
                <p> (ROUND BUILDING) G.S.T. ROAD,</p>
                <p> MELMARUVATHUR, CHENGALPATTU DIST - 603 319.</p>
                <p> RECEPTION PH: 044 - 27529084, 7598449853</p>

            </div>
        </div>
        <div class="widget widget-3 center-me">
            <img src="{{ asset('assets/img/APLLOGO.png') }}" alt="APL-LOGO" height="150" width="120">
        </div>
        <div class="clear"></div>
    </br>

        <div>
            <div class="widget widget-4 ">
                <div>
                    <span style="font-weight: 400;" class="inline">GSTIN:</span>
                    <span class="">33AGZPR2791L1ZF</span>
                </div>
            </div>


            <div class="widget widget-13">
                <p class="inline" style="color: transparent; padding-bottom: -10px ;">GB</p>

            </div>
            <div class="widget widget-14">
                <div style="font-weight: 500; text-align: right;">
                    <span class="inline"> E-Mail:adhiparasakthilodging@gmail.com</span>
                </div>
            </div>

        </div>
        <div class="clear"></div>



                @php
                    $currentMonth = date('n'); // Get the current month (1 to 12)

                    // Check if the current month is April or later
                    if ($currentMonth >= 4) {
                        // Finance year starts from April 1st of the current year to March 31st of the next year
                        $startYear = date('y');
                        $endYear = date('y', strtotime('+1 year'));
                    } else {
                        // Finance year starts from April 1st of the previous year to March 31st of the current year
                        $startYear = date('y', strtotime('-1 year'));
                        $endYear = date('y');
                    }

                @endphp



        <div class="clear"></div>


        @php
            $lastCustomerDetailLast = $customer->customerDetail->last();
            $lastCustomerDetailFirst = $customer->customerDetail->first();
            $dateAndTime_check_in = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $lastCustomerDetailFirst->check_in);

            // Separate the date and time components
            $date_check_in = $dateAndTime_check_in->format('d/m/Y'); // Format: DD-MM-YYYY
            $time_check_in = $dateAndTime_check_in->format('H:i:s'); // Format: HH:MM:SS

            // Create Carbon instance for current date and time
            $dateAndTime = \Carbon\Carbon::now();
            // $dateAndTime->setTimezone('Asia/Kolkata'); // Change 'Asia/Kolkata' to the desired timezone
            // Separate the date and time components for current date and time
            $date = $dateAndTime->format('d/m/Y'); // Format: DD-MM-YYYY
            $time = $dateAndTime->format('H:i:s'); // Format: HH:MM:SS (24-hour format)

            // Assuming $lastCustomerDetail->check_in is a string in 'Y-m-d H:i:s' format
            $dateAndTime_check_out = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $customer->checkOut->created_at);
            // dd($dateAndTime_check_out);
            // Separate the date and time components
            $date_check_out = $dateAndTime_check_out->format('d/m/Y'); // Format: DD-MM-YYYY
            $time_check_out = $dateAndTime_check_out->format('H:i:s'); // Format: HH:MM:SS
            $roomNames = $customer->select_rooms->pluck('name')->map(function ($name) {
                return rtrim($name, ', ');
            });

            $pax = 0;
            if ($customer->total_adult > $customer->room_type->max_person) {
                $pax = $customer->room_type->max_person + count($customer->checkOut->extraBeds);
            } else {
                $pax = $customer->total_adult;
            }

        @endphp

        <div style="margin-top: 5px">
            <table class="without_border" width="100%">
                <tbody>
                    <tr class="continued" width="100%">
                        <td class='firstTD'><span class="inline">Bill No</span></td>
                        <td class="secondTD"><span class="inline">:</span></td>
                        <td class="thirdTD"><span class="inline">@if (isset($customer->houseguest))
                    <span class="inline">M/{{ sprintf('%03d', $customer->houseguest->id) }}</span>
                @else
                    <span class="inline">{{ $customer->checkOut->BillNumber }}</span>
                @endif</b></span></td>
                        <td class="gap"> </td>
                        <td class="fourthTD" style="text-align: right"><span class="inline" >Date</span></td>
                        <td class="fifthTD">:</td>
                        <td class="sixthTD"><span class="inline">{{ \Carbon\Carbon::parse($customer->checkout->created_at)->format('d/m/Y H:i:s') }}</span></td>


                    </tr>

                    <tr class="without_border " width="100%">
                        <td class='firstTD'><span class="inline">Guest Name</span></td>
                        <td class="secondTD"><span class="inline">:</span></td>
                        <td class="thirdTD"><span class="inline"><b>{{ $customer->guest_name ?? '' }}</b></span></td>
                        <td class="gap"> </td>
                        <td class="fourthTD"><span class="inline">Room No</span></td>
                        <td class="fifthTD">:</td>
                        <td class="sixthTD"><span class="inline">{{ implode(', ', $roomNames->toArray()) }}</span></td>


                    </tr>
                    <tr class="without_border">
                        <td class='firstTD'><span class="inline">Address</span></td>
                        <td class="secondTD"><span class="inline">:</span></td>
                        <td class="thirdTD"><span class="inline">{{ wordwrap($customer->address .', ' . $customer->pincode ?? '', 50, "\n", true) }}</span></td>
                        <td class="gap"> </td>
                        <td class="fourthTD"><span class="inline">Room Type</span></td>
                        <td class="fifthTD">:</td>
                        <td class="sixthTD"><span class="inline">{{ $customer->room_type->name }}</span></td>
                    </tr>
                     <tr class="without_border">
                        <td class='firstTD'><span class="inline">Guest GSTIN</span></td>
                        <td class="secondTD"><span class="inline">:</span></td>
                        <td class="thirdTD"><span class="inline">{{ $customer->guest_gstin ?? 'NIL' }}</span></td>
                        <td class="gap"> </td>
                        <td class="fourthTD"><span class="inline">No.Of. Pax </span></td>
                        <td class="fifthTD">:</td>
                        <td class="sixthTD"><span class="inline">{{ $pax }} + {{ $customer->total_child }}</span></td>
                    </tr>
                     <tr class="without_border">
                        <td class='firstTD'><span class="inline">Nationality</span></td>
                        <td class="secondTD"><span class="inline">:</span></td>
                        <td class="thirdTD"><span class="inline">{{ $customer->nationality->name ?? 'NIL' }}</span></td>
                        <td class="gap"> </td>
                        <td class="fourthTD"><span class="inline">Mobile</span></td>
                        <td class="fifthTD">:</td>
                        <td class="sixthTD"><span class="inline">+{{ $customer->country_code . '   ' . $customer->phone_number ?? '' }}</span></td>
                    </tr>
                     <tr class="without_border">
                        <td class='firstTD'><span class="inline">Chk.In.Date</span></td>
                        <td class="secondTD"><span class="inline">:</span></td>
                        <td class="thirdTD"><span class="inline">{{ $date_check_in ?? ''}}</span></td>
                        <td class="gap"> </td>
                        <td class="fourthTD"><span class="inline">Chk.Out.Date</span></td>
                        <td class="fifthTD">:</td>
                        <td class="sixthTD"><span class="inline"> @if (isset($dateAndTime_check_out))
                            {{ $date_check_out }}
                        @else
                            {{ $date }}
                        @endif</span></td>
                    </tr>
                     <tr class="without_border">
                        <td class='firstTD'><span class="inline">Chk.In.Time </span></td>
                        <td class="secondTD"><span class="inline">:</span></td>
                        <td class="thirdTD"><span class="inline">{{ $time_check_in ?? '' }}</span></td>
                        <td class="gap"> </td>
                        <td class="fourthTD"><span class="inline">Chk.Out.Time</span></td>
                        <td class="fifthTD">:</td>
                        <td class="sixthTD"><span class="inline"> @if (isset($dateAndTime_check_out))
                            {{ $time_check_out }}
                        @else
                            {{ $time }}
                        @endif</span></td>
                    </tr>
                </tbody>


            </table>

            <div class="clear"></div>
        </div>


        <style>
            table {
                border-collapse: collapse;
                width: 100%;
            }

            tr {
                border-top: 1px solid #000000;
                border-bottom: 1px solid #000;
                border-left: none;
                border-right: none;
            }


            /* Apply dashed border to the first tr element */
            tr.dashed {
                border-style: dashed;
                border-left: none;
                border-right: none;
            }
            tr.continued {
                border-style: line;
                border-top: 1px solid #000000;
                border-bottom: 1px solid #000;
                border-left: none;
                border-right: none;
            }

            tr {
                border: none;
            }

            th,
            td {
                padding: 3px;
                text-align: left;
            }

            .trtd {
                padding-bottom: -5px;
            }

            .trgap {
                height: 15px;
            }
        </style>

        <br>

        <table style="margin-left:2%; width:94%; margin-left:4% text-align:center;">

            <tr class="dashed">
                <th style="">S.No</th>
                <th>Room No</th>
                <th>PARTICULAR'S</th>
                <th>RATE</th>
                <th>DAYS</th>
                <th style="text-align:right; padding-right:5px;">AMOUNT</th>
            </tr>
            @php
                $extraPersons = 0;
                $extraPRC = 0;
                $extraCost = 0;
                $rent = $customer->checkOut->total_amount;

            @endphp

            @if ($customer->total_adult > $customer->room_type->max_person)
                {{-- dd(); --}}
                @php
                    //   $extraPersons = $customer->room_type->max_person + $extra_count;
                    $extraPersons = $customer->room_type->max_person +count($customer->checkOut->extraBeds);
                    $extraCost = $extraPersons * $customer->room_type->extra_price * $customer->checkOut->numDays;
                    $rent = $customer->room_type->price * $customer->checkOut->numDays; //$totalRent - $extraCost + $discountAmount;
                    $extraPRC = $customer->room_type->extra_price;

                @endphp
            @endif
            @foreach ($customer->select_rooms as $key => $select_room)
                <tr class="trtd">
                    <td style="padding-left:5px;">{{ $key + 1 }}</td>
                    <td>{{ $select_room->name }}</td>
                    <td>Room Rent</td>
                    <td>{{ number_format($customer->room_type->price, 2) }}</td>
                    <td>{{ $customer->checkOut->numDays }}</td>
                    <td style="text-align:right">{{ number_format($rent, 2) }}</td>
                </tr>
            @endforeach

            @if ($extraPRC > 0)
                <tr class="trtd">
                    <td></td>
                    <td></td>
                    <td>Extra Person </td>
                    <td>{{ $extraPRC }}</td>
                    <td></td>
                    <td style="text-align:right; padding-right:5px;"> {{ number_format($customer->checkOut->TotalCost, 2) }}</td>
                </tr>
            @endif



            @php
                $discountprice = $rent;// + $customer->checkOut->TotalCost; //$customer->room_type->price; Poobalan
                $discountPercentage = $customer->discount_ids->dicount ?? 0; // Assuming discount is nullable
                $discountAmount = ($discountprice * $discountPercentage) / 100;
                $discountprice = $discountAmount;
            @endphp
            @if ($discountprice > 0)
                <tr class="trtd">
                    <td></td>
                    <td></td>
                    <td>Discount</td>
                    <td>{{ $discountPercentage }}%</td>
                    <td></td>
                    <td style="text-align:right; padding-right:5px;">{{ number_format($discountprice, 2) }}</td>
                </tr>
            @endif





            <tr class="trtd">
                <td> </td>
                <td> </td>
                <td>CGST</td>
                <td>{{ $gst ? $gst->gst_percentage / 2 . '%' : '' }}</td>
                <td>-</td>
                <td style="text-align:right; padding-right:5px;">
                    {{ $customer->checkOut ? number_format($customer->checkOut->cgst, 2) : '' }}</td>
            </tr>

            <tr class="trtd">
                <td> </td>
                <td> </td>
                <td>SGST</td>
                <td>{{ $gst ? $gst->gst_percentage / 2 . '%' : '' }}</td>
                <td>-</td>
                <td style="text-align:right; padding-right:5px;">
                    {{ $customer->checkOut ? number_format($customer->checkOut->sgst, 2) : '' }}</td>
            </tr>
            <tr class="trgap">
                <td> </td>
                <td> </td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>

        </table>
        <div class="widget widget-4 mt-10">


            <table style="width:100%; margin-left: 5%;">
                <tr style="border: none;">
                    <th width="17%">Rec.No</th>
                    <th width="18%">Amount</th>
                    <th width="30%">Date</th>
                    <th width="30%">Payment</th>
                </tr>
                @if (isset($customer->advanceAmount))
                    @foreach ($customer->advanceAmount as $key => $advanceamount)
                        @php
                            $amountInWords = '';
                            $payment_method = '';

                            // Check if payment method is set
                            if ($advanceamount->payment_method) {
                                foreach (\App\Models\Customer::PAYMENT_METHOD_SELECT as $key => $label) {
                                    if ($key == $advanceamount->payment_method) {
                                        // Match found, you can perform further operations here
                                        $payment_method = $label;
                                        break; // Exit the loop once match is found
                                    }
                                }
                            }

                        @endphp
                        <tr>
                            <td>{{ sprintf('%03d', $advanceamount->id) }}</td>
                            <td>{{ $advanceamount->advance_amount }}</td>
                            <td>{{ \Carbon\Carbon::parse($advanceamount->created_at)->format('d-m-Y') }}</td>


                            <td>{{ $advanceamount->payment_method_name }}</t>
                        </tr>
                    @endforeach
                @endif
            </table>
            <div>

            </div>
        </div>


        <div class="widget widget-5">
            <!-- <p class="inline" style="color: transparent; padding-bottom: -10px ;">GB</p> -->
        </div>

        <div class="widget widget-6">
            <table width="100%" class="rnd-tab">
                <tr style="border: none;">
                    <!-- <td></td> -->
                    <td width="50%">Rnd off</td>
                    <td width="20%">:</td>
                    <td width="30%" style="text-align: right; border-bottom: 1px solid #000">
                        @if ($customer->checkOut && number_format(fmod($customer->checkOut->total_amount, 1), 2) > 0)
                            {{ 1 - number_format(fmod($customer->checkOut->total_amount, 1), 2) }}
                        @else
                            0.00
                        @endif
                    </td>
                </tr>

                <tr style="border: none;">
                    <!-- <td></td> -->
                    <td width="50%">Gross Amount</td>
                    <td width="20%">:</td>
                    <td width="30%" style="text-align: right; border-bottom: 1px solid #000">
                        {{ $customer->checkOut ? ceil($customer->checkOut->total_amount) : '' }}.00</td>
                </tr>

                <tr style="border: none;">
                    <!-- <td></td> -->
                    <td width="50%">Advance</td>
                    <td width="20%">:</td>
                    <td width="30%" style="text-align: right; border-bottom: 1px solid #000">
                        {{ $customer->checkOut->advance_amount ?? '' }} </td>
                </tr>

                <tr style="border: none;">
                    <!-- <td></td> -->
                    <td width="50%">
                        @if (round($customer->checkOut->balance_amount) > 0)
                            Settlement
                        @else
                            Refund
                        @endif
                    </td>
                    <td width="20%">:</td>
                    <td width="30%" style="text-align: right; border-bottom: 1px solid #000">
                        {{ ceil($customer->checkOut->balance_amount) ?? '' }}.00</td>
                </tr>

            </table>


        </div>

        <div class="widget widget-4" style="width:450px">
            <div style="line-height:25px;">
                @php
                    $amountInWords = '';
                    $payment_method = '';

                    // Check if $customer->checkOut exists and is not null
                    if ($customer->checkOut) {
                        // Assuming $customer->checkOut->total_amount holds the numeric value you want to spell out
                        $amount = round($customer->checkOut->balance_amount);

                        // Create a new NumberFormatter instance to spell out the number in words
                        $numberFormatter = new NumberFormatter('en', NumberFormatter::SPELLOUT);

                        // Convert the number into words
                        $amountInWords = ucwords($numberFormatter->format($amount));

                        // Check if payment method is set
                        if ($customer->checkOut->payment_method) {
                            foreach (\App\Models\Customer::PAYMENT_METHOD_SELECT as $key => $label) {
                                if ($key == $customer->checkOut->payment_method) {
                                    // Match found, you can perform further operations here
                                    $payment_method = $label;
                                    break; // Exit the loop once match is found
                                }
                            }
                        }
                    }
                @endphp


                <p><b>Amount in words:{{ $amountInWords }}  only</b></p>
                <p> Settlement Type: <b>{{ $payment_method }}</b></p>
                @php
                    $user = null;

                    // Check if $customer->checkOut exists and is not null
                    if ($customer->user_ids_id) {
                        // Check if user_ids_id is set
                        if ($customer->user_ids_id) {
                            // Assuming \App\Models\User::find($id) returns the user object corresponding to the user_ids_id
                            $user = \App\Models\User::find($customer->user_ids_id);
                        }
                    }
                    $userCheckout = null;

                    // Check if $customer->checkOut exists and is not null
                    if ($customer->checkOut) {
                        // Check if user_ids_id is set
                        if ($customer->checkOut->user_ids_id) {
                            // Assuming \App\Models\User::find($id) returns the user object corresponding to the user_ids_id
                            $userCheckout = \App\Models\User::find($customer->checkOut->user_ids_id);
                        }
                    }
                @endphp


                <p> Checked in By : <b>{{ $user->name ?? '' }}</b></p>
                <p> F.O.A Sign Checkout By :<b> {{ $userCheckout->name ??"" }}</b> </p>
            </div>
        </div>
        <div class="widget widget-11">
            <p class="inline" style="color: transparent; padding-bottom: -10px ;">GB</p>
        </div>
        <div class="widget widget-12" style="text-align: right; margin-left:50px">
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <p> Guest Signature</p>
        </div>

        <div class="widget widget-4">

        </div>
        <div class="widget widget-15" style="text-align: center;">

            <br/>
            <b> Thanks For staying with us</b><br>
            <b> * * * * * * * * * Duplicate Bill * * * * * * * * * * * * * * *</b>
        </div>
        <div class="widget widget-15" style="text-align: center;">

        </div>
        <div class="clear"></div>
        <!--<div style="text-align:center">-->
        <!--    ஆன்மிகத்தாலும் ஆதிபராசக்தி இயக்கத்தாலும் தான் உலகில் நல்ல வழி ஏற்படும்.-->
        <!--</div>-->
        <div class="row">
            <div style="text-align:center;" id="bckButton" id="back-btn">
                <a href="javascript:history.back()" class="back-button">Back</a>
            </div>
            <div style="text-align:center;" id="printButton">
                <button class="printButton" onclick="printPage()">Print</button>

            </div>
        </div>

        <div>

            <script>
                function printPage() {
                    // Hide the print button before printing
                    document.getElementById('printButton').style.display = 'none';
                    document.getElementById('bckButton').style.display = 'none';

                    // Trigger the print action
                    window.print();
                }

                // Listen for the afterprint event
                window.addEventListener('afterprint', function() {
                    // Show the print button after the print dialog is closed
                    document.getElementById('printButton').style.display = 'block';
                });
            </script>

</body>

</html>
