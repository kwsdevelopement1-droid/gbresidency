<?php

namespace App\Models;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class Customer extends Model
{
    use SoftDeletes, HasFactory;

    public $table = 'customers';

    public const ID_PROOF_SELECT = [
        '1' => 'Aadhar',
        '2' => 'PAN',
        '3' => 'Driving Licence',
        '4' => 'Ration Smart Card',
        '5' => 'Voter ID',
        '6' => 'Govt issued ID Card',
        '7' => 'Passport ',
        '8' => 'Institution Letter ',
        '9' => 'Others '
        
    ];

    public const PAYMENT_METHOD_SELECT = [
        '1' => 'Cash',
        '2' => 'Card',
        '3' => 'Credit',
        '4' => 'UPI',
    ];

    public const STATUS_SELECT = [
        '1' => 'Blocked',
        '0' => 'Cleaned Room',
        '2' => 'Recent Vacate',
    ];

    public const CODE_RATE_SELECT = [
        '1' => 'Rack',
        '2' => 'House Guest',
    ];
    public const SEG_SELECT = [
        '1' => 'DFIT',
        '2' => 'FFIT',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    public const GUEST_TYPE_SELECT = [
        '1' => 'Regular',
        '2' => 'Walk in',
        '3' => 'Reservation',
        '4' => 'Travel Agent',
    ];

    protected $fillable = [
        'guest_type',
        'guest_name',
        'email',
        'country_code',
        'phone_number',
        'guest_gstin',
        'seg',
        'total_adult',
        'total_child',
        'country_id',
        'nationality_id',
        'address',
        'pincode',
        'id_proof',
        'id_proof_number',
        'pr_exp_date',
        'visa_exp_date',
        'room_type_id',
        'no_fo_room',
        'rate_code',
        'dicount_price',
        'price',
        'total_amount',
        'status',
        'user_ids_id',
        'discount_ids_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }
    public function check_outs()
    {
        // $checkoutDateTime = \Carbon\Carbon::parse($latestCustomerDetail->check_out);
        // $remainingDateDifference = \Carbon\Carbon::now()->diff($checkoutDateTime);

        return $this->hasMany(Customerdetail::class, 'customer_ids_id')->pluck('check_out')->where('customer_ids_id', $this->id)
            ->latest()
            ->first();;
    }

    public function latestCheckOut()
    {

        // return $this->hasOne(Customerdetail::class, 'customer_ids_id', 'id')
        // ->latest('check_out');
        return $this->hasOne(Customerdetail::class, 'customer_ids_id', 'id')
            ->latest('check_out')
            ->selectRaw('*, TIMESTAMPDIFF(HOUR, check_out, NOW()) as time_diff_hours');
    }


    public function user_ids()
    {
        return $this->belongsTo(User::class, 'user_ids_id');
    }

    public function country()
    {
        return $this->belongsTo(Country::class, 'country_id');
    }
    public function discount_ids()
    {
        return $this->belongsTo(Discount::class, 'discount_ids_id');
    }
    public function nationality()
    {
        return $this->belongsTo(Country::class, 'nationality_id');
    }

    public function checkOut()
    {

        return $this->hasOne(Checkout::class, 'customer_ids_id', 'id')->latest();
    }
    
  public function recentCheckOut()
{
    return $this->hasOne(Checkout::class, 'customer_ids_id', 'id')
        ->latestOfMany();
}

public function getLatestCheckoutAttribute()
{
    $checkoutQuery = Checkout::where('customer_ids_id', $this->id)
        ->select('id', 'customer_ids_id', 'created_at', DB::raw('"Checkout" as source_table'));

    $checkout2425Query = Checkout24_25::where('customer_ids_id', $this->id)
        ->select('id', 'customer_ids_id', 'created_at', DB::raw('"Checkout24_25" as source_table'));

    $checkoutOldQuery = CheckoutOld::where('customer_ids_id', $this->id)
        ->select('id', 'customer_ids_id', 'created_at', DB::raw('"CheckoutOld" as source_table'));

    return $checkoutQuery
        ->union($checkout2425Query)
        ->union($checkoutOldQuery)
        ->orderBy('created_at', 'desc')
        ->first();
}

    public function checkOutOld()
    {

        return $this->hasOne(CheckoutOld::class, 'customer_ids_id', 'id')->latest();
    }
    public function Checkout24_25()
    {

        return $this->hasOne(Checkout24_25::class, 'customer_ids_id', 'id')->latest();
    }
    public function Checkout25_26()
    {

        return $this->hasOne(Checkout25_26::class, 'customer_ids_id', 'id')->latest();
    }
    public function checkout_user_id()
    {
        return $this->hasOne(Checkout::class, 'user_ids_id', 'user_ids_id')->latest();
    }

    public function refund()
    {
        return $this->hasOne(Refuntamount::class, 'customers_ids_id', 'id');
    }

    public function room_type()
    {
        return $this->belongsTo(Floor::class, 'room_type_id');
    }
    public function customerDetail()
    {
        return $this->hasMany(Customerdetail::class, 'customer_ids_id', 'id');
    }
    public function houseguest()
    {
        return $this->hasOne(Houseguest::class, 'customer_ids_id', 'id');
    }
    public function monthlyguest()
    {
        return $this->hasOne(MonthlyGuests::class, 'customer_ids_id', 'id');
    }

    public function advanceAmount()
    {
        return $this->hasMany(AdvanceAmount::class, 'customer_ids_id', 'id')
            ->union($this->hasMany(AdvanceAmountOld::class, 'customer_ids_id', 'id'));
    }
    /*public function advanceAmount()
    {
        return $this->hasMany(AdvanceAmount::class, 'customer_ids_id', 'id');
    }*/

    public function scopeAllAdvanceAmount($query, $fromDate, $toDate)
    {
        return $query->with(['advanceAmount' => function ($query) use ($fromDate, $toDate) {
            $query->whereBetween('created_at', [$fromDate, $toDate]);
        }]);
    }


    public function select_rooms()
    {
        return $this->belongsToMany(Room::class)->with('floors');
    }

    public function extraBedsData()
    {
        return $this->hasMany(ExtraBed::class, 'guest_id', 'id');
    }

    //numDays
    public function getNumDaysAttribute()
    {
        $checkInDate = $this->created_at;
        $checkoutDate = \Carbon\Carbon::now();
        if ($this->status == 2) {
            $checkoutDate = $this->checkOut->created_at;
        }

        if ($checkInDate && $checkoutDate) {

            $differenceInHours = ceil($checkoutDate->diffInMinutes($checkInDate) / 60) - 1;

            if ($differenceInHours <= 24)
                $numDays  = 1;
            else
                $numDays = ceil(($differenceInHours) / 24);

            return $numDays;
        } else {
            // Handle cases where there's no check-in date or created_at timestamp
            return null;
        }
    }

    //Occupancy report related

    public function scopeWasPresentDuring($query, $from_date, $to_date)
    {
        // return $query->whereHas('checkOut', function ($subQuery) use ($fromDate, $toDate) {
        //     $subQuery->whereBetween('created_at', [$fromDate, $toDate]);
        // });
        // return $query->whereHas('customerDetail', function ($detailQuery) use ($from_date, $to_date) {
        //     $detailQuery->where(function ($subQuery) use ($from_date, $to_date) {
        //         $subQuery->whereBetween('check_in', [$from_date, $to_date])
        //             ->orWhereBetween('check_out', [$from_date, $to_date])
        //             ->orWhereNull('check_out');
        //     });
        // });
        // return $query->where(function ($query) use ($from_date, $to_date) {
        //     $query->where('status', 1)
        //         ->where('created_at', '<', $to_date)
        //         ->orWhere(function ($query) use ($from_date, $to_date) {
        //             $query->where('status', 2)
        //                 ->where(function ($subQuery) use ($from_date, $to_date) {
        //                     $subQuery->where(function ($subSubQuery) use ($from_date, $to_date) {
        //                         $subSubQuery->whereBetween('created_at', [$from_date, $to_date]);
        //                     })
        //                         ->orWhereHas('checkOut', function ($checkOutQuery) use ($from_date, $to_date) {
        //                             $checkOutQuery->whereBetween('created_at', [$from_date, $to_date]);
        //                         });
        //                 });
        //         });
        // });
        return $query->where(function ($query) use ($from_date, $to_date) {
            $query->where('status', 1)
                ->where('created_at', '<', $to_date)
                ->orWhere(function ($query) use ($from_date, $to_date) {
                    $query->where('status', 2)
                        ->where(function ($subQuery) use ($from_date, $to_date) {
                            $subQuery->whereBetween('created_at', [$from_date, $to_date])
                                ->orWhereHas('checkOut', function ($checkOutQuery) use ($from_date, $to_date) {
                                    $checkOutQuery->whereBetween('created_at', [$from_date, $to_date]);
                                });
                        });
                });
        });
    }

    public static function getCustomersWithRelatedInfo($fromDate, $toDate)
    {
        return Customer::with([
            'customerDetail',
            'discount_ids',
            'checkOut',
            'advanceAmount',
            'country',
            'nationality',
            'room_type',
            'select_rooms',
            'houseguest',
            'refund',
            'user_ids',
            'extraBedsData'
        ])->wasPresentDuring($fromDate, $toDate)
            ->orderBy('created_at', 'asc')
            ->get();
    }
}
