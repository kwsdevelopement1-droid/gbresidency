<?php

namespace App\Models;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CustomerRoom extends Model
{
    use SoftDeletes, HasFactory;

    protected $table = 'customer_room';

    protected $fillable = [
        'customer_id',
        'room_id',

    ];

}
