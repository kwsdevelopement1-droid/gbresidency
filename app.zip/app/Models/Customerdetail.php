<?php

namespace App\Models;

use Carbon\Carbon;
use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Customerdetail extends Model
{
    use SoftDeletes, HasFactory;

    public $table = 'customerdetails';

    public const PAYMENT_METHOD_SELECT = [

    ];

    protected $dates = [
        'check_in',
        'check_out',
        'days',
        'user_ids_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'customer_ids_id',
        'check_in',
        'check_out',
        'days',
        'user_ids_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function customer_ids()
    {
        return $this->belongsTo(Customer::class, 'customer_ids_id');
    }
    public function customer()
    {
        return $this->belongsTo(Customer::class, 'customer_ids_id', 'id');
    }

    // public function getCheckInAttribute($value)
    // {
    //     return $value ? Carbon::createFromFormat('Y-m-d H:i:s', $value)->format(config('panel.date_format') . ' ' . config('panel.time_format')) : null;
    // }

    // public function setCheckInAttribute($value)
    // {
    //     $this->attributes['check_in'] = $value ? Carbon::createFromFormat(config('panel.date_format') . ' ' . config('panel.time_format'), $value)->format('Y-m-d H:i:s') : null;
    // }

    // public function getCheckOutAttribute($value)
    // {
    //     return $value ? Carbon::createFromFormat('Y-m-d H:i:s', $value)->format(config('panel.date_format') . ' ' . config('panel.time_format')) : null;
    // }

    // public function setCheckOutAttribute($value)
    // {
    //     $this->attributes['check_out'] = $value ? Carbon::createFromFormat(config('panel.date_format') . ' ' . config('panel.time_format'), $value)->format('Y-m-d H:i:s') : null;
    // }
}
