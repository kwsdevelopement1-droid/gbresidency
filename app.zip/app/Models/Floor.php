<?php

namespace App\Models;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Floor extends Model
{
    use SoftDeletes, HasFactory;

    public $table = 'floors';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'name',
        'select_room_type_id',
        'price',
        'max_person',
        'extra_price',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function select_rooms()
    {
        return $this->belongsToMany(Room::class);
    }

    public function select_room_type()
    {
        return $this->belongsTo(Roomtype::class, 'select_room_type_id');
    }

    public function rooms()
    {
        return $this->belongsToMany(Room::class, 'floor_room', 'floor_id', 'room_id');
    }
}
