<?php

namespace App\Models;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AdvanceAmount extends Model
{
    use SoftDeletes, HasFactory;

    public $table = 'advance_amounts';

    public const PAYMENT_METHOD_SELECT = [
        '1' => 'Cash',
        '2' => 'Card',
        '3' => 'Credit',
        '4' => 'UPI',
    ];

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'customer_ids_id',
        'advance_amount',
        'payment_method',
        'user_ids_id',
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }


    public function getPaymentMethodNameAttribute()
    {
        return self::PAYMENT_METHOD_SELECT[$this->payment_method] ?? null;
    }

    public function customer_ids()
    {
        return $this->belongsTo(Customer::class, 'customer_ids_id')->with(['customerDetail',  'country', 'nationality', 'room_type', 'select_rooms']);
    }

}
