<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Authenticatable as AuthenticatableTrait;

class OnlineUser extends Model implements Authenticatable


{
    use HasFactory;
    
    protected $table = 'onlineusers';

    
    protected $fillable = [
        'name', 'email', 'phone', 'password',
    ];
    
    
     use \Illuminate\Auth\Authenticatable;

    public function getAuthIdentifierName()
    {
        return 'id'; // The column name of the primary key
    }

    public function getAuthIdentifier()
    {
        return $this->{$this->getAuthIdentifierName()};
    }

    public function getAuthPassword()
    {
        return $this->password; // Assuming your password column is named 'password'
    }

    public function getRememberToken()
    {
        return $this->remember_token; // Assuming your remember token column is named 'remember_token'
    }

    public function setRememberToken($value)
    {
        $this->remember_token = $value; // Assuming your remember token column is named 'remember_token'
    }

    public function getRememberTokenName()
    {
        return 'remember_token'; // The name of the remember token column
    }
}
