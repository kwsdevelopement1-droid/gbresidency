<?php

use App\Http\Controllers\Backend\TempController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::redirect('/', '/backend');
// Route::get('/home', function () {
//     if (session('status')) {
//         return redirect()->route('backend.home')->with('status', session('status'));
//     }

//     return redirect()->route('backend.home');
// });

Auth::routes(['register' => false]);

Route::group(['prefix' => 'backend', 'as' => 'backend.', 'namespace' => 'Backend', 'middleware' => ['auth']], function () {
    Route::get('/', 'HomeController@index')->name('home');
    // Permissions
    Route::delete('permissions/destroy', 'PermissionsController@massDestroy')->name('permissions.massDestroy');
    Route::resource('permissions', 'PermissionsController');

    // Roles
    Route::delete('roles/destroy', 'RolesController@massDestroy')->name('roles.massDestroy');
    Route::resource('roles', 'RolesController');

    // Users
    Route::delete('users/destroy', 'UsersController@massDestroy')->name('users.massDestroy');
    Route::resource('users', 'UsersController');

    //edit_advance

    // Route::delete('advance/destroy', 'EditadvanceController@massDestroy')->name('advance.massDestroy');
    Route::resource('edit_advance', 'EditadvanceController');

    //edit_settlement

    // Route::delete('settlement/destroy', 'EditsettlementController@massDestroy')->name('settlement.massDestroy');
    Route::resource('edit_settlement', 'EditsettlementController');

    //Remove Extra Bed

    // Route::delete('extrabed/destroy', 'RemoveextrabedController@massDestroy')->name('extrabed.massDestroy');
    Route::resource('remove_extrabed', 'RemoveextrabedController');



    // Room
    Route::delete('rooms/destroy', 'RoomController@massDestroy')->name('rooms.massDestroy');
    Route::resource('rooms', 'RoomController');

    // Roomtype
    Route::delete('roomtypes/destroy', 'RoomtypeController@massDestroy')->name('roomtypes.massDestroy');
    Route::resource('roomtypes', 'RoomtypeController');

    // Floor
    Route::delete('floors/destroy', 'FloorController@massDestroy')->name('floors.massDestroy');
    Route::resource('floors', 'FloorController');

    // Countries
    Route::delete('countries/destroy', 'CountriesController@massDestroy')->name('countries.massDestroy');
    Route::resource('countries', 'CountriesController');

    // Customer
    Route::delete('customers/destroy', 'CustomerController@massDestroy')->name('customers.massDestroy');
    Route::resource('customers', 'CustomerController');
    Route::post('customers/advance', 'CustomerController@advancestore')->name('advance');




    // Customerdetail
    Route::delete('customerdetails/destroy', 'CustomerdetailController@massDestroy')->name('customerdetails.massDestroy');
    Route::resource('customerdetails', 'CustomerdetailController');
    Route::resource('checkouts', 'CheckoutController');
    Route::resource('floor-wise', 'FloorWiseController')->only(['index']);
    Route::resource('facility-wise', 'FacilityWiseController')->only(['index']);

    //extra checkin & checkout

    Route::get('extra-check-in', 'CheckInController@showExtraCheckIn')->name('extra-checkin');
    Route::get('extra-check-out', 'CheckInController@showExtraCheckOut')->name('extra-checkout');

    //Extra Bed
    Route::post('/extrabed/checkin', 'ExtraBedController@check_in')->name('extraCheckIn');
    Route::post('/extrabed/check_out_extra', 'ExtraBedController@check_out_extra')->name('extraCheckOut');

    //Check-in
    Route::resource('check-in', 'CheckInController')->only(['index']);
    Route::post('/ajax/data', 'CheckInController@ajax_data')->name('ajax_data');
    Route::post('/ajax/data/phone_no', 'CheckInController@ajax_data_phone_no')->name('phone_number');
    Route::post('/ajax/data/bill_no', 'CheckInController@ajax_data_bill_no')->name('ajax_data_bill_no');
    Route::post('/ajax/data/room_no', 'CheckInController@ajax_data_room_no')->name('ajax_data_room_no');

    Route::post('/ajax/data/price', 'CheckInController@ajax_data_price')->name('ajax_data_price');
    Route::get('check-in-modification', 'CheckInController@modification_index')->name('check-in-modification.index');

    //Transfer /Promotion
    Route::get('room_transfer', 'CheckInController@RoomTransferIndex')->name('room.transfer.index');
    Route::post('room_transfer', 'CheckInController@RoomTransferFilter')->name('room.transfer.filter');
    Route::post('room_transfer_submit', 'CheckInController@RoomTransferSubmit')->name('room.transfer.submit');

    Route::post('/ajax/data/ajax_data_modification', 'CheckInController@ajax_data_modification')->name('ajax_data_modification');
    Route::get('check-out', 'CheckInController@check_out')->name('check-out.index');
    Route::get('room-cancelation', 'CheckInController@room_cancelation')->name('room_cancelation.index');
    Route::post('room-cancelation-post', 'CheckInController@storecancelation')->name('check-in-cancellations.store');
    Route::get('bill-statement', 'CheckInController@bill_index')->name('bill-statement.index');
    Route::get('bill-statement/{id}', 'CheckInController@advanceUPdf')->name('bill-statement.advance-pdf');
    Route::get('bill-statement-second/{id}', 'CheckInController@secondUPdf')->name('bill-statement.second-pdf');

    Route::get('bill-statement-secondtemp/{id}', 'ReportsController@secondUPdf')->name('bill-statement.secondtemp-pdf');

    Route::get('room-status', 'CheckInController@room_status_index')->name('room.status.index');
    Route::post('room-status-post', 'CheckInController@room_status_store')->name('room_status_store');

    Route::get('cashier-report', 'CheckInController@CashierReportindex')->name('cashier.report.index');
    Route::post('cashier-report-filtter', 'CheckInController@CashierReportFillter')->name('cashier.report.fillter');

    Route::get('advance-report', 'CheckInController@AdvanceReportindex')->name('advance.report.index');
    Route::post('advance-report', 'CheckInController@AdvanceReportFillter')->name('advance.report.filter');

    Route::get('report_daily_collection', 'ReportsController@DailyCollectionReportindex')->name('daily.collection.report.index');
    Route::post('report_daily_collection', 'ReportsController@DailyCollectionReportFillter')->name('daily.collection.report.filter');

    Route::get('extent', 'CheckInController@extent_index')->name('extent.index');
    Route::post('extent-store', 'CheckInController@extent_store')->name('extent.store');
    Route::get('foreigners-report', 'CheckInController@ForeignersGuestListindex')->name('foreigners.report.index');

    Route::get('credit_bills_collection', 'ReportsController@CreditBillCollectionReportindex')->name('credit.collection.report.index');
    Route::post('credit_bills_collection', 'ReportsController@CreditBillCollectionReportFillter')->name('credit.collection.report.filter');

    Route::get('credit_cards_collection', 'ReportsController@CreditCardCollectionReportindex')->name('credit.card.collection.report.index');
    Route::post('credit_cards_collection', 'ReportsController@CreditCardCollectionReportFillter')->name('credit.card.collection.report.filter');

    Route::get('occupancy_report', 'ReportsController@OccupancyReportindex')->name('occupancy.report.index');
    Route::post('occupancy_report', 'ReportsController@OccupancyReportFillter')->name('occupancy.report.filter');

    Route::get('report_checkin', 'ReportsController@CheckInReportindex')->name('checkin.report.index');
    Route::post('report_checkin', 'ReportsController@CheckInReportFillter')->name('checkin.report.filter');

    Route::get('report_checkout', 'ReportsController@CheckOutReportIndex')->name('checkout.report.index');
    Route::post('report_checkout', 'ReportsController@CheckOutReportFillter')->name('checkout.report.filter');



    Route::get('excel_collection', 'ReportsController@ExcelCollectionReportindex')->name('excel.collection.report.index');
    Route::post('excel_collection', 'ReportsController@ExelCollectionReportFillter')->name('excel.collection.report.filter');

    Route::get('room_status', 'ReportsController@GetRoomStatus')->name('room.status.report.index');

    Route::get('guest_folio', 'ReportsController@GuestFolioIndex')->name('guest.folio.index');
    Route::post('guest_folio', 'ReportsController@GuestFolioFilter')->name('guest.folio.filter');

    // Advance Amount
    Route::resource('advance-amounts', 'AdvanceAmountController');

    Route::post('advance_duplicate', 'AdminController@GetDuplicateAdvanceReciept')->name('advance.duplicate');


    Route::get('generate_pdf/{id}', 'TempController@secondUPdf')->name('pdf.filter');
    Route::get('high_balance', 'ReportsController@HighBalanceReportindex')->name('high.balance.report.index');


});

Route::group(['prefix' => 'profile', 'as' => 'profile.', 'namespace' => 'Auth', 'middleware' => ['auth']], function () {
    // Change password
    if (file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))) {
        Route::get('password', 'ChangePasswordController@edit')->name('password.edit');
        Route::post('password', 'ChangePasswordController@update')->name('password.update');
        Route::post('profile', 'ChangePasswordController@updateProfile')->name('password.updateProfile');
        Route::post('profile/destroy', 'ChangePasswordController@destroy')->name('password.destroyProfile');
    }
});
