@extends('layouts.backend')
@section('content')
@section('title_nav')

<div class="row title-card">

    <h2 class="d-flex align-items-center justify-content-center">Edit Room</h2>
    </div>
    @endsection
    <div class="row">
        <div class="col-md-3">
           @include('backend.include.sidebar')
        </div>
        <div class="col-md-9">
            <form class="" method="POST" action="{{ route("backend.rooms.update", [$room->id]) }}" enctype="multipart/form-data">
                @method('PUT')
                @csrf
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="name">Room Name</label>

                        <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="name" id="name" placeholder="Room Name" value="{{ old('name', $room->name) }}" required>
                      @error('name')
                      <span class="invalid-feedback" role="alert">
                          <strong>{{ $message }}</strong>
                      </span>
                  @enderror
                    </div> 
                    <button type="submit" class="btn btn-primary mt-4">Update</button>

              
            </form>
        </div>
    </div>




@endsection