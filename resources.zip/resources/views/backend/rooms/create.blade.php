@extends('layouts.backend')
@section('content')
@section('title_nav')
    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Create Room</h2>
    </div>
@endsection
<div class="row">
    <div class="col-md-3">
        @include('backend.include.sidebar')
    </div>
    <div class="col-md-9">
        <form method="POST" action="{{ route('backend.rooms.store') }}"
            enctype="multipart/form-data">
            @csrf
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="name">Room Name</label>

                        <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text"
                            name="name" id="name" placeholder="Room Name" value="{{ old('name', '') }}"
                            required>
            
                    @error('name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
            </div>
                <button type="submit" class="btn btn-primary mt-4">Create</button>


        </form>
    </div>
</div>




@endsection
