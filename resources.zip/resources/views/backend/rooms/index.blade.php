@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />


    <style>
        table {
  border-collapse: collapse;
}

table, th, td {
  border: none;
}

.btn.btn-primary {
width: 512px;
height: 48px;
/* padding: 8px 16px; */
border-radius: 4px;
background: #901111;
border: none;
color: #FFF;
font-family: Montserrat;
font-size: 14px;
font-style: normal;
font-weight: 600;
line-height: normal;
}
.btn.btn-success {
background-color: #8dd3bb;
border-color: #8dd3bb;
font-family: Montserrat;
font-style: normal;
font-weight: 700;
line-height: normal;
}
th {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 700;
line-height: normal;
letter-spacing: 0.263px;
}
td {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 500;
line-height: normal;
letter-spacing: 0.263px;
}
td span{
padding: initial !important;
color: #000 !important;
font-family: Raleway !important;
font-size: 17.518px !important;
font-style: normal !important;
font-weight: 500 !important;
line-height: normal !important;
letter-spacing: 0.263px !important;
}
td span::after {
content: " |";
}
.form-control.form-control-sm {
height: 25px;
}
.table > :not(caption) > * > * {
box-shadow: none;
}
.page-item.active .page-link {
background-color: #8dd3bb;
border-color: #8dd3bb;
}
    </style>
@endsection

@section('title_nav')

    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Room Lists</h2>
    </div>
@endsection
<div class="row">
    <div class="col-md-3">
        @include('backend.include.sidebar')
    </div>
    <div class="col-md-9">
        @can('room_create')
            <div style="margin-bottom: 10px;" class="row">
                <div class="col-lg-12 d-flex justify-content-end">
                    <a class="btn btn-success" href="{{ route('backend.rooms.create') }}">
                        <span><i class="fa fa-plus"></i></span> Add New
                    </a>
                </div>
            </div>
        @endcan
        <div class="card">

            <div class="card-body">
                <div class="table-responsive">
                    <table class=" table table-bordered table-striped table-hover datatable datatable-Room">
                        <thead>
                            <tr>
                                {{-- <th width="10">

                        </th> --}}
                                <th>
                                    ID
                                </th>
                                <th>
                                    Room Name
                                </th>
                                <th>
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($rooms as $key => $room)
                                <tr data-entry-id="{{ $room->id }}">
                                    {{-- <td>

                            </td> --}}
                                    <td>
                                        {{ $room->id ?? '' }}
                                    </td>
                                    <td>
                                        {{ $room->name ?? '' }}
                                    </td>
                                    <td>
                                        @can('room_show')
                                            {{-- <a class="btn-eye" href="{{ route('backend.rooms.show', $room->id) }}">
                                        <i class="fa fa-eye"></i>
                                    </a> --}}
                                        @endcan

                                        @can('room_edit')
                                            <a class="btn btn-warning" href="{{ route('backend.rooms.edit', $room->id) }}">
                                                Edit
                                            </a>
                                        @endcan

                                        @can('room_delete')
                                            <form action="{{ route('backend.rooms.destroy', $room->id) }}" method="POST"
                                                onsubmit="return confirm('{{ trans('global.areYouSure') }}');"
                                                style="display: inline-block;">
                                                <input type="hidden" name="_method" value="DELETE">
                                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        @endcan

                                    </td>

                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection
@section('scripts')
    @parent
    <script src="{{ asset('assets/datatable/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/datatable/js/dataTables.bootstrap5.min.js') }}"></script>

    <script>
        $(function() {
            let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
            @can('room_delete')
                let deleteButtonTrans = '{{ trans('global.datatables.delete') }}'
                let deleteButton = {
                    text: deleteButtonTrans,
                    url: "{{ route('backend.rooms.massDestroy') }}",
                    className: 'btn-danger',
                    action: function(e, dt, node, config) {
                        var ids = $.map(dt.rows({
                            selected: true
                        }).nodes(), function(entry) {
                            return $(entry).data('entry-id')
                        });

                        if (ids.length === 0) {
                            alert('{{ trans('global.datatables.zero_selected') }}')

                            return
                        }

                        if (confirm('{{ trans('global.areYouSure') }}')) {
                            $.ajax({
                                    headers: {
                                        'x-csrf-token': _token
                                    },
                                    method: 'POST',
                                    url: config.url,
                                    data: {
                                        ids: ids,
                                        _method: 'DELETE'
                                    }
                                })
                                .done(function() {
                                    location.reload()
                                })
                        }
                    }
                }
                dtButtons.push(deleteButton)
            @endcan

            $.extend(true, $.fn.dataTable.defaults, {
                orderCellsTop: true,
                order: [
                    [1, 'desc']
                ],
                pageLength: 100,
            });
            let table = $('.datatable-Room:not(.ajaxTable)').DataTable({
                buttons: dtButtons
            })
            $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e) {
                $($.fn.dataTable.tables(true)).DataTable()
                    .columns.adjust();
            });

        })
    </script>
@endsection
