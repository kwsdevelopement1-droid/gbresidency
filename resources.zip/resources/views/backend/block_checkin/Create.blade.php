@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
    <link rel="stylesheet" href="{{ URL::asset('css/flatpickr.min.css') }}">



    <style>
        table {
  border-collapse: collapse;
}

table, th, td {
  border: none;
}

.btn.btn-primary {
width: 512px;
height: 48px;
/* padding: 8px 16px; */
border-radius: 4px;
background: #901111;
border: none;
color: #FFF;
font-family: Montserrat;
font-size: 14px;
font-style: normal;
font-weight: 600;
line-height: normal;
}
.btn.btn-success {
background-color: #8dd3bb;
border-color: #8dd3bb;
font-family: Montserrat;
font-style: normal;
font-weight: 700;
line-height: normal;
}
th {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 700;
line-height: normal;
letter-spacing: 0.263px;
}
td {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 500;
line-height: normal;
letter-spacing: 0.263px;
}
td span{
padding: initial !important;
color: #000 !important;
font-family: Raleway !important;
font-size: 17.518px !important;
font-style: normal !important;
font-weight: 500 !important;
line-height: normal !important;
letter-spacing: 0.263px !important;
}
td span::after {
content: " ";
}
.form-control.form-control-sm {
height: 25px;
}
.table > :not(caption) > * > * {
box-shadow: none;
}
.page-item.active .page-link {
background-color: #8dd3bb;
border-color: #8dd3bb;
}




 .gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        .gallery img {
            max-width: 150px;
            cursor: pointer;
        }
        .gallery div {
            position: relative;
        }
        .gallery div .remove {
            position: absolute;
            top: 5px;
            right: 5px;
            background: red;
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            font-size: 14px;
            width: 20px;
            height: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }



    </style>
@endsection

@section('title_nav')

    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Online Room Create</h2>
    </div>
@endsection


                                

<form action="{{route('backend.storeblockdate')}}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="row">
            <div class="col-md-6">
                <div>
                    <label>Reason To Block</label>
                    <input type="text" name="reason" class="form-control" placeholder="Enter Room Type" required>
                </div>
            </div>
            <div class="col-md-6">
                <div>
                    <label>Block Date</label>
                    <input type="text" id="blockdate" name="blockdate" class="form-control" placeholder="Enter Block Date" required><br>
                </div>
            </div>
            <div class="col-md-3"></div>
            <div class="col-md-6"><br>
                <input type="submit" class="btn btn-primary" value="Submit" name="Submit">
            </div>
            <div class="col-md-3"></div>
        </div>
    </form>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js"></script>
    <script src="{{ URL::asset('js/flatpickr.js') }}"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            flatpickr("#blockdate", {
                dateFormat: "d-m-Y"
            });
        });
    </script>

@endsection


