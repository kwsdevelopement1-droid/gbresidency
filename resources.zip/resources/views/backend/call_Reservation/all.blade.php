@section('title', 'Company Details')
@include('layouts.backend')

<!-- Styles -->
<link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
<link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<style>
    table {
        border-collapse: collapse;
    }
    table, th, td {
        border: none;
    }
    .btn.btn-primary {
        width: 512px;
        height: 48px;
        border-radius: 4px;
        background: #901111;
        border: none;
        color: #FFF;
        font-family: Montserrat;
        font-size: 14px;
        font-weight: 600;
    }
    .btn.btn-success {
        background-color: #8dd3bb;
        border-color: #8dd3bb;
        font-family: Montserrat;
        font-weight: 700;
    }
    th, td {
        color: #000;
        font-family: Raleway;
        font-size: 15.518px;
    }
    td span {
        color: #000 !important;
        font-family: Raleway !important;
        font-size: 17.518px !important;
    }
    .page-item.active .page-link {
        background-color: #8dd3bb;
        border-color: #8dd3bb;
    }
</style>

<div class="row title-card">
    <h2 class="d-flex align-items-center justify-content-center">Room Lists</h2>
</div>

<div class="row m-2">
    <div class="col-md-12">
        <div style="margin-bottom: 10px;" class="row">
            <div class="col-lg-6 d-flex justify-content-start">
                <a class="btn btn-success" href="{{ route('backend.call_reservation_list') }}">
                    <span><i class="fa fa-eye"></i></span> Show Current List
                </a>
            </div>
            <div class="col-lg-6 d-flex justify-content-end">
                <a class="btn btn-success" href="{{ route('backend.call_reservation_create') }}">
                    <span><i class="fa fa-plus"></i></span> Add New
                </a>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover datatable datatable-Room" id="example1">
                        <thead>
                            <tr>
                                <th>Si.No</th>
                                <th>Check-in Date</th>
                                <th>Expt Arv Time</th>
                                <th>Guest Name</th>
                                <th>Place</th>
                                <th>Contact</th>
                                <th>Required Rooms</th>
                                <th>Alloted Rooms</th>
                                <th>Reference</th>
                                <th>Booking Taken BY</th>
                                <th>Check-out Date</th>
                                <th>Booked On</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($callreservations as $callreservation)
                            
                            <tr style="background-color: {{ $callreservation->status == 1 ? '#fbb836' : ($callreservation->status == 2 ? '#0c89d0' : '') }}">

                                <td>{{ $loop->iteration }}</td>
                                <td>{{ \Carbon\Carbon::parse($callreservation->checkin_datetime)->format('d/m/Y') }}</td>
                                <td>{{ \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $callreservation->checkin_datetime)->format('H:i') }}</td>

                                <td>{{$callreservation->guest_name}}</td>
                                <td>{{$callreservation->place}}</td>
                                <td>{{$callreservation->contact_no}}</td>
                                <td>{{$callreservation->rooms}}</td>
                                <td>{{$callreservation->alloted_rooms}}</td>
                                <td>{{$callreservation->reference}}</td>
                                <td>{{$callreservation->booking_by}}</td>
                                <td>{{ \Carbon\Carbon::parse($callreservation->checkout_datetime)->format('d/m/Y') }}</td>
                                <td>{{ \Carbon\Carbon::parse($callreservation->created_at)->format('d/m/Y') }}</td>
                                <td>
                                    <div style="display: flex; align-items: center;">
                                        <a class="btn btn-info" href="{{ route('backend.call_reservation_editt', $callreservation->id) }}">
                                            <i class="fa fa-pencil"></i>
                                        </a>
                                        <form action="{{ route('backend.call_reservation_delete', $callreservation->id) }}" method="POST" style="display:inline; margin-left: 10px;">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this reservation?');">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.colVis.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

<script>
$(document).ready(function () {
    var table = $("#example1").DataTable({
        responsive: true,
        lengthChange: true,
        autoWidth: false,
        paging: true,
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
        dom: 'Bflrtip',
        buttons: [
            "copy",
            "excel",
            {
                extend: "pdf",
                orientation: "landscape", // Make PDF landscape
                pageSize: "A4", // Set PDF to A4 size
                title: "GB Residency - Call Reservation Report Full",
                customize: function (doc) {
                    // Set full-width table
                    var colCount = doc.content[1].table.body[0].length;
                    var tableWidths = [];
                    for (i = 0; i < colCount; i++) {
                        tableWidths.push((100 / colCount) + '%'); // Evenly distribute width
                    }
                    doc.content[1].table.widths = tableWidths;

                    // Reduce font size for better fit
                    doc.defaultStyle.fontSize = 8;
                    doc.styles.tableHeader.fontSize = 10;

                    // Set table border and spacing
                    doc.content[1].layout = {
                        hLineWidth: function () { return 0.5; },
                        vLineWidth: function () { return 0.5; },
                        hLineColor: function () { return '#aaa'; },
                        vLineColor: function () { return '#aaa'; }
                    };
                }
            },
            "print",
            "colvis"
        ]
    });

    table.buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
});
</script>
