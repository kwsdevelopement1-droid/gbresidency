@section('title', 'Company Details')
@include('layouts.backend')


    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


    <style>
        table {
            border-collapse: collapse;
        }
        table, th, td {
            border: none;
        }
        .btn.btn-primary {
            width: 512px;
            height: 48px;
            border-radius: 4px;
            background: #901111;
            border: none;
            color: #FFF;
            font-family: Montserrat;
            font-size: 14px;
            font-weight: 600;
        }
        .btn.btn-success {
            background-color: #8dd3bb;
            border-color: #8dd3bb;
            font-family: Montserrat;
            font-weight: 700;
        }
        th {
            color: #000;
            font-family: Raleway;
            font-size: 17.518px;
            font-weight: 700;
        }
        td {
            color: #000;
            font-family: Raleway;
            font-size: 17.518px;
            font-weight: 500;
        }
        td span {
            color: #000 !important;
            font-family: Raleway !important;
            font-size: 17.518px !important;
        }
        .page-item.active .page-link {
            background-color: #8dd3bb;
            border-color: #8dd3bb;
        }
    </style>



    <div class="row title-card">
        <h2 class="d-flex align-items-center justify-content-center">Call Reservation Create</h2>
    </div>

<div class="container"> 


<form action="{{ route('backend.call_reservation_create_save') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="row">
        <div class="col-md-6">
            <label>Guest Name</label>
            <input type="text" name="guest_name" class="form-control" placeholder="Enter Guest Name" required>
        </div>
        <div class="col-md-6">
            <label>Contact Number</label>
            <input type="text" name="contact_no" class="form-control" placeholder="Enter Contact Number" required>
        </div>
    </div>

    <div class="row mt-4">
        <!--<div class="col-md-6">-->
        <!--    <label>Guest Details</label>-->
        <!--    <textarea name="guest_details" class="form-control" placeholder="Enter Details" required></textarea>-->
        <!--</div>-->
        <div class="col-md-12">
            <label>Reference</label>
            <textarea name="reference" class="form-control" placeholder="Enter Reference" ></textarea>
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-md-6">
            <label>Check-in Date and Time</label>
            <input type="datetime-local" id="checkin_datetime" name="checkin_datetime" class="form-control" required>
        </div>
        <div class="col-md-6">
            <label>Check-out Date and Time</label>
            <input type="datetime-local" id="checkout_datetime" name="checkout_datetime" class="form-control" >
        </div>
         
        
        
        
    </div>

    <div class="row mt-4">
            <div class="col-md-6">
                <label for="floor_id">Select Floors:</label>
                <select id="floor_id" class="form-control select2" multiple="multiple" name="floor[]" onchange="updateFloorList()">
                    @foreach($floors as $floorRooms)
                        <option value="{{ $floorRooms->floor_name }}">{{ $floorRooms->floor_name }}</option>
                    @endforeach
                </select>
            </div>
            
             <div class="col-md-6">
            <label>Place</label>
            <input type="text" name="Place" class="form-control" placeholder="Enter Place Name" required>
        </div>
        </div>

    <div class="row mt-4">
        <div class="col-md-12">
            <label>Selected Floors and Count:</label>
            <div id="selected-floors">
                <!-- Dynamically generated floor list with input fields -->
            </div>
        </div>
    </div>
    
    <div class="row mt-4">
        <div class="col-md-12">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>

    
    </div>


    
   </form>
</div>

 
    
    



<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function () {
            // Initialize Select2 with placeholder and full width
            $('#floor_id').select2({
                placeholder: "Select Floors",
                allowClear: true,
                width: '100%' // Full-width dropdown
            });
        });

        // Update selected floors and their count dynamically
        function updateFloorList() {
            const selectedOptions = $('#floor_id').val() || [];
            const selectedFloorsContainer = document.getElementById('selected-floors');

            // Clear the container
            selectedFloorsContainer.innerHTML = '';

            // Add selected floors with input fields
            selectedOptions.forEach(floorName => {
                const div = document.createElement('div');
                div.className = 'floor-item mb-3';
                div.innerHTML = `
                    <div class="d-flex align-items-center">
                        <span class="me-3">${floorName}</span>
                        <input type="number" name="floor_count[${floorName}]" class="form-control w-25" placeholder="Enter count" required>
                    </div>
                `;
                selectedFloorsContainer.appendChild(div);
            });
        }
        </script>



