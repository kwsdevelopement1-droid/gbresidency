
@section('title', 'Edit Reservation')
@include('layouts.backend')

    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


    <style>
        table {
            border-collapse: collapse;
        }
        table, th, td {
            border: none;
        }
        .btn.btn-primary {
            width: 512px;
            height: 48px;
            border-radius: 4px;
            background: #901111;
            border: none;
            color: #FFF;
            font-family: Montserrat;
            font-size: 14px;
            font-weight: 600;
        }
        .btn.btn-success {
            background-color: #8dd3bb;
            border-color: #8dd3bb;
            font-family: Montserrat;
            font-weight: 700;
        }
        th {
            color: #000;
            font-family: Raleway;
            font-size: 17.518px;
            font-weight: 700;
        }
        td {
            color: #000;
            font-family: Raleway;
            font-size: 17.518px;
            font-weight: 500;
        }
        td span {
            color: #000 !important;
            font-family: Raleway !important;
            font-size: 17.518px !important;
        }
        .page-item.active .page-link {
            background-color: #8dd3bb;
            border-color: #8dd3bb;
        }
    </style>



<div class="container">
    <h2>Edit Reservation</h2>
    <form action="{{ route('backend.call_reservation_update', $reservation->id) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="row">
            <div class="col-md-6">
                <label>Guest Name</label>
                <input type="text" name="guest_name" class="form-control" value="{{ $reservation->guest_name }}" required>
            </div>
            <div class="col-md-6">
                <label>Contact Number</label>
                <input type="text" name="contact_no" class="form-control" value="{{ $reservation->contact_no }}" required>
            </div>
        </div>

        <div class="row mt-4">
            <!--<div class="col-md-6">-->
            <!--    <label>Guest Details</label>-->
            <!--    <textarea name="guest_details" class="form-control" required>{{ $reservation->guest_details }}</textarea>-->
            <!--</div>-->
            <div class="col-md-12">
                <label>Reference</label>
                <textarea name="reference" class="form-control" >{{ $reservation->reference }}</textarea>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <label>Check-in Date and Time</label>
                <input type="datetime-local" name="checkin_datetime" class="form-control" value="{{ $reservation->checkin_datetime }}" required>
            </div>
            <div class="col-md-6">
                <label>Check-out Date and Time</label>
                <input type="datetime-local" name="checkout_datetime" class="form-control" value="{{ $reservation->checkout_datetime }}" >
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
            <!--    <label>Select Floors:</label>-->
            <!--    <select id="floor_id" class="form-control select2" multiple="multiple" name="floor[]" onchange="updateFloorList()">-->
            <!--        @foreach($floors as $floorId => $floorRooms)-->
            <!--            <option value="{{ $floorRooms->first()->floor_name }}"-->
            <!--                {{ str_contains($reservation->rooms, $floorRooms->first()->floor_name) ? 'selected' : '' }}>-->
            <!--                {{ $floorRooms->first()->floor_name }}-->
            <!--            </option>-->
            <!--        @endforeach-->
            <!--    </select>-->
            <!--</div>-->
            
            
                <!--<label>Select Floors:</label>-->
                <!--<select id="floor_id" class="form-control select2" multiple="multiple" name="floor[]" onchange="updateFloorList()">-->
                <!--    @foreach($floors as $floorId => $floorRooms)-->
                <!--        <option value="{{ $floorRooms->floor_name }}"-->
                <!--            {{ str_contains($reservation->rooms, $floorRooms->floor_name) ? 'selected' : '' }}>-->
                <!--            {{ $floorRooms->floor_name }}-->
                <!--        </option>-->
                <!--    @endforeach-->
                <!--</select>-->
                
                <label>Select Floors:</label>
<select id="floor_id" class="form-control select2" multiple="multiple" name="floor[]" onchange="updateFloorList()">
    @php
        // Extract floor names from $reservation->rooms
        $reservedRooms = collect(explode(',', $reservation->rooms))->map(function ($room) {
            return trim(explode(':', $room)[0]); // Extract the floor name before ":"
        })->toArray();
    @endphp
    @foreach($floors as $floorId => $floorRooms)
        <option value="{{ $floorRooms->floor_name }}"
            {{ in_array($floorRooms->floor_name, $reservedRooms) ? 'selected' : '' }}>
            {{ $floorRooms->floor_name }}
        </option>
    @endforeach
</select>


                
            </div>
            <div class="col-md-6">
                <label>Place</label>
                <input type="text" name="Place" class="form-control" value="{{ $reservation->place }}" required>
            </div>
            
            
            
        </div>
        
    

        <div class="row mt-4">
            <div class="col-md-6">
                <label>Selected Floors and Count:</label>
                <div id="selected-floors">
                    <!-- Dynamically populate the selected floors -->
                    @foreach(explode(', ', $reservation->rooms) as $floor)
                        @php
                            [$floorName, $count] = explode(': ', $floor);
                        @endphp
                        <div class="floor-item mb-3">
                            <div class="d-flex align-items-center">
                                <span class="me-3">{{ $floorName }}</span>
                                <input type="number" name="floor_count[{{ $floorName }}]" class="form-control w-25" value="{{ $count }}" required>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
            
                <div class="col-md-6">
                <label>Alloted Rooms</label>
                <input type="text" name="alloted_rooms" class="form-control" value="{{ $reservation->alloted_rooms }}" >
                
                <br>
             <label>Status:</label><br>
Checked in:
<input type="checkbox" name="status" value="1" {{ $reservation->status == 1 ? 'checked' : '' }} onclick="toggleCheckbox(this)">
&nbsp; &nbsp; &nbsp; &nbsp;
Not Come:
<input type="checkbox" name="status" value="2" {{ $reservation->status == 2 ? 'checked' : '' }} onclick="toggleCheckbox(this)">

<script>
  function toggleCheckbox(checkbox) {
    document.querySelectorAll('input[name="status"]').forEach((item) => {
      if (item !== checkbox) item.checked = false;
    });
  }
</script>


            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
        $(document).ready(function () {
            // Initialize Select2 with placeholder and full width
            $('#floor_id').select2({
                placeholder: "Select Floors",
                allowClear: true,
                width: '100%' // Full-width dropdown
            });
        });

function updateFloorList() {
    const selectedOptions = $('#floor_id').val() || [];
    const selectedFloorsContainer = document.getElementById('selected-floors');
    selectedFloorsContainer.innerHTML = '';

    selectedOptions.forEach(floorName => {
        const div = document.createElement('div');
        div.className = 'floor-item mb-3';
        div.innerHTML = `
            <div class="d-flex align-items-center">
                <span class="me-3">${floorName}</span>
                <input type="number" name="floor_count[${floorName}]" class="form-control w-25" placeholder="Enter count" required>
            </div>
        `;
        selectedFloorsContainer.appendChild(div);
    });
}
</script>
