@extends('layouts.backend')
@section('title', 'Edit Checkout Record')
@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <style>
        .form-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .form-section h5 {
            color: #901111;
            border-bottom: 2px solid #901111;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .btn-primary {
            background: #901111;
            border-color: #901111;
        }
        .btn-primary:hover {
            background: #7a0e0e;
            border-color: #7a0e0e;
        }
        .required {
            color: #dc3545;
        }
        .amount-input {
            font-weight: bold;
            font-size: 1.1em;
        }
    </style>
@endsection

@section('content')
<div class="row">
    <div class="col-md-3">
        @include('backend.include.sidebar')
    </div>
    <div class="col-md-9">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="mb-0">
                                <i class="fa fa-edit"></i> Edit Checkout Record
                                <span class="badge bg-info ms-2">Bill #{{ $checkout->bill_no ?? 'N/A' }}</span>
                            </h4>
                        </div>
                        <div class="card-body">
                            @if ($errors->any())
                                <div class="alert alert-danger">
                                    <ul class="mb-0">
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif

                            <form method="POST" action="{{ route('backend.post-checkout-edit.update', [$table, $checkout->id]) }}">
                                @csrf
                                @method('PUT')
                                <!-- Customer Information (Editable) -->
                                <div class="form-section">
                                    <h5><i class="fa fa-user"></i> Customer Information</h5>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group mb-3">
                                                <label class="form-label">Customer Name <span class="required">*</span></label>
                                                <input type="text" 
                                                       name="guest_name" 
                                                       id="guest_name_input"
                                                       class="form-control" 
                                                       value="{{ old('guest_name', $checkout->customer_ids->guest_name ?? '') }}" 
                                                       required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group mb-3">
                                                <label class="form-label">Mobile Number <span class="required">*</span></label>
                                                <input type="text" 
                                                       name="phone_number" 
                                                       id="phone_number_input"
                                                       class="form-control" 
                                                       value="{{ old('phone_number', $checkout->customer_ids->phone_number ?? '') }}" 
                                                       pattern="[0-9]{10}" 
                                                       maxlength="10"
                                                       required>
                                                <small class="form-text text-muted">Enter 10 digit mobile number</small>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group mb-3">
                                                <label class="form-label">Guest GSTIN</label>
                                                <input type="text" 
                                                       name="guest_gstin" 
                                                       id="guest_gstin_input"
                                                       class="form-control" 
                                                       value="{{ old('guest_gstin', $checkout->customer_ids->guest_gstin ?? '') }}"
                                                       maxlength="15"
                                                       onchange="calculateGST()">
                                                <small class="form-text text-muted">Leave empty or enter 15 character GSTIN</small>
                                            </div>
                                        </div>
                                    </div>
                                <!-- Financial Information (Editable) -->
                                <div class="form-section">
                                    <h5><i class="fa fa-money"></i> Financial Information</h5>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="form-label">Tariff <span class="required">*</span></label>
                                                <div class="input-group">
                                                    <span class="input-group-text">₹</span>
                                                    <input type="number" 
                                                           name="tariff" 
                                                           id="tariff_input"
                                                           class="form-control financial-field"
                                                           value="{{ old('tariff', $checkout->tariff ?? ($checkout->total_amount - $checkout->cgst - $checkout->sgst - $checkout->igst - $checkout->total_cost)) }}" 
                                                           step="0.01" 
                                                           min="0"
                                                           required
                                                           onchange="calculateGST()">
                                                           
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="form-label">Extra Person</label>
                                                <div class="input-group">
                                                    <span class="input-group-text">₹</span>
                                                    <input type="number" 
                                                        id="extra_person_input"
                                                        name="extra_person_cost" 
                                                        class="form-control financial-field"
                                                        value="{{ old('extra_person_cost', $checkout->extra_person_cost ?? $checkout->total_cost) }}" 
                                                        step="0.01" 
                                                        min="0"
                                                        onchange="calculateGST()">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="form-label">CGST</label>
                                                <div class="input-group">
                                                    <span class="input-group-text">₹</span>
                                                    <input type="number"
                                                           name="cgst" 
                                                           id="cgst_input"
                                                           class="form-control financial-field" 
                                                           value="{{ old('cgst', $checkout->cgst) }}" 
                                                           step="0.01" 
                                                           min="0">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="form-label">SGST</label>
                                                <div class="input-group">
                                                    <span class="input-group-text">₹</span>
                                                    <input type="number" 
                                                           name="sgst" 
                                                           id="sgst_input"
                                                           class="form-control financial-field" 
                                                           value="{{ old('sgst', $checkout->sgst) }}" 
                                                           step="0.01" 
                                                           min="0">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="form-label">IGST</label>
                                                <div class="input-group">
                                                    <span class="input-group-text">₹</span>
                                                    <input type="number" 
                                                           name="igst" 
                                                           id="igst_input"
                                                           class="form-control financial-field" 
                                                           value="{{ old('igst', $checkout->igst) }}" 
                                                           step="0.01" 
                                                           min="0">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="form-label">Payment Method <span class="required">*</span></label>
                                                <select name="payment_method" class="form-control" required>
                                                    @foreach($paymentMethods as $key => $method)
                                                        <option value="{{ $key }}" 
                                                                {{ old('payment_method', $checkout->payment_method) == $key ? 'selected' : '' }}>
                                                            {{ $method }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>                              
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="form-label">Total Amount <span class="required">*</span></label>
                                                <div class="input-group">
                                                    <span class="input-group-text">₹</span>
                                                    <input type="number" 
                                                           name="total_amount" 
                                                           id="total_amount_input"
                                                           class="form-control amount-input" 
                                                           value="{{ old('total_amount', $checkout->total_amount) }}" 
                                                           step="0.01" 
                                                           min="0" 
                                                           required
                                                           onchange="calculateBalance()">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="form-label">Advance Amount <span class="required">*</span></label>
                                                <div class="input-group">
                                                    <span class="input-group-text">₹</span>
                                                    <input type="number" 
                                                           name="advance_amount" 
                                                           id="advance_amount_input"
                                                           class="form-control amount-input" 
                                                           value="{{ old('advance_amount', $checkout->advance_amount) }}" 
                                                           step="0.01" 
                                                           min="0" 
                                                           required
                                                           onchange="calculateBalance()">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group mb-3">
                                                <label class="form-label">Balance Amount <span class="required">*</span></label>
                                                <div class="input-group">
                                                    <span class="input-group-text">₹</span>
                                                    <input type="number" 
                                                           name="balance_amount" 
                                                           id="balance_amount_input"
                                                           class="form-control amount-input" 
                                                           value="{{ old('balance_amount', $checkout->balance_amount) }}" 
                                                           step="0.01" 
                                                           required
                                                           readonly>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Additional Information -->
                            <div class="form-section">
                                <h5><i class="fa fa-info-circle"></i> Additional Information</h5>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group mb-3">
                                            <label class="form-label">Remarks</label>
                                            <textarea name="remarks" 
                                                        class="form-control" 
                                                        rows="3" 
                                                        placeholder="Enter any additional remarks...">{{ old('remarks', $checkout->remarks) }}</textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Edit Reason (Required for audit) -->
                            <div class="form-section">
                                <h5><i class="fa fa-exclamation-triangle"></i> Edit Justification</h5>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group mb-3">
                                            <label class="form-label">Reason for Edit <span class="required">*</span></label>
                                            <textarea name="edit_reason" 
                                                        class="form-control" 
                                                        rows="3" 
                                                        placeholder="Please provide a detailed reason for this edit (required for audit trail)..."
                                                        required>{{ old('edit_reason') }}</textarea>
                                            <small class="form-text text-muted">This information will be logged for audit purposes.</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between">
                                <a href="{{ route('backend.post-checkout-edit.index') }}" class="btn btn-secondary">
                                    <i class="fa fa-arrow-left"></i> Back to List
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-save"></i> Update Checkout Record
                                </button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
    @parent
    <script>
        function calculateGST() {
            const tariff = parseFloat(document.getElementById('tariff_input').value) || 0;
            const extraPerson = parseFloat(document.getElementById('extra_person_input').value) || 0;
            const guestGstinInput = document.getElementById('guest_gstin_input');
            const guestGstin = guestGstinInput ? guestGstinInput.value.trim() : '';            
            // Calculate base amount (tariff + extra person)
            const baseAmount = tariff + extraPerson;
            
            // Calculate 5% GST
            const gstAmount = baseAmount * 0.05;
            
            // Determine if IGST or CGST+SGST based on GSTIN
            const isIGST = guestGstin !== '' && guestGstin.toLowerCase() !== 'nil' && !guestGstin.startsWith('33');            
            let cgst = 0, sgst = 0, igst = 0;
            
            if (isIGST) {
                igst = gstAmount; // Full 5% as IGST
                cgst = 0;
                sgst = 0;
            } else {
                cgst = gstAmount / 2; // 2.5% CGST
                sgst = gstAmount / 2; // 2.5% SGST
                igst = 0;
            }
            
            // Update GST fields
            document.getElementById('cgst_input').value = cgst.toFixed(2);
            document.getElementById('sgst_input').value = sgst.toFixed(2);
            document.getElementById('igst_input').value = igst.toFixed(2);
            
            // Calculate total and balance
            calculateTotalAndBalance();
        }

        function calculateTotalAndBalance() {
            const tariff = parseFloat(document.getElementById('tariff_input').value) || 0;
            const extraPerson = parseFloat(document.getElementById('extra_person_input').value) || 0;
            const cgst = parseFloat(document.getElementById('cgst_input').value) || 0;
            const sgst = parseFloat(document.getElementById('sgst_input').value) || 0;
            const igst = parseFloat(document.getElementById('igst_input').value) || 0;
            const advanceAmount = parseFloat(document.getElementById('advance_amount_input').value) || 0;
            
            const totalAmount = tariff + extraPerson + cgst + sgst + igst;
            const balanceAmount = totalAmount - advanceAmount;            
            
            document.getElementById('total_amount_input').value = totalAmount.toFixed(2);
            document.getElementById('balance_amount_input').value = balanceAmount.toFixed(2);
        }

        function calculateBalance() {
            calculateTotalAndBalance();
        }

        document.addEventListener('DOMContentLoaded', function() {
            // Do not auto-recalculate on load; keep DB values as-is
            // Only recalc when tariff or extra person changes, and recalc balance when advance changes
            const tariff = document.getElementById('tariff_input');
            const extra = document.getElementById('extra_person_input');
            const advance = document.getElementById('advance_amount_input');

            if (tariff) tariff.addEventListener('input', calculateGST);
            if (extra) extra.addEventListener('input', calculateGST);
            if (advance) advance.addEventListener('input', calculateBalance);
        });
</script>
@endsection



                                                   
                                                    