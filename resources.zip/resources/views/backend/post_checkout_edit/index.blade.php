@extends('layouts.backend')
@section('title', 'Post-Checkout Edit')
@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
    <style>
        #initialMessage i {
            color: #8DD3BB;
        }
        .search-container {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid #e0e0e0;
        }
        .search-input {
            border: 2px solid #8DD3BB;
            border-radius: 8px;
            padding: 12px 16px;
            font-size: 16px;
            width: 100%;
            max-width: 400px;
            transition: all 0.3s ease;
        }
        .search-input:focus {
            outline: none;
            border-color: #009834;
            box-shadow: 0 0 0 3px rgba(141, 211, 187, 0.2);
        }
        .search-label {
            color: #8DD3BB;
            font-weight: 600;
            margin-bottom: 8px;
            display: block;
        }
        .no-results {
            text-align: center;
            padding: 40px;
            color: #6c757d;
            display: none;
        }
        .checkout-card {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
        }
        .checkout-card:hover {
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        .status-badge {
            font-size: 0.8em;
            padding: 4px 8px;
            border-radius: 12px;
        }
        .amount-highlight {
            font-weight: bold;
            color: #28a745;
        }
        .edit-btn {
            background: #901111;
            border: none;
            color: white;
            padding: 8px 16px;
            border-radius: 4px;
            transition: all 0.3s ease;
        }
        .edit-btn:hover {
            background: #7a0e0e;
            transform: scale(1.05);
        }
    </style>
@endsection

@section('content')
<div class="row">
    <div class="col-md-3">
        @include('backend.include.sidebar')
    </div>
    <div class="col-md-9">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h4 class="mb-0">
                                <i class="fa fa-edit"></i> Post-Checkout Edit
                            </h4>
                            <span class="badge bg-info">{{ $allCheckouts->count() }} Records (Last 30 Days)</span>
                        </div>
                        <div class="card-body">
                            @if(session('success'))
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    {{ session('success') }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif
                            @if(session('error'))
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    {{ session('error') }}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                </div>
                            @endif
                            <!-- Search Container -->
                            <div class="search-container">
                                <label class="search-label" for="billSearchInput">Search by Bill Number</label>
                                <input type="text" id="billSearchInput" class="search-input" placeholder="Enter bill number to search..." autocomplete="off">
                            </div>
                            <!-- No Results Message -->
                            <div id="noResultsMessage" class="no-results">
                                <i class="fa fa-search fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No matching records found</h5>
                                <p class="text-muted">Try searching with a different bill number.</p>
                            </div>
                            <!-- Initial Message -->
                            <div id="initialMessage" class="text-center py-5">
                                <i class="fa fa-search fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">Search for Bill Records</h5>
                                <p class="text-muted">Enter a bill number above to search and view checkout records.</p>
                            </div>
                            @if($allCheckouts->count() > 0)
                                <div class="row" id="checkoutRecords" style="display: none;">
                                    @foreach($allCheckouts as $checkout)
                                    <div class="col-md-6 col-lg-4 checkout-item" data-bill-no="{{ $checkout->bill_no ?? '' }}">
                                            <div class="checkout-card">
                                                <div class="card-body">
                                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                                        <h6 class="card-title mb-0">
                                                            Bill #{{ $checkout->bill_no ?? 'N/A' }}
                                                        </h6>
                                                        <span class="status-badge bg-primary text-white">
                                                            {{ ucfirst(str_replace('_', ' ', $checkout->table_source)) }}
                                                        </span>
                                                    </div>   
                                                    <div class="customer-info mb-2">
                                                        <strong>{{ $checkout->customer_ids->name ?? 'Unknown Customer' }}</strong><br>
                                                        <small class="text-muted">{{ $checkout->customer_ids->mobile ?? 'No Mobile' }}</small>
                                                    </div>
                                                    <div class="financial-info mb-3">
                                                        <div class="row">
                                                            <div class="col-6">
                                                                <small class="text-muted">Total Amount</small><br>
                                                                <span class="amount-highlight">₹{{ number_format($checkout->total_amount, 2) }}</span>
                                                            </div>
                                                            <div class="col-6">
                                                                <small class="text-muted">Balance</small><br>
                                                                <span class="amount-highlight">₹{{ number_format($checkout->balance_amount, 2) }}</span>
                                                            </div>
                                                        </div>
                                                        <div class="row mt-2">
                                                            <div class="col-6">
                                                                <small class="text-muted">Payment Method</small><br>
                                                                <span class="badge bg-secondary">
                                                                    {{ \App\Models\Checkout::PAYMENT_METHOD_SELECT[$checkout->payment_method] ?? 'Unknown' }}
                                                                </span>
                                                            </div>
                                                            <div class="col-6">
                                                                <small class="text-muted">Date</small><br>
                                                                <small>{{ $checkout->created_at->format('d/m/Y H:i') }}</small>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="d-flex justify-content-between align-items-center">
                                                    <small class="text-muted">
                                                        By: User ID {{ $checkout->user_ids_id ?? 'Unknown' }}
                                                    </small>
                                                        <a href="{{ route('backend.post-checkout-edit.edit', [$checkout->table_source, $checkout->id]) }}" 
                                                           class="btn edit-btn btn-sm">
                                                            <i class="fa fa-edit"></i> Edit
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <div class="row" id="checkoutRecords" style="display: none;">
                                    <i class="fa fa-inbox fa-3x text-muted mb-3"></i>
                                    <h5 class="text-muted">No checkout records found</h5>
                                    <p class="text-muted">No checkout records available for editing in the last 30 days.</p>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
    @parent
    <script src="{{ asset('assets/datatable/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/datatable/js/dataTables.bootstrap5.min.js') }}"></script>
    <script>
    $(document).ready(function() {
        $('#noResultsMessage').hide();
        $('#billSearchInput').on('input', function() {
            var searchTerm = $(this).val().toLowerCase().trim();
            var visibleCount = 0;
            
            if (searchTerm === '') {
                $('#checkoutRecords').hide();
                $('#noResultsMessage').hide();
                $('#initialMessage').show();
                $('.badge.bg-info').text('{{ $allCheckouts->count() }} Records (Last 30 Days)');
                return;
            }
            
            $('#checkoutRecords').show();
            $('#initialMessage').hide(); 
            $('.checkout-item').each(function() {
                var billNo = $(this).data('bill-no');
                var billNoStr = billNo ? billNo.toString().toLowerCase() : '';
                
                if (billNoStr.includes(searchTerm)) {
                    $(this).show();
                    visibleCount++;
                } else {
                    $(this).hide();
                }
            });
            
            if (visibleCount === 0) {
                $('#noResultsMessage').show();
                $('#initialMessage').hide();
            } else {
                $('#noResultsMessage').hide();
            }
            
            var totalCount = $('.checkout-item').length;
            $('.badge.bg-info').text(visibleCount + ' of ' + totalCount + ' Records');
        });
        
        $('#billSearchInput').on('keydown', function(e) {
            if (e.key === 'Escape') {
                $(this).val('');
                $(this).trigger('input');
            }
        });
    });
    </script>
@endsection
