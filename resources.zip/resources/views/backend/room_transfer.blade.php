@section('title', 'Room Transfer')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link href="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/css/tempusdominus-bootstrap-4.min.css"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css"
        integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('assets/intl-tel-input-18.2.1/build/css/intlTelInput.css') }}">
    <style type="text/css" media="print">
        @page {
            size: auto;
            /* auto is the initial value */
            margin: 0;
            /* this affects the margin in the printer settings */
        }
    </style>
    <style>
        .printButton {
            cursor: pointer;
            background: #bc1b1b;
            color: #fff;
            width: 100px;
            border: none;
            border-radius: 2px;
            height: 28px;
            font-size: 20px;
        }

        .iti {
            width: 100%;
        }

        .hide {
            display: none;
        }

        .default-form .selectize-control {
            position: relative;
            width: 250px;
            border-radius: 4px 4px 0px 0px;
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 16px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
        }

        .default-form .selectize-input {
            height: 58px;
        }

        .green-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #009834;
        }

        .color-rooms h3 {
            color: #000;
            font-family: Montserrat;
            font-size: 19px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            white-space: nowrap;
            position: relative;
            left: 39px;
        }

        .color-rooms h4 {
            color: #FFF;
            font-family: Montserrat;
            font-size: 30px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            text-align: center;
            position: relative;
            bottom: 3px;
        }


        .colors {
            max-width: 25%;
        }

        .orange-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FF823C;
        }

        .yellow-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FBB836;
        }

        .blue-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #0C89D0;
        }

        .black-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #000;
        }

        .default-form .input-group-text {

            height: 56px;
        }

        .default-form .fa.fa-calendar {
            font-size: 29px;
        }

        .default-form #no_of_room {
            width: 250px;
            height: 60px;
        }

        .default-form .selectize-input>* {
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 17.039px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
            text-transform: uppercase;
            margin: 12px;
        }

        #bill_no {
            width: 250px !important;
            height: 60px !important;
        }

        #room_no {
            width: 250px !important;
            height: 60px !important;
        }

        .default-form .btn-search {
            border-radius: 4.26px;
            background: #8DD3BB;
            border: none;
            width: 55px;
            height: 55px;
            margin-left: 15px;
        }

        .check-in-form-title {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 33.072px;
            font-style: normal;
            font-weight: 700;
            line-height: 150%;
            /* 49.608px */
        }

        .check_in .form-control {
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;

        }

        .check_in label {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 500;
            line-height: 40px;
        }

        .check_in .selectize-control.single .selectize-input {
            border-color: #b8b8b8;
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;
        }

        .active-btn {
            color: #000;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            border-radius: 15px;
            border: 5px solid #009834;
            background: none;
        }

        .btn-save {
            border-radius: 10px;
            background: #8DD3BB;
            width: 672.804px;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            padding: 23.869px 0px 24.213px 0px;
            border: none;
        }

        table {
            width: 100%;
        }

        tr {
            height: 42px;
            border-radius: 21.116px;
            background: #FFF;
            box-shadow: 0px 2.815px 26.747px 0px rgba(141, 211, 187, 0.33);
        }

        th,
        tr {
            color: #000;
            leading-trim: both;
            text-edge: cap;
            font-family: Raleway;
            font-size: 20px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
            letter-spacing: 0.3px;
        }

        td {
            width: 40%;
        }

        .btn-checkout {
            border-radius: 10px;
            background: #901111;
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-cancel {
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            border: 5px solid #8DD3BB;
            color: #8DD3BB;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-extend {
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            background: #8DD3BB;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }



        .active-btn {
            color: #000 !important;
            font-family: Montserrat !important;
            font-size: 20px !important;
            font-style: normal !important;
            font-weight: 700 !important;
            line-height: normal !important;
            border-radius: 15px !important;
            border: 5px solid #009834 !important;
            background: none !important;
        }

        .black {
            border-radius: 15px;
            background: #000;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .single-color {

            border-radius: 15px;
            background: #FF823C;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .multiple-color {

            border-radius: 15px;
            background: #FBB836;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .recently-vacate-color {

            border-radius: 15px;
            background: #0C89D0;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }


        .main-color {

            border-radius: 15px;
            background: #009834;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .input-group-text {
            height: 64px;
        }

        .fa.fa-calendar {
            font-size: 30px;
        }
    </style>
@endsection
@section('title_nav')
    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Room Transfer/Promote</h2>
    </div>
@endsection

<div class="container mt-4">
    <div class="row">

        <form class="default-form d-flex justify-content-between mt-4" id="form1" method="POST">
            @csrf
            <input type="hidden" name="user_ids_id" value="{{ Auth::id() }}">




            <div class="form-row" style="margin: 0 auto;">
                <div class="form-group col-md-12">
                    <span class="has-float-label">
                        <input class="form-control {{ $errors->has('room_no') ? 'is-invalid' : '' }}" type="text"
                            name="room_no" id="room_no" placeholder="Room No" required value="{{ $room_no }}">

                        <label for="room_no">Room Number</label>
                </div>

            </div>


            @if ($customers_data)
                <input type="hidden" name="customer_ids_id" value="{{ $customers_data->id }}">
            @endif


    </div>
    </form>





    <div id="check-in-div">
        <div class="row mt-4">
            @if ($customers_data)
                <div class="check-in-form-title">
                    <h3>Guest Details</h3>
                </div>
                {{-- <div>{{ $customers_data }}</div> --}}
                <form class="check_in" id="form2">
                    @csrf
                    <input type="hidden" name="user_ids_id" value="{{ Auth::id() }}">
                    <input type="hidden" name="cust_id" value="{{ $customers_data->id }}">
                    <input type="hidden" name="check_in" value="{{ $customers_data->created_at }}">
                    <input type="hidden" name="from_room_id"
                        value="{{ $customers_data->select_rooms->pluck('id')->implode(', ') }}">
                    <input type="hidden" name="select_rooms" value="{{ count($customers_data->select_rooms) }}">
                    <input type="hidden" name="from_room_type" value="{{ $customers_data->room_type_id }}">
                    <input type="hidden" name="from_room_name" value="{{ $customers_data->select_rooms->pluck('name')->implode(', ') }}">
                    <input type="hidden" name="from_room_max" value="{{ $customers_data->room_type->max_person }}">

                    <input type="hidden" name="from_room_adults" value="{{ $customers_data->total_adult }}">
                    <input type="hidden" name="from_room_extra" value="{{ count($extra_beds ?? []) }}">

                    <input type="hidden" name="to_room_type" value="">
                    <input type="hidden" name="to_room_id" value="">
                    <input type="hidden" name="to_room_name" value="">

                    <input type="hidden" name="to_room_max" value="">
                    <input type="hidden" name="to_room_price" value="">
                    <input type="hidden" name="to_room_extra" value="">



                    <div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="required" for="guest_name">Guest Name :
                                        {{ $customers_data->guest_name }}</label>
                                    <div><label class="required" for="guest_name"></label></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="required" for="check_in">Check In :
                                    {{ $customers_data->created_at }}</label>


                            </div>

                        </div>

                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <div class="form-group">
                                    <label class="required" for="phone">Phone Number :
                                        +{{ $customers_data->country_code }}
                                        {{ $customers_data->phone_number }}</label>

                                </div>
                            </div>

                            <div class="col-md-6">

                                <label class="required" for="selected_room">Selected Rooms :
                                    {{ $customers_data->select_rooms->pluck('name')->implode(', ') }}
                                </label>
                            </div>

                        </div>
                         <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="required" for="guest_name">Total Adults :
                                        {{ $customers_data->total_adult }}</label>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="required" for="check_in">Present Extra Persons :
                                    {{ count($extra_beds) }}</label>


                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <div class="form-group">
                                    <label class="required" for="phone">Rent :
                                        {{ $customers_data->room_type->price }} </label>

                                </div>
                            </div>

                            <div class="col-md-6">

                                <label class="required" for="selected_room">Extra Person Price :
                                    {{ $customers_data->room_type->extra_price }}
                                </label>
                            </div>

                        </div>

                        <div class="row">
                            <div class="col-md-6">

                                <label class="required" for="selected_room">Select Room :

                                </label>
                            </div>
                            <div class="form-group col-md-6">
                                <span class="has-float-label">
                                    <select name="room_type_id" id="room_type_id" placeholder="Select Room Type"
                                        required>
                                        <option value="" selected>Select Room Type</option>
                                        @foreach ($floors as $id => $floor)
                                            @if (($floor->price >= $customers_data->room_type->price) ||  ((auth()->user() && auth()->user()->roles()->first()->id == 1)))
                                                <option value="{{ $floor->id }}">{{ $floor->name }} -Rs
                                                    {{ $floor->price }}</option>
                                            @endif
                                        @endforeach
                                    </select>
                            </div>




                        </div>

                        <div class="row mt-4" id="table_extra">

                        </div>
                        <div id="floor-container">
                            <!-- Floors will be appended here -->
                        </div>
                         <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="required" for="new_max">
                                        </label>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="required" for="new_extra">
                                    </label>


                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary paymentModalclose" data-dismiss="modal"
                                id="closeModelBtn">Close</button>
                            <!-- Change the type to "submit" to trigger the form submission -->
                            <!-- Add data attribute to store route URL -->
                            <button type="button" class="btn btn-primary" id="saveChangesBtn"
                                data-route="{{ route('backend.advance') }}">Transfer / Promote</button>
                        </div>

                </form>
            @endif
            <div>
            </div>

            {{-- <div class="container">
                <div class="row mt-4">


                <div id="pdf-second-container"></div>

              </div>
            </div> --}}

        @endsection
        @section('scripts')
            @parent
            <script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/js/tempusdominus-bootstrap-4.min.js">
            </script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
                integrity="sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
                crossorigin="anonymous" referrerpolicy="no-referrer"></script>
            <script src="{{ asset('assets/intl-tel-input-18.2.1/build/js/intlTelInput.min.js') }}"></script>
            <script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>
            <script>
                var ldays = 1;
                var totalRent = 0.00;
                var extraBedCost = 0.00;
                var extraBedDays = 0;


                function printPage() {
                    // Hide the print button before printing
                    try {
                        document.getElementById('printButton').style.display = 'none';

                        document.getElementById('back-btn').style.display = 'none';
                    } catch (e) {}


                    // Trigger the print action
                    window.print();
                }

                // Listen for the afterprint event
                window.addEventListener('afterprint', function() {
                    // Show the print button after the print dialog is closed
                    document.getElementById('printButton').style.display = 'block';
                    document.getElementById('back-btn').style.display = 'initial';

                });

                function phone_number() {
                    var input_phone = document.querySelector("#phone_number"),
                        errorMsg = document.querySelector("#error-msg"),
                        validMsg = document.querySelector("#valid-msg");

                    // here, the index maps to the error code returned from getValidationError - see readme
                    var errorMap = ["Invalid number", "Invalid country code", "Too short", "Too long", "Invalid number"];

                    var iti = intlTelInput(input_phone, {
                        allowDropdown: true,
                        formatOnDisplay: true,
                        phoneValidation: true,
                        separateDialCode: true,
                        enablePlaceholder: true,
                        autoPlaceholder: "polite",
                        placeholderNumberType: "MOBILE",
                        searchCountryPlaceholder: 'Search Country',
                        preferredCountries: ["in"],
                        hiddenInput: "dialCodes",
                        utilsScript: "{{ url('assets/intl-tel-input-18.2.1/build/js/utils.js') }}"
                    });

                    iti.promise.then(function() {
                        var inputValue = input_phone.value.replace(/\s+/g, '');

                        // Remove leading zeros
                        inputValue = inputValue.replace(/^0+/, '');

                        // Set the modified value back to the input field
                        input_phone.value = inputValue;
                        // console.log("Initialised!");
                    });

                    $("input[name='country_code'").val(91);
                    // $("input[name='dialCode'").val(91);

                    var reset_input_phone = function() {
                        input_phone.classList.remove("error");
                        errorMsg.innerHTML = "";
                        errorMsg.classList.add("hide");
                        validMsg.classList.add("hide");
                    };

                    input_phone.addEventListener("countrychange", function() {
                        var data_iti = iti.getSelectedCountryData();
                        $("input[name='country_code'").val(data_iti.dialCode);
                        // $("input[name='dialCode'").val(data_iti.dialCode);

                        // console.log("country code " + JSON.stringify(iti.getSelectedCountryData()));
                        // console.log("country code " + data_iti.dialCode);
                    });

                    // on blur: validate
                    input_phone.addEventListener('blur', function() {
                        // console.log("blur!");
                        // console.log($("input[name='dialCodes'").val());
                        reset_input_phone();
                        if (input_phone.value.trim()) {
                            if (iti.isValidNumber()) {
                                validMsg.classList.remove("hide");
                            } else {
                                input_phone.classList.add("error");
                                var errorCode = iti.getValidationError();
                                errorMsg.innerHTML = errorMap[errorCode];
                                errorMsg.classList.remove("hide");
                            }
                        }
                    });

                    // on keyup / change flag: reset
                    input_phone.addEventListener('change', reset_input_phone);
                    input_phone.addEventListener('keyup', reset_input_phone);
                }


                function secondpdf(id) {
                    var formData1 = new FormData($('#form1')[0]);

                    var myurl = "{{ route('backend.bill-statement.second-pdf', ':id') }}".replace(':id', id) + "?numDays=" +
                        ldays + "&totalRent=" + totalRent + "&totalExtraDays=" + extraBedDays + "&totalExtraCost=" + extraBedCost;
                    console.log(myurl);
                    $.ajax({
                        url: myurl,
                        dataType: 'json',
                        method: 'GET',

                        success: function(response) {
                            // Replace the entire content of the HTML document with the received HTML
                            $('html').html(response.html);
                            //             // Create an iframe element
                            //             var iframe = $('<iframe>', {
                            //     src: response.pdfUrl,
                            //     style: 'width: 100%; height: 500px; border: none;'
                            // });
                            //             // var iframe = '<iframe src="' + response.pdfUrl + '"></iframe>';
                            //             // console.log(iframe);

                            //             // Append the iframe to a container in your HTML (replace '#pdf-container' with the selector of your choice)
                            //             $('#pdf-second-container').html(iframe);
                        },
                        error: function(xhr, status, error) {
                            console.error(xhr.responseText);
                            // Handle errors here
                        }
                    });
                }

                $(document).ready(function() {
                    $("select").selectize();
                    $('#form2')[0].reset();

                    $('#closeModelBtn').on('click', function() {
                        history.back();
                    });

                    $('#saveChangesBtn').on('click', function() {
                        var selectedButtonCount = $('.btn-block.active-btn').length;

                        if (selectedButtonCount == 0) {
                            Swal.fire({
                                title: 'Please select a Transfer Room',
                                icon: "error"
                            });
                        } else if (selectedButtonCount > 1) {
                            Swal.fire({
                                title: 'Please select only One Transfer Room at a Time',
                                icon: "error"
                            });
                        } else {

                            numRooms = $('input[name="select_rooms"]').val();
                            if (numRooms > 1) {
                                Swal.fire({
                                    title: 'Group Transfer not Available Yet',
                                    icon: "error"
                                });
                            } else {

                                $('.btn-block').each(function() {
                                    if ($(this).hasClass('active-btn')) {
                                        selectedVal = $(this).data('btn-id');
                                        selectedRoomVal = $(this).text();

                                    }
                                });
                                console.log("selected Room" + selectedVal + "\n room no=" + selectedRoomVal);

                                $('input[name="to_room_name"]').val(selectedRoomVal);
                                $('input[name="to_room_id"]').val(selectedVal);
                                var formData2 = new FormData($('#form2')[0]);

                                var _token = $('meta[name="csrf-token"]').attr('content');
                                $.ajax({
                                    url: "{{ route('backend.room.transfer.submit') }}",
                                    method: "POST",
                                    data: formData2,
                                    headers: {
                                        'x-csrf-token': _token
                                    },
                                    processData: false,
                                    contentType: false,
                                    success: function(response) {
                                        // Handle successful response
                                        console.log("AJAX request successful:", response);
                                        Swal.fire({
                                            title: response.message,
                                            icon: "success"
                                        });
                                        // history.back();

                                    },
                                    error: function(xhr, status, error) {
                                        // Handle AJAX error
                                        console.error("AJAX request failed:", xhr.responseText);
                                        Swal.fire({
                                            title: 'Something Went Wrong',
                                            icon: "error"
                                        });
                                    }
                                });
                            }


                        }


                    });

                    $('#form2').submit(function() {
                        return false;
                    });
                    var selectize = $('#room_type_id')[0].selectize;
                    selectize.clear();


                    var room_type_id = $('#room_type_id')
                        .val(); // Assuming you have an input field with id 'room_type_id'


                    // Get the current URL
                    var currentUrl = window.location.href;

                    // Parse the URL to extract query parameters
                    var urlParams = new URLSearchParams(currentUrl.split('?')[1]);

                    // Get the value of the 'room' query parameter
                    var room = urlParams.get('room');

                    // Get the value of the 'type' query parameter
                    var type = urlParams.get('type');

                    // Output the values (just for demonstration)
                    // console.log("Room:", room);
                    // console.log("Type:", type);

                    if (room && type) {
                        var selectizeroom_type_id = $('#room_type_id')[0].selectize;

                        // Set the selected option for the 'guest_type' Selectize instance
                        selectizeroom_type_id.setValue(type);
                        setTimeout(function() {
                            $('#ajax-btn').trigger('click');
                        }, 1000);

                        // $("#ajax-btn").trigger('click');
                        // window.onload=function(){
                        // $("#ajax-btn").click();
                        // }
                    }


                    function ajax_data_box(response) {
                        // console.log(JSON.stringify(response));

                        $('#floor-container').empty();


                        var floorItem = response.data;
                        var roomStatuses = response.roomStatuses;

                        var blocked_count = 0;
                        var recent_count = 0;
                        var main_count = 0;
                        var single_count = 0;
                        var multiple_count = 0;



                        $('input[name="to_room_type"]').val(floorItem.id);
                        $('input[name="to_room_price"]').val(floorItem.price);
                        $('input[name="to_room_max"]').val(floorItem.max_person);
                        $('input[name="to_room_extra"]').val(floorItem.extra_price);

                        $('label[for="new_max"]').text("Max Persons Allowed : " +  floorItem.max_person);

                        oldCount = parseInt($('input[name="from_room_max"]').val()) + parseInt($('input[name="from_room_extra"]').val());
                        newExtra = oldCount -floorItem.max_person;// $('input[name="to_room_extra"]').val(

                        $('label[for="new_extra"]').text("Extra Persons Calculated : " +  newExtra);



                        var roomcontent = floorItem.select_rooms.map(roomItem => {
                            var booked = Array.from(response.booked) || [];
                            var multiple_book = response.multiple_book || [];
                            var className = "";
                            if (roomItem.status == 1) {
                                className = "black";
                                blocked_count++;
                            } else if (typeof booked !== 'undefined' && booked
                                .includes(roomItem.id)) {
                                className = "single-color";
                                single_count++;

                            } else if (typeof multiple_book !== 'undefined' &&
                                multiple_book.includes(roomItem.id)) {
                                className = "multiple-color";
                                multiple_count++;

                            } else if (roomItem.status == 2) {
                                className = "recently-vacate-color";
                                recent_count++;
                            } else {
                                className = "btn-block main-color";
                                main_count++;
                            }
                            return `<div class="col-6 col-sm-4 col-md-3 col-lg-1 mb-3">
                <button class="${className}" data-btn-id="${roomItem.id}">${roomItem.name}</button>
            </div>`;
                        }).join('');

                        var floorHtml = `<div class="row mt-4">
        <div class="card">
            <div class="card-header text-center">
                <h3>${floorItem.name} - ${main_count} Price:${floorItem.price }  Extra: ${floorItem.extra_price}</h3>
            </div>
            <div class="card-body">
                <div class="row mt-4">
                    ${roomcontent}
                </div>
            </div>
        </div>
    </div>`;



                        $('#floor-container').append(floorHtml);

                        // Check if response.customers_data is defined and not null




                    }


                    $('#room_type_id').on('change', function(e) {
                        e.preventDefault();
                        var room_type_id = $(this).val();

                        var _token = $('meta[name="csrf-token"]').attr('content');


                        $.ajax({
                            url: "{{ route('backend.ajax_data') }}",
                            method: "POST",
                            headers: {
                                'x-csrf-token': _token
                            },
                            data: {
                                room_type_id: room_type_id
                            },
                            success: function(response) {
                                console.log(response);
                                // Handle the response as needed
                                if (response.data) {
                                    ajax_data_box(response);
                                } else {
                                    console.log('No data received');
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error(xhr.responseText);
                                // Handle errors
                            }
                        });
                    });
                    //New Function Change for Room Number
                    $('#room_no').on('keyup change blur', function(e) {
                        if (e.which == 13) {
                            var _token = $('meta[name="csrf-token"]').attr('content');
                            var formData1 = new FormData($('#form1')[0]); // Get data from Form 1
                            $('#form1').submit();
                        }
                    });
                    //End function Room Number

                    $('#bill_no').on('keyup change blur', function(e) {
                        if (e.which != 13) {
                            return;
                        }
                        e.preventDefault();
                        var bill_no = $(this).val();

                        var _token = $('meta[name="csrf-token"]').attr('content');


                        $.ajax({
                            url: "{{ route('backend.ajax_data_bill_no') }}",
                            method: "POST",
                            headers: {
                                'x-csrf-token': _token
                            },
                            data: {
                                bill_no: bill_no
                            },
                            success: function(response) {
                                //  console.log(response);
                                // Handle the response as needed
                                if (response.data) {
                                    ajax_data_box(response);
                                } else {
                                    console.log('No data received');
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error(xhr.responseText);
                                // Handle errors
                            }
                        });
                    });
                    var hasLooped = false;

                    function getCalculatedTotalDays(checkInTime) {
                        var lCheckIn = new Date(checkInTime);
                        var lCheckout = new Date();

                        console.log("lcheckin" + lCheckIn + "\n lcheckout" + lCheckout);
                        differenceInHours = Math.ceil((lCheckout - lCheckIn) / (1000 * 60 *
                            60));
                        console.log("differenceInHours" + differenceInHours);

                        if (differenceInHours > 23)
                            differenceInHours -= 1;

                        tdays = Math.ceil(differenceInHours / 24);
                        console.log("tdays:" + tdays);
                        return tdays;
                    }

                    $(document).on('click', '.btn-block', function(e) {
                        e.preventDefault();

                        $('#check-in-div').removeClass('d-none');

                        // Toggle active-btn class on the clicked button
                        $(this).toggleClass('active-btn');

                        // Initialize an array to store selected values
                        var selectedValues = [];

                        // Remove existing input fields
                        $('#room_type_container').empty();

                        // Loop through all buttons with class btn-block
                        $('.btn-block').each(function() {
                            // If the button has active-btn class, add its value to selectedValues array
                            if ($(this).hasClass('active-btn')) {
                                selectedValues.push($(this).data('btn-id'));
                                // Create a new input field for each selected value
                                var inputField = $(
                                    '<input type="hidden" name="select_rooms[]" class="selected-room" required>'
                                );
                                // Set the value of the input field
                                inputField.val($(this).data('btn-id'));
                                // Append the input field to the container
                                $('#room_type_container').append(inputField);
                            }
                        });
                        var selectedButtonCount = $('.btn-block.active-btn').length;

                        // Get the values of check-in and check-out inputs
                        // var checkinValue = $('input[name="check_in"]').val();
                        // var checkoutValue = $('input[name="check_out"]').val();
                        // console.log(checkinValue);
                        // // Parse the dates using the Date object
                        // var checkinDate = new Date(checkinValue);
                        // var checkoutDate = new Date(checkoutValue);

                        // // Calculate the difference in milliseconds between the two dates
                        // var differenceInMilliseconds = checkoutDate.getTime() - checkinDate.getTime();

                        // // Convert milliseconds to days
                        // var differenceInDays = Math.round(differenceInMilliseconds / (1000 * 60 * 60 * 24));

                        // Get the values of check-in and check-out inputs
                        var checkinValue = $('input[name="check_in"]').val();
                        var checkoutValue = $('input[name="check_out"]').val();

                        // Parse the dates using Moment.js
                        var checkinDate = moment(checkinValue, 'DD-MM-YYYY HH:mm');
                        var checkoutDate = moment(checkoutValue, 'DD-MM-YYYY HH:mm');

                        // Calculate the difference in days
                        var differenceInDays = checkoutDate.diff(checkinDate, 'days');
                        var TotalDays = '';

                        if (isNaN(differenceInDays) || differenceInDays === 0) {
                            TotalDays = 1;
                        } else {
                            TotalDays = differenceInDays;
                        }

                        // alert(TotalDays);

                        $('input[name="days"]').val(TotalDays);
                        // alert(selectedButtonCount);
                        // Get the default values
                        // Get the default values
                        var default_price = parseFloat($('#price').val());
                        var default_old_price = parseFloat($('#old_price').val());

                        // Calculate the new price
                        var new_price = (default_old_price * selectedButtonCount * TotalDays).toFixed(2);

                        // Update the value of the input field with the new price
                        $('#price').val(new_price);


                        // $('#old_price').val(default_old_price * selectedButtonCount * TotalDays);
                        // Get the selected value
                        $('#no_of_room').val(selectedButtonCount);

                    });


                });

                // $("select").selectize();

                $(document).ready(function() {
                    $('#datetimepickercheckin, #datetimepickercheckout').datetimepicker({
                        useCurrent: false,
                        showTodayButton: true,
                        showClear: true,
                        toolbarPlacement: 'bottom',
                        sideBySide: true,
                        format: 'DD-MM-YYYY HH:mm', // Set your desired format here
                        icons: {
                            time: "fa fa-clock",
                            date: "fa fa-calendar",
                            up: "fa fa-arrow-up",
                            down: "fa fa-arrow-down",
                            previous: "fa fa-chevron-left",
                            next: "fa fa-chevron-right",
                            today: "fa fa-clock",
                            clear: "fa fa-trash-alt",
                            close: "fa fa-times"
                        }
                    });
                });
            </script>

        @endsection
