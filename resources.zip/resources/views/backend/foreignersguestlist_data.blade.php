<!-- Styles -->
<link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
<link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<style>
    table {
        border-collapse: collapse;
    }
    table, th, td {
        border: none;
    }
    .btn.btn-primary {
        width: 512px;
        height: 48px;
        border-radius: 4px;
        background: #901111;
        border: none;
        color: #FFF;
        font-family: Montserrat;
        font-size: 14px;
        font-weight: 600;
    }
    .btn.btn-success {
        background-color: #8dd3bb;
        border-color: #8dd3bb;
        font-family: Montserrat;
        font-weight: 700;
    }
    th, td {
        color: #000;
        font-family: Raleway;
        font-size: 15.518px;
    }
    td span {
        color: #000 !important;
        font-family: Raleway !important;
        font-size: 17.518px !important;
    }
    .page-item.active .page-link {
        background-color: #8dd3bb;
        border-color: #8dd3bb;
    }
</style>

<div class="row title-card">
    <h2 class="d-flex align-items-center justify-content-center">Foreign Guests List</h2>
</div>

<div class="row m-2">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover datatable datatable-Room" id="example1">
                        <thead>
                            <tr>
                                <th>RM. NO</th>
                                <th>GUEST NAME</th>
                                <th>NATIONALITY</th>
                                <th>CHECK-IN DATE</th>
                                <th>CHECK-OUT DATE</th>
                                <th>P.P. EXP. DATE</th>
                                <th>VISA EXP. DATE</th>
                                <th>PASSPORT NO</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($reports as $key => $report)
                                @php
                                    // Ensure correct room names without trailing commas
                                    $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                                        return rtrim($name, ', ');
                                    });

                                    // Get the latest checkout date
                                $latestCheckOutDate = optional($report->latest_checkout)->created_at ?? 'N/A';



                                @endphp
                                <tr>
                                    <td>{{ $roomNames->implode(', ') }}</td>
                                    <td>{{ $report->guest_name ?? '' }}</td>
                                    <td>{{ $report->nationality->name ?? '' }}</td>
                                    <td>{{ optional($report->customerDetail->first())->check_in ?? '' }}</td>
                                    <td>{{ $latestCheckOutDate }}</td> <!-- Display the latest checkout date -->
                                    <td>{{ $report->pr_exp_date ?? '' }}</td>
                                    <td>{{ $report->visa_exp_date ?? '' }}</td>
                                    <td>{{ $report->id_proof_number ?? '' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.colVis.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

<script>
    $(document).ready(function () {
        var table = $("#example1").DataTable({
            responsive: true,
            lengthChange: true, // Enable the length change dropdown
            autoWidth: false,
            paging: true,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
            dom: 'Bflrtip', // Include the length change dropdown ('l')
            buttons: [
                {
                    extend: "copy",
                    title: "Foreign Guests List"
                },
                {
                    extend: "excel",
                    title: "Foreign Guests List"
                },
                {
                    extend: "pdf",
                    title: "Foreign Guests List",
                    orientation: "landscape", // Adjust layout for better visibility
                    pageSize: "A4",
                    customize: function (doc) {
                        doc.styles.title = {
                            fontSize: 16,
                            bold: true,
                            alignment: "center"
                        };
                    }
                },
                {
                    extend: "print",
                    title: "Foreign Guests List",
                    customize: function (win) {
                        $(win.document.body)
                            .css("font-size", "12pt")
                            .prepend('<h2 style="text-align:center;">Foreign Guests List</h2>');
                    }
                },
                "colvis"
            ]
        });

        table.buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    });
</script>