@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css"
    integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
.selectize-control {
  position: relative;
  border-radius: 4px 4px 0px 0px;
  color: #1C1B1F;
  font-family: Montserrat;
  font-size: 16px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
}

    </style>
@endsection
@section('title_nav')

    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Create Room</h2>
    </div>
@endsection
<div class="row">
    <div class="col-md-3">
        @include('backend.include.sidebar')
    </div>
    <div class="col-md-9">
        <form method="POST" action="{{ route("backend.floors.store") }}" enctype="multipart/form-data">
            @csrf
            <div class="form-row mt-4">
                <div class="form-group col-md-12">
                    <label for="name">Room Name</label>

                        <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text"
                            name="name" id="name" placeholder="Room Name" value="{{ old('name', '') }}"
                            required>
                    @error('name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                
            </div>

            <div class="form-row  mt-4">
                <div class="form-group col-md-12">
                    <label for="select_rooms">Select Rooms</label>

                    <select class="{{ $errors->has('select_rooms') ? 'is-invalid' : '' }}" name="select_rooms[]" id="select_rooms" placeholder="Select Rooms" multiple required>
                    @foreach($select_rooms as $id => $select_room)
                        <option value="{{ $id }}" {{ in_array($id, old('select_rooms', [])) ? 'selected' : '' }}>{{ $select_room }}</option>
                    @endforeach
                </select>
                
                    @if($errors->has('select_rooms'))
                    <div class="invalid-feedback">
                        {{ $errors->first('select_rooms') }}
                    </div>
                @endif
                </div>
                
            </div>

            <div class="form-row  mt-4">
                <div class="form-group col-md-12">
                    <label for="select_room_type">Select Room Type</label>

                    <select class="{{ $errors->has('select_room_type') ? 'is-invalid' : '' }}" name="select_room_type_id" id="select_room_type_id" placeholder="Select Room Type" required>
                    @foreach($select_room_types as $id => $entry)
                        <option value="{{ $id }}" {{ old('select_room_type_id') == $id ? 'selected' : '' }}>{{ $entry }}</option>
                    @endforeach
                </select>
                
                    @if($errors->has('select_room_type'))
                    <div class="invalid-feedback">
                        {{ $errors->first('select_room_type') }}
                    </div>
                @endif
                </div>
                
            </div>

            <div class="form-row mt-4">
                <div class="form-group col-md-12">
                    <label for="price">Room price</label>

                        <input class="form-control {{ $errors->has('price') ? 'is-invalid' : '' }}" type="text"
                            name="price" id="price" placeholder="Room price" value="{{ old('price', '') }}"
                            required>
                    @error('price')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                
            </div>

            <div class="form-row mt-4">
                <div class="form-group col-md-12">
                    <label for="max_person">Room Max Person</label>
                        <input class="form-control {{ $errors->has('max_person') ? 'is-invalid' : '' }}" type="text"
                            name="max_person" id="max_person" placeholder="Room Max Person" value="{{ old('max_person', '') }}"
                            required>
                    @error('max_person')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                
            </div>
            <div class="form-row mt-4">
                <div class="form-group col-md-12">
                    <label for="extra_price">Room Extra Price</label>
                        <input class="form-control {{ $errors->has('extra_price') ? 'is-invalid' : '' }}" type="text"
                            name="extra_price" id="extra_price" placeholder="Room Extra Price" value="{{ old('extra_price', '') }}"
                            required>
                    @error('extra_price')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                
            </div>
                <button type="submit" class="btn btn-primary mt-4">Create</button>


        </form>
    </div>
</div>





@endsection
@section('scripts')
@parent
<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
integrity="sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
            $("#select_room_type_id").selectize();

            $("#select_rooms").selectize({
  plugins: ["remove_button"],

});

</script>
@endsection

