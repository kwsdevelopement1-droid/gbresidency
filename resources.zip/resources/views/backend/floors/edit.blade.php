@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css"
    integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
.selectize-control {
  position: relative;
  width: 512px;
  border-radius: 4px 4px 0px 0px;
  color: #1C1B1F;
  font-family: Montserrat;
  font-size: 16px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
}
.selectize-input {
  height: 60px;
}
    </style>
@endsection
@section('title_nav')

    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Create Room</h2>
    </div>
@endsection
<div class="row">
    <div class="col-md-3">
        @include('backend.include.sidebar')
    </div>
    <div class="col-md-9">
        <form method="POST" action="{{ route("backend.floors.update", [$floor->id]) }}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="form-row mt-4">
                <div class="form-group col-md-6">
                    <span class="has-float-label">
                        <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text"
                            name="name" id="name" placeholder="Room Name" value="{{ old('name', $floor->name) }}"
                            required>
                        <label for="name">Room Name</label>
                    </span>
                    @error('name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                
            </div>

            <div class="form-row  mt-4">
                <div class="form-group col-md-6">
                    <span class="has-float-label">
                    <select class="{{ $errors->has('select_rooms') ? 'is-invalid' : '' }}" name="select_rooms[]" id="select_rooms" placeholder="Select Rooms" multiple required>
                    @foreach($select_rooms as $id => $select_room)
                    <option value="{{ $id }}" {{ (in_array($id, old('select_rooms', [])) || $floor->select_rooms->contains($id)) ? 'selected' : '' }}>{{ $select_room }}</option>                    @endforeach
                </select>
                
                <label for="select_rooms">Select Rooms</label>
                    </span>
                    @if($errors->has('select_rooms'))
                    <div class="invalid-feedback">
                        {{ $errors->first('select_rooms') }}
                    </div>
                @endif
                </div>
                
            </div>

            <div class="form-row  mt-4">
                <div class="form-group col-md-6">
                    <span class="has-float-label">
                    <select class="{{ $errors->has('select_room_type') ? 'is-invalid' : '' }}" name="select_room_type_id" id="select_room_type_id" placeholder="Select Room Type" required>
                    @foreach($select_room_types as $id => $entry)
                    <option value="{{ $id }}" {{ (old('select_room_type_id') ? old('select_room_type_id') : $floor->select_room_type->id ?? '') == $id ? 'selected' : '' }}>{{ $entry }}</option>                    @endforeach
                </select>
                
                <label for="select_room_type">Select Room Type</label>
                    </span>
                    @if($errors->has('select_room_type'))
                    <div class="invalid-feedback">
                        {{ $errors->first('select_room_type') }}
                    </div>
                @endif
                </div>
                
            </div>


            
            <div class="form-row mt-4">
                <div class="form-group col-md-6">
                    <span class="has-float-label">
                        <input class="form-control {{ $errors->has('price') ? 'is-invalid' : '' }}" type="text"
                            name="price" id="price" placeholder="Room price" value="{{ $floor->price ?? ''}}"
                            required>
                        <label for="price">Room price</label>
                    </span>
                    @error('price')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                
            </div>

            <div class="form-row mt-4">
                <div class="form-group col-md-6">
                    <span class="has-float-label">
                        <input class="form-control {{ $errors->has('max_person') ? 'is-invalid' : '' }}" type="text"
                            name="max_person" id="max_person" placeholder="Room max_person" value="{{ $floor->max_person ?? ''}}"
                            required>
                        <label for="max_person">Room max_person</label>
                    </span>
                    @error('max_person')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                
            </div>
            <div class="form-row mt-4">
                <div class="form-group col-md-6">
                    <span class="has-float-label">
                        <input class="form-control {{ $errors->has('extra_price') ? 'is-invalid' : '' }}" type="text"
                            name="extra_price" id="extra_price" placeholder="Room extra_price" value="{{ $floor->extra_price ?? '' }}"
                            required>
                        <label for="extra_price">Room extra_price</label>
                    </span>
                    @error('extra_price')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                
            </div>
                <button type="submit" class="btn btn-primary mt-4">Update</button>


        </form>
    </div>
</div>





@endsection
@section('scripts')
@parent
<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
integrity="sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
            $("#select_room_type_id").selectize();

            $("#select_rooms").selectize({
  plugins: ["remove_button"],

});

</script>
@endsection

