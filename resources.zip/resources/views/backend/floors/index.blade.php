@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
	<link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />


    <style>
.badge {
  color: #000 !important;
}
    </style>
@endsection

@section('title_nav')

<div class="row title-card">

    <h2 class="d-flex align-items-center justify-content-center">Room Lists</h2>
    </div>
    @endsection
    <div class="row">
        <div class="col-md-3">
           @include('backend.include.sidebar')
        </div>
        <div class="col-md-9">
        @can('floor_create')
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12 d-flex justify-content-end">
            <a class="btn btn-success" href="{{ route('backend.floors.create') }}">
                <span><i class="fa fa-plus"></i></span> Add New
            </a>
        </div>
    </div>
@endcan
<div class="card">

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Floor">
                <thead>
                    <tr>
                        {{-- <th width="10">

                        </th> --}}
                        <th>
                            ID
                        </th>
                        <th>
                            Name
                        </th>
                        <th>
                            Rooms
                        </th>
                        <th>
                            Room Type
                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($floors as $key => $floor)
                        <tr data-entry-id="{{ $floor->id }}">
                            {{-- <td>

                            </td> --}}
                            <td>
                                {{ $floor->id ?? '' }}
                            </td>
                            <td>
                                {{ $floor->name ?? '' }}
                            </td>
                            <td>
                                @foreach($floor->select_rooms->take(5) as $key => $item)
                                <span class="badge badge-info">{{ $item->name }}</span>
                                @if($key == 4)
                                <strong>.......</strong>
                            @endif                            @endforeach
                            
                               
                            </td>
                            <td>
                                {{ $floor->select_room_type->name ?? '' }}
                            </td>
                            <td>
                                @can('floor_show')
                                    {{-- <a class="btn btn-xs btn-primary" href="{{ route('backend.floors.show', $floor->id) }}">
                                        {{ trans('global.view') }}
                                    </a> --}}
                                @endcan

                                @can('floor_edit')
                                    <a class="btn btn-warning" href="{{ route('backend.floors.edit', $floor->id) }}">
                                        Edit
                                    </a>
                                @endcan

                                @can('floor_delete')
                                    <form action="{{ route('backend.floors.destroy', $floor->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                @endcan

                            </td>

                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>


</div>
</div>

@endsection
@section('scripts')
@parent
<script src="{{ asset('assets/datatable/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/datatable/js/dataTables.bootstrap5.min.js') }}"></script>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
@can('floor_delete')
  let deleteButtonTrans = '{{ trans('global.datatables.delete') }}'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "{{ route('backend.floors.massDestroy') }}",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('{{ trans('global.datatables.zero_selected') }}')

        return
      }

      if (confirm('{{ trans('global.areYouSure') }}')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
@endcan

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-Floor:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
@endsection
