@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent

    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />

    <style>
        .checkout{
  width: 90px;
  height: 29px;
  border-radius: 14.349px;
  background: #901111;
  color: #FFF;
  font-family: Raleway;
  font-size: 11.905px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  letter-spacing: 0.179px;
  border: none;
}
.checkin {
  width: 90px;
  height: 29px;
  border-radius: 14.349px;
  background: #009834;
  color: #FFF;
  font-family: Raleway;
  font-size: 11.905px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  letter-spacing: 0.179px;
  border: none;
}
.banner{
    height: 563.85px;
    background: linear-gradient(90deg, rgba(0, 35, 77, 0.63) 11.46%, rgba(0, 35, 77, 0.00) 77.37%), url("{{ asset('assets/img/banner.jpeg') }}") lightgray 0px -221.583px / 100.279% 170.94% no-repeat;
}
table {
  border-collapse: collapse;
}

table, th, td {
  border: none;
}

.btn.btn-primary {
width: 512px;
height: 48px;
/* padding: 8px 16px; */
border-radius: 4px;
background: #901111;
border: none;
color: #FFF;
font-family: Montserrat;
font-size: 14px;
font-style: normal;
font-weight: 600;
line-height: normal;
}
.btn.btn-success {
background-color: #8dd3bb;
border-color: #8dd3bb;
font-family: Montserrat;
font-style: normal;
font-weight: 700;
line-height: normal;
}
th {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 700;
line-height: normal;
letter-spacing: 0.263px;
height: 42.232px;

}
td {
  color: #000;
  font-family: Raleway;
  font-size: 17.518px;
  font-style: normal;
  font-weight: 500;
  line-height: normal;
  letter-spacing: 0.263px;
  /* border-radius: 21.116px;
  background: #FFF !important;
  box-shadow: 0px 2.815px 26.747px 0px rgba(141, 211, 187, 0.33) !important;
  height: 42.232px; */
}
tr{
    border-radius: 21.116px;
background: #FFF;
box-shadow: 0px 2.815px 26.747px 0px rgba(141, 211, 187, 0.33);
height: 42.232px;
}
.form-control.form-control-sm {
height: 25px;
}
.table > :not(caption) > * > * {
box-shadow: none;
}
.page-item.active .page-link {
background-color: #8dd3bb;
border-color: #8dd3bb;
}
.table > thead {
  vertical-align: initial;
  height: 60px;
}
.form-control.form-control-sm {
  width: 738.609px !important;
  height: 49.608px;
  border-radius: 20.67px;
  background: #FFF;
  box-shadow: 0px 2.756px 26.182px 0px rgba(141, 211, 187, 0.33);
}
.search{
    padding: 8px 11px 0 0;
}
.home-title h3{
    color: #8DD3BB;
font-family: Montserrat;
font-size: 33.072px;
font-style: normal;
font-weight: 700;
line-height: 150%; /* 49.608px */
}
label{
    color: #2D3748;
font-family: Helvetica;
font-size: 19.292px;
font-style: normal;
font-weight: 400;
line-height: normal;
letter-spacing: 0.289px;
}
#datatable-Customer_wrapper {
  margin-top: 26px;
}

.single {
  color: #FFF;
  font-family: Raleway;
  font-size: 11.905px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  letter-spacing: 1.179px;
  border-radius: 14.349px;
  background: #FF823C;
  width: 68.979px;
  height: 28.699px;
  border: none;
}

.group {
  color: #FFF;
  font-family: Raleway;
  font-size: 11.905px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  letter-spacing: 1.179px;
  border-radius: 14.349px;
  background: #FBB836;
  width: 68.979px;
  height: 28.699px;
  border: none;
}

.extent {
  color: #FFF;
  font-family: Raleway;
  font-size: 11.905px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  letter-spacing: 1.179px;
  border-radius: 14.349px;
  background: #8DD3BB;
  width: 68.979px;
  height: 28.699px;
  border: none;
}
    </style>
@endsection
@section('title_nav')
    <div class="row banner">
    </div>
@endsection
<div class="container">
    <div class="row">
        <div class="col-md-3 home-title">
            <h3>GUEST LIST</h3>
        </div>
        <div class="col-md-7">
            <label class="d-flex"><span class="search">Search: </span><input type="text" id="custom-search-input" class="form-control form-control-sm" placeholder="" aria-controls="DataTables_Table_0"></label>        </div>
      </div>
  <div class="row">
        <table class="table table-bordered table-striped table-hover datatable datatable-Customer" id="datatable-Customer">
            <thead>
                <tr>

                    <th>
                        Room NO
                    </th>
                    <th>
                        Guest Name
                    </th>
                    <th>
                        Check In Time
                    </th>
                    <th>Check Out Time</th>
                    <th>
                        Type
                    </th>
                    <th>
                        Remaining Time
                    </th>
                    <th>
                        Pending Amount
                    </th>
                    <th>
                        Extend
                    </th>
                    <th>
                        Check Out
                    </th>

                </tr>
            </thead>

            <tbody>
                @foreach($customers as $key => $customer)
                @foreach($customer->select_rooms as $key => $item)


                    <tr data-entry-id="{{ $customer->id }}">
                        <td>

                            {{ $item->name }}

                      </td>
                      <td>
                          {{ $customer->guest_name ?? '' }}
                      </td>

                      <td>
                        {{ $customer->customerDetail->last() ? \Carbon\Carbon::parse($customer->customerDetail->last()->check_in)->format('d/m/Y (h.iA)') : '' }}
                    </td>
                    <td>
                        {{ $customer->customerDetail->last() ? \Carbon\Carbon::parse($customer->customerDetail->last()->check_out)->format('d/m/Y (h.iA)') : '' }}
                    </td>
                    <td>
                        @if(count($customer->select_rooms) < 1)
                        <button class="single">Normal</button>
                                                    @else
                                                    <button class="group">Group</button>

                                                    @endif

                    </td>
                    <td>

                        @php
                            $lastCheckIn = \Carbon\Carbon::parse($customer->customerDetail->last()->check_in);
                            $lastCheckOut = \Carbon\Carbon::parse($customer->customerDetail->last()->check_out);
                            $hoursDifference = $lastCheckIn->diffInHours($lastCheckOut);
                            $minutesDifference = $lastCheckIn->diffInMinutes($lastCheckOut) % 60;
                        @endphp
                        {{ $hoursDifference }} hours {{ $minutesDifference }} minutes
                    </td>
                        <td>
                            {{ $customer->price - $customer->customerDetail->sum('advance_amount') }}
                        </td>
                        <td>
                        <button class="extent" onclick="window.location='{{ route('backend.check-in-modification.index') }}?room={{ $item->id }}&type={{ $customer->room_type_id }}'">Extend</button>
                    </td>
                    <td>
                        @if($customer->status==2)
<button class="checkout">CheckOut</button>
                        @else
                        <button class="checkin">CheckIn</button>

                        @endif
                    </td>

                    </tr>
                    @endforeach
                @endforeach
            </tbody>
        </table>

  </div>
</div>
@endsection
@section('scripts')
@parent
@parent
<script src="{{ asset('assets/datatable/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('assets/datatable/js/dataTables.bootstrap5.min.js') }}"></script>

<script>
    $(document).ready(function() {
        var table = $('#datatable-Customer').DataTable({
            "pageLength": 20, // Number of records per page
            "lengthMenu": [ [10, 20, 50, -1], [10, 20, 50, "All"] ], // Customize the length menu
            "searching": false, // Disable default search feature
            "ordering": false // Disable sorting
        });

        $('#custom-search-input').on('keyup', function () {
            table.search(this.value).draw();
        });
    });
</script>
@endsection
