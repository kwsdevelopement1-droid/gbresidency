@section('title', 'Room Status')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link href="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/css/tempusdominus-bootstrap-4.min.css"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css"
        integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('assets/intl-tel-input-18.2.1/build/css/intlTelInput.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
    <link href="https://cdn.datatables.net/2.0.5/css/dataTables.dataTables.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/3.0.2/css/buttons.dataTables.css" rel="stylesheet" />
    <style>
        .printButton {
            cursor: pointer;
            background: #bc1b1b;
            color: #fff;
            width: 100px;
            border: none;
            border-radius: 2px;
            height: 28px;
            font-size: 20px;
        }

        .iti {
            width: 100%;
        }

        .hide {
            display: none;
        }

        .default-form .selectize-control {
            position: relative;
            width: 250px;
            border-radius: 4px 4px 0px 0px;
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 16px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
        }

        .default-form .selectize-input {
            height: 58px;
        }

        .green-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #009834;
        }

        .color-rooms h3 {
            color: #000;
            font-family: Montserrat;
            font-size: 19px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            white-space: nowrap;
            position: relative;
            left: 39px;
        }

        .color-rooms h4 {
            color: #FFF;
            font-family: Montserrat;
            font-size: 30px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            text-align: center;
            position: relative;
            bottom: 3px;
        }


        .colors {
            max-width: 25%;
        }

        .orange-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FF823C;
        }

        .yellow-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FBB836;
        }

        .blue-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #0C89D0;
        }

        .black-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #000;
        }

        .default-form .input-group-text {

            height: 56px;
        }

        .default-form .fa.fa-calendar {
            font-size: 29px;
        }

        .default-form #no_of_room {
            width: 250px;
            height: 60px;
        }

        .default-form .selectize-input>* {
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 17.039px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
            text-transform: uppercase;
            margin: 12px;
        }

        #bill_no {
            width: 250px !important;
            height: 60px !important;
        }

        .default-form .btn-search {
            border-radius: 4.26px;
            background: #8DD3BB;
            border: none;
            width: 55px;
            height: 55px;
            margin-left: 15px;
        }

        .check-in-form-title {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 33.072px;
            font-style: normal;
            font-weight: 700;
            line-height: 150%;
            /* 49.608px */
        }

        .check_in .form-control {
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;

        }

        .check_in label {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 500;
            line-height: 40px;
        }

        .check_in .selectize-control.single .selectize-input {
            border-color: #b8b8b8;
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;
        }

        .active-btn {
            color: #000;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            border-radius: 15px;
            border: 5px solid #009834;
            background: none;
        }

        .btn-save {
            border-radius: 10px;
            background: #8DD3BB;
            width: 672.804px;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            padding: 23.869px 0px 24.213px 0px;
            border: none;
        }

        .single {
            color: #FFF;
            font-family: Raleway;
            font-size: 11.905px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 1.179px;
            border-radius: 14.349px;
            background: #FF823C;
            width: 88.979px;
            height: 28.699px;
            border: none;
        }

        .group {
            color: #FFF;
            font-family: Raleway;
            font-size: 11.905px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 1.179px;
            border-radius: 14.349px;
            background: #FBB836;
            width: 88.979px;
            height: 28.699px;
            border: none;
        }

        .disc_guest {
            color: #FFF;
            font-family: Raleway;
            font-size: 11.905px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 1.179px;
            border-radius: 14.349px;
            background: #500808;
            width: 88.979px;
            height: 28.699px;
            border: none;
        }

        .house_guest {
            color: #FFF;
            font-family: Raleway;
            font-size: 11.905px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 1.179px;
            border-radius: 14.349px;
            background: #0b5526;
            width: 88.979px;
            height: 28.699px;
            border: none;
        }
        .monthly_guest {
            color: #FFF;
            font-family: Raleway;
            font-size: 11.905px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 1.179px;
            border-radius: 14.349px;
            background: #b41792;
            width: 88.979px;
            height: 28.699px;
            border: none;
        }

        table {
            width: 100%;
        }

        tr {
            height: 42px;
            border-radius: 21.116px;
            background: #FFF;
            box-shadow: 0px 2.815px 26.747px 0px rgba(141, 211, 187, 0.33);
        }

        th,
        tr {
            color: #000;
            leading-trim: both;
            text-edge: cap;
            font-family: Raleway;
            font-size: 20px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
            letter-spacing: 0.3px;
        }



        .btn-checkout {
            border-radius: 10px;
            background: #901111;
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-cancel {
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            border: 5px solid #8DD3BB;
            color: #8DD3BB;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-extend {
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            background: #8DD3BB;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }



        .active-btn {
            color: #000 !important;
            font-family: Montserrat !important;
            font-size: 20px !important;
            font-style: normal !important;
            font-weight: 700 !important;
            line-height: normal !important;
            border-radius: 15px !important;
            border: 5px solid #009834 !important;
            background: none !important;
        }

        .black {
            border-radius: 15px;
            background: #000;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .single-color {

            border-radius: 15px;
            background: #FF823C;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .multiple-color {

            border-radius: 15px;
            background: #FBB836;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .recently-vacate-color {

            border-radius: 15px;
            background: #0C89D0;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }


        .main-color {

            border-radius: 15px;
            background: #009834;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .input-group-text {
            height: 64px;
        }

        .fa.fa-calendar {
            font-size: 30px;
        }

        #datatable-Customer_wrapper {
            margin-top: 26px;
        }

        .search {
            padding: 8px 11px 0 0;
        }

        .numericCol {
            text-align: right;
        }

        table.dataTable tfoot th {
            text-align: right;
        }

        table {
            table-layout: fixed;
        }

        td {
            overflow: hidden;
            text-overflow: ellipsis;
        }

        th {
            font-size: 14px;
            font-weight: bold;
        }

        td {
            overflow: hidden;
            text-overflow: ellipsis;
            font-size: 12px;
        }
    </style>
@endsection
@section('title_nav')
    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">High Balance Report </h2>
    </div>
@endsection


<div class="container mt-4">

    <div class="row">

        <form class="default-form d-flex justify-content-between mt-4" id="form1" method="POST">
            @csrf



        </form>

    </div>
    @php
        $currentDomain = request()->getHost();
        $from_date = \Carbon\Carbon::now()->format('d-m-Y');
    @endphp
    <div class="row">
        @if ($customers)
            @if (count($customers) == 0)

                <span>No Room Records Found</span>
            @else
                {{-- <span> {{ json_encode($report[0]) }}</span> --}}
                {{-- <div class="row">
                    <button id="print_me">Print</button>
                </div> --}}
                <div align="center"> Om Sakthi</div>
                <div align="center"><b>
                        {{ Str::contains($currentDomain, 'gbresidency') ? 'GB Residency' : 'ADHIPARASAKTHI Lodging' }}</b>
                </div>
                <div align="center"> Melmaruvathur</div>
                <div align="center">High Balance Report </div>
                <div align="right">Report Time: {{ $from_date }} </div>
                <div class="row dt-container datatable-Customer_wrapper">

                    <table
                        class="table tablesort tablesearch-table  table-bordered table-striped table-hover display  dataTabledatatable-Customer "
                        id="datatable-Customer">

                        <thead>
                            <tr>
                                <th data-tablesort-type="int">Si No</th>

                                <th data-tablesort-type="int">
                                    Room NO
                                </th>
                                <th data-tablesort-type="string">
                                    Guest Name
                                </th>
                                <th data-tablesort-type="number">
                                    Phone
                                </th>
                                <th data-tablesort-type="date">
                                    Check In Time
                                </th>

                                <th>
                                    Type
                                </th>

                                {{-- <th data-tablesort-type="string">
                        Rem. Time
                    </th> --}}
                                <th data-tablesort-type="int">
                                    Days
                                </th>
                                <th data-tablesort-type="int">
                                    PAX
                                </th>
                                <th data-tablesort-type="int">
                                    Rent
                                </th>
                                <th data-tablesort-type="int" align="center">
                                    EP Amount
                                </th>
                                <th data-tablesort-type="int">
                                    Disc
                                </th>
                                <th data-tablesort-type="int">
                                    CGST
                                </th>
                                <th data-tablesort-type="int">
                                    SGST
                                </th>
                                <th data-tablesort-type="int">
                                    IGST
                                </th>
                                <th data-tablesort-type="int">
                                    Advance
                                </th>

                                <th data-tablesort-type="int" align="right">
                                    Balance
                                </th>



                            </tr>
                        </thead>

                        <tbody>
                            @php
                                $totalVal = 0.0;
                            @endphp
                            @foreach ($customers as $key => $customer)
                                {{-- @foreach ($customer->select_rooms as $keyroom => $item) --}}
                                <tr data-entry-id="{{ $customer->id }}">
                                    <td>{{ $key + 1 }}</td>
                                    <td>

                                        {{ $customer->select_rooms->pluck('name')->implode(', ') }}

                                    </td>
                                    <td>
                                        {{ $customer->guest_name ?? '' }}
                                    </td>
                                    <td>
                                        {{ $customer->phone_number ?? '' }}
                                    </td>
                                    <td>
                                        {{ $customer->customerDetail->last() ? \Carbon\Carbon::parse($customer->customerDetail->last()->check_in)->format('d/m/Y H.i') : '' }}
                                    </td>
                                    {{-- <td>
                                {{ $customer->customerDetail->last() ? \Carbon\Carbon::parse($customer->customerDetail->last()->check_out)->format('d/m/Y (h.iA)') : '' }}
                            </td> --}}
                                    <td>
                                        @if ($customer->rate_code == 2)
                                            <button class="house_guest">{{ $customer->room_type->name }}</button>
                                        @elseif ($customer->discount_ids_id != null)
                                            <button class="disc_guest">{{ $customer->room_type->name }}</button>
                                        @elseif (count($customer->select_rooms) > 1)
                                            <button class="group">{{ $customer->room_type->name }}</button>
                                        @elseif (isset($customer->monthlyguest))
                                            <button class="monthly_guest">{{ $customer->room_type->name }}</button>
                                        @else
                                            <button class="single">{{ $customer->room_type->name }}</button>
                                        @endif

                                    </td>
                                    {{-- <td align="right">

                                @php
                                    // $lastCheckIn = \Carbon\Carbon::parse($customer->customerDetail->last()->check_in);
                                    $lastCheckIn = \Carbon\Carbon::now(); //\Carbon\Carbon::parse(moment());
                                    $lastCheckOut = \Carbon\Carbon::parse($customer->customerDetail->last()->check_out);
                                    $hoursDifference = $lastCheckOut->diffInHours($lastCheckIn);
                                    $minutesDifference = $lastCheckOut->diffInMinutes($lastCheckIn) % 60;

                                    $remainingTime = \Carbon\Carbon::now()->diff($lastCheckOut);
                                    $isPastDue = $lastCheckOut->isPast();

                                    $lastCheckIn = Carbon\Carbon::parse($customer->customerDetail->last()->check_in);
                                    $currentDateTime = Carbon\Carbon::now();

                                    // Calculate the difference in minutes between the last check-in and the current time
                                    $minutesDifference = $lastCheckIn->diffInMinutes($currentDateTime);

                                    // Calculate the number of days including the grace period
                                    $daysWithGrace = ceil($minutesDifference / (24 * 60));

                                    // Calculate the remaining time to checkout
                                    $remainingTime = $daysWithGrace * 24 * 60 - $minutesDifference;
                                    $remainingTimeInMinutes = $daysWithGrace * 24 * 60 - $minutesDifference;

                                    // Calculate the remaining hours and remaining minutes
                                    $remainingHours = floor($remainingTimeInMinutes / 60);
                                    $remainingMinutes = $remainingTimeInMinutes % 60;

                                    $formattedRemainingTime = sprintf(
                                        '%02d:%02d',
                                        ($remainingHours + 1) % 24,
                                        $remainingMinutes,
                                    );
                                @endphp
                                <span style="color: {{ $isPastDue ? 'red' : 'black' }}">
                                    {{ $formattedRemainingTime }}
                                </span>

                            </td> --}}

                                    @php
                                        $checkInTime = \Carbon\Carbon::parse($customer->created_at);
                                        $hoursPastCheckIn = ceil(Carbon\Carbon::now()->diffInHours($checkInTime)) - 1;
                                        $roomPrice = $customer->rate_code == 1 ? $customer->room_type->price : 0;
                                        if ($hoursPastCheckIn < 25) {
                                            $numDays = 1;
                                        } else {
                                            $numDays = ceil($hoursPastCheckIn / 24);
                                        }
                                        $roomRent = $roomPrice * $numDays;

                                        if (isset($customer->houseguest)) {
                                            $roomRent = 0;
                                            $rent = 0;
                                            $roomRate = 0;
                                        } elseif (isset($customer->monthlyguest)) {
                                            $numD = ceil($customer->numDays / 32);
                                            $roomRate = $customer->monthlyguest->rate;
                                            $roomRent = $customer->monthlyguest->rate * $numD;
                                            $rent =
                                                $customer->monthlyguest->rate *
                                                $customer->no_fo_room *
                                                ceil($numD / 32);
                                        } else {
                                            // $roomRate = $customer->select_rooms->first()->floors->first()->price;
                                            // $roomRent = $customer->select_rooms->first()->floors->first()->price * $numD;
                                            // $rent += $customer->select_rooms->first()->floors->first()->price * $numD;
                                        }


                                        // /{{ $roomPrice }}X {{ $numDays }}= {{ $roomRent }}

                                        $tempCost = 0.0;

                                        $pax = $customer->total_adult;

                                        foreach ($customer->extraBedsData as $extraBed) {
                                            if ($extraBed->checkin_status == 0) {
                                                // console.log(JSON.stringify(element));
                                                $pax += 1;
                                                $now = \Carbon\Carbon::now();
                                                $hoursPastCheckIn =
                                                     $now->diffInHours($extraBed->created_at) - 1;
                                                if ($hoursPastCheckIn < 25) {
                                                    $extraDays = 1;
                                                } else {
                                                    $extraDays = ceil($hoursPastCheckIn / 24);
                                                }
                                                $extraCost = $extraDays * $extraBed->price;
                                                $tempCost += $extraCost;
                                            } else {
                                                $tempCost += $extraBed->totalcost;
                                            }
                                        }
                                        $extraBedCost = $tempCost;
                                        $tempTotal = $roomRent + $extraBedCost;
                                        $discount = $customer->discount_ids_id == null ? 0.0 : $tempTotal * 0.3;
                                        $tempTotal -= $discount;

                                        $gst = $tempTotal * 0.12;
                                        
                                        // Check if IGST or CGST+SGST based on guest_gstin
                                        $guestGstin = $customer->guest_gstin ?? '';
                                        $isIGST = !empty(trim($guestGstin)) && strtolower(trim($guestGstin)) !== 'nil' && !str_starts_with($guestGstin, '33');
                                        
                                        if ($isIGST) {
                                            $igst = $gst;
                                            $cgst = 0;
                                            $sgst = 0;
                                        } else {
                                            $cgst = $gst / 2;
                                            $sgst = $gst / 2;
                                            $igst = 0;
                                        }
                                        
                                        if ($customer->advanceAmount) {
                                            $advanceAmt = $customer->advanceAmount->sum('advance_amount');
                                        } else {
                                            $advanceAmt = 0.0;
                                        }
                                        $balance = $tempTotal + $gst - $advanceAmt;
                                        $totalVal += $balance;
                                    @endphp
                                    <td align="center">{{isset($customer->monthlyguest)?$numD: $numDays }} </td>
                                    <td align="center">{{ $pax }}</td>
                                    <td align="right">{{ number_format((float) $roomRent, 2, '.', '') }}</td>
                                    <td align="right">{{ number_format((float) $extraBedCost, 2, '.', '') }}</td>
                                    <td align="right">

                                        {{ number_format((float) $discount, 2, '.', '') }}
                                    </td>
                                    <td align="right">{{ number_format((float) $cgst, 2, '.', '') }}</td>
                                    <td align="right">{{ number_format((float) $sgst, 2, '.', '') }}</td>
                                    <td align="right">{{ number_format((float) $igst, 2, '.', '') }}</td>
                                    <td align="right">
                                        {{ number_format($advanceAmt, 2, '.', '') }}
                                    </td>



                                    <td align="right">
                                        {{-- {{ $numDays }}
                                {{ $roomRent }}+{{ $extraBedCost }} +
                                {{ $gst }}-{{ $customer->advanceAmount->sum('advance_amount') }}= --}}
                                        {{ number_format((float) $balance, 2, '.', '') }}
                                    </td>
                                    {{-- <td>
                                <button class="extent"
                                    onclick="window.location='{{ route('backend.check-in-modification.index') }}?room={{ $item->id }}&type={{ $customer->room_type_id }}'">Extend</button>
                            </td> --}}


                                </tr>
                                {{-- @endforeach --}}
                            @endforeach

                        </tbody>
                        <tfoot>
                            <tr>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th>Total</th>
                                <th></th>
                                <th></th>
                                <th class="numericCol"></th>
                                <th class="numericCol"></th>
                                <th class="numericCol"></th>
                                <th class="numericCol"></th>
                                <th class="numericCol"></th>
                                <th class="numericCol"></th>
                                <th class="numericCol"></th>
                                <th class="numericCol" align="right">
                                    {{ number_format((float) $totalVal, 2, '.', '') }}</th>
                            </tr>
                        </tfoot>


                    </table>

                </div>
            @endif



        @endif

    </div>
</div>

@endsection
@section('scripts')
@parent
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/2.0.5/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/dataTables.buttons.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.dataTables.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.print.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/js/tempusdominus-bootstrap-4.min.js">
    < script script src = "https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
    integrity = "sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
    crossorigin = "anonymous"
    referrerpolicy = "no-referrer" >
</script>
<script src="{{ asset('assets/intl-tel-input-18.2.1/build/js/intlTelInput.min.js') }}"></script>
<script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>



<script>
    $(document).ready(function() {


        var table = new DataTable('#datatable-Customer', {
            paging: false,
            pageLength: 20,
            searching: false,
            lengthMenu: [
                [10, 20, 50, -1],
                [10, 20, 50, "All"]
            ],
            // fixedHeader: true,
            bInfo: true,
            autoWidth: true, // Disable the auto width calculation
            footerCallback: function(row, data, start, end, display) {
                let api = this.api();

                // Remove the formatting to get integer data for summation
                let intVal = function(i) {
                    return typeof i === 'string' ?
                        i.replace(/[\$,]/g, '') * 1 :
                        typeof i === 'number' ?
                        i :
                        0;
                };

                // Total over all pages - columns 8 to 15 (Rent, EP Amount, Disc, CGST, SGST, IGST, Advance, Balance)
                for (i = 8; i <= 15; i++) {
                    total = api
                        .column(i)
                        .data()
                        .reduce((a, b) => intVal(a) + intVal(b), 0);

                    api.column(i).footer().innerHTML =
                        parseFloat(total).toFixed(2);
                }
            },



            layout: {

                topStart: {
                    buttons: [{
                            extend: 'pdfHtml5',
                            title: 'Ap Lodging',
                            filename: 'high_balance_report{{ \Carbon\Carbon::now()->format('d-m-Y') }}',
                            orientation: 'landscape',
                            pageSize: 'A4',
                            customize: function(doc) {
                                doc.content.splice(0, 1, {
                                    text: [{
                                            text: ' Om Sakthi \n',
                                            bold: true,
                                            fontSize: 11
                                        }, {
                                            text: "{{ Str::contains($currentDomain, 'gbresidency') ? 'GB Residency' : 'ADHIPARASAKTHI Lodging' }}\n",
                                            bold: true,
                                            fontSize: 16
                                        }, {
                                            text: 'High Balance Report - {{ \Carbon\Carbon::now()->format('d-m-Y') }} \n ',
                                            bold: true,
                                            fontSize: 12
                                        },
                                        {
                                            text: 'Report Time {{ \Carbon\Carbon::now()->format('d-m-Y H:i:s') }}',
                                            bold: false,
                                            fontSize: 12
                                        }
                                    ],
                                    margin: [0, 0, 0, 12],
                                    alignment: 'center'
                                });

                                doc.content[1].table.widths = ['4%', '5%', '12%', '8%', '8%',
                                    '8%', '4%', '4%', '6%', '6%', '5%', '5%', '5%', '5%', '7%', '8%'
                                ];

                                var rowCount = doc.content[1].table.body.length;
                                for (i = 1; i < rowCount; i++) {
                                    doc.content[1].table.body[i][2].alignment = 'left';
                                    doc.content[1].table.body[i][3].alignment = 'left';
                                    doc.content[1].table.body[i][4].alignment = 'left';
                                    doc.content[1].table.body[i][5].alignment = 'left';
                                    doc.content[1].table.body[i][6].alignment = 'center';
                                    doc.content[1].table.body[i][7].alignment = 'center';
                                    doc.content[1].table.body[i][8].alignment = 'right';
                                    doc.content[1].table.body[i][9].alignment = 'right';
                                    doc.content[1].table.body[i][10].alignment = 'right';
                                    doc.content[1].table.body[i][11].alignment = 'right';
                                    doc.content[1].table.body[i][12].alignment = 'right';
                                    doc.content[1].table.body[i][13].alignment = 'right';


                                };
                            }
                        }, {
                            extend: 'excel',
                            title: 'High Balance Report -{{ $from_date }}',
                            filename: 'hign_balance_report{{ $from_date }}'
                        }, {
                            extend: 'csv',
                            filename: 'high_balance_report{{ $from_date }}'
                        },
                        {
                            extend: 'print',
                            footer: true,
                            header: true,
                            title: '',
                            orientation: 'landscape',
                            pageSize: 'A4',


                            customize: function(win) {

                                $(win.document.body)
                                    .css('font-size', '14pt')
                                    .prepend(
                                        '<div align="center"> Om Sakthi</div><div  align="center"><b> {{ Str::contains($currentDomain, 'gbresidency') ? 'GB Residency' : 'ADHIPARASAKTHI Lodging' }}</b></div><div align="center"> Melmaruvathur</div><div  align="center">High Balance Report For {{ \Carbon\Carbon::parse($from_date)->format('d-m-Y') }} </div><div  align="right"> {{ \Carbon\Carbon::now()->format('d-m-Y H:i:s') }}</div>'
                                    );

                                $(win.document.body)
                                    .find('table')
                                    .addClass('compact')
                                    .css('font-size', 'inherit');



                                $(win.document.body).find('table tbody td:nth-child(1)').css(
                                    'text-align', 'center');

                                // $(win.document.body).find('table tbody td:nth-child(1)').css('width', '5%');
                                $(win.document.body).find('table tbody td:nth-child(3)').css(
                                    'text-align', 'left');
                                $(win.document.body).find('table tbody td:nth-child(4)').css(
                                    'text-align', 'left');
                                $(win.document.body).find('table tbody td:nth-child(5)').css(
                                    'text-align', 'left');
                                $(win.document.body).find('table tbody td:nth-child(6)').css(
                                    'text-align', 'left');
                                $(win.document.body).find('table tbody td:nth-child(7)').css(
                                    'text-align', 'center');
                                $(win.document.body).find('table tbody td:nth-child(8)').css(
                                    'text-align', 'center');
                                $(win.document.body).find('table tbody td:nth-child(9)').css(
                                    'text-align', 'right');
                                $(win.document.body).find('table tbody td:nth-child(10)').css(
                                    'text-align', 'right');
                                $(win.document.body).find('table tbody td:nth-child(11)').css(
                                    'text-align', 'center');
                                $(win.document.body).find('table tbody td:nth-child(12)').css(
                                    'text-align', 'center');
                                $(win.document.body).find('table tbody td:nth-child(13)').css(
                                    'text-align', 'right');
                                $(win.document.body).find('table tbody td:nth-child(14)').css(
                                    'text-align', 'right');
                                $(win.document.body).find('table tbody th').css(
                                    'text-align', 'right');

                            }
                        }
                    ],
                }
            },
            columnDefs: [{
                    'align': 'center',
                    "aTargets": [0, 1, 6, 7],
                },
                {
                    "width": "4%",
                    "aTargets": [0, 6, 7]
                },
                {
                    "width": "5%",
                    "aTargets": [1]
                },
                {
                    "width": "12%",
                    "aTargets": [2]
                },
                {
                    "width": "8%",
                    "aTargets": [3, 4]
                },
                {
                    "width": "8%",
                    "aTargets": [5]
                },
                {
                    "width": "6%",
                    "aTargets": [8, 9, 10]
                },
                {
                    "width": "5%",
                    "aTargets": [11, 12, 13]
                },
                {
                    "width": "7%",
                    "aTargets": [14]
                },
                {
                    "width": "8%",
                    "aTargets": [15]
                },
            ],
        });

    });
</script>

@endsection
