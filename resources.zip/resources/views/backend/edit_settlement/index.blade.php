@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
<link href="https://cdn.datatables.net/2.0.5/css/dataTables.dataTables.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/3.0.2/css/buttons.dataTables.css" rel="stylesheet" />


    <style>
        table {
  border-collapse: collapse;
}

table, th, td {
  border: none;
}

.btn.btn-primary {
width: 512px;
height: 48px;
/* padding: 8px 16px; */
border-radius: 4px;
background: #901111;
border: none;
color: #FFF;
font-family: Montserrat;
font-size: 14px;
font-style: normal;
font-weight: 600;
line-height: normal;
}
.btn.btn-success {
background-color: #8dd3bb;
border-color: #8dd3bb;
font-family: Montserrat;
font-style: normal;
font-weight: 700;
line-height: normal;
}
th {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 700;
line-height: normal;
letter-spacing: 0.263px;
}
td {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 500;
line-height: normal;
letter-spacing: 0.263px;
}
td span{
padding: initial !important;
color: #000 !important;
font-family: Raleway !important;
font-size: 17.518px !important;
font-style: normal !important;
font-weight: 500 !important;
line-height: normal !important;
letter-spacing: 0.263px !important;
}

.form-control.form-control-sm {
height: 25px;
}
.table > :not(caption) > * > * {
box-shadow: none;
}
.page-item.active .page-link {
background-color: #8dd3bb;
border-color: #8dd3bb;
}
    </style>
@endsection

@section('title_nav')

    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Edit Settlement </h2>
    </div>
@endsection
<div class="row">
    <div class="col-md-3">
        @include('backend.include.sidebar')
    </div>
    <div class="col-md-9">

        <div class="card">


            <div class="card-body">
                <div class="table-responsive">
                    <table
                        class="table tablesort tablesearch-table  table-bordered table-striped table-hover display  dataTabledatatable-Customer "
                        id="datatable-Customer">
                        <thead>
                            <tr>

                                <th>
                                  Si No
                                </th>
                                <th>
                                   Guest Name
                                </th>
                                <th>
                                    Room No
                                </th>

                                <th>
                                    Bill no
                                </th>
                                <th>
                                    Amount
                                </th>
                                <th>Payment Method</th>
                                <th>
                                    Checkout Date
                                </th>
                                <th>
                                 Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                             @if ($reports)
                                @foreach ($reports as $key => $report)

                                <tr >

                                    <td>
                                      {{ $key + 1 }}
                                    </td>
                                    <td>
                                        {{ $report->customer_ids->guest_name }}
                                    </td>
                                    <td>
                                      @php
                                                $roomNames = $report->customer_ids->select_rooms
                                                    ->pluck('name')
                                                    ->map(function ($name) {
                                                        return rtrim($name, ', ');
                                                    });
                                            @endphp
                                            {{ implode(', ', $roomNames->toArray()) }}
                                    </td>

                                    <td>
                                       {{ $report->bill_no }}                              </td>
                                       <td>
                                        {{ $report->balance_amount }}
                                       </td>
                                        <td>
                                            {{ $report->PaymentMethodName }}
                                        </td>
                                        <td>
                                            {{ $report->customer_ids->created_at->format('d-m-Y H:i:s') }}
                                        </td>

                                    <td>

                                        <! assigning dummy user_id---->

                                            <a class="btn btn-xs btn-info"  href="{{ route('backend.edit_settlement.edit', $report->id) }}">
                                              Edit
                                            </a>

                                    </td>

                                </tr>
                                @endforeach
                                @else
                                <tr>
                                    <td>Sorry, No Settlement Records found for Yesterday and Today</td>
                                </tr>
                            @endif

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection
@section('scripts')
@parent
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/2.0.5/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/dataTables.buttons.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.dataTables.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.print.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/js/tempusdominus-bootstrap-4.min.js">
    < script script src = "https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
    integrity = "sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
    crossorigin = "anonymous"
    referrerpolicy = "no-referrer" >
</script>
<script src="{{ asset('assets/intl-tel-input-18.2.1/build/js/intlTelInput.min.js') }}"></script>
<script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>
<script>
    $(document).ready(function() {


        var table = new DataTable('#datatable-Customer', {
            paging: false,
            pageLength: 20,
            searching: true,
            sorting:false,
            lengthMenu: [
                [10, 20, 50, -1],
                [10, 20, 50, "All"]
            ],
            // fixedHeader: true,
            bInfo: true,
            autoWidth: true, // Disable the auto width calculation
            columnDefs: [{
                'align': 'center',
                "aTargets": [0, 2, 3, 4, 5],
            },
            {
                "width": "8%",
                "aTargets": [0, 2,  4, 5,7],

            },
            {
                "width": "18%",
                "aTargets": [3,6]
            },
            {
                "width": "25%",
                "aTargets": [1]
            },



        ],
        });




    });
</script>
@endsection
