@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css"
        integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .selectize-control {
            position: relative;
            border-radius: 4px 4px 0px 0px;
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 16px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
        }
    </style>
@endsection
@section('title_nav')
    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Create Room</h2>
    </div>
@endsection
<div class="row">
    <div class="col-md-3">
        @include('backend.include.sidebar')
    </div>


    <div class="col-md-9">
        <form method="POST" action="{{route('backend.edit_settlement.update',$report->id)}}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="form-group">
                <label class="required" for="bill_no">Bill NO</label>
                <input class="form-control " type="text" name="bill_no" id="bill_no" value="{{ $report->bill_no }}"
                    required readonly>
            </div>

            <div class="form-group">
                <label class="required" for="guest_name">Guest Name</label>
                <input class="form-control " type="text" name="guest_name" id="guest_name"
                    value="{{ $report->customer_ids->guest_name }}" required readonly>
            </div>

            <div class="form-group">
                <label class="required" for="room_name">Room Name</label>
                @php

                    $roomNames = $report->customer_ids->select_rooms->pluck('name')->map(function ($name) {
                        return rtrim($name, ', ');
                    });
                @endphp
                <input class="form-control " type="text" name="room_name" id="room_name"
                    value="{{ implode(', ', $roomNames->toArray()) }}" required readonly>
            </div>


            <div class="form-group">
                <label class="required" for="adv_amt">Settlement Amount</label>
                <input class="form-control " type="text" name="balance_amount" id="balance_amount"
                    value="{{ $report->balance_amount }}" required>
            </div>

            <div class="form-group">
                <label class="required" for="pmt_method">Payment method</label>
                <select class="form-control" name="payment_method" id="payment_method" required>
                    <option value="1" {{ $report->payment_method == '1' ? 'selected' : '' }}>Cash</option>
                    <option value="2" {{ $report->payment_method == '2' ? 'selected' : '' }}>Card</option>
                    <option value="3" {{ $report->payment_method == '3' ? 'selected' : '' }}>Credit</option>
                    <option value="4" {{ $report->payment_method == '4' ? 'selected' : '' }}>UPI</option>

                </select>
            </div>



            <div class="form-group mt-4">
                <button class="btn btn-danger" type="submit">
                    Submit
                </button>
            </div>
        </form>
    </div>
</div>


@endsection
@section('scripts')
@parent

<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
    integrity="sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $(document).ready(function() {
        $("#roles").selectize({
            plugins: ["remove_button"],

        });
    });
</script>

@endsection
