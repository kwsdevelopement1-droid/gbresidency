<!DOCTYPE html>

<html lang="en">
    @php
        $currentDomain = request()->getHost();
    @endphp
<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title></title>

    <style>
        body {

            overflow-x: hidden;

        }

        * {

            font-size: 14px;

        }





        .printButton {

            margin-right: 50px;



            cursor: pointer;



            background: #bc1b1b;



            color: #fff;



            width: 100px;



            border: none;



            border-radius: 4px;



            height: 38px;



            font-size: 20px;



        }



        .back-button {

            /* margin-left:50px; */



            display: inline-block;



            padding: 8px 16px;



            background-color: #4CAF50;



            color: white;



            text-decoration: none;



            border-radius: 4px;

            font-size: 20px;





        }





        .back-button:hover {



            background-color: #45a049;



        }





        .prul {

            float: left;

            height: 2px;

            background-color: black;

            margin-top: -1%;

        }



        .pad-ro {

            padding-left: 850px;

        }

        .nop {

            padding-left: 720px;

        }

        .adt {

            text-align: left;

        }

        .padl {

            padding-left: 45px;

        }

        .ltw {

            width: 120%;

        }

        .amma {

            padding-left: 30px;

        }



        @media print {

            .prul {

                float: left;

                height: 2px;

                background-color: black;

                margin-top: -16px;

            }



            .pad-ro {

                padding-left: 250px;

            }



            .nop {

                padding-left: 180px;

            }



            .padl {

                padding-left: 20px;

            }

            .ltw {

                width: 110%;

            }



            .amma {

                padding-left: 5px;

            }

            div.buttons {

                display: none;

            }

            @page {
                color: #000;
                size: auto;
                margin-left: 50px;
                margin-right: 50px;
                margin-top: 50px;
                margin-bottom: 5px;
            }

        }
    </style>

</head>



<body>



    @php

        // Create Carbon instance for current date and time

        $dateAndTime = \Carbon\Carbon::now();

        // $dateAndTime->setTimezone('Asia/Kolkata'); // Change 'Asia/Kolkata' to the desired timezone

        // Create Carbon instance for check-in date and time

        $dateAndTime_check_in = \Carbon\Carbon::createFromFormat(
            'Y-m-d H:i:s',
            $customer->customerDetail->last()->check_in,
        );

        // Separate the date and time components for check-in date and time

        $date_check_in = $dateAndTime_check_in->format('d/m/Y'); // Format: DD-MM-YYYY

        $time_check_in = $dateAndTime_check_in->format('H:i:s'); // Format: HH:MM:SS (24-hour format)

        // Separate the date and time components for current date and time

        $date = $dateAndTime->format('d/m/Y'); // Format: DD-MM-YYYY

        $time = $dateAndTime->format('H:i:s'); // Format: HH:MM:SS (24-hour format)

        $roomNames = $customer->select_rooms->pluck('name')->map(function ($name) {
            return rtrim($name, ', ');
        });

        $amount = round($customer->advanceAmount->last()->advance_amount ?? 0);

        // Create a new NumberFormatter instance to spell out the number in words

        $numberFormatter = new NumberFormatter('en', NumberFormatter::SPELLOUT);

        // Convert the number into words

        $amountInWords = ucwords($numberFormatter->format($amount));

        // Display the result

        $payment_method = '';

        foreach (\App\Models\Customer::PAYMENT_METHOD_SELECT as $key => $label) {
            if ($key == $customer->advanceAmount->last()->payment_method) {
                // Match found, you can perform further operations here

                $payment_method = $label;
            }
        }

        $user = \App\Models\User::find($customer->advanceAmount->last()->user_ids_id);

        $pax = 0;

        if ($customer->total_adult >= $customer->room_type->max_person * $customer->no_fo_room) {
            $pax = $customer->room_type->max_person * $customer->no_fo_room + $extra_count1;
        } else {
            $pax = $customer->total_adult;
        }

    @endphp









    <div class="part1">



        <div style="border: 1px solid black; ">

            <table width="100%">

                <tr>

                    <td width="25%"> <img src="{{ asset('assets/img/amma-1.png') }}" style="height: 140px; width:120px;"
                            class="amma"> </td>
                    @if (Str::contains($currentDomain, 'gbresidency'))
                        <td width="50%" style="text-align: center; line-height: 8px;">

                            <p>Om Sakthi </p>

                            <b style="font-size: 15px;">G.B Residency</b>

                            <p>HOSPITAL ROAD, MELMARUVATHUR, </p>

                            <p> CHENGALPATTU DIST - 603 319.</p>

                            <b>RECEPTION PH: 044 - 27528450, 9444539691</b>

                        </td>
                    @else
                        <td width="50%" style="text-align: center; line-height: 8px;">

                            <p>Om Sakthi </p>

                            <b style="font-size: 15px;">ADHIPARASAKTHI LODGING</b>

                            <p>(ROUND BUILDING),G.S.T. ROAD </p>

                            <p> MELMARUVATHUR, CHENGALPATTU DIST - 603 319.</p>

                            <b>RECEPTION PH: 044 - 27529084, 7598449853</b>

                        </td>
                    @endif

                    <td width="25%" style="text-align: right;"><img src="{{ asset('assets/img/APLLOGO.png') }}"
                            style="height: 110px; width:135px;"alt=""></td>

                </tr>



                <tr>

                    <td style="padding-left: 3%; "><b style="font-size: 18px">REC.NO:
                            {{ sprintf('%03d', $customer->advanceAmount->last()->id ?? ($customer->id ?? '')) }}</b>
                    </td>

                    <td>

                        <p style="text-align: center; text-decoration: underline; ;"><b style="font-size: 18px">ADVANCE
                                RECEIPT</b></p>

                    </td>

                    <td style="line-height: 10px; padding-top: 20px; padding-left: 40px;">

                        <p style="font-size: 17px; font-weight: 600;"> Date : {{ $date ?? '' }}</p>

                        <p style="font-size: 17px; font-weight: 600;"> Time : {{ $time ?? '' }}</p>

                    </td>

                </tr>

            </table>



            <div style="padding-left: 3%; margin-top: -20px;">

                <p style="width:80%; "> Received with thanks from : <b
                        style="font-size: 18px">{{ $customer->guest_name ?? '' }}</b></p>

                <div style="padding-left: 2%;">

                    <hr width="95%" class="prul">



                </div>



                <p style="width:80%; "> Towards BOOKING ADVANCE <SPan class="pad-ro">Room NO : </SPan><b
                        style="font-size: 18px">{{ implode(', ', $roomNames->toArray()) }}</b></p>

                <div style="padding-left: 2%;">

                    <hr width="95%" class="prul">



                </div>



                <p style="width:100%; "> the sum of Rs
                    <b>{{ number_format($customer->advanceAmount->last()->advance_amount, 2) }}</b> &nbsp; &nbsp; &nbsp;
                    &nbsp; <b>{{ $amountInWords }}</b> <SPan class="nop"><b>No Of Pax : </b><b
                            style="font-size: 18px">{{ $pax }} + {{ $customer->total_child }}</b></SPan>
                </p>

                <div style="padding-left: 2%;">

                    <hr width="95%" class="prul">



                </div>



                <p style="width:80%; "> By : <b style="font-size: 18px">{{ $payment_method }}</b></p>

                <div style="padding-left: 2%;">

                    <hr width="95%" class="prul">



                </div>

            </div>



            <table class="ltw">

                <tr>

                    <td colspan="2" class="padl" width="70%">Note: Advance will not be Refunded at any cost.<br>
                        Guest Staying time 24 hrs only.No grace time are provided here.Suppose excees more than 24 hrs stay you have to pay next day rent.<br>
                விருந்தினர் தங்கும் நேரம் 24 மணி நேரம் மட்டுமே.இங்கு சலுகை நேரம் வழங்கப்படவில்லை.24 மணிநேரத்திற்கு மேல் தங்கினால் அடுத்த நாள் வாடகை செலுத்த வேண்டும்.
                    </td>




                    <td class="adt" valign="top">Arrival Date : {{ $date_check_in ?? '' }} </br>
                Arrival Time : {{ $time_check_in ?? '' }}</td>

                </tr>



                <tr>

                    <td></td>

                    <td></td>

                    <td class="adt"></td>

                </tr>

            </table>



            <br>





            <table width="100%">



                <tr style="font-weight: bold;">

                    <td class="padl" width="30%">F.A.O Sign CheckIn By : {{ $user->name ?? '' }}</td>
                   <td  width="30%"><p style="text-align: center;">Thanks For Choosing With Us</p></td>

                    <td style="text-align: center;" width="30%"> Guest Signature</td>

                </tr>



            </table>
              <br>



        </div>

    </div>





    <br>

    <br>

    <div class="part1">



        <div style="border: 1px solid black; ">

            <table width="100%">

                <tr>

                    <td width="25%"> <img src="{{ asset('assets/img/amma-1.png') }}"
                            style="height: 140px; width:120px;" class="amma"> </td>
                    @if (Str::contains($currentDomain, 'gbresidency'))
                        <td width="50%" style="text-align: center; line-height: 8px;">

                            <p>Om Sakthi </p>

                            <b style="font-size: 15px;">G.B Residency</b>

                            <p>HOSPITAL ROAD, MELMARUVATHUR, </p>

                            <p> CHENGALPATTU DIST - 603 319.</p>

                            <b>RECEPTION PH: 044 - 27528450, 9444539691</b>

                        </td>
                    @else
                        <td width="50%" style="text-align: center; line-height: 8px;">

                            <p>Om Sakthi </p>

                            <b style="font-size: 15px;">ADHIPARASAKTHI LODGING</b>

                            <p>(ROUND BUILDING),G.S.T. ROAD </p>

                            <p> MELMARUVATHUR, CHENGALPATTU DIST - 603 319.</p>

                            <b>RECEPTION PH: 044 - 27529084, 7598449853</b>

                        </td>
                    @endif

                    <td width="25%" style="text-align: right;"><img src="{{ asset('assets/img/APLLOGO.png') }}"
                            style="height: 110px; width:135px;"alt=""></td>

                </tr>



                <tr>

                    <td style="padding-left: 3%; "><b style="font-size: 18px">REC.NO:
                            {{ sprintf('%03d', $customer->advanceAmount->last()->id ?? ($customer->id ?? '')) }}</b>
                    </td>

                    <td>

                        <p style="text-align: center; text-decoration: underline; ;"><b style="font-size: 18px">ADVANCE
                                RECEIPT</b></p>

                    </td>

                    <td style="line-height: 10px; padding-top: 20px; padding-left: 40px;">

                        <p style="font-size: 17px; font-weight: 600;"> Date : {{ $date ?? '' }}</p>

                        <p style="font-size: 17px; font-weight: 600;"> Time : {{ $time ?? '' }}</p>

                    </td>

                </tr>

            </table>



            <div style="padding-left: 3%; margin-top: -20px;">

                <p style="width:80%; "> Received with thanks from : <b
                        style="font-size: 18px">{{ $customer->guest_name ?? '' }}</b></p>

                <div style="padding-left: 2%;">

                    <hr width="95%" class="prul">



                </div>



                <p style="width:80%; "> Towards BOOKING ADVANCE <SPan class="pad-ro">Room NO : </SPan><b
                        style="font-size: 18px">{{ implode(', ', $roomNames->toArray()) }}</b></p>

                <div style="padding-left: 2%;">

                    <hr width="95%" class="prul">



                </div>



                <p style="width:100%; "> the sum of Rs
                    <b>{{ number_format($customer->advanceAmount->last()->advance_amount, 2) }}</b> &nbsp; &nbsp;
                    &nbsp; &nbsp; <b>{{ $amountInWords }}</b> <SPan class="nop"><b>No Of Pax : </b><b
                            style="font-size: 18px">{{ $pax }} + {{ $customer->total_child }}</b></SPan>
                </p>

                <div style="padding-left: 2%;">

                    <hr width="95%" class="prul">



                </div>



                <p style="width:80%; "> By : <b style="font-size: 18px">{{ $payment_method }}</b></p>

                <div style="padding-left: 2%;">

                    <hr width="95%" class="prul">



                </div>

            </div>



            <table class="ltw">

                <tr>

                    <td class="padl">Note: Advance will not be Refunded at any cost.</td>

                    <td></td>

                    <td class="adt">Arrival Date : {{ $date_check_in ?? '' }}</td>

                </tr>



                <tr>

                    <td></td>

                    <td></td>

                    <td class="adt">Arrival Time : {{ $time_check_in ?? '' }}</td>

                </tr>

            </table>




            <table width="100%">



                <tr style="font-weight: bold;">

                    <td class="padl" width="30%">F.A.O Sign CheckIn By : {{ $user->name ?? '' }}</td>

                    <td style="text-align: center;" width="35%"> Thanks For Choosing With Us</td>

                    <td style="text-align: center;" width="30%"> Guest Signature</td>

                </tr>



            </table>



         
        </div>

    </div>



    <br>

  



    <div class="buttons" style="text-align:center; ">

        <button class="printButton" onclick="window.print()">Print</button>

        <!-- <button>back</button> -->

        <a href="javascript:location.reload(true)" class="back-button" id="back-btn">Back</a>

    </div>



</body>
