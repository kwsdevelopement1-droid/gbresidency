@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link href="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/css/tempusdominus-bootstrap-4.min.css"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css"
        integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('assets/intl-tel-input-18.2.1/build/css/intlTelInput.css') }}">
    <style type="text/css" media="print">
        @page {
            size: auto;   /* auto is the initial value */
            margin: 0;  /* this affects the margin in the printer settings */
        }
        </style>
    <style>
        .printButton {
            cursor: pointer;
  background: #bc1b1b;
  color: #fff;
  width: 100px;
  border: none;
  border-radius: 2px;
  height: 28px;
  font-size: 20px;
}
        .iti {
            width: 100%;
        }

        .hide {
            display: none;
        }

        .default-form .selectize-control {
            position: relative;
            width: 250px;
            border-radius: 4px 4px 0px 0px;
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 16px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
        }

        .default-form .selectize-input {
            height: 58px;
        }

        .green-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #009834;
        }

        .color-rooms h3 {
            color: #000;
  font-family: Montserrat;
  font-size: 19px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  white-space: nowrap;
  position: relative;
  left: 39px;
        }

        .color-rooms h4 {
  color: #FFF;
  font-family: Montserrat;
  font-size: 30px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  text-align: center;
  position: relative;
  bottom: 3px;
}


        .colors {
            max-width: 25%;
        }

        .orange-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FF823C;
        }

        .yellow-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FBB836;
        }

        .blue-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #0C89D0;
        }

        .black-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #000;
        }

        .default-form .input-group-text {

            height: 56px;
        }

        .default-form .fa.fa-calendar {
            font-size: 29px;
        }

        .default-form #no_of_room {
            width: 250px;
            height: 60px;
        }

        .default-form .selectize-input>* {
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 17.039px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
            text-transform: uppercase;
            margin: 12px;
        }
        #bill_no {
  width: 250px !important;
  height: 60px !important;
}
 #room_no {
            width: 250px !important;
            height: 60px !important;
        }
        .default-form .btn-search {
            border-radius: 4.26px;
            background: #8DD3BB;
            border: none;
            width: 55px;
            height: 55px;
            margin-left: 15px;
        }

        .check-in-form-title {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 33.072px;
            font-style: normal;
            font-weight: 700;
            line-height: 150%;
            /* 49.608px */
        }

        .check_in .form-control {
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;

        }

        .check_in label {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 500;
            line-height: 40px;
        }

        .check_in .selectize-control.single .selectize-input {
            border-color: #b8b8b8;
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;
        }

        .active-btn {
            color: #000;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            border-radius: 15px;
            border: 5px solid #009834;
            background: none;
        }
        .btn-save{
            border-radius: 10px;
background: #8DD3BB;width: 672.804px;
color: #F2F2F2;
text-align: center;
font-family: Roboto;
font-size: 23.869px;
font-style: normal;
font-weight: 700;
line-height: normal;
padding: 23.869px 0px 24.213px 0px;
border: none;
        }
        table{
            width: 100%;
        }
        tr {
  height: 42px;
  border-radius: 21.116px;
  background: #FFF;
  box-shadow: 0px 2.815px 26.747px 0px rgba(141, 211, 187, 0.33);
}
th,tr {
  color: #000;
  leading-trim: both;
  text-edge: cap;
  font-family: Raleway;
  font-size: 20px;
  font-style: normal;
  font-weight: 600;
  line-height: normal;
  letter-spacing: 0.3px;
}
td{
    width: 40%;
}

.btn-checkout {
  border-radius: 10px;
  background: #901111;
  display: flex;
  width: 383.54px;
  height: 76.082px;
  transform: rotate(0.265deg);
  padding: 23.627px 0px 24.455px 0px;
  justify-content: center;
  align-items: center;
  color: #F2F2F2;
  text-align: center;
  font-family: Roboto;
  font-size: 23.869px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
}
.btn-cancel {
  display: flex;
  width: 383.54px;
  height: 76.082px;
  transform: rotate(0.265deg);
  padding: 23.627px 0px 24.455px 0px;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
  border: 5px solid #8DD3BB;
  color: #8DD3BB;
  text-align: center;
  font-family: Roboto;
  font-size: 23.869px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
}
.btn-extend {
  display: flex;
  width: 383.54px;
  height: 76.082px;
  transform: rotate(0.265deg);
  padding: 23.627px 0px 24.455px 0px;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
  background: #8DD3BB;
  color: #F2F2F2;
  text-align: center;
  font-family: Roboto;
  font-size: 23.869px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
}



.active-btn {
            color: #000 !important;
            font-family: Montserrat !important;
            font-size: 20px !important;
            font-style: normal !important;
            font-weight: 700 !important;
            line-height: normal !important;
            border-radius: 15px !important;
            border: 5px solid #009834 !important;
            background: none !important;
        }

        .black {
            border-radius: 15px;
            background: #000;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .single-color {

            border-radius: 15px;
            background: #FF823C;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .multiple-color {

            border-radius: 15px;
            background: #FBB836;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .recently-vacate-color {

            border-radius: 15px;
            background: #0C89D0;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }


        .main-color {

            border-radius: 15px;
            background: #009834;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

.input-group-text {
  height: 64px;
}
.fa.fa-calendar {
  font-size: 30px;
}



    </style>
@endsection
@section('title_nav')
    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Extend Check In</h2>
    </div>
@endsection

<div class="container mt-4">
    <div class="row">

        <form class="default-form d-flex justify-content-between mt-4" id="form1">
            @csrf
            <input type="hidden" name="user_ids_id" value="{{ Auth::id() }}">

         <input type="hidden" name="customer_ids_id">

         <input type="hidden" name="days" id="days">

         <input type="hidden" name="total_price" id="total_price">

         <div class="form-row" style="margin: 0 auto;">
            <div class="form-group col-md-12">
                <span class="has-float-label">
                    <input class="form-control {{ $errors->has('bill_no') ? 'is-invalid' : '' }}"
                    type="text" name="bill_no" id="bill_no" placeholder="Advance Bill No" required
                    autocomplete="off">

                    <label for="bill_no">Advance Bill No</label>
            </div>

        </div>
        <div class="form-row" style="margin: 0 auto;">
                <div class="form-group col-md-12">
                    <span class="has-float-label">
                        <input class="form-control {{ $errors->has('room_no') ? 'is-invalid' : '' }}" type="text"
                            name="room_no" id="room_no" placeholder="Room No" required autocomplete="off">

                        <label for="room_no">Room Number</label>
                </div>

            </div>


        <div class="form-row" style="margin: 0 auto;">
            <div class="form-group col-md-12">
                <span class="has-float-label">
                    <select name="room_type_id" id="room_type_id" placeholder="Select Room Type" required>
                        <option value="" selected>Select Room Type</option>
                        @foreach ($floors as $id => $floor)
                            <option value="{{ $id }}">{{ $floor }}</option>
                        @endforeach
                    </select>

                    <label for="select_room_type">Rooms Type</label>
            </div>

        </div>

            {{-- <button type="button" id="ajax-btn" class="btn-search"><svg xmlns="http://www.w3.org/2000/svg"
                    width="27" height="26" viewBox="0 0 27 26" fill="none">
                    <path
                        d="M18.8339 16.7262L18.8209 16.7435L18.8362 16.7588L23.5326 21.4552C23.7406 21.6881 23.8516 21.9918 23.8429 22.304C23.8341 22.6164 23.7061 22.9135 23.4851 23.1345C23.2641 23.3555 22.9669 23.4835 22.6545 23.4923C22.3424 23.501 22.0387 23.39 21.8058 23.182L17.1094 18.4856L17.0941 18.4703L17.0768 18.4833C15.5757 19.6109 13.7486 20.2196 11.8713 20.2175C7.07584 20.2175 3.17437 16.316 3.17437 11.5206C3.17437 6.72525 7.07584 2.82379 11.8712 2.82379C16.6666 2.82379 20.5681 6.72525 20.5681 11.5206C20.5701 13.398 19.9615 15.2251 18.8339 16.7262ZM5.6164 11.5206V11.5207C5.61839 13.1789 6.27802 14.7687 7.45059 15.9413C8.62316 17.1139 10.2129 17.7735 11.8712 17.7755H11.8712C13.1083 17.7755 14.3176 17.4086 15.3462 16.7213C16.3748 16.0341 17.1765 15.0572 17.6499 13.9143C18.1234 12.7713 18.2472 11.5137 18.0059 10.3004C17.7645 9.08707 17.1688 7.97257 16.2941 7.09781C15.4193 6.22306 14.3048 5.62735 13.0915 5.386C11.8782 5.14466 10.6205 5.26852 9.47761 5.74194C8.33469 6.21535 7.35782 7.01705 6.67053 8.04565C5.98324 9.07425 5.6164 10.2836 5.6164 11.5206Z"
                        fill="#112211" stroke="#112211" stroke-width="0.0499188" />
                </svg></button> --}}
            </div>
        </form>
        <div id="floor-container">
            <!-- Floors will be appended here -->
        </div>
        <div class="d-none" id="check-in-div">
            <div class="row mt-4">
                <div class="check-in-form-title">
                    <h3>Guest Details</h3>
                </div>
                <form class="check_in"  id="form2">
                    @csrf
                    <div>

                        <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="required" for="guest_name">Guest Name</label>
                                    <input class="form-control {{ $errors->has('guest_name') ? 'is-invalid' : '' }}"
                                        type="text" name="guest_name" id="guest_name"
                                        value="{{ old('guest_name', '') }}" readonly="" required>
                                    @if ($errors->has('guest_name'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('guest_name') }}
                                        </div>
                                    @endif
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="required" for="phone_number">Phone Number</label>
                                    <input type="hidden" value="91" name="country_code">

                                    <input class="form-control {{ $errors->has('phone_number') ? 'is-invalid' : '' }}"
                                        type="text" name="phone_number" id="phone_number"
                                        value="{{ old('phone_number', '') }}" readonly="" required>
                                    <span id="valid-msg" class="hide">✓ Valid</span>
                                    <span id="error-msg" class="hide"></span>
                                    @if ($errors->has('phone_number'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('phone_number') }}
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div class="row">

                            <div class="col-md-6">
                                <label class="required" for="guest_name">Check In</label>

                                <div class="form-group">
                                    <div class="input-group date" id="datetimepickercheckin_old" data-target-input="nearest">
                                        <input type="text" name="check_in_old" class="form-control datetimepicker-input"
                                            data-target="#datetimepickercheckin_old" readonly="" />
                                        <div class="input-group-append" data-target="#datetimepickercheckin_old"
                                            data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                        </div>
                                    </div>
                                </div>
                                </div>
                            <div class="col-md-6">
                                <label class="required" for="guest_name">Check Out</label>

                                <div class="form-group">
                                    <div class="input-group date" id="datetimepickercheckout_old" data-target-input="nearest">
                                        <input type="text" name="check_out_old" class="form-control datetimepicker-input"
                                            data-target="#datetimepickercheckout_old" readonly="" />
                                        <div class="input-group-append" data-target="#datetimepickercheckout_old"
                                            data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                        </div>
                                    </div>
                                </div>
                                </div>
                        </div>

                        <div class="row">

                            <div class="col-md-6 mx-auto">
                                <div class="form-group">
                                    <label for="price">Room Price</label>
                                    <input
                                        class="form-control {{ $errors->has('price') ? 'is-invalid' : '' }}"
                                        type="number" name="price" id="price"
                                        value="{{ old('price', '') }}" step="0.01" readonly="">
                                    @if ($errors->has('price'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('price') }}
                                        </div>
                                    @endif

                                </div>
                            </div>

                        </div>

                        <div class="row mt-4">
                                <div class="col-md-6 d-flex align-items-center justify-content-center" id="table_data">

                                </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="required" for="guest_name">Extent Check In</label>
                                    <div class="input-group date" id="datetimepickercheckin" data-target-input="nearest">
                                        <input type="text" name="check_in" class="form-control datetimepicker-input"
                                            data-target="#datetimepickercheckin" />
                                        <div class="input-group-append" data-target="#datetimepickercheckin"
                                            data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="required" for="guest_name">Extent Check Out</label>
                                    <div class="input-group date" id="datetimepickercheckout" data-target-input="nearest">
                                        <input type="text" name="check_out" class="form-control datetimepicker-input"
                                            data-target="#datetimepickercheckout" />
                                        <div class="input-group-append" data-target="#datetimepickercheckout"
                                            data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Payment Method</label>
                                    <select class="{{ $errors->has('payment_method') ? 'is-invalid' : '' }}"
                                        name="payment_method" id="payment_method">
                                        @foreach (App\Models\Customer::PAYMENT_METHOD_SELECT as $key => $label)
    <option value="{{ $key }}" {{ 1 === (string) $key ? 'selected' : '' }}>
        {{ $label }}
    </option>
@endforeach

                                        {{-- <option value disabled
                                            {{ old('payment_method', null) === null ? 'selected' : '' }}>
                                            Payment Method</option>
                                        @foreach (App\Models\Customer::PAYMENT_METHOD_SELECT as $key => $label)
                                            <option value="{{ $key }}"
                                                {{ old('payment_method', '') === (string) $key ? 'selected' : '' }}>
                                                {{ $label }}</option>
                                        @endforeach --}}
                                    </select>
                                    @if ($errors->has('payment_method'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('payment_method') }}
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="required" for="guest_name">Remarks</label>
                                    <textarea class="form-control" name="remarks"></textarea>
                                </div>
                            </div>
                        <div id="room_type_container"></div>

                        <div class="row mt-4">
                            <div class="col-sm mt-4">
                                <button class="btn-extend" type="button">
                                    Extent
                                </button>
                              </div>
                              <div class="col-sm mt-4">
                                <button class="btn-cancel" type="button">
                                    Cancel
                                </button>
                              </div>
                              <div class="col-sm mt-4">
                                <button class="btn-checkout" type="submit">
                                    Check Out
                                </button>
                              </div>

                </div>
                </form>

                <div>
                </div>

                              {{-- <div class="container">
                <div class="row mt-4">


                <div id="pdf-second-container"></div>

              </div>
            </div> --}}
            <div class="modal fade" id="paymentModal" tabindex="-1" role="dialog" aria-labelledby="paymentModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="paymentModalLabel">Payment Details</h5>
                        <button type="button" class="paymentModalclose" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- Payment form goes here -->
                        <!-- Add an input field to hold the customer ID -->
                        <input type="hidden" id="customer_id" name="customer_ids_id">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="advance_amount">Advance Amount</label>
                                    <input class="form-control" type="number" name="advance_amount" id="advance_amount"
                                        step="0.01">
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Payment Method</label>
                                    <select class="" name="payment_method" id="payment_method">
                                        <option value="" selected>Select</option>
                                        @foreach (App\Models\Customer::PAYMENT_METHOD_SELECT as $key => $label)
                                            <option value="{{ $key }}">{{ $label }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary paymentModalclose"
                            data-dismiss="modal">Close</button>
                        <!-- Change the type to "submit" to trigger the form submission -->
                        <!-- Add data attribute to store route URL -->
                        <button type="button" class="btn btn-primary" id="saveChangesBtn"
                            data-route="{{ route('backend.advance') }}">Save changes</button>
                    </div>
                </div>
            </div>
        </div>
            @endsection
            @section('scripts')
                @parent
                <script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
                <script src="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/js/tempusdominus-bootstrap-4.min.js">
                </script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
                    integrity="sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
                    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
                <script src="{{ asset('assets/intl-tel-input-18.2.1/build/js/intlTelInput.min.js') }}"></script>
                <script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>
                <script>

function printPage() {
    // Hide the print button before printing
    document.getElementById('printButton').style.display = 'none';

    // Trigger the print action
    window.print();
}

// Listen for the afterprint event
window.addEventListener('afterprint', function() {
    // Show the print button after the print dialog is closed
    document.getElementById('printButton').style.display = 'initial';
});
function phone_number(){
                    var input_phone = document.querySelector("#phone_number"),
                        errorMsg = document.querySelector("#error-msg"),
                        validMsg = document.querySelector("#valid-msg");

                    // here, the index maps to the error code returned from getValidationError - see readme
                    var errorMap = ["Invalid number", "Invalid country code", "Too short", "Too long", "Invalid number"];

                    var iti = intlTelInput(input_phone, {
                        allowDropdown: true,
                        formatOnDisplay: true,
                        phoneValidation: true,
                        separateDialCode: true,
                        enablePlaceholder: true,
                        autoPlaceholder: "polite",
                        placeholderNumberType: "MOBILE",
                        searchCountryPlaceholder: 'Search Country',
                        preferredCountries: ["in"],
                        hiddenInput: "dialCodes",
                        utilsScript: "{{ url('assets/intl-tel-input-18.2.1/build/js/utils.js') }}"
                    });

                    iti.promise.then(function() {
                          var inputValue = input_phone.value.replace(/\s+/g, '');

            // Remove leading zeros
            inputValue = inputValue.replace(/^0+/, '');

            // Set the modified value back to the input field
            input_phone.value = inputValue;
                        // console.log("Initialised!");
                    });

                    $("input[name='country_code'").val(91);
                    // $("input[name='dialCode'").val(91);

                    var reset_input_phone = function() {
                        input_phone.classList.remove("error");
                        errorMsg.innerHTML = "";
                        errorMsg.classList.add("hide");
                        validMsg.classList.add("hide");
                    };

                    input_phone.addEventListener("countrychange", function() {
                        var data_iti = iti.getSelectedCountryData();
                        $("input[name='country_code'").val(data_iti.dialCode);
                        // $("input[name='dialCode'").val(data_iti.dialCode);

                        // console.log("country code " + JSON.stringify(iti.getSelectedCountryData()));
                        // console.log("country code " + data_iti.dialCode);
                    });

                    // on blur: validate
                    input_phone.addEventListener('blur', function() {
                        // console.log("blur!");
                        // console.log($("input[name='dialCodes'").val());
                        reset_input_phone();
                        if (input_phone.value.trim()) {
                            if (iti.isValidNumber()) {
                                validMsg.classList.remove("hide");
                            } else {
                                input_phone.classList.add("error");
                                var errorCode = iti.getValidationError();
                                errorMsg.innerHTML = errorMap[errorCode];
                                errorMsg.classList.remove("hide");
                            }
                        }
                    });

                    // on keyup / change flag: reset
                    input_phone.addEventListener('change', reset_input_phone);
                    input_phone.addEventListener('keyup', reset_input_phone);
                }


                function firstpdf(id) {
        $.ajax({
            url: "{{ route('backend.bill-statement.advance-pdf', ':id') }}".replace(':id',
                id), // Replace :id with the actual value of id        method: "GET",
            dataType: 'json',
            success: function(response) {
                // Create an iframe element
                // var iframe = $('<iframe>', {
                //     src: response.pdfUrl,
                //     style: 'width: 100%; height: 500px; border: none;'
                // });
                $('html').html(response.html);

                // var iframe = '<iframe src="' + response.pdfUrl + '"></iframe>';

                // Append the iframe to a container in your HTML (replace '#pdf-container' with the selector of your choice)
                // $('#pdf-container').html(iframe);
                // Open the modal

                // $('#pdf-modal').css('display', 'block');

                // // Set the PDF URL to the iframe source
                // $('#pdf-iframe').attr('src', response.pdfUrl);
                // $('.main-class, .navbar').addClass('d-none');

            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                // Handle errors here
            }
        });
    }

                    $(document).ready(function() {
                        $("select").selectize();
        $('#form2')[0].reset();
        var selectize = $('#room_type_id')[0].selectize;
selectize.clear();
                        $('#seg').change(function(){
      // Get the selected value
      var selectedValue = $(this).val();
      var selectize; // Declare selectize outside the if block

      if(selectedValue == 1) {
          // Initialize Selectize.js on the country_id select element
          var $countrySelect = $('#country_id').selectize();

          // Get the Selectize.js instance
          selectize = $countrySelect[0].selectize;

          // Set the value of the select element
          selectize.setValue('95');

          // Initialize Selectize.js on the nationality_id select element
          var $nationalitySelect = $('#nationality_id').selectize();

          // Get the Selectize.js instance
          selectize = $nationalitySelect[0].selectize;

          // Set the value of the select element
          selectize.setValue('95');
      } else {
          // Unset the value from both select elements
          selectize = $('#country_id')[0].selectize;
          selectize.clear();

          selectize = $('#nationality_id')[0].selectize;
          selectize.clear();
      }
  });

                        var room_type_id = $('#room_type_id')
                        .val(); // Assuming you have an input field with id 'room_type_id'



                // Get the current URL
                var currentUrl = window.location.href;

        // Parse the URL to extract query parameters
        var urlParams = new URLSearchParams(currentUrl.split('?')[1]);

        // Get the value of the 'room' query parameter
        var room = urlParams.get('room');

        // Get the value of the 'type' query parameter
        var type = urlParams.get('type');

        // Output the values (just for demonstration)
        // console.log("Room:", room);
        // console.log("Type:", type);

        if(room && type){
            var selectizeroom_type_id= $('#room_type_id')[0].selectize;

// Set the selected option for the 'guest_type' Selectize instance
selectizeroom_type_id.setValue(type);
setTimeout(function(){
        $('#ajax-btn').trigger('click');
    }, 1000);

// $("#ajax-btn").trigger('click');
// window.onload=function(){
// $("#ajax-btn").click();
// }
        }


function ajax_data_box(response){
    $('#floor-container').empty();
    var floorItem = response.data;
var roomStatuses = response.roomStatuses;

var blocked_count = 0;
var recent_count = 0;
var main_count = 0;
var single_count = 0;
var multiple_count = 0;
var roomcontent = floorItem.select_rooms.map(roomItem => {
    var booked = response.booked || [];
    var multiple_book = response.multiple_book || [];
    var className = "";
    if (roomItem.status == 1) {
        className = "black";
        blocked_count++;
    } else if (typeof booked !== 'undefined' && booked.includes(roomItem.id)) {
        className = "btn-block single-color";
        single_count++;

    } else if (typeof multiple_book !== 'undefined' && multiple_book.includes(roomItem.id)) {
        className = "btn-block multiple-color";
        multiple_count++;

    } else if (roomItem.status == 2) {
        className = "recently-vacate-color";
        recent_count++;
    } else {
        className = "main-color";
        main_count++;
    }
    return `<div class="col-6 col-sm-4 col-md-3 col-lg-1 mb-3">
                <button class="${className}" data-btn-id="${roomItem.id}">${roomItem.name}</button>
            </div>`;
}).join('');

var floorHtml = `
    <div class="row mt-4">
        <div class="card">
            <div class="card-header text-center">
                <h3>${floorItem.name} - ${main_count}</h3>
            </div>
            <div class="card-body">
                <div class="row mt-4">
                    ${roomcontent}
                </div>
            </div>
        </div>
    </div>`;


                        // $('#available_room').text(main_count);
                        // $('#black_room').text(blocked_count);
                        // $('#recent_room').text(recent_count);
                        // $('#normal_room').text(single_count);
                        // $('#group_room').text(multiple_count);
                        $('#floor-container').append(floorHtml);

                        // Check if response.customers_data is defined and not null
if (response.customers_data && response.customers_data.select_rooms) {
    // Extract the array of room IDs using map
    var roomIds = response.customers_data.select_rooms.map(room => room.id);

    // Iterate over each button with the class .btn-block inside #floor-container
    $('#floor-container .btn-block').each(function() {
        // Check if the data-btn-id attribute of the button exists in roomIds array
        if (roomIds.includes($(this).data('btn-id'))) {
            // Trigger a click event on the button
            $(this).trigger('click');
        }
    });
}


                                        if(room && type){

                                         // Iterate over each button with the class .btn-block inside #floor-container
    $('#floor-container .btn-block').each(function() {
        // Check if the data-btn-id attribute of the button matches the room variable
        if ($(this).data('btn-id') == room) {
            // Trigger a click event on the button
            $(this).trigger('click');
        }
    });

            }
}


$('#room_type_id').on('change', function(e) {
            e.preventDefault();
            var room_type_id = $(this).val();

     var _token = $('meta[name="csrf-token"]').attr('content');


                            $.ajax({
                                url: "{{ route('backend.ajax_data') }}",
                                method: "POST",
                                headers: {
                                    'x-csrf-token': _token
                                },
                                data: {
                                    room_type_id: room_type_id
                                },
                                success: function(response) {
                                    // console.log(response);
                                    // Handle the response as needed
                                    if (response.data) {
                                        ajax_data_box(response);
                                }

                                else {
                                        console.log('No data received');
                                    }
                                },
                                error: function(xhr, status, error) {
                                    console.error(xhr.responseText);
                                    // Handle errors
                                }
                            });
                        });

        $('#bill_no').on('keyup change blur', function(e) {
    e.preventDefault();
            var bill_no = $(this).val();

     var _token = $('meta[name="csrf-token"]').attr('content');


                            $.ajax({
                                url: "{{ route('backend.ajax_data_bill_no') }}",
                                method: "POST",
                                headers: {
                                    'x-csrf-token': _token
                                },
                                data: {
                                    bill_no: bill_no
                                },
                                success: function(response) {
                                //  console.log(response);
                                    // Handle the response as needed
                                    if (response.data) {
                                        ajax_data_box(response);
                                }

                                else {
                                        console.log('No data received');
                                    }
                                },
                                error: function(xhr, status, error) {
                                    console.error(xhr.responseText);
                                    // Handle errors
                                }
                            });
                        });

                        //New Function Change for Room Number
                    $('#room_no').on('keyup change blur', function(e) {
                        if (e.which != 13) {
                            return;
                        }
                        e.preventDefault();
                        var room_no = $(this).val();
                        if (room_no.length < 2)
                            return;

                        room_no = room_no.toUpperCase();
                        var _token = $('meta[name="csrf-token"]').attr('content');


                        $.ajax({
                            url: "{{ route('backend.ajax_data_room_no') }}",
                            method: "POST",
                            headers: {
                                'x-csrf-token': _token
                            },
                            data: {
                                room_no: room_no
                            },
                            success: function(response) {
                                console.log(response);
                                // Handle the response as needed
                                if (response.data) {
                                    ajax_data_box(response);
                                } else {
                                    console.log('No data received');
                                }
                            },
                            error: function(xhr, status, error) {
                                console.error(xhr.responseText);
                                // Handle errors
                            }
                        });
                    });
                        var hasLooped = false;

                        $(document).on('click', '#floor-container .btn-block', function() {
                            $('#check-in-div').removeClass('d-none');

phone_number();
    // Remove active-btn class from all buttons
    $('.btn-block').removeClass('active-btn');

    // Toggle active-btn class on the clicked button
    $(this).addClass('active-btn');

    // Remove existing input fields
   // Initialize an array to store selected values
   var selectedValues = [];

// Remove existing input fields
$('#room_type_container').empty();

// Loop through all buttons with class btn-blockname="room_ids[]"
$('.btn-block').each(function() {
    // If the button has active-btn class, add its value to selectedValues array
    if ($(this).hasClass('active-btn')) {
        selectedValues.push($(this).data('btn-id'));
        // Create a new input field for each selected value
        var inputField = $('<input type="hidden" name="room_ids[]" class="selected-room" required>');
        // Set the value of the input field
        inputField.val($(this).data('btn-id'));
        // Append the input field to the container
        $('#room_type_container').append(inputField);
    }
});
    // Get the selected value
    var select_rooms = $(this).data('btn-id');
    var _token = $('meta[name="csrf-token"]').attr('content');
                            $.ajax({
                                url: "{{ route('backend.ajax_data_modification') }}",
                                method: "POST",
                                headers: {
                                    'x-csrf-token': _token
                                },       type: 'POST',
        data: {
            select_rooms: select_rooms
        },
        dataType: 'json',
        success: function(response) {
            var customer_data=response.data;
 // Assuming `response.data.customer_detail` is your array
 var customerDetails = response.data.customer_detail;

// Accessing the last item in the array
var lastCustomerDetail = customerDetails[customerDetails.length - 1];
var advance_amount = response.data.advance_amount; // Assuming advance_amount is an array of numbers

// Using Array.reduce() to sum up the values
// Assuming advance_amount is an array of objects containing advance_amount property
var advance_amount_sum_of = advance_amount.reduce((acc, obj) => acc + parseFloat(obj.advance_amount), 0);
var advance_amount_sum = parseFloat(advance_amount_sum_of); // Assuming advance_amount_sum is already defined

var checkInTimestamp = lastCustomerDetail.check_in;
var checkOutTimestamp = lastCustomerDetail.check_out;

// Convert timestamps to Moment.js objects
var checkInTime = moment(checkInTimestamp);
var checkOutTime = moment(checkOutTimestamp);
var formattedCheckIn = checkInTime.format('DD-MM-YYYY HH:mm');
var formattedCheckOut = checkOutTime.format('DD-MM-YYYY HH:mm');

// Set formatted timestamps to input fields
$('input[name="check_in_old"]').val(formattedCheckIn);

$('input[name="check_out_old"]').val(formattedCheckOut);
$('input[name="check_in"]').val(formattedCheckOut);

            customer_data.select_rooms.forEach(function(room) {
    // Get the id of the current room object
    var roomId = room.id;

    // Find the button with the corresponding data-btn-id attribute
    var $button = $('#floor-container .btn-block[data-btn-id="' + roomId + '"]');

    // Add the active class to the button if found
    if ($button.length) {
        $button.addClass('active-btn');

        // Create an input field for each room
    var inputField = $('<input type="hidden" name="room_ids[]" class="selected-room" required>');

    // Set the value of the input field to the room's id
    inputField.val(room.id);

    $('#room_type_container').append(inputField);
        hasLooped = true;
    }
});

// Using toFixed(2) to ensure two decimal places
            // console.log(response);
            var selectedButtonCount = $('.btn-block.active-btn').length;
// alert(selectedButtonCount);
            $('input[name="customer_ids_id"]').val(customer_data.id);
           // Assuming customer_data.room_type.price and selectedButtonCount are already defined

// Calculate the price
var price = parseFloat(customer_data.room_type.price) * parseFloat(selectedButtonCount);

// Set the price value to the input field
$('input[name="price"]').val(price.toFixed(2)); // Assuming you want to display the price with two decimal places

// Calculate the balance
var balance = price - advance_amount_sum;

// Now you can use the balance as needed


            $('#guest_name').val(customer_data.guest_name);
            $("input[name='country_code'").val(customer_data.country_code);

            $('#phone_number').val('+' +customer_data.country_code + + customer_data.phone_number);




$('#table_data').empty();


var htmtable = '<table class="w-100 mt-4">' +
                        '<tbody>' +

                          '<tr>' +
                                '<th>Balance</th>' +
                                '<td id="balance">' + balance + '</td>' + // Append check-in value here without quotes
                                                            '</tr>' +
                                                            '<tr>' +
                                '<th>Total</th>' +
                                '<td id="total"></td>' + // Append check-in value here without quotes
                                                            '</tr>' +
                        '</tbody>' +
                    '</table>';

    $('#table_data').append(htmtable);

// Output remaining time
// console.log('Remaining time: ' + remainingHours + ' hours and ' + remainingMinutes + ' minutes');


// Iterate over each object in the select_rooms array



        },
        error: function(xhr, status, error) {
            console.error(xhr.responseText);
            // Handle errors here
        }
    });
});

$('#saveChangesBtn').on('click', function() {
         // Get the value of user_ids_id
// var userIdsId = $('input[name="user_ids_id"]').val();

// // Add user_ids_id to the form data
// $('#paymentModal input[name="user_ids_id"]').val(userIdsId);

// Serialize the form data
var formData = $('#paymentModal').find('input, select').serialize();

            var routeUrl = $(this).data('route');
            var _token = $('meta[name="csrf-token"]').attr('content');

            // Send AJAX POST request
            $.ajax({
                url: routeUrl,
                method: "POST",
                headers: {
                    'x-csrf-token': _token
                },
                data: formData,
                success: function(response) {
                    // Handle success response
                    console.log(response);
                    $('#paymentModal').modal('hide');
                    firstpdf(response.data.customer_ids_id);
                },
                error: function(xhr, status, error) {
                    // Handle error response
                    console.error(xhr.responseText);
                }
            });
        });
  $('#form2').on('submit', function(e) {
            e.preventDefault();
            // alert($(this).valid());
                var _token = $('meta[name="csrf-token"]').attr('content');

                var formData1 = new FormData($('#form1')[0]); // Get data from Form 1
                var formData2 = new FormData($('#form2')[0]); // Get data from Form 2

                // Append data from Form 2 to Form 1
                for (var pair of formData2.entries()) {
                    formData1.append(pair[0], pair[1]);
                }

                $.ajax({
                    url: "{{ route('backend.extent.store') }}",
                    method: "POST",
                    data: formData1,
                    headers: {
                        'x-csrf-token': _token
                    },
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        Swal.fire({
                            title: response.message,
                            icon: "success"
                        });
                        // firstpdf(response.data.id);
                        $('#paymentModal').on('show.bs.modal', function(e) {
                            $(this).find('#customer_id').val(response.data.customer_ids_id );
                        });

                        // Open the modal popup automatically
                        $('#paymentModal').modal('show');
                    },
                    error: function(xhr, status, error) {
                        Swal.fire({
                            title: 'Something Went Wrong',
                            icon: "success"
                        });
                        console.error(xhr.responseText);
                    }
                });

        });

});

                    // $("select").selectize();

                    $(document).ready(function() {
                        $('#datetimepickercheckin').datetimepicker({
            useCurrent: false,
            showTodayButton: true,
            showClear: true,
            toolbarPlacement: 'bottom',
            sideBySide: true,
            format: 'DD-MM-YYYY HH:mm', // Set your desired format here
            icons: {
                time: "fa fa-clock",
                date: "fa fa-calendar",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down",
                previous: "fa fa-chevron-left",
                next: "fa fa-chevron-right",
                today: "fa fa-clock",
                clear: "fa fa-trash-alt",
                close: "fa fa-times"
            },
        });

        // For checkout date picker
        $('#datetimepickercheckout').datetimepicker({
            useCurrent: false,
            showTodayButton: true,
            showClear: true,
            toolbarPlacement: 'bottom',
            sideBySide: true,
            format: 'DD-MM-YYYY HH:mm', // Set your desired format here
            icons: {
                time: "fa fa-clock",
                date: "fa fa-calendar",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down",
                previous: "fa fa-chevron-left",
                next: "fa fa-chevron-right",
                today: "fa fa-clock",
                clear: "fa fa-trash-alt",
                close: "fa fa-times"
            }
        });


        $('#datetimepickercheckin_old').datetimepicker({
            useCurrent: false,
            showTodayButton: true,
            showClear: true,
            toolbarPlacement: 'bottom',
            sideBySide: true,
            format: 'DD-MM-YYYY HH:mm', // Set your desired format here
            icons: {
                time: "fa fa-clock",
                date: "fa fa-calendar",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down",
                previous: "fa fa-chevron-left",
                next: "fa fa-chevron-right",
                today: "fa fa-clock",
                clear: "fa fa-trash-alt",
                close: "fa fa-times"
            },
        });

        // For checkout date picker
        $('#datetimepickercheckout_old').datetimepicker({
            useCurrent: false,
            showTodayButton: true,
            showClear: true,
            toolbarPlacement: 'bottom',
            sideBySide: true,
            format: 'DD-MM-YYYY HH:mm', // Set your desired format here
            icons: {
                time: "fa fa-clock",
                date: "fa fa-calendar",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down",
                previous: "fa fa-chevron-left",
                next: "fa fa-chevron-right",
                today: "fa fa-clock",
                clear: "fa fa-trash-alt",
                close: "fa fa-times"
            }
        });


        $("#datetimepickercheckin").on("change.datetimepicker", ({date, oldDate}) => {

      })
      $("#datetimepickercheckout").on("change.datetimepicker", function({ date, oldDate }) {
    // var checkinValue = $('input[name="check_in"]').val();
    // var checkoutValue = $('input[name="check_out"]').val();

    // // Parse the dates using the Date object
    // var checkinDate = new Date(checkinValue);
    // var checkoutDate = new Date(checkoutValue);

    // // Calculate the difference in milliseconds between the two dates
    // var differenceInMilliseconds = checkoutDate.getTime() - checkinDate.getTime();

    // // Convert milliseconds to days
    // var differenceInDays = Math.round(differenceInMilliseconds / (1000 * 60 * 60 * 24));
    // var TotalDays = '';
    // if (isNaN(differenceInDays) || differenceInDays === 0) {
    //     TotalDays = 1;
    // } else {
    //     TotalDays = differenceInDays;
    // }
// Get the values of check-in and check-out inputs
var checkinValue = $('input[name="check_in"]').val();
var checkoutValue = $('input[name="check_out"]').val();

// Parse the dates using Moment.js
var checkinDate = moment(checkinValue, 'DD-MM-YYYY HH:mm');
var checkoutDate = moment(checkoutValue, 'DD-MM-YYYY HH:mm');

// Calculate the difference in days
var differenceInDays = checkoutDate.diff(checkinDate, 'days');
var TotalDays = '';

if (isNaN(differenceInDays) || differenceInDays === 0) {
    TotalDays = 1;
} else {
    TotalDays = differenceInDays;
}
    $('input[name="days"]').val(TotalDays);
    var default_price = parseFloat($('#price').val()) * TotalDays;

// Assuming #balance, #price, and #taota are elements, we need to retrieve their values correctly
var balanceValue = parseFloat($('#balance').text().trim()); // Assuming #balance contains a numeric value
var total = balanceValue + default_price;
$('input[name="total_price"]').val(total);

$('#total').text(balanceValue + ' + ' + default_price + ' = ' + (total));
// console.log( balanceValue '+' default_price '=' total);

});


                    });
                </script>

            @endsection
