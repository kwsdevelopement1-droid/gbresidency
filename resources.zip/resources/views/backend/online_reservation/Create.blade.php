@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />


    <style>
        table {
  border-collapse: collapse;
}

table, th, td {
  border: none;
}

.btn.btn-primary {
width: 512px;
height: 48px;
/* padding: 8px 16px; */
border-radius: 4px;
background: #901111;
border: none;
color: #FFF;
font-family: Montserrat;
font-size: 14px;
font-style: normal;
font-weight: 600;
line-height: normal;
}
.btn.btn-success {
background-color: #8dd3bb;
border-color: #8dd3bb;
font-family: Montserrat;
font-style: normal;
font-weight: 700;
line-height: normal;
}
th {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 700;
line-height: normal;
letter-spacing: 0.263px;
}
td {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 500;
line-height: normal;
letter-spacing: 0.263px;
}
td span{
padding: initial !important;
color: #000 !important;
font-family: Raleway !important;
font-size: 17.518px !important;
font-style: normal !important;
font-weight: 500 !important;
line-height: normal !important;
letter-spacing: 0.263px !important;
}
td span::after {
content: " ";
}
.form-control.form-control-sm {
height: 25px;
}
.table > :not(caption) > * > * {
box-shadow: none;
}
.page-item.active .page-link {
background-color: #8dd3bb;
border-color: #8dd3bb;
}




 .gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        .gallery img {
            max-width: 150px;
            cursor: pointer;
        }
        .gallery div {
            position: relative;
        }
        .gallery div .remove {
            position: absolute;
            top: 5px;
            right: 5px;
            background: red;
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            font-size: 14px;
            width: 20px;
            height: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }



    </style>
@endsection

@section('title_nav')

    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Online Room Create</h2>
    </div>
@endsection


                                

<form action="{{ route('backend.onlineroomstore') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="row">
    <div class="col-md-4">
    <div>
        <label>Room type</label>
        <input type="text" name="roomname" class="form-control" placeholder="Enter Room Type" required>
    </div>
    </div>
    <div class="col-md-4">
    <div>
        <label>Room Price</label>
        <input type="text" name="roomprice" class="form-control" placeholder="Enter Room price" required><br>
    </div>
    </div>
    <div class="col-md-4">
    
    <div>
        <label>Reservation Amount</label>
        <input type="text" name="reservationprice" class="form-control" placeholder="Enter Reservation price" required>
    </div>
    
    </div>
    <div class="col-md-6">
    
    <div>
        <label>Number Of PAX</label>
     
        <select id="exampleSelect" name="exampleSelect" class="form-control">
            <option value="1"> 1</option>
            <option value="2" selected> 2</option>
            <option value="3"> 3</option>
            <option value="4"> 4</option>
            <option value="5"> 5</option>
            <option value="6"> 6</option>
            <option value="7"> 7</option>
            <option value="8"> 8</option>
            <option value="9">9</option>
            <option value="10"> 10</option>
        </select>
    </div>
    
    </div>
    
    <div class="col-md-6">
    <div>
    <label>Over View</label>
        <textarea name="overview" class="form-control" placeholder="Enter Overview" required></textarea><br>
    </div>
    </div>
    

    <div class="col-md-6">
    
    <div>
        <label>Select an image to upload:</label>
        <input type="file" class="form-control" id="singleImageInput" name="singleImageInput" accept="image/*">
        <br><br>
        <label>Image Preview:</label><br>
         <center><img id="empty_sigle_img" src="../../images/empty_icon.png" style="max-width: 300px;"></center>
        <img id="singleImagePreview"  src="#" alt="Selected Image" style="display: none; max-width: 300px;">
    </div>
    
    </div>
    
    <div class="col-md-6">
    
    <div>
        <label>Select images for gallery:</label>
        <input type="file"  class="form-control" id="galleryImageInput" name="galleryImageInput[]" accept="image/*" multiple>
        <br><br>
        <label>Image Gallery:</label>
        <div class="gallery" id="gallery"></div>
        <div><center><img id="empty_multi_img" src="../../images/empty_icon.png" style="max-width: 300px;"></center></div>
    </div>
    
    </div>
    <div class="col-md-3"></div>
    <div class="col-md-6"><br>
    <input type="submit" class="btn btn-primary" value="Submit" name="Submit">
    </div>
    <div class="col-md-3"></div>
    </div>
</form>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js"></script>
<script>
    document.getElementById('singleImageInput').addEventListener('change', function(event) {
        
        document.getElementById('empty_sigle_img').style.display="none";
        
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.getElementById('singleImagePreview');
                img.src = e.target.result;
                img.style.display = 'block';
            }
            reader.readAsDataURL(file);
        }
    });

    // Image gallery
    document.getElementById('galleryImageInput').addEventListener('change', function(event) {
        document.getElementById('empty_multi_img').style.display="none";
        const files = event.target.files;
        const gallery = document.getElementById('gallery');
        const currentImageCount = gallery.children.length;
        const totalImageCount = currentImageCount + files.length;

        if (totalImageCount > 5) {
            alert('You can only upload up to 5 images.');
            return;
        }

        Array.from(files).forEach(file => {
            const reader = new FileReader();
            reader.onload = function(e) {
                const div = document.createElement('div');
                const img = document.createElement('img');
                img.src = e.target.result;

                const removeButton = document.createElement('button');
                removeButton.innerHTML = '&times;';
                removeButton.classList.add('remove');
                removeButton.addEventListener('click', function() {
                    gallery.removeChild(div);
                });

                div.appendChild(img);
                div.appendChild(removeButton);
                gallery.appendChild(div);
            }
            reader.readAsDataURL(file);
        });
    });

    new Sortable(document.getElementById('gallery'), {
        animation: 150,
        ghostClass: 'sortable-ghost'
    });
</script>


@endsection


