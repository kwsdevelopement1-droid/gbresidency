@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />


    <style>
        table {
  border-collapse: collapse;
}

table, th, td {
  border: none;
}

.btn.btn-primary {
width: 512px;
height: 48px;
/* padding: 8px 16px; */
border-radius: 4px;
background: #901111;
border: none;
color: #FFF;
font-family: Montserrat;
font-size: 14px;
font-style: normal;
font-weight: 600;
line-height: normal;
}
.btn.btn-success {
background-color: #8dd3bb;
border-color: #8dd3bb;
font-family: Montserrat;
font-style: normal;
font-weight: 700;
line-height: normal;
}
th {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 700;
line-height: normal;
letter-spacing: 0.263px;
}
td {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 500;
line-height: normal;
letter-spacing: 0.263px;
}
td span{
padding: initial !important;
color: #000 !important;
font-family: Raleway !important;
font-size: 17.518px !important;
font-style: normal !important;
font-weight: 500 !important;
line-height: normal !important;
letter-spacing: 0.263px !important;
}
td span::after {
content: " ";
}
.form-control.form-control-sm {
height: 25px;
}
.table > :not(caption) > * > * {
box-shadow: none;
}
.page-item.active .page-link {
background-color: #8dd3bb;
border-color: #8dd3bb;
}






.switch {
  position: relative;
  display: inline-block;
  width: 50px;
  height: 24px;
}
.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 16px;
  width: 16px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
    </style>
@endsection

@section('title_nav')

    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Room Lists</h2>
    </div>
@endsection
<div class="row">
    
    <div class="col-md-12">
       
            <div style="margin-bottom: 10px;" class="row">
                <div class="col-lg-12 d-flex justify-content-end">
                    <a class="btn btn-success" href="{{route('backend.room_create')}}">
                        <span><i class="fa fa-plus"></i></span> Add New
                    </a>
                </div>
            </div>
       
        <div class="card">

            <div class="card-body">
                <div class="table-responsive">
                    <table class=" table table-bordered table-striped table-hover datatable datatable-Room">
                        <thead>
                            <tr>
                                {{-- <th width="10">

                        </th> --}}
                                <th>
                                    Si.No
                                </th>
                                <th>
                                    Room Type
                                </th>
                                 <th>
                                    Image
                                </th>
                                <th>
                                   Cost
                                </th>
                                <th>
                                   Reservation Cost 
                                </th>
                               <!-- <th>
                                   Visibility 
                                </th>-->
                                
                                <th>
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            @foreach($rooms as $room)
                                <tr data-entry-id="">
                                    
                                    <td>
                                       {{$loop->iteration}}
                                    </td>
                                    <td>
                                       {{$room->roomname}}
                                    </td>
                                    
                                    <td>
                                        <img src="{{ asset('storage/siteimages/'. $room->single_image) }}" style="height:50px; width:50px;">
                                    </td>
                                    
                                    <td>
                                        {{$room->roomprice}}
                                    </td>
                                    
                                    <td>
                                         {{$room->reservationprice}}
                                    </td>
                                    <!--<td>
                                        <label class="switch">
                                          <input type="checkbox" checked>
                                            <span class="slider round"></span>
                                        </label>
                                    </td>-->
                                    
                                    <td>
                                       <a class="btn btn-warning" href="{{ route('backend.onlineroomedit', ['room' => $room->id]) }}">
                                                Edit
                                            </a>
                                           
                                       
                                            <form action="{{ route('backend.onlineroomdelete', ['room' => $room->id]) }}" method="POST"
                onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
                                        

                                    </td>

                                </tr>
                           @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection


