@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />


    <style>
        table {
  border-collapse: collapse;
}

table, th, td {
  border: none;
}

.btn.btn-primary {
width: 512px;
height: 48px;
/* padding: 8px 16px; */
border-radius: 4px;
background: #901111;
border: none;
color: #FFF;
font-family: Montserrat;
font-size: 14px;
font-style: normal;
font-weight: 600;
line-height: normal;
}
.btn.btn-success {
background-color: #8dd3bb;
border-color: #8dd3bb;
font-family: Montserrat;
font-style: normal;
font-weight: 700;
line-height: normal;
}
th {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 700;
line-height: normal;
letter-spacing: 0.263px;
}
td {
color: #000;
font-family: Raleway;
font-size: 17.518px;
font-style: normal;
font-weight: 500;
line-height: normal;
letter-spacing: 0.263px;
}
td span{
padding: initial !important;
color: #000 !important;
font-family: Raleway !important;
font-size: 17.518px !important;
font-style: normal !important;
font-weight: 500 !important;
line-height: normal !important;
letter-spacing: 0.263px !important;
}
td span::after {
content: " ";
}
.form-control.form-control-sm {
height: 25px;
}
.table > :not(caption) > * > * {
box-shadow: none;
}
.page-item.active .page-link {
background-color: #8dd3bb;
border-color: #8dd3bb;
}




 .gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        .gallery img {
            max-width: 150px;
            cursor: pointer;
        }
        .gallery div {
            position: relative;
        }
        .gallery div .remove {
            position: absolute;
            top: 5px;
            right: 5px;
            background: red;
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            font-size: 14px; 
            width: 20px;
            height: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

.is-invalid {
    border-color: #dc3545;
}

.invalid-feedback {
    color: #dc3545;
    font-size: 0.875em;
    display: block;
}


    </style>
@endsection

@section('title_nav')

    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Online Room Create</h2>
    </div>
@endsection

<form action="{{ route('backend.updateonlineroom', ['id' => $room->id]) }}" method="POST" enctype="multipart/form-data">

    @csrf
        <div class="row">
            <div class="col-md-4">
                <div>
                    <label>Room type</label>
                    <input type="text" name="roomname" class="form-control" placeholder="Enter Room Type" value="{{ $room->roomname }}" required>
                    @error('roomname')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
                </div>
            </div>
            <div class="col-md-4">
                <div>
                    <label>Room Price</label>
                    <input type="text" name="roomprice" class="form-control" placeholder="Enter Room price" value="{{ $room->roomprice }}" required><br>
                     @error('roomprice')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
                </div>
            </div>
            <div class="col-md-4">
                <div>
                    <label>Reservation Amount</label>
                    <input type="text" name="reservationprice" class="form-control" placeholder="Enter Reservation price" value="{{ $room->reservationprice }}" required>
                     @error('reservationprice')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
                </div>
            </div>
            
            <div class="col-md-6">
    <div>
        <label>Number Of PAX</label>
        <select id="exampleSelect" name="no_tax" class="form-control">
            <?php
            $taxOptions = range(1, 10);
            foreach ($taxOptions as $option) {
                $selected = ($option == $room->no_tax) ? 'selected' : '';
                echo "<option value=\"$option\" $selected> $option</option>";
            }
            ?>
        </select>
    </div>
</div>

            
            
            <div class="col-md-6">
                <div>
                    <label>Over View</label>
                    <textarea name="overview" class="form-control" placeholder="Enter Overview" required>{{ $room->overview }}</textarea><br>
                       @error('overview')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
                </div>
            </div>

            <div class="col-md-6">
        <div class="col-md-6">
        <div>
            <label>Select an image to upload:</label>
            <input type="file" class="form-control" id="singleImageInput" name="singleImageInput" accept="image/*">
             @error('singleImageInput')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            <br><br>
            <label>Image Preview:</label><br>

            <img id="singleImagePreview" src="{{ $room->single_image ? asset('storage/siteimages/'.$room->single_image) : asset('storage/siteimages/empty_icon.png') }}" style="max-width: 200px; display: {{ $room->single_image ? 'block' : 'none' }}">
        </div>
    </div>
    </div>


        <div class="col-md-6">
                <div class="form-group">
                    <label>Select images for gallery:</label>
                    <input type="file" class="form-control" id="galleryImageInput" name="galleryImageInput[]" accept="image/*" multiple>
                    <br><br>
                    <label>Image Gallery:</label>
                    <div class="gallery" id="gallery">
                        @if($galleryImages)
                            @foreach($galleryImages as $image)
                                <div class="sortable-item">
                                    <img src="{{ asset('storage/siteimages/'.$image) }}" style="max-width: 108px; margin-right: 10px;">
                                    <button class="remove" onclick="removeImage(this)">x</button>
                                </div>
                            @endforeach
                        @else
                            <img id="empty_multi_img" src="{{ asset('storage/siteimages/empty_icon.png') }}" style="max-width: 300px;">
                        @endif
                    </div>
                </div>
            </div>


    <div class="col-md-3"></div>
    <div class="col-md-6"><br>
        <input type="submit" class="btn btn-primary" value="Submit" name="Submit">
    </div>
    <div class="col-md-3"></div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js"></script>
    <script>

        document.getElementById('singleImageInput').addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const img = document.getElementById('singleImagePreview');
                    img.src = e.target.result;
                    img.style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        });

            document.getElementById('galleryImageInput').addEventListener('change', function(event) {
            const files = event.target.files;
            const gallery = document.getElementById('gallery');
            const currentImageCount = gallery.children.length;
            const totalImageCount = currentImageCount + files.length;

            if (totalImageCount > 5) {
                alert('You can only upload up to 5 images.');
                return;
            }

            Array.from(files).forEach(file => {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const div = document.createElement('div');
                    div.classList.add('sortable-item');
                    const img = document.createElement('img');
                    img.src = e.target.result;

                    const removeButton = document.createElement('button');
                    removeButton.innerHTML = '&times;';
                    removeButton.classList.add('remove');
                    removeButton.addEventListener('click', function() {
                        gallery.removeChild(div);
                    });

                    div.appendChild(img);
                    div.appendChild(removeButton);
                    gallery.appendChild(div);
                }
                reader.readAsDataURL(file);
            });
        });

        new Sortable(document.getElementById('gallery'), {
            animation: 150,
            ghostClass: 'sortable-ghost'
        });

        function removeImage(element) {
            element.parentNode.remove();
        }
    </script>



@endsection


