<!DOCTYPE html>
<html>

<head>
    <title>APL Check Out Bill</title>
    <style type="text/css" media="print">
        @page {
            size: auto;
            /* auto is the initial value */
            margin: 0;
            /* this affects the margin in the printer settings */
        }
    </style>
    <style>
        @media print {
            .rnd-tab {
                margin-left: 65%;
            }

        }

        .printButton {
            cursor: pointer;
            background: #bc1b1b;
            color: #fff;
            width: 100px;
            border: none;
            border-radius: 2px;
            height: 28px;
            font-size: 20px;
        }

        * {
            font-family: 'Times New Roman';
        }

        .widget {
            float: left;
            /* border: 1px solid #ccc;  */
            box-sizing: border-box;
            padding-left: 20px;
            padding-right: 20px;
        }

        .widget-1 {
            width: 20%;
            /* 20% width for Widget 1 */
        }

        .widget-2 {
            width: 60%;
            /* 50% width for Widget 2 */
        }

        .widget-3 {
            width: 20%;
            /* 30% width for Widget 3 */
        }

        .widget img {
            max-width: 100%;
            height: auto;
        }

        .clear {
            clear: both;
            /* Clear the float to prevent overlapping content */
        }

        .widget-4 {
            width: 45%;
            /* 20% width for Widget 1 */
        }

        .widget-5 {
            width: 20%;
            /* 50% width for Widget 2 */
        }

        .widget-6 {
            width: 35%;
            /* 30% width for Widget 3 */
        }

        .inline {
            display: inline;
            /* Display elements inline */
        }

        .inlineright {
            display: inline;
            text-align: right;
            /* Display elements inline */
        }

        .widget-7 {
            width: 70%;
            /* 20% width for Widget 1 */
        }

        .widget-8 {
            width: 20%;
            /* 50% width for Widget 2 */
        }

        .rnd-tab {
            margin-left: 60%;
        }

        hr.new2 {
            border-top: 2px dashed rgb(0, 0, 0);
        }


        .address {
            display: flex;
            align-items: flex-start;
        }

        .address .label {
            min-width: 100px;
            /* Adjust as needed */
            margin-right: 10px;
        }

        .address .value {
            flex-grow: 1;
            word-wrap: break-word;
            margin-left: -8px;
        }

        .d>th {
            font-weight: 300;
        }



        .widget-11 {
            width: 30%;
            /* 50% width for Widget 2 */
        }

        .widget-12 {
            width: 25%;
            /* 50% width for Widget 2 */
        }

        .widget-13 {
            width: 12%;
            /* 50% width for Widget 2 */
        }

        .widget-14 {
            width: 43%;
            /* 50% width for Widget 2 */
        }

        .widget-15 {
            width: 100%;
            /* 50% width for Widget 2 */
        }

        .back-button {
            display: inline-block;
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }

        .back-button:hover {
            background-color: #45a049;
        }

        html,
        div.content {
            width: 210mm;
            height: 297mm;
            margin: 0 auto;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }
    </style>
    <script>
        console.log("I am here");
        console.log(JSON.stringify($req));
    </script>
</head>
<!-- <body style="padding-left:20%; padding-right:20%;"> -->

<body>
    <div id="back-btn">
        <a href="javascript:location.reload(true)" class="back-button">Back</a>
    </div>
    <div style="margin-top: 20px;" id="content">
        <div class="widget widget-1">
            <img src="{{ asset('assets/img/amma-1.png') }}" alt="amma" height="100" width="100">
        </div>


        <div class="widget widget-2">
            <div style="text-align: center; line-height: 10px;">
                <p style="font-weight: 400; font-size: 18px;">Om Sakthi</p>
                <p> <b>ADHIPARASAKTHI LODGING</b></p>
                <p> G.S.T. ROAD</p>
                <p> MELMARUVATHUR, CHENGALPATTU DIST - 603 319.</p>
                <p> RECEPTION PH: 044 - 27529084, 7598449853</p>
            </div>
        </div>
        <div class="widget widget-3">
            <img src="{{ asset('assets/img/APLLOGO.png') }}" alt="APL-LOGO">
        </div>
        <div class="clear"></div>



        <div>
            <div class="widget widget-4">
                <div style="font-weight: 800;">
                    <span class="inline">GSTin:</span>
                    <span class="inline">33AGZPR2791L1ZF</span>
                </div>
            </div>


            <div class="widget widget-13">
                <p class="inline" style="color: transparent; padding-bottom: -10px ;">GB</p>

            </div>
            <div class="widget widget-14">
                <div style="font-weight: 500; text-align: right;">
                    <span class="inline"> E-Mail:</span>
                    <span class="inline">adhiparasakthilodging@gmail.com</span>
                </div>
            </div>

        </div>
        <div class="clear"></div>
        <hr style="height: 1px; background-color: black; ">


        <div class="widget widget-4">
            <div style="text-align: left;">
                <span class="inline">Bill No &nbsp; &nbsp; &nbsp;:</span>
                @php
                $currentMonth = date('n'); // Get the current month (1 to 12)

                // Check if the current month is April or later
                if ($currentMonth >= 4) {
                // Finance year starts from April 1st of the current year to March 31st of the next year
                $startYear = date('y');
                $endYear = date('y', strtotime('+1 year'));
                } else {
                // Finance year starts from April 1st of the previous year to March 31st of the current year
                $startYear = date('y', strtotime('-1 year'));
                $endYear = date('y');
                }

                @endphp
                @if(isset($customer->houseguest))
                <span class="inline">M/{{ sprintf("%03d",$customer->houseguest->id) }}</span>

                @else
                <span class="inline">APL/{{ $startYear }}-{{ $endYear }}/{{ sprintf("%03d",$customer->checkOut->id) }}</span>

                @endif
            </div>
        </div>

        <div class="widget widget-5">
            <p class="inline" style="color: transparent; padding-bottom: -10px ;">GB</p>
        </div>

        <div class="widget widget-6">
            <div style="text-align: right;">
                <span class="inline">Date &nbsp; &nbsp; &nbsp;:</span>
                <span class="inline">{{ \Carbon\Carbon::now()->format('d/m/Y H:i:s') }}</span>
            </div>
        </div>
        <div class="clear"></div>
        <hr style="height: 1px; background-color: black; padding-bottom:-10px;">


        <div>
            <div class="widget widget-4" style="line-height: 25px;">
                <div>
                    <span class="inline">Guest Name&nbsp; &nbsp;:</span>
                    <span class="inline">{{ $customer->guest_name ?? ''}}</span>
                </div>

                <div class="address">
                    <span class="label">Address&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; :</span>
                    <span class="value">{{ wordwrap($customer->address ?? '', 50, "\n", true) }}</span>
                </div>

                <div>
                    <span class="inline">Guest GSTIN :</span>
                    <span class="inline">{{ $customer->guest_gstin ?? 'NIL'}}</span>
                </div>

                <div>
                    <span class="inline">Nationality&nbsp; &nbsp; &nbsp;:</span>
                    <span class="inline">{{ $customer->nationality->name ?? 'NIL'}}</span>
                </div>
                @php
                $lastCustomerDetailLast = $customer->customerDetail->last();
                $lastCustomerDetailFirst = $customer->customerDetail->first();
                $dateAndTime_check_in = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $lastCustomerDetailFirst->check_in);

                // Separate the date and time components
                $date_check_in = $dateAndTime_check_in->format('d/m/Y'); // Format: DD-MM-YYYY
                $time_check_in = $dateAndTime_check_in->format('H:i:s'); // Format: HH:MM:SS

                // Create Carbon instance for current date and time
                $dateAndTime = \Carbon\Carbon::now();
                // $dateAndTime->setTimezone('Asia/Kolkata'); // Change 'Asia/Kolkata' to the desired timezone
                // Separate the date and time components for current date and time
                $date = $dateAndTime->format('d/m/Y'); // Format: DD-MM-YYYY
                $time = $dateAndTime->format('H:i:s'); // Format: HH:MM:SS (24-hour format)


                // Assuming $lastCustomerDetail->check_in is a string in 'Y-m-d H:i:s' format
                $dateAndTime_check_out = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $customer->checkOut->created_at);
                // dd($dateAndTime_check_out);
                // Separate the date and time components
                $date_check_out = $dateAndTime_check_out->format('d/m/Y'); // Format: DD-MM-YYYY
                $time_check_out = $dateAndTime_check_out->format('H:i:s'); // Format: HH:MM:SS
                $roomNames = $customer->select_rooms->pluck('name')->map(function ($name) {
                return rtrim($name, ', ');
                });

                $pax = 0;
                if($customer->total_adult >= ($customer->room_type->max_person *$customer->no_fo_room) ){
                $pax = $customer->room_type->max_person + $extra_count1;
                }
                else{
                $pax = $customer->total_adult;
                }


                @endphp
                <div>
                    <span class="inline">Chk.In.Date&nbsp; &nbsp;:</span>
                    <span class="inline">{{ $date_check_in ?? ''}}</span>
                </div>

                <div>
                    <span class="inline">Chk.In.Time :</span>
                    <span class="inline">{{ $time_check_in ?? '' }}</span>


                </div>
            </div>


            <div class="widget widget-5">
                <p style="color:transparent">GB</p>
            </div>

            <div class="widget widget-6" style="line-height: 25px; ">

                <div>
                    <span class="inline">Room No&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;:</span>
                    <span class="inline">{{ implode(', ', $roomNames->toArray()) }}</span>
                </div>

                <div>
                    <span class="inline">Room Type &nbsp; &nbsp; &nbsp;:</span>
                    <span class="inline">{{ $customer->room_type->name }}</span>
                </div>

                <div>
                    <span class="inline"> No.Of. Pax &nbsp; &nbsp; &nbsp;:</span>
                    <span class="inline">{{ $pax }} + {{ $customer->total_child  }}</span>
                </div>

                <div>
                    <span class="inline">Mobile &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;:</span>
                    <span class="inline">{{$customer->country_code . '   ' . $customer->phone_number?? '' }}</span>
                </div>

                <div>
                    <span class="inline">Chk.Out.Date &nbsp;&nbsp; :</span>
                    <span class="inline">@if(isset($dateAndTime_check_out))
                        {{ $date_check_out }}
                        @else
                        {{ $date }}
                        @endif
                    </span>

                </div>

                <div>
                    <span class="inline">Chk.Out.Time :</span>
                    <span class="inline">
                        @if(isset($dateAndTime_check_out))
                        {{ $time_check_out }}
                        @else
                        {{ $time }}
                        @endif</span>
                </div>

            </div>
            <div class="clear"></div>
        </div>


        <style>
            table {
                border-collapse: collapse;
                width: 100%;
            }

            tr {
                border-top: 1px solid #000;
                border-bottom: 1px solid #000;
                border-left: none;
                border-right: none;
            }

            /* Apply dashed border to the first tr element */
            tr:first-child {
                border-style: dashed;
                border-left: none;
                border-right: none;
            }

            tr {
                border: none;
            }

            th,
            td {
                padding: 3px;
                text-align: left;
            }

            .trtd {
                padding-bottom: -5px;
            }

            .trgap {
                height: 15px;
            }
        </style>

        <br>

        <table style="margin-left:2%; width:94%; margin-left:4% text-align:center;">

            <tr>
                <th style="">S.No</th>
                <th>Room No</th>
                <th>PARTICULAR'S</th>
                <th>RATE</th>
                <th>DAYS</th>
                <th style="text-align:right; padding-right:5px;">AMOUNT</th>
            </tr>
            @php
            $extraPersons = 0;
            $extraPRC = 0;
            $extraCost = 0;
            $rent = $totalRent;

            @endphp

            @if($customer->total_adult > $customer->room_type->max_person)
            {{-- dd(); --}}
            @php
            // $extraPersons = $customer->room_type->max_person + $extra_count;
            $extraPersons = $customer->room_type->max_person + $extra_count1;
            $extraCost = $extraPersons * $customer->room_type->extra_price * $numDays;
            $rent = $customer->room_type->price * $numDays;//$totalRent - $extraCost + $discountAmount;
            $extraPRC = $customer->room_type->extra_price ;

            @endphp
            @endif
            @foreach($customer->select_rooms as $key => $select_room)
            <tr class="trtd">
                <td style="padding-left:5px;">{{ $key + 1 }}</td>
                <td>{{ $select_room->name }}</td>
                <td>Room Rent</td>
                <td>{{ number_format($customer->room_type->price, 2) }}</td>
                <td>{{ $numDays }}</td>
                <td style="text-align:right">{{ number_format($rent, 2) }}</td>
            </tr>
            @endforeach

            @if ($extra_count1 > 0)
            <tr class="trtd">
                <td></td>
                <td></td>
                <td>Extra Person</td>
                <td>{{ $extraPRC }}</td>
                <td></td>
                <td style="text-align:right; padding-right:5px;"> {{ number_format($totalExtraCost , 2)  }}</td>
            </tr>
            @endif



            @php
            $discountprice = $rent + $totalExtraCost; //$customer->room_type->price; Poobalan
            $discountPercentage = $customer->discount_ids->dicount ?? 0; // Assuming discount is nullable
            $discountAmount = ($discountprice * $discountPercentage) / 100;
            $discountprice = $discountAmount;
            @endphp
            @if ($discountprice>0)
            <tr class="trtd">
                <td></td>
                <td></td>
                <td>Discount</td>
                <td>{{ $discountPercentage }}%</td>
                <td></td>
                <td style="text-align:right; padding-right:5px;">{{ number_format($discountprice, 2) }}</td>
            </tr>
            @endif



            <tr class="trgap">
                <td> </td>
                <td> </td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>

            <tr class="trtd">
                <td> </td>
                <td> </td>
                <td>CGST</td>
                <td>{{ $gst ? ($gst->gst_percentage / 2) . '%' : '' }}</td>
                <td>-</td>
                <td style="text-align:right; padding-right:5px;">{{ $customer->checkOut ? number_format($customer->checkOut->cgst, 2) : '' }}</td>
            </tr>

            <tr class="trtd">
                <td> </td>
                <td> </td>
                <td>SGST</td>
                <td>{{ $gst ? ($gst->gst_percentage / 2) . '%' : '' }}</td>
                <td>-</td>
                <td style="text-align:right; padding-right:5px;">{{ $customer->checkOut ? number_format($customer->checkOut->sgst, 2) : '' }}</td>
            </tr>

        </table>
        <div class="widget widget-4">


            <table style="width:100%; margin-left: 5%;">
                <tr style="border: none;">
                    <th width="17%">Rec.No</th>
                    <th width="18%">Amount</th>
                    <th width="30%">Date</th>
                    <th width="30%">Payment</th>
                </tr>
                @if(isset($customer->advanceAmount))
                @foreach($customer->advanceAmount as $key => $advanceamount)
                @php
                $amountInWords = '';
                $payment_method = '';

                // Check if payment method is set
                if ($advanceamount->payment_method) {
                foreach (\App\Models\Customer::PAYMENT_METHOD_SELECT as $key => $label) {
                if ($key == $advanceamount->payment_method) {
                // Match found, you can perform further operations here
                $payment_method = $label;
                break; // Exit the loop once match is found
                }
                }
                }

                @endphp
                <tr>
                    <td>{{ sprintf("%03d", $advanceamount->id) }}</td>
                    <td>{{ $advanceamount->advance_amount }}</td>
                    <td>{{ \Carbon\Carbon::parse($advanceamount->created_at)->format('d-m-Y') }}</td>


                    <td>{{ $advanceamount->payment_method_name }}</t>
                </tr>



                @endforeach
                @endif
            </table>
            <div>

            </div>
        </div>


        <div class="widget widget-5">
            <!-- <p class="inline" style="color: transparent; padding-bottom: -10px ;">GB</p> -->
        </div>

        <div class="widget widget-6">
            <table width="100%" class="rnd-tab">
                <tr style="border: none;">
                    <!-- <td></td> -->
                    <td width="50%">Rnd off</td>
                    <td width="20%">:</td>
                    <td width="30%" style="text-align: right; border-bottom: 1px solid #000"> @if($customer->checkOut && number_format(fmod($customer->checkOut->total_amount, 1), 2) > 0)
                        {{ 1 - number_format(fmod($customer->checkOut->total_amount, 1), 2) }}
                        @else
                        0.00
                        @endif
                    </td>
                </tr>

                <tr style="border: none;">
                    <!-- <td></td> -->
                    <td width="50%">Gross Amount</td>
                    <td width="20%">:</td>
                    <td width="30%" style="text-align: right; border-bottom: 1px solid #000">{{ $customer->checkOut ? ceil($customer->checkOut->total_amount) : '' }}.00</td>
                </tr>

                <tr style="border: none;">
                    <!-- <td></td> -->
                    <td width="50%">Advance</td>
                    <td width="20%">:</td>
                    <td width="30%" style="text-align: right; border-bottom: 1px solid #000">{{ $customer->checkOut->advance_amount ?? ''}} </td>
                </tr>

                <tr style="border: none;">
                    <!-- <td></td> -->
                    <td width="50%">@if(round($customer->checkOut->balance_amount) > 0) Settlement
                        @else
                        Refund

                        @endif</td>
                    <td width="20%">:</td>
                    <td width="30%" style="text-align: right; border-bottom: 1px solid #000">{{ ceil($customer->checkOut->balance_amount) ?? ''}}.00</td>
                </tr>

            </table>


        </div>

        <div class="widget widget-4">
            <div style="line-height:25px;">
                @php
                $amountInWords = '';
                $payment_method = '';

                // Check if $customer->checkOut exists and is not null
                if ($customer->checkOut) {
                // Assuming $customer->checkOut->total_amount holds the numeric value you want to spell out
                $amount = round($customer->checkOut->balance_amount);

                // Create a new NumberFormatter instance to spell out the number in words
                $numberFormatter = new NumberFormatter('en', NumberFormatter::SPELLOUT);

                // Convert the number into words
                $amountInWords = ucwords($numberFormatter->format($amount));

                // Check if payment method is set
                if ($customer->checkOut->payment_method) {
                foreach (\App\Models\Customer::PAYMENT_METHOD_SELECT as $key => $label) {
                if ($key == $customer->checkOut->payment_method) {
                // Match found, you can perform further operations here
                $payment_method = $label;
                break; // Exit the loop once match is found
                }
                }
                }
                }
                @endphp


                <p><b>Amount in words:{{ $amountInWords }} </b></p>
                <p> Settlement Type: {{ $payment_method }}</p>
                @php
                $user = null;

                // Check if $customer->checkOut exists and is not null
                if ($customer->checkOut) {
                // Check if user_ids_id is set
                if ($customer->checkOut->user_ids_id) {
                // Assuming \App\Models\User::find($id) returns the user object corresponding to the user_ids_id
                $user = \App\Models\User::find($customer->checkOut->user_ids_id);
                }
                }
                @endphp


                <p> Checked in By : {{ $user->name ?? '' }}</p>
                <p> F.O.A Sign Checkout By : </p>
            </div>
        </div>
        <div class="widget widget-11">
            <p class="inline" style="color: transparent; padding-bottom: -10px ;">GB</p>
        </div>
        <div class="widget widget-12" style="text-align: right;">
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <p> Guest Signature</p>
        </div>

        <div class="widget widget-4">

        </div>
        <div class="widget widget-15" style="text-align: center;">
            <b> Thanks For staying with us</b><br>
            <b> * * * * * * * * * * * * * * * * * * * * * * * *</b>
        </div>
        <div class="widget widget-15" style="text-align: center;">

        </div>
        <div class="clear"></div>
        @if (Str::contains($currentDomain, 'gbresidency'))
        <div style="text-align:center">
            ஆன்மிகத்தாலும் ஆதிபராசக்தி இயக்கத்தாலும் தான் உலகில் நல்ல வழி ஏற்படும்.
        </div>

        <div style="text-align:center;" id="printButton">
            <button class="printButton" onclick="printPage()">Print</button>

        </div>

        <div>

            <script>
                function printPage() {
                    // Hide the print button before printing
                    document.getElementById('printButton').style.display = 'none';

                    // Trigger the print action
                    window.print();
                }

                // Listen for the afterprint event
                window.addEventListener('afterprint', function() {
                    // Show the print button after the print dialog is closed
                    document.getElementById('printButton').style.display = 'block';
                });
            </script>

</body>

</html>