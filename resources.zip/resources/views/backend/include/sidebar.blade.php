<div class="card">
    <ul class="list-group list-group-flush">
      <li class="list-group-item"><a href="{{route("backend.rooms.index")}}">Rooms</a></li>
      <li class="list-group-item"><a href="{{route("backend.floors.index")}}">Room Types</a></li>
      <li class="list-group-item"><a href="{{route("backend.edit_settlement.index")}}">Edit Settlement Payment</a></li>
      <li class="list-group-item"><a href="{{route("backend.users.index")}}">Users</a></li>

      @if(auth()->user() && auth()->user()->roles()->first()->id == 1)

        <li class="list-group-item"><a href="{{route("backend.edit_advance.index")}}">Edit Advance Payment</a></li>
        <li class="list-group-item"><a href="{{route("backend.monthly-guests.index")}}">Monthly Guests</a></li>
         
         <!-- New Admin-Only Financial Management Options -->
         @can('post_checkout_edit')
         <li class="list-group-item">
             <a href="{{route("backend.post-checkout-edit.index")}}">
                Post-Checkout Edit
             </a>
         </li>
         @endcan 
         @endif

    </ul>
 </div>