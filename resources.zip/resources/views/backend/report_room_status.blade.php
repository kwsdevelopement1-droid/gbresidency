@section('title', 'Room Status')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link href="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/css/tempusdominus-bootstrap-4.min.css"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css"
        integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('assets/intl-tel-input-18.2.1/build/css/intlTelInput.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
    <link href="https://cdn.datatables.net/2.0.5/css/dataTables.dataTables.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/3.0.2/css/buttons.dataTables.css" rel="stylesheet" />
    <style>
        .printButton {
            cursor: pointer;
            background: #bc1b1b;
            color: #fff;
            width: 100px;
            border: none;
            border-radius: 2px;
            height: 28px;
            font-size: 20px;
        }

        .iti {
            width: 100%;
        }

        .hide {
            display: none;
        }

        .default-form .selectize-control {
            position: relative;
            width: 250px;
            border-radius: 4px 4px 0px 0px;
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 16px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
        }

        .default-form .selectize-input {
            height: 58px;
        }

        .green-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #009834;
        }

        .color-rooms h3 {
            color: #000;
            font-family: Montserrat;
            font-size: 19px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            white-space: nowrap;
            position: relative;
            left: 39px;
        }

        .color-rooms h4 {
            color: #FFF;
            font-family: Montserrat;
            font-size: 30px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            text-align: center;
            position: relative;
            bottom: 3px;
        }


        .colors {
            max-width: 25%;
        }

        .orange-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FF823C;
        }

        .yellow-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FBB836;
        }

        .blue-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #0C89D0;
        }

        .black-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #000;
        }

        .default-form .input-group-text {

            height: 56px;
        }

        .default-form .fa.fa-calendar {
            font-size: 29px;
        }

        .default-form #no_of_room {
            width: 250px;
            height: 60px;
        }

        .default-form .selectize-input>* {
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 17.039px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
            text-transform: uppercase;
            margin: 12px;
        }

        #bill_no {
            width: 250px !important;
            height: 60px !important;
        }

        .default-form .btn-search {
            border-radius: 4.26px;
            background: #8DD3BB;
            border: none;
            width: 55px;
            height: 55px;
            margin-left: 15px;
        }

        .check-in-form-title {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 33.072px;
            font-style: normal;
            font-weight: 700;
            line-height: 150%;
            /* 49.608px */
        }

        .check_in .form-control {
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;

        }

        .check_in label {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 500;
            line-height: 40px;
        }

        .check_in .selectize-control.single .selectize-input {
            border-color: #b8b8b8;
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;
        }

        .active-btn {
            color: #000;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            border-radius: 15px;
            border: 5px solid #009834;
            background: none;
        }

        .btn-save {
            border-radius: 10px;
            background: #8DD3BB;
            width: 672.804px;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            padding: 23.869px 0px 24.213px 0px;
            border: none;
        }

        table {
            width: 100%;
        }

        tr {
            height: 42px;
            border-radius: 21.116px;
            background: #FFF;
            box-shadow: 0px 2.815px 26.747px 0px rgba(141, 211, 187, 0.33);
        }

        th,
        tr {
            color: #000;
            leading-trim: both;
            text-edge: cap;
            font-family: Raleway;
            font-size: 20px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
            letter-spacing: 0.3px;
        }



        .btn-checkout {
            border-radius: 10px;
            background: #901111;
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-cancel {
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            border: 5px solid #8DD3BB;
            color: #8DD3BB;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-extend {
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            background: #8DD3BB;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }



        .active-btn {
            color: #000 !important;
            font-family: Montserrat !important;
            font-size: 20px !important;
            font-style: normal !important;
            font-weight: 700 !important;
            line-height: normal !important;
            border-radius: 15px !important;
            border: 5px solid #009834 !important;
            background: none !important;
        }

        .black {
            border-radius: 15px;
            background: #000;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .single-color {

            border-radius: 15px;
            background: #FF823C;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .multiple-color {

            border-radius: 15px;
            background: #FBB836;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .recently-vacate-color {

            border-radius: 15px;
            background: #0C89D0;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }


        .main-color {

            border-radius: 15px;
            background: #009834;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .input-group-text {
            height: 64px;
        }

        .fa.fa-calendar {
            font-size: 30px;
        }

        #datatable-Customer_wrapper {
            margin-top: 26px;
        }

        .search {
            padding: 8px 11px 0 0;
        }

        .numericCol {
            text-align: right;
        }

        table.dataTable tfoot th {
            text-align: right;
        }

        table {
            table-layout: fixed;
        }

        td {
            overflow: hidden;
            text-overflow: ellipsis;
        }

        th {
            font-size: 14px;
            font-weight: bold;
        }

        td {
            overflow: hidden;
            text-overflow: ellipsis;
            font-size: 12px;
        }
    </style>
@endsection
@section('title_nav')
    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Room Status Report </h2>
    </div>
@endsection


<div class="container mt-4">

    <div class="row">

        <form class="default-form d-flex justify-content-between mt-4" id="form1" method="POST">
            @csrf



        </form>

    </div>
    @php
        $currentDomain = request()->getHost();
        $from_date = \Carbon\Carbon::now()->format('d-m-Y');
    @endphp
    <div class="row">
        @if ($floors)
            @if (count($floors) == 0)

                <span>No Room Records Found</span>
            @else
                {{-- <span> {{ json_encode($report[0]) }}</span> --}}
                {{-- <div class="row">
                    <button id="print_me">Print</button>
                </div> --}}
                <div align="center"> Om Sakthi</div>
                <div align="center"><b>
                        {{ Str::contains($currentDomain, 'gbresidency') ? 'GB Residency' : 'ADHIPARASAKTHI Lodging' }}</b>
                </div>
                <div align="center"> Melmaruvathur</div>
                <div align="center">Room Status Report </div>
                <div class="row dt-container datatable-Customer_wrapper">

                    <table
                        class="table tablesort tablesearch-table  table-bordered table-striped table-hover display  dataTabledatatable-Customer "
                        id="datatable-Customer">
                        <thead>





                            <tr>

                                <th data-tablesort-type="int" width="5%">
                                    S.NO
                                </th>
                                <th data-tablesort-type="string">
                                    Type
                                </th>

                                <th data-tablesort-type="int">
                                    OCCUPIED
                                </th>

                                <th data-tablesort-type="int">
                                    VACANT
                                </th>

                                <th data-tablesort-type="int">
                                    BLOCK
                                </th>
                                <th data-tablesort-type="int">
                                    VACANT DIRTY
                                </th>
                                <th data-tablesort-type="int">
                                    TOTAL
                                </th>
                                <th data-tablesort-type="int">
                                    HOUSE GUEST
                                </th>
                                <th data-tablesort-type="int">
                                    F.COUNT
                                </th>
                                <th data-tablesort-type="int">
                                    F.PAX
                                </th>
                            </tr>
                        </thead>

                        <tbody>
                            @php
                                $totalVal = 0.0;
                                $occupiedTotal = 0.0;
                                $vacantTotal = 0.0;
                                $blockTotal = 0.0;
                                $dirtyTotal = 0.0;
                                $houseGuestTotal = 0.0;
                                $fGuestTotal = 0.0;
                                $fPaxTotal = 0.0;
                            @endphp
                            @foreach ($floors as $key => $floor)
                                <tr data-entry-id="{{ $floor->id }}">
                                    {{-- <td>{{ $key + 1 }}</td> --}}
                                    <td>

                                        {{ $floor->id }}

                                    </td>
                                    <td>
                                        {{ $floor->name }}
                                    </td>
                                    <td>
                                        {{ $roomTypeIdCounts[$floor->id] ?? 0 }}

                                    </td>
                                    <td>

                                        {{ (int) $floor->available_rooms - ($roomTypeIdCounts[$floor->id] ?? 0) }}

                                    </td>
                                    <td>
                                        {{ $floor->blocked_rooms }}
                                    </td>

                                    <td>
                                        {{ $floor->dirty_rooms }}
                                    </td>
                                    <td>
                                        {{ $floor->total }}
                                    </td>
                                    <td>
                                        {{ $houseGuestCounts[$floor->id] ?? 0 }}
                                    </td>
                                    <td>
                                        {{ $forignGuestCounts[$floor->id] ?? 0 }}
                                    </td>
                                    <td>
                                        {{ $forignGuestPax[$floor->id] ?? 0 }}
                                    </td>


                                </tr>
                            @endforeach

                        </tbody>
                        <tfoot>
                            <tr>
                                <th></th>
                                <th>Total</th>

                                <th align="center">
                                    {{ $occupiedTotal }}
                                </th>
                                <th>
                                    {{ $vacantTotal }}
                                </th>
                                <th>
                                    {{ $blockTotal }}
                                </th>
                                <th>
                                    {{ $dirtyTotal }}
                                </th>
                                <th>
                                    {{ $totalVal }}
                                </th>
                                <th>
                                    {{ $houseGuestTotal }}
                                </th>
                                <th>
                                    {{ $fGuestTotal }}
                                </th>
                                <th>
                                    {{ $fPaxTotal }}
                                </th>


                            </tr>


                        </tfoot>

                    </table>

                </div>
            @endif



        @endif

    </div>
</div>

@endsection
@section('scripts')
@parent
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/2.0.5/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/dataTables.buttons.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.dataTables.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.print.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/js/tempusdominus-bootstrap-4.min.js">
    < script script src = "https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
    integrity = "sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
    crossorigin = "anonymous"
    referrerpolicy = "no-referrer" >
</script>
<script src="{{ asset('assets/intl-tel-input-18.2.1/build/js/intlTelInput.min.js') }}"></script>
<script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>



<script>
    $(document).ready(function() {


        var table = new DataTable('#datatable-Customer', {
            paging: false,
            pageLength: 20,
            searching: false,
            lengthMenu: [
                [10, 20, 50, -1],
                [10, 20, 50, "All"]
            ],
            // fixedHeader: true,
            bInfo: true,
            autoWidth: true, // Disable the auto width calculation
            footerCallback: function (row, data, start, end, display) {
        let api = this.api();

        // Remove the formatting to get integer data for summation
        let intVal = function (i) {
            return typeof i === 'string'
                ? i.replace(/[\$,]/g, '') * 1
                : typeof i === 'number'
                ? i
                : 0;
        };

        // Total over all pages
        for( i = 2; i < 11; i++){
        total = api
            .column(i)
            .data()
            .reduce((a, b) => intVal(a) + intVal(b), 0);


        api.column(i).footer().innerHTML =
              total ;
        }
    },



    layout: {

            topStart: {
                buttons: [{
                        extend: 'pdfHtml5',
                        title: 'Ap Lodging',
                        filename: 'room_status_report{{ \Carbon\Carbon::now()->format('d-m-Y') }}',
                        orientation: 'landscape',
                        pageSize: 'A4',
                        customize: function(doc) {
                            doc.content.splice(0, 1, {
                                text: [{
                                        text: ' Om Sakthi \n',
                                        bold: true,
                                        fontSize: 11
                                    }, {
                                        text: "{{ Str::contains($currentDomain, 'gbresidency') ? 'GB Residency' : 'ADHIPARASAKTHI Lodging' }}\n",
                                        bold: true,
                                        fontSize: 16
                                    }, {
                                        text: 'Room Status Report - {{ \Carbon\Carbon::now()->format('d-m-Y') }} \n ',
                                        bold: true,
                                        fontSize: 12
                                    },
                                    {
                                        text: 'Report Time {{ \Carbon\Carbon::now()->format('d-m-Y H:i:s') }}',
                                        bold: false,
                                        fontSize: 12
                                    }
                                ],
                                margin: [0, 0, 0, 12],
                                alignment: 'center'
                            });

                            doc.content[1].table.widths = ['9%', '20%', '9%', '9%', '9%',
                                '9%', '9%', '9%', '9%', '9%',
                            ];

                            var rowCount = doc.content[1].table.body.length;
                            for (i = 1; i < rowCount - 1; i++) {
                                doc.content[1].table.body[i][2].alignment = 'center';
                                doc.content[1].table.body[i][3].alignment = 'center';
                                doc.content[1].table.body[i][4].alignment = 'center';
                                doc.content[1].table.body[i][5].alignment = 'center';
                                doc.content[1].table.body[i][6].alignment = 'center';
                                doc.content[1].table.body[i][7].alignment = 'center';
                                doc.content[1].table.body[i][8].alignment = 'center';
                                doc.content[1].table.body[i][9].alignment = 'center';

                            };
                        }
                    }, {
                        extend: 'excel',
                        title: 'Room Status Report -{{ $from_date }}',
                        filename: 'room_status_report{{ $from_date }}'
                    }, {
                        extend: 'csv',
                        filename: 'room_status_report{{ $from_date }}'
                    },
                    {
                        extend: 'print',
                        footer: true,
                        header: true,
                        title: '',
                        orientation: 'portrait',
                        pageSize: 'A4',


                        customize: function(win) {

                            $(win.document.body)
                                .css('font-size', '14pt')
                                .prepend(
                                    '<div align="center"> Om Sakthi</div><div  align="center"><b> {{ Str::contains($currentDomain, 'gbresidency') ? 'GB Residency' : 'ADHIPARASAKTHI Lodging' }}</b></div><div align="center"> Melmaruvathur</div><div  align="center">Room Status Report For {{ \Carbon\Carbon::parse($from_date)->format('d-m-Y') }} </div><div  align="right"> {{ \Carbon\Carbon::now()->format('d-m-Y H:i:s') }}</div>'
                                );

                            $(win.document.body)
                                .find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');



                            $(win.document.body).find('table tbody td:nth-child(1)').css(
                                'text-align', 'center');

                            // $(win.document.body).find('table tbody td:nth-child(1)').css('width', '5%');
                            $(win.document.body).find('table tbody td:nth-child(3)').css(
                                'text-align', 'right');
                            $(win.document.body).find('table tbody td:nth-child(4)').css(
                                'text-align', 'right');
                            $(win.document.body).find('table tbody td:nth-child(5)').css(
                                'text-align', 'right');
                            $(win.document.body).find('table tbody td:nth-child(6)').css(
                                'text-align', 'right');
                            $(win.document.body).find('table tbody td:nth-child(7)').css(
                                'text-align', 'right');
                            $(win.document.body).find('table tbody td:nth-child(8)').css(
                                'text-align', 'right');
                            $(win.document.body).find('table tbody td:nth-child(9)').css(
                                'text-align', 'right');
                            $(win.document.body).find('table tbody td:nth-child(10)').css(
                                'text-align', 'right');
                            $(win.document.body).find('table tbody th').css(
                                'text-align', 'right');

                        }
                    }
                ],
            }
        },
        columnDefs: [{
                'align': 'center',
                "aTargets": [0, 2, 3, 4, 5, 6, 7, 8, 9],
            },
            {
                "width": "8%",
                "aTargets": [0, 2, 3, 5, 6],

            },
            {
                "width": "20%",
                "aTargets": [1]
            },



        ],
    });
    // var table = $('#datatable-Customer').DataTable({
    //     "pageLength": 20, // Number of records per page
    //     "lengthMenu": [
    //         [10, 20, 50, -1],
    //         [10, 20, 50, "All"]
    //     ], // Customize the length menu
    //     "searching": false, // Disable default search feature
    //     "ordering": true, // Disable sorting
    //     "autoWidth": false,
    //     "fixedColumns": true,
    //     "columns": [{
    //             width: '5%'
    //         }, {
    //             width: '8%'
    //         }, {
    //             width: '15%'
    //         }, {
    //             width: '5%'
    //         }, {
    //             width: '25%'
    //         },
    //         {
    //             width: '5%'
    //         },
    //         {
    //             width: '15%'
    //         }
    //     ],

    //     "aoColumnDefs": [

    //         {
    //             "sClass": "numericCol",
    //             "aTargets": [0, 2, 6]
    //         }
    //     ],
    //     dom: 'Bfrtip',
    //     buttons: [{
    //             extend: 'pdf',
    //             title: 'Advance Report',
    //             filename: 'advance_report',
    //             orientation: 'landscape',
    //             pageSize: 'A4',
    //         }, {
    //             extend: 'excel',
    //             title: 'Advance Report',
    //             filename: 'advance_report'
    //         }, {
    //             extend: 'csv',
    //             filename: 'advance_report'
    //         },
    //         {
    //             extend: 'print',
    //             footer: true,
    //             header: true,

    //             exportOptions: {
    //                 orientation: 'landscape'
    //             },
    //             customize: function(win) {
    //                 // $(win.document.body).prepend('<div>Additional Header Content Here</div>');
    //                 $(win.document.body).find('table').widths = ['2%', '14%', '14%', '14%',
    //                     '14%', '14%', '14%', '14%'
    //                 ];


    //             }




    //         }
    //     ]
    // });
    });
</script>

@endsection
