@extends('layouts.backend')
@section('content')
<div class="row">
    <div class="col-md-3">
        @include('backend.include.sidebar')
    </div>
    <div class="col-md-9">
<div class="card">
    {{-- <div class="card-header">
        {{ trans('global.edit') }} {{ trans('cruds.roomtype.title_singular') }}
    </div> --}}

    <div class="card-body">
        <form method="POST" action="{{ route("backend.roomtypes.update", [$roomtype->id]) }}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="form-group">
                <label class="required" for="name">Name</label>
                <input class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" type="text" name="name" id="name" value="{{ old('name', $roomtype->name) }}" required>
                @if($errors->has('name'))
                    <div class="invalid-feedback">
                        {{ $errors->first('name') }}
                    </div>
                @endif
            </div>
            <div class="form-group mt-4">
                <button class="btn btn-danger" type="submit">
                   Submit
                </button>
            </div>
        </form>
    </div>
</div>

</div></div>

@endsection