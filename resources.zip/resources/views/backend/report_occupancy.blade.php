@section('title', 'Occupancy Report {{ $from_date }}')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link href="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/css/tempusdominus-bootstrap-4.min.css"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css"
        integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('assets/intl-tel-input-18.2.1/build/css/intlTelInput.css') }}" />
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
    <link href="https://cdn.datatables.net/2.0.5/css/dataTables.dataTables.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/3.0.2/css/buttons.dataTables.css" rel="stylesheet" />
    <style type="text/css" media="print">
        @page {
            size: auto;
            /* auto is the initial value */
            margin: 0;
            /* this affects the margin in the printer settings */
        }
    </style>
    <style>
        .printButton {
            cursor: pointer;
            background: #bc1b1b;
            color: #fff;
            width: 100px;
            border: none;
            border-radius: 2px;
            height: 28px;
            font-size: 20px;
        }

        .iti {
            width: 100%;
        }

        .hide {
            display: none;
        }

        .default-form .selectize-control {
            position: relative;
            width: 250px;
            border-radius: 4px 4px 0px 0px;
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 16px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
        }

        .default-form .selectize-input {
            height: 58px;
        }

        .green-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #009834;
        }

        .color-rooms h3 {
            color: #000;
            font-family: Montserrat;
            font-size: 19px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            white-space: nowrap;
            position: relative;
            left: 39px;
        }

        .color-rooms h4 {
            color: #FFF;
            font-family: Montserrat;
            font-size: 30px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            text-align: center;
            position: relative;
            bottom: 3px;
        }


        .colors {
            max-width: 25%;
        }

        .orange-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FF823C;
        }

        .yellow-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FBB836;
        }

        .blue-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #0C89D0;
        }

        .black-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #000;
        }

        .default-form .input-group-text {

            height: 56px;
        }

        .default-form .fa.fa-calendar {
            font-size: 29px;
        }

        .default-form #no_of_room {
            width: 250px;
            height: 60px;
        }

        .default-form .selectize-input>* {
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 17.039px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
            text-transform: uppercase;
            margin: 12px;
        }

        #bill_no {
            width: 250px !important;
            height: 60px !important;
        }

        .default-form .btn-search {
            border-radius: 4.26px;
            background: #8DD3BB;
            border: none;
            width: 55px;
            height: 55px;
            margin-left: 15px;
        }

        .check-in-form-title {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 33.072px;
            font-style: normal;
            font-weight: 700;
            line-height: 150%;
            /* 49.608px */
        }

        .collection_date .form-control {
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;

        }

        .collection_date label {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 500;
            line-height: 40px;
        }

        .collection_date .selectize-control.single .selectize-input {
            border-color: #b8b8b8;
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;
        }

        .active-btn {
            color: #000;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            border-radius: 15px;
            border: 5px solid #009834;
            background: none;
        }

        .btn-save {
            border-radius: 10px;
            background: #8DD3BB;
            width: 672.804px;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            padding: 23.869px 0px 24.213px 0px;
            border: none;
        }

        table {
            width: 100%;
        }

        tr {
            height: 42px;
            border-radius: 21.116px;
            background: #FFF;
            box-shadow: 0px 2.815px 26.747px 0px rgba(141, 211, 187, 0.33);
        }


        tr {
            color: #000;
            leading-trim: both;
            text-edge: cap;
            font-family: Raleway;
            font-size: 20px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
            letter-spacing: 0.3px;
        }



        .btn-checkout {
            border-radius: 10px;
            background: #901111;
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-cancel {
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            border: 5px solid #8DD3BB;
            color: #8DD3BB;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-extend {
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            background: #8DD3BB;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }



        .active-btn {
            color: #000 !important;
            font-family: Montserrat !important;
            font-size: 20px !important;
            font-style: normal !important;
            font-weight: 700 !important;
            line-height: normal !important;
            border-radius: 15px !important;
            border: 5px solid #009834 !important;
            background: none !important;
        }

        .black {
            border-radius: 15px;
            background: #000;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .single-color {

            border-radius: 15px;
            background: #FF823C;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .multiple-color {

            border-radius: 15px;
            background: #FBB836;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .recently-vacate-color {

            border-radius: 15px;
            background: #0C89D0;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }


        .main-color {

            border-radius: 15px;
            background: #009834;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .input-group-text {
            height: 64px;
        }

        .fa.fa-calendar {
            font-size: 30px;
        }

        #datatable-Customer_wrapper {
            margin-top: 6px;
        }

        .search {
            padding: 8px 11px 0 0;
        }

        .numericCol {
            text-align: right;
        }

        .bigCol {
            text-align: left;
            width: 100px;
        }

        table.dataTable tfoot th {
            text-align: right;

        }

        table {
            table-layout: fixed;
        }

        th {
            font-size: 14px;
            font-weight: bold;

        }


        td {
            overflow: hidden;
            text-overflow: ellipsis;
            font-size: 12px;
        }
    </style>
@endsection
@section('title_nav')
    <div class="row title-card">

        <h4 class="d-flex align-items-center justify-content-center">Occupancy Report
            {{ date('d-m-Y', strtotime($from_date)) }} To {{ date('d-m-Y', strtotime($to_date)) }}</h4>
    </div>
@endsection


<div class="container mt-1">

    <div class="row">

        <form class="default-form d-flex justify-content-between mt-4" id="form1" method="POST">
            @csrf

            <div class="form-row">
                <div class="form-group col-md-12">
                    <span class="has-float-label">
                        <div class="input-group date" id="datetimepickerfromdate" data-target-input="nearest">
                            <input type="text" name="from_date" class="form-control datetimepicker-input"
                                data-target="#datetimepickerfromdate" />
                            <div class="input-group-append" data-target="#datetimepickerfromdate"
                                data-toggle="datetimepicker">
                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                            </div>
                        </div>
                        <label for="check_in">From Date</label>
                    </span>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-12">
                    <span class="has-float-label">
                        <div class="input-group date" id="datetimepickertodate" data-target-input="nearest">
                            <input type="text" name="to_date" class="form-control datetimepicker-input"
                                data-target="#datetimepickertodate" />
                            <div class="input-group-append" data-target="#datetimepickertodate"
                                data-toggle="datetimepicker">
                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                            </div>
                        </div>
                        <label for="check_out">To Date</label>
                    </span>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-12">
                    <span class="has-float-label">
                        <input id="collection_button" type="button" value=" Go  " width="50px" class="submit" />
                </div>

            </div>

        </form>

    </div>
    <div class="row">
        @if ($customers)
            @if (count($customers) == 0)

                <span>No Occupancy Records Found</span>
            @else
                {{-- <span> {{ json_encode($report[0]) }}</span> --}}
                {{-- <div class="row">
                    <button id="print_me">Print</button>
                </div> --}}
                <div class="row dt-container datatable-Customer_wrapper">
                    {{-- <div>{{ $customers[1] }}</div> --}}
                    <table
                        class="table tablesort tablesearch-table  table-bordered table-striped table-hover display  dataTabledatatable-Customer "
                        id="datatable-Customer">
                        <thead>
                            <tr>
                                <th data-tablesort-type="int">
                                    SI #
                                </th>

                                <th data-tablesort-type="int">
                                    Room NO
                                </th>
                                <th>
                                    Check In
                                </th>
                                <th data-tablesort-type="int">
                                    Check Out
                                </th>
                                <th data-tablesort-type="string">
                                    Guest Name
                                </th>
                                <th data-tablesort-type="number">
                                    Phone
                                </th>
                                <th data-tablesort-type="string" >
                                    Address
                                </th>
                                <th data-tablesort-type="int">
                                    Country
                                </th>
                                <th data-tablesort-type="int">
                                    Nationality
                                </th>
                                <th data-tablesort-type="int">
                                    Passport exp
                                </th>
                                <th data-tablesort-type="int" align="right">
                                    Visa Exp
                                </th>


                                <th>
                                    Type
                                </th>


                                <th data-tablesort-type="int">
                                    Days
                                </th>
                                <th data-tablesort-type="int">
                                    PAX
                                </th>





                            </tr>
                        </thead>

                        <tbody>
                            @php
                                $totalVal = 0.0;
                                 $siNo = 1;
                            @endphp
                            @foreach ($customers as $key => $customer)
                                @foreach ($customer->select_rooms as $keyroom => $item)
                                    <tr data-entry-id="{{ $customer->id }}">
                                        <td>{{ $siNo++ }}</td>
                                        <td>

                                            {{ $item->name }}

                                        </td>
                                        <td>
                                            {{ $customer->customerDetail->last() ? \Carbon\Carbon::parse($customer->customerDetail->last()->check_in)->format('d/m/Y H.i') : '' }}
                                        </td>
                                        <td align="right">
                                            @if ($customer->status == 2)
                                                {{ $customer->checkOut ? \Carbon\Carbon::parse($customer->checkout->created_at)->format('d/m/Y H.i') : '' }}
                                            @endif
                                        </td>
                                        <td>
                                            {{ $customer->guest_name ?? '' }}
                                        </td>
                                        <td width="10%">
                                            +{{ $customer->country_code ?? '' }} {{ $customer->phone_number ?? '' }}
                                        </td>

                                        {{-- <td>
                                {{ $customer->customerDetail->last() ? \Carbon\Carbon::parse($customer->customerDetail->last()->check_out)->format('d/m/Y (h.iA)') : '' }}
                            </td> --}}



                                        @php
                                            $checkInTime = \Carbon\Carbon::parse(
                                                $customer->customerDetail->last()->check_in,
                                            );

                                            if ($customer->status == 2) {
                                                //$hoursPastCheckIn =
                                                $hoursPastCheckIn = $customer->checkout?
                                                    \Carbon\Carbon::parse(
                                                        $customer->checkout->created_at,
                                                    )->diffInHours($checkInTime) - 1:\Carbon\Carbon::parse(
                                                        $customer->checkoutOld->created_at,
                                                    )->diffInHours($checkInTime) - 1;
                                                    //\Carbon\Carbon::parse($customer->checkout->created_at)->diffInHours(
                                                      //  $checkInTime,
                                                    //) - 1;
                                                $roomPrice =
                                                    $customer->rate_code == 1 ? $customer->room_type->price : 0;
                                                if ($hoursPastCheckIn < 25) {
                                                    $numDays = 1;
                                                } else {
                                                    $numDays = ceil($hoursPastCheckIn / 24);
                                                }
                                            } else {
                                                $numDays = '';
                                            }

                                            $tempCost = 0.0;

                                            $pax = $customer->total_adult;

                                            // foreach ($customer->extraBedsData as $extraBed) {
                                            //     if ($extraBed->checkin_status == 0) {
                                            //         // console.log(JSON.stringify(element));
                                            //         $pax += 1;
                                            //         $hoursPastCheckIn =
                                            //             Carbon\Carbon::now()->diffInHours($extraBed->checkin_date) - 1;
                                            //         if ($hoursPastCheckIn < 25) {
                                            //             $extraDays = 1;
                                            //         } else {
                                            //             $extraDays = ceil($hoursPastCheckIn / 24);
                                            //         }
                                            //         $extraCost = $extraDays * $extraBed->price;
                                            //         $tempCost += $extraCost;
                                            //     } else {
                                            //         $tempCost += $extraBed->totalcost;
                                            //     }
                                            // }
                                            // $extraBedCost = $tempCost;
                                            // $tempTotal = $roomRent + $extraBedCost;
                                            // $discount = $customer->discount_ids_id == null ? 0.0 : $tempTotal * 0.3;
                                            // $tempTotal -= $discount;

                                            // $gst = $tempTotal * 0.12;
                                            // if ($keyroom == 0) {
                                            //     $advanceAmt = $customer->advanceAmount->sum('advance_amount');
                                            // } else {
                                            //     $advanceAmt = 0.00;
                                            // }
                                            // $balance = $tempTotal + $gst - $advanceAmt;
                                            // $totalVal += $balance;

                                        @endphp
                                        <td >{{ $customer->address }},{{ $customer->pincode }}</td>
                                        <td align="right">{{ $customer->country->name }}</td>
                                        <td align="right">{{ $customer->nationality->name }}</td>
                                        <td align="right">

                                            {{ $customer->pr_exp_date ?? '' }}
                                        </td>


                                        <td align="right">
                                            {{ $customer->visa_exp_date ?? '' }}
                                        </td>
                                        <td>
                                            @if ($customer->rate_code == 2)
                                                <span class="house_guest">{{ $customer->room_type->name }}</span>
                                            @elseif ($customer->discount_ids_id != null)
                                                <span class="disc_guest">{{ $customer->room_type->name }}</span>
                                            @elseif (count($customer->select_rooms) > 1)
                                                <span class="group">{{ $customer->room_type->name }}</span>
                                            @else
                                                <span class="single">{{ $customer->room_type->name }}</span>
                                            @endif

                                        </td>
                                        <td align="center">{{ $numDays }}</td>
                                        <td align="center">{{ $pax }}</td>



                                    </tr>
                                @endforeach
                            @endforeach

                        </tbody>
                        {{-- <tfoot>
                <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>

                    <th>Total</th>
                    <th class="numericCol" align="right"> {{ number_format((float) $totalVal, 2, '.', '') }}</th>
                    <th></th>

                </tr>
            </tfoot> --}}

                    </table>

                </div>
            @endif



        @endif

    </div>
</div>
@php
    $currentDomain = request()->getHost();
@endphp
@endsection
@section('scripts')
@parent
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/2.0.5/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/dataTables.buttons.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.dataTables.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.2/js/buttons.print.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/datatables-buttons-excel-styles@1.2.0/js/buttons.html5.styles.min.js">
    </script>
    <script
        src="https://cdn.jsdelivr.net/npm/datatables-buttons-excel-styles@1.2.0/js/buttons.html5.styles.templates.min.js">
    </script>

<script src="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/js/tempusdominus-bootstrap-4.min.js">
    < script src = "https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
    integrity = "sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
    crossorigin = "anonymous"
    referrerpolicy = "no-referrer" >
</script>
<script src="{{ asset('assets/intl-tel-input-18.2.1/build/js/intlTelInput.min.js') }}"></script>
<script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>



<script>
    $(document).ready(function() {

        $('#collection_button').on('click', function(e) {
            var selectedUserId = $(this).val(); // Get the selected value from the select element

            // e.preventDefault();
            if (selectedUserId !== '') {
                var _token = $('meta[name="csrf-token"]').attr('content');

                var formData1 = new FormData($('#form1')[0]); // Get data from Form 1

                $('#form1').submit();


            }
        });


        $('#datetimepickerfromdate').datetimepicker({
            useCurrent: false,
            defaultDate: moment(),

            showTodayButton: true,
            showClear: true,
            toolbarPlacement: 'bottom',
            sideBySide: true,
            format: 'DD-MM-YYYY', // Set your desired format here
            icons: {
                time: "fa fa-clock",
                date: "fa fa-calendar",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down",
                previous: "fa fa-chevron-left",
                next: "fa fa-chevron-right",
                today: "fa fa-clock",
                clear: "fa fa-trash-alt",
                close: "fa fa-times"
            },

        });


        $('#datetimepickertodate').datetimepicker({
            useCurrent: false,
            defaultDate: moment(),

            showTodayButton: true,
            showClear: true,
            toolbarPlacement: 'bottom',
            sideBySide: true,
            format: 'DD-MM-YYYY', // Set your desired format here
            icons: {
                time: "fa fa-clock",
                date: "fa fa-calendar",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down",
                previous: "fa fa-chevron-left",
                next: "fa fa-chevron-right",
                today: "fa fa-clock",
                clear: "fa fa-trash-alt",
                close: "fa fa-times"
            },

        });

        new DataTable('#datatable-Customer', {
            paging: false,
            layout: {
                topStart: {
                    buttons: [{
                            extend: 'pdf',
                            title: 'Occupancy Report',
                            filename: 'occupancy_report',
                            orientation: 'landscape',
                            pageSize: 'A4',
                             customize: function(doc) {
                                    doc.content.splice(0, 1, {
                                        text: [{
                                                text: ' Om Sakthi \n',
                                                bold: true,
                                                fontSize: 11
                                            }, {
                                                text: "{{ Str::contains($currentDomain, 'gbresidency') ? 'GB Residency' : 'ADHIPARASAKTHI Lodging' }}\n",
                                                bold: true,
                                                fontSize: 16
                                            }, {
                                                text: 'Excel Collection Report - {{ \Carbon\Carbon::parse($from_date)->format('d-m-Y') }}-{{ \Carbon\Carbon::parse($to_date)->format('d-m-Y') }} \n ',
                                                bold: true,
                                                fontSize: 12
                                            },
                                            {
                                                text: 'Report Time {{ $reportTime }}',
                                                bold: false,
                                                fontSize: 12
                                            }
                                        ],
                                        margin: [0, 0, 0, 12],
                                        alignment: 'center'
                                    });

                                    doc.content[1].table.widths = ['5%','5%', '8%', '8%', '12%', '8%',
                                        '20%', '5%', '5%', '5%', '5%', '5%', '5%','5%',
                                    ];

                                    doc.content[1].table.body.forEach(row => {
                                        row.forEach(cell => {


                                            if (cell != undefined && cell.style !=
                                                "tableHeader" && (!cell.colSpan ||
                                                    cell.colSpan === 1)) {

                                                const colIndex = row.indexOf(cell);



                                            } else {
                                                // console.log(cell);
                                            }
                                        });
                                    });


                                    var rowCount = doc.content[1].table.body.length;
                                    for (i = 1; i < rowCount - 5; i++) {
                                        doc.content[1].table.body[i][1].alignment = 'center';
                                        doc.content[1].table.body[i][4].alignment = 'left';
                                        doc.content[1].table.body[i][5].alignment = 'left';
                                        doc.content[1].table.body[i][6].alignment = 'left';
                                        doc.content[1].table.body[i][7].alignment = 'left';
                                        doc.content[1].table.body[i][8].alignment = 'left';
                                        doc.content[1].table.body[i][9].alignment = 'left';
                                        doc.content[1].table.body[i][11].alignment = 'left';

                                    };
                                }

                        }, {
                            extend: 'excel',
                            title: '',
                            filename: 'occupancy_report',
                            "excelStyles": [{
                                        "template": "blue_gray_medium"
                                    },
                                    {
                                        "cells": ['A1:L1','A2:L2','A3:L3'],
                                        "style": {
                                            "font": {
                                                "b": true
                                            },
                                            "alignment": {
                                                "horizontal": "center"
                                            }
                                        }
                                    },
                                    {
                                        "cells": ['A4:L4'],
                                        "style": {
                                            "font": {
                                                "b": true
                                            },
                                            "alignment": {
                                                "horizontal": "right"
                                            }
                                        }
                                    }
                                ],
                                "insertCells": [{
                                        "cells": [
                                            "A1"

                                        ],
                                        "content": "",
                                        "pushRow": true,

                                    },
                                    {
                                        'cells':["A1"],
                                        'content':" {{ $reportTime }}",
                                        'pushRow':true,

                                    },

                                    {
                                        "cells": [
                                            "A1"

                                        ],
                                        "content": "Occupancy Report For {{ \Carbon\Carbon::parse($from_date)->format('d-m-Y') }} To {{ \Carbon\Carbon::parse($to_date)->format('d-m-Y') }} ",
                                        "pushRow": true,

                                    },
                                    {
                                        "cells": [
                                            "A1"

                                        ],
                                        "content": "{{ Str::contains($currentDomain, 'gbresidency') ? 'GB Residency' : 'ADHIPARASAKTHI Lodging' }}",
                                        "pushRow": true
                                    },
                                    {
                                        "cells": "A1",
                                        "content": [
                                            "Om Sakthi"
                                        ],
                                        "pushRow": true
                                    },



                                ],
                                pageStyle: {
                                    sheetPr: {
                                        pageSetUpPr: {
                                            fitToPage: 1 // Fit the printing to the page
                                        }
                                    },
                                    printOptions: {
                                        horizontalCentered: true,
                                        verticalCentered: true,
                                    },
                                    pageSetup: {
                                        orientation: "landscape", // Orientation
                                        paperSize: "9", // Paper size (9 = A4)
                                        fitToWidth: "1", // Fit to page width
                                        fitToHeight: "0", // Fit to page height
                                    },
                                    pageMargins: {
                                        left: "0.2",
                                        right: "0.2",
                                        top: "0.4",
                                        bottom: "0.4",
                                        header: "0",
                                        footer: "0",
                                    },
                                    mergeCells: { // Merge Cells
                                        mergeCell: [
                                            'A1:N1',
                                            'A2:N2',
                                            'A3:N3',
                                            'A4:N4',

                                        ]
                                    },

                                }
                        }, {
                            extend: 'csv',
                            filename: 'occupancy_report'
                        },
                        {
                            extend: 'print',
                            footer: true,
                            header: true,
                            title: '',

                            orientation: 'landscape',
                            pageSize: 'A4',


                                customize: function(win) {

                                    $(win.document.body)
                                        .css('font-size', '14pt')
                                        .prepend(
                                            '<div align="center"> Om Sakthi</div><div  align="center"><b> {{ Str::contains($currentDomain, 'gbresidency') ? 'GB Residency' : 'ADHIPARASAKTHI Lodging' }}</b></div><div align="center"> Melmaruvathur</div><div  align="center">Occupancy Report For {{ \Carbon\Carbon::parse($from_date)->format('d-m-Y') }} To {{ \Carbon\Carbon::parse($to_date)->format('d-m-Y') }}</div><div  align="right"> {{ $reportTime }}</div>'
                                        );

                                    $(win.document.body)
                                        .find('table')
                                        .addClass('compact')
                                        .css('font-size', 'inherit');



                                    $(win.document.body).find('table tbody td:nth-child(1)').css(
                                        'text-align', 'center');
                                    // $(win.document.body).find('table tbody td:nth-child(1)').css('width', '5%');
                                    $(win.document.body).find('table tbody td:nth-child(3)').css(
                                        'text-align', 'left');
                                    $(win.document.body).find('table tbody td:nth-child(4)').css(
                                        'text-align', 'right');
                                    $(win.document.body).find('table tbody td:nth-child(6)').css(
                                        'text-align', 'left');
                                    $(win.document.body).find('table tbody td:nth-child(7)').css(
                                        'text-align', 'left');
                                    $(win.document.body).find('table tbody td:nth-child(8)').css(
                                        'text-align', 'left');
                                    $(win.document.body).find('table tbody td:nth-child(9)').css(
                                        'text-align', 'left');
                                    $(win.document.body).find('table tbody td:nth-child(10)').css(
                                        'text-align', 'right');
                                    $(win.document.body).find('table tbody td:nth-child(11)').css(
                                        'text-align', 'left');
                                    $(win.document.body).find('table tbody td:nth-child(12)').css(
                                        'text-align', 'right');



                                }
                        }
                    ],
                }
            },
             "aoColumnDefs": [

                {
                    "sClass": "numericCol",
                    "aTargets": [0, 1],

                },
                {
                    "sClass": "bigCol",
                    "aTargets": [2, 3, 5]
                },
                {
                    "sWidth": "15%",
                    "aTargets": [6]
                },

                {
                    "sWidth": "10%",
                    "aTargets": [ 4, 5]
                },
                {
                    "sWidth": "7%",
                    "aTargets": [2, 3,7,8,9,10,11]
                },
                {
                    "sWidth": "4%",
                    "aTargets": [0, 1,12]
                }



            ],

        });








    });
</script>

@endsection
