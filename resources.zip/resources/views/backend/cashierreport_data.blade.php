<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>

    <style>

      @media print {

        .page {

            page-break-after: always; /* Ensure page break after each element with the class "page" */

        }



        .page::after {

            content: "";

            display: block;

            border-top: solid 1px black; /* Add border to the bottom of each page */

        }

    }



        table {

            width: 95%;

            border-collapse: collapse;

        }



        th, td {

            /* border: 1px solid black; */

            padding-top: 4px;

            padding-left: 18px;



            text-align: left;

        }



        th:nth-child(1),

        td:nth-child(1) {

            width: 25%;

        }



        th:nth-child(2),

        td:nth-child(2) {

            width: 34%;

        }



        th:nth-child(3),

        td:nth-child(3) {

            width: 10%;

        }



        th:nth-child(4),

        td:nth-child(4) {

            width: 23%;

        }



        th:nth-child(5),

        td:nth-child(5) {

            width: 7%;

        }











        .widget {

            float: left;

            /* border: 1px solid #ccc;  */

            box-sizing: border-box;

            padding: 10px;

        }

        .widget-1 {

            width: 30%; /* 20% width for Widget 1 */

        }

        .widget-2 {

            width: 40%; /* 50% width for Widget 2 */

        }

        .widget-3 {

            width: 30%; /* 50% width for Widget 2 */

        }



        .widget-4 {

            width: 80%; /* 50% width for Widget 2 */

        }

        .widget-5 {

            width: 20%; /* 50% width for Widget 2 */

        }

          .printButton {
            cursor: pointer;
            background: #bc1b1b;
            color: #fff;
            width: 100px;
            border: none;
            border-radius: 2px;
            height: 28px;
            font-size: 20px;
        }

        .back-button {
            display: inline-block;
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }

        .back-button:hover {
            background-color: #45a049;
        }













    </style>

</head>

<body>

  <div id="content">

    @php



  $From_Date = \Carbon\Carbon::createFromFormat('d-m-Y', $data['check_in'])->format('d-m-Y');

$To_Date = \Carbon\Carbon::createFromFormat('d-m-Y', $data['check_out'])->format('d-m-Y');

$FromDate = \Carbon\Carbon::createFromFormat('d-m-Y', $data['check_in'])->startOfDay();

    $ToDate = \Carbon\Carbon::createFromFormat('d-m-Y', $data['check_out'])->endOfDay();



@endphp
@php
    $currentDomain = request()->getHost();
@endphp


<div id="content">

    <div style="padding: 10px; border: solid 1px black;">

    <div style="text-align: center; line-height: 8px;">

    <p style="color: red;">OMSAKTHI</p>

    <p style="font-weight: bold; font-size: 18px;">{{ Str::contains($currentDomain, 'gbresidency') ? 'GB Residency' : 'ADHIPARASAKTHI Lodging' }}</p>

    <p>MELMARUVATHUR</p>

</div>

<hr>



<div class="widget widget-1">

    <p style="font-weight: bold;">Cashier Collection Report: </p>

</div>

<div class="widget widget-2">

    <p><b>Form:</b> {{ $From_Date ?? '' }} &nbsp; &nbsp; <b>To:</b> {{ $To_Date }}</p>

</div>

<div class="widget widget-3" style="text-align: right;">

    <p><b>User Name:</b> {{ $user_ids == "ALL" ? "ALL" : $reports->first()->user_ids->name }}</p>



</div>

<div class="clear"></div>

<p style="text-align:center;"><b>Advance Collection </b></p>

<p style="text-decoration: underline; margin-bottom: 10px;"><b>Advance Collection Amount (by cash) :- &nbsp; &nbsp; </b></p>



<table>

    <tr>

        <th> Adv.No </th>

        <th> Guest Name</th>

        <th> </th>

        <th> Room No </th>

        <th> Amount</th>



    </tr>



    @php



$totalAdvanceAmount = $reports->flatMap->advanceAmount->sum('advance_amount');

$totalSettlementAmount = $reports->flatMap(function ($report) {
    return $report->checkOut && !$report->houseguest && $report->checkOut->payment_method != 3 ?
        [$report->checkOut->balance_amount] : [];
})->sum();

$totalSettlementAmount += $reports->flatMap(function ($report) {
    return $report->checkOutOld && !$report->houseguest && $report->checkOutOld->payment_method != 3 ?
        [$report->checkOutOld->balance_amount] : [];
})->sum();

$totalSettlementAmount += $reports->flatMap(function ($report) {
    return $report->Checkout24_25 && !$report->houseguest && $report->Checkout24_25->payment_method != 3 ?
        [$report->Checkout24_25->balance_amount] : [];
})->sum();







$totalCreditAmount = $reports->flatMap(function ($report, $user_ids) {
    return ($report->checkOut && !$report->houseguest && $report->checkOut->payment_method == 3 && ($report->checkOut->user_ids_id == $user_ids || $user_ids == 'ALL')) ?
        [$report->checkOut->balance_amount] : [];
})->sum();

$totalCreditAmount += $reports->flatMap(function ($report, $user_ids) {
    return ($report->checkOutOld && !$report->houseguest && $report->checkOutOld->payment_method == 3 && ($report->checkOutOld->user_ids_id == $user_ids || $user_ids == 'ALL')) ?
        [$report->checkOutOld->balance_amount] : [];
})->sum();

$totalCreditAmount += $reports->flatMap(function ($report, $user_ids) {
    return ($report->Checkout24_25 && !$report->houseguest && $report->Checkout24_25->payment_method == 3 && ($report->Checkout24_25->user_ids_id == $user_ids || $user_ids == 'ALL')) ?
        [$report->Checkout24_25->balance_amount] : [];
})->sum();







    $totalRefundAmount = $reports->flatMap(function ($report) {

    return $report->refund ? [$report->refund->amount] : [];

})->sum();





   $total= $totalAdvanceAmount + $totalSettlementAmount + $totalCreditAmount;

@endphp



<?php



$advancebycash = 0;

?>

{{-- @foreach($reports as $key => $report) --}}
@foreach ($reports->sortBy('advanceAmount.created_at') as $key => $report)

    @foreach($report->advanceAmount as $key => $advanceamount)
    {{-- @foreach ($report->advanceAmount->sortBy('id') as $key => $advanceamount) --}}
    @php
     $isBetween= false;
    $FromDate = \Carbon\Carbon::createFromFormat('d-m-Y', $data['check_in'])->startOfDay();

    $ToDate = \Carbon\Carbon::createFromFormat('d-m-Y', $data['check_out'])->endOfDay();
    $isBetween = \Carbon\Carbon::parse( $advanceamount->created_at)->between($FromDate, $ToDate);
    @endphp




    @if($advanceamount->payment_method == 1 && \Carbon\Carbon::parse( $advanceamount->created_at)->between($FromDate, $ToDate) && ($advanceamount->user_ids_id == $user_ids || $user_ids == 'ALL'))



        @php

            $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {

                return rtrim($name, ', ');

            });



        @endphp

        <tr>

            <td>A{{ sprintf("%03d", $advanceamount->id) }}</td>

            <td>{{ $report->guest_name ?? '' }} </td>

            <td></td>

            <td>{{ $roomNames->implode(', ') }}</td>

            <td>{{ $advanceamount->advance_amount }}</td>

        </tr>

        <?php

        $advancebycash += $advanceamount->advance_amount;

        ?>

        @endif

    @endforeach

@endforeach



<tr>

    <td></td>

    <td></td>

    <td></td>

    <th>Advance Amount (By Cash):</th>

    <td>{{ $advancebycash }}</td>

</tr>







</table>



<p style="text-decoration: underline; margin-bottom: 10px;"><b>Advance Collection Amount (by card & UPI) :- &nbsp; &nbsp; </b></p>



<table>

    <tr>

        <th> Adv.No </th>

        <th> Guest Name</th>

        <th> </th>

        <th> Room No </th>

        <th> Amount</th>



    </tr>



    @php



$totalAdvanceAmount = $reports->flatMap->advanceAmount->sum('advance_amount');

$totalSettlementAmount = $reports->flatMap(function ($report) {
    return $report->checkOut && !$report->houseguest && $report->checkOut->payment_method != 3 ?
        [$report->checkOut->balance_amount] : [];
})->sum();

$totalSettlementAmount += $reports->flatMap(function ($report) {
    return $report->checkOutOld && !$report->houseguest && $report->checkOutOld->payment_method != 3 ?
        [$report->checkOutOld->balance_amount] : [];
})->sum();

$totalSettlementAmount += $reports->flatMap(function ($report) {
    return $report->Checkout24_25 && !$report->houseguest && $report->Checkout24_25->payment_method != 3 ?
        [$report->Checkout24_25->balance_amount] : [];
})->sum();







$totalCreditAmount = $reports->flatMap(function ($report, $user_ids) {
    return ($report->checkOut && !$report->houseguest && $report->checkOut->payment_method == 3 && ($report->checkOut->user_ids_id == $user_ids || $user_ids == 'ALL')) ?
        [$report->checkOut->balance_amount] : [];
})->sum();

$totalCreditAmount += $reports->flatMap(function ($report, $user_ids) {
    return ($report->checkOutOld && !$report->houseguest && $report->checkOutOld->payment_method == 3 && ($report->checkOutOld->user_ids_id == $user_ids || $user_ids == 'ALL')) ?
        [$report->checkOutOld->balance_amount] : [];
})->sum();

$totalCreditAmount += $reports->flatMap(function ($report, $user_ids) {
    return ($report->Checkout24_25 && !$report->houseguest && $report->Checkout24_25->payment_method == 3 && ($report->Checkout24_25->user_ids_id == $user_ids || $user_ids == 'ALL')) ?
        [$report->Checkout24_25->balance_amount] : [];
})->sum();







    $totalRefundAmount = $reports->flatMap(function ($report) {

    return $report->refund ? [$report->refund->amount] : [];

})->sum();





   $total= $totalAdvanceAmount + $totalSettlementAmount + $totalCreditAmount;



@endphp



<?php



$advancebycard = 0;

?>



{{-- @foreach($reports as $key => $report) --}}
@foreach ($reports->sortBy('advanceAmount.created_at') as $key => $report)

    @foreach($report->advanceAmount as $key => $advanceamount)

    @php
     $isBetween= false;
    $FromDate = \Carbon\Carbon::createFromFormat('d-m-Y', $data['check_in'])->startOfDay();

    $ToDate = \Carbon\Carbon::createFromFormat('d-m-Y', $data['check_out'])->endOfDay();
    $isBetween = \Carbon\Carbon::parse( $advanceamount->created_at)->between($FromDate, $ToDate);
    @endphp


    @if(($advanceamount->payment_method == 2 || $advanceamount->payment_method == 4 )&& \Carbon\Carbon::parse( $advanceamount->created_at)->between($FromDate, $ToDate) && ($advanceamount->user_ids_id == $user_ids || $user_ids == 'ALL'))



        @php

            $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {

                return rtrim($name, ', ');

            });

        @endphp

        <tr>

            <td>A{{ sprintf("%03d", $advanceamount->id) }} </td>

            <td>{{ $report->guest_name ?? '' }}</td>

            <td></td>

            <td>{{ $roomNames->implode(', ') }}</td>

            <td>{{ $advanceamount->advance_amount }}</td>

        </tr>



        <?php

        $advancebycard += $advanceamount->advance_amount;

        ?>



        @endif

    @endforeach

@endforeach



<tr>

    <td></td>

    <td></td>

    <td></td>

    <th>Advance Amount (By Card & UPI):</th>

    <td>{{ $advancebycard }}</td>

</tr>



<tr>

    <td></td>

    <td></td>

    <td></td>

    <th></th>

    <td></td>

</tr>

@php

$advantotamt =  $advancebycard + $advancebycash;

@endphp

<tr>

    <td></td>

    <td></td>

    <td></td>

    <th>Advance Amount Total:</th>

    <td style="border-top: solid 1px; border-bottom: solid 1px;">{{ $advantotamt}}</td>



</tr>





</table>









@php

            $currentMonth = date('n'); // Get the current month (1 to 12)



            // Check if the current month is April or later

            if ($currentMonth >= 4) {

                // Finance year starts from April 1st of the current year to March 31st of the next year

                $startYear = date('y');

                $endYear = date('y', strtotime('+1 year'));

            } else {

                // Finance year starts from April 1st of the previous year to March 31st of the current year

                $startYear = date('y', strtotime('-1 year'));

                $endYear = date('y');

            }

           @endphp













<p style="text-align:center"><b>Settlement Amount</b></p>

<p style="text-decoration: underline; margin-bottom: 10px;"><b>Settlement Amount  (by cash) :- &nbsp; &nbsp; </b></p>



<table>
    <tr>
        <th> Bill No </th>
        <th> Guest Name</th>
        <th> </th>
        <th> Room No </th>
        <th> Amount </th>
    </tr>

    @php
        $totalSetbycash = 0;
    @endphp

    {{-- checkOutOld Section --}}
    @foreach ($reports->sortBy('checkOutOld.created_at') as $key => $report)
        @if(isset($report->checkOutOld) && (\Carbon\Carbon::parse($report->checkOutOld->created_at)->between($FromDate, $ToDate)) && !isset($report->houseguest) && $report->checkOutOld->payment_method != 3 && $report->checkOutOld->balance_amount > 0.0
            && $report->checkOutOld->payment_method == 1 && ($report->checkOutOld->user_ids_id == $user_ids || $user_ids == 'ALL'))
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                    return rtrim($name, ', ');
                });
            @endphp
            <tr>
                <td>
                    @if(isset($report->houseguest))
                        <span class="inline">M/{{ sprintf("%03d", $report->houseguest->id) }}</span>
                    @else
                        <span class="inline">{{ $report->checkOutOld->bill_no }}</span>
                    @endif
                </td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td> </td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ $report->checkOutOld->balance_amount ?? '' }}</td>
            </tr>
            <?php
                $totalSetbycash += $report->checkOutOld->balance_amount;
            ?>
        @endif
    @endforeach

    {{-- checkOut Section --}}
    @foreach ($reports->sortBy('checkOut.created_at') as $key => $report)
        @if(isset($report->checkOut) && (\Carbon\Carbon::parse($report->checkOut->created_at)->between($FromDate, $ToDate)) && !isset($report->houseguest) && $report->checkOut->payment_method != 3 && $report->checkOut->balance_amount > 0.0
            && $report->checkOut->payment_method == 1 && ($report->checkOut->user_ids_id == $user_ids || $user_ids == 'ALL'))
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                    return rtrim($name, ', ');
                });
            @endphp
            <tr>
                <td>
                    @if(isset($report->houseguest))
                        <span class="inline">M/{{ sprintf("%03d", $report->houseguest->id) }}</span>
                    @else
                        <span class="inline">{{ $report->checkOut->bill_no }}</span>
                    @endif
                </td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td> </td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ $report->checkOut->balance_amount ?? '' }}</td>
            </tr>
            <?php
                $totalSetbycash += $report->checkOut->balance_amount;
            ?>
        @endif
    @endforeach

    {{-- Checkout24_25 Section --}}
    @foreach ($reports->sortBy('Checkout24_25.created_at') as $key => $report)
        @if(isset($report->Checkout24_25) && (\Carbon\Carbon::parse($report->Checkout24_25->created_at)->between($FromDate, $ToDate)) && !isset($report->houseguest) && $report->Checkout24_25->payment_method != 3 && $report->Checkout24_25->balance_amount > 0.0
            && $report->Checkout24_25->payment_method == 1 && ($report->Checkout24_25->user_ids_id == $user_ids || $user_ids == 'ALL'))
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                    return rtrim($name, ', ');
                });
            @endphp
            <tr>
                <td>
                    @if(isset($report->houseguest))
                        <span class="inline">M/{{ sprintf("%03d", $report->houseguest->id) }}</span>
                    @else
                        <span class="inline">{{ $report->Checkout24_25->bill_no }}</span>
                    @endif
                </td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td> </td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ $report->Checkout24_25->balance_amount ?? '' }}</td>
            </tr>
            <?php
                $totalSetbycash += $report->Checkout24_25->balance_amount;
            ?>
        @endif
    @endforeach
    
    {{-- Checkout25_26 Section --}}
    @foreach ($reports->sortBy('Checkout25_26.created_at') as $report)
        @if(isset($report->Checkout25_26) && (\Carbon\Carbon::parse($report->Checkout25_26->created_at)->between($FromDate, $ToDate)) && !isset($report->houseguest) && $report->Checkout25_26->payment_method != 3 && $report->Checkout25_26->balance_amount > 0.0
            && $report->Checkout25_26->payment_method == 1 && ($report->Checkout25_26->user_ids_id == $user_ids || $user_ids == 'ALL'))
    
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(fn($name) => rtrim($name, ', '));
            @endphp
    
            <tr>
                <td>{{ $report->Checkout25_26->bill_no }}</td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td></td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ $report->Checkout25_26->balance_amount }}</td>
            </tr>
    
            <?php $totalSetbycash += $report->Checkout25_26->balance_amount; ?>
        @endif
    @endforeach

    <tr>
        <td> </td>
        <td> </td>
        <td> </td>
        <th> Set.Amt (By Cash) : </th>
        <td> {{ $totalSetbycash }}</td>
    </tr>
</table>



<p style="text-decoration: underline; margin-bottom: 10px;"><b>Settlement Amount (by Card & UPI) :- &nbsp; &nbsp; </b></p>



<table>
    <tr>
        <th> Bill No </th>
        <th> Guest Name</th>
        <th> </th>
        <th> Room No </th>
        <th> Amount </th>
    </tr>

    @php
        $totalSetbycard = 0;
    @endphp

    {{-- checkOutOld Section --}}
    @foreach ($reports->sortBy('checkOutOld.created_at') as $key => $report)
        @if(isset($report->checkOutOld) && !isset($report->houseguest) && \Carbon\Carbon::parse($report->checkOutOld->created_at)->between($FromDate, $ToDate) && ($report->checkOutOld->payment_method == 2 || $report->checkOutOld->payment_method == 4) && $report->checkOutOld->balance_amount > 0.0 && ($report->checkOutOld->user_ids_id == $user_ids || $user_ids == 'ALL'))
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                    return rtrim($name, ', ');
                });
            @endphp
            <tr>
                <td>
                    @if(isset($report->houseguest))
                        <span class="inline">M/{{ sprintf("%03d", $report->houseguest->id) }}</span>
                    @else
                        <span class="inline">{{ $report->checkOutOld->bill_no }}</span>
                    @endif
                </td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td> </td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ $report->checkOutOld->balance_amount ?? '' }}</td>
            </tr>
            <?php
                $totalSetbycard += $report->checkOutOld->balance_amount;
            ?>
        @endif
    @endforeach

    {{-- checkOut Section --}}
    @foreach ($reports->sortBy('checkOut.created_at') as $key => $report)
        @if(isset($report->checkOut) && !isset($report->houseguest) && \Carbon\Carbon::parse($report->checkOut->created_at)->between($FromDate, $ToDate) && ($report->checkOut->payment_method == 2 || $report->checkOut->payment_method == 4) && $report->checkOut->balance_amount > 0.0 && ($report->checkOut->user_ids_id == $user_ids || $user_ids == 'ALL'))
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                    return rtrim($name, ', ');
                });
            @endphp
            <tr>
                <td>
                    @if(isset($report->houseguest))
                        <span class="inline">M/{{ sprintf("%03d", $report->houseguest->id) }}</span>
                    @else
                        <span class="inline">{{ $report->checkOut->bill_no }}</span>
                    @endif
                </td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td> </td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ $report->checkOut->balance_amount ?? '' }}</td>
            </tr>
            <?php
                $totalSetbycard += $report->checkOut->balance_amount;
            ?>
        @endif
    @endforeach

    {{-- Checkout24_25 Section --}}
    @foreach ($reports->sortBy('Checkout24_25.created_at') as $key => $report)
        @if(isset($report->Checkout24_25) && !isset($report->houseguest) && \Carbon\Carbon::parse($report->Checkout24_25->created_at)->between($FromDate, $ToDate) && ($report->Checkout24_25->payment_method == 2 || $report->Checkout24_25->payment_method == 4) && $report->Checkout24_25->balance_amount > 0.0 && ($report->Checkout24_25->user_ids_id == $user_ids || $user_ids == 'ALL'))
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                    return rtrim($name, ', ');
                });
            @endphp
            <tr>
                <td>
                    @if(isset($report->houseguest))
                        <span class="inline">M/{{ sprintf("%03d", $report->houseguest->id) }}</span>
                    @else
                        <span class="inline">{{ $report->Checkout24_25->bill_no }}</span>
                    @endif
                </td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td> </td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ $report->Checkout24_25->balance_amount ?? '' }}</td>
            </tr>
            <?php
                $totalSetbycard += $report->Checkout24_25->balance_amount;
            ?>
        @endif
    @endforeach
    
    {{-- Checkout25_26 Section --}}
    @foreach ($reports->sortBy('Checkout25_26.created_at') as $report)
        @if(isset($report->Checkout25_26) && !isset($report->houseguest) && \Carbon\Carbon::parse($report->Checkout25_26->created_at)->between($FromDate, $ToDate)
            && ($report->Checkout25_26->payment_method == 2 || $report->Checkout25_26->payment_method == 4)
            && $report->Checkout25_26->balance_amount > 0.0
            && ($report->Checkout25_26->user_ids_id == $user_ids || $user_ids == 'ALL'))
    
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(fn($name) => rtrim($name, ', '));
            @endphp
    
            <tr>
                <td>{{ $report->Checkout25_26->bill_no }}</td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td></td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ $report->Checkout25_26->balance_amount }}</td>
            </tr>
    
            <?php $totalSetbycard += $report->Checkout25_26->balance_amount; ?>
        @endif
    @endforeach

    <tr>
        <td> </td>
        <td> </td>
        <td> </td>
        <th> Set.Amt (By card & UPI): </th>
        <td> {{ $totalSetbycard }}</td>
    </tr>

    <tr>
        <td> </td>
        <td> </td>
        <td> </td>
        <th> </th>
        <td> </td>
    </tr>

    <?php
        // $totalSettlement = $totalSetbycredit + $totalSetbycash + $totalSetbycard;
        $totalSettlement = $totalSetbycash + $totalSetbycard;
    ?>

    <tr>
        <td> </td>
        <td> </td>
        <td> </td>
        <th> Total Set.Amt : </th>
        <td style="border-top: solid 1px; border-bottom: solid 1px;"> {{ $totalSettlement }}</td>
    </tr>
</table>























<p style="text-decoration: underline; margin-bottom: 10px;"><b>Refund Amount :- &nbsp; &nbsp;  </b></p>



<table>
    <tr>
        <th> Bill No </th>
        <th> Guest Name</th>
        <th> </th>
        <th> Room No </th>
        <th> Amount</th>
    </tr>

    @php
        $totalRefund = 0;
    @endphp

    {{-- checkOutOld Section --}}
    @foreach ($reports->sortBy('checkOutOld.created_at') as $key => $report)
        @if(isset($report->checkOutOld) && !isset($report->houseguest) && \Carbon\Carbon::parse($report->checkOutOld->created_at)->between($FromDate, $ToDate) && $report->checkOutOld->payment_method != 3 && $report->checkOutOld->balance_amount < 0.0 && ($report->checkOutOld->user_ids_id == $user_ids || $user_ids == 'ALL'))
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                    return rtrim($name, ', ');
                });
            @endphp
            <tr>
                <td>
                    @if(isset($report->houseguest))
                        <span class="inline">M/{{ sprintf("%03d", $report->houseguest->id) }}</span>
                    @else
                        <span class="inline">{{ $report->checkOutOld->bill_no }}</span>
                    @endif
                </td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td> </td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ $report->checkOutOld->balance_amount ?? '' }}</td>
            </tr>
            <?php
                $totalRefund += $report->checkOutOld->balance_amount;
            ?>
        @endif
    @endforeach

    {{-- checkOut Section --}}
    @foreach ($reports->sortBy('checkOut.created_at') as $key => $report)
        @if(isset($report->checkOut) && !isset($report->houseguest) && \Carbon\Carbon::parse($report->checkOut->created_at)->between($FromDate, $ToDate) && $report->checkOut->payment_method != 3 && $report->checkOut->balance_amount < 0.0 && ($report->checkOut->user_ids_id == $user_ids || $user_ids == 'ALL'))
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                    return rtrim($name, ', ');
                });
            @endphp
            <tr>
                <td>
                    @if(isset($report->houseguest))
                        <span class="inline">M/{{ sprintf("%03d", $report->houseguest->id) }}</span>
                    @else
                        <span class="inline">{{ $report->checkOut->bill_no }}</span>
                    @endif
                </td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td> </td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ $report->checkOut->balance_amount ?? '' }}</td>
            </tr>
            <?php
                $totalRefund += $report->checkOut->balance_amount;
            ?>
        @endif
    @endforeach

    {{-- Checkout24_25 Section --}}
    @foreach ($reports->sortBy('Checkout24_25.created_at') as $key => $report)
        @if(isset($report->Checkout24_25) && !isset($report->houseguest) && \Carbon\Carbon::parse($report->Checkout24_25->created_at)->between($FromDate, $ToDate) && $report->Checkout24_25->payment_method != 3 && $report->Checkout24_25->balance_amount < 0.0 && ($report->Checkout24_25->user_ids_id == $user_ids || $user_ids == 'ALL'))
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                    return rtrim($name, ', ');
                });
            @endphp
            <tr>
                <td>
                    @if(isset($report->houseguest))
                        <span class="inline">M/{{ sprintf("%03d", $report->houseguest->id) }}</span>
                    @else
                        <span class="inline">{{ $report->Checkout24_25->bill_no }}</span>
                    @endif
                </td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td> </td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ $report->Checkout24_25->balance_amount ?? '' }}</td>
            </tr>
            <?php
                $totalRefund += $report->Checkout24_25->balance_amount;
            ?>
        @endif
    @endforeach
    
    {{-- Checkout25_26 Section --}}
    @foreach ($reports->sortBy('Checkout25_26.created_at') as $report)
        @if(isset($report->Checkout25_26) && !isset($report->houseguest) && \Carbon\Carbon::parse($report->Checkout25_26->created_at)->between($FromDate, $ToDate)
            && $report->Checkout25_26->payment_method != 3
            && $report->Checkout25_26->balance_amount < 0.0
            && ($report->Checkout25_26->user_ids_id == $user_ids || $user_ids == 'ALL'))
    
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(fn($name) => rtrim($name, ', '));
            @endphp
    
            <tr>
                <td>{{ $report->Checkout25_26->bill_no }}</td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td></td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ $report->Checkout25_26->balance_amount }}</td>
            </tr>
    
            <?php $totalRefund += $report->Checkout25_26->balance_amount; ?>
        @endif
    @endforeach

    <tr>
        <td> </td>
        <td> </td>
        <td> </td>
        <th> Ref.Amt : </th>
        <td style="border-top: solid 1px; border-bottom: solid 1px;">{{ $totalRefund }}</td>
    </tr>
</table>





<p style="text-decoration: underline; margin-bottom: 10px;"><b>Credit Bills Amount :- &nbsp; &nbsp; </b></p>



<table>
    <tr>
        <th> Bill No </th>
        <th> Guest Name</th>
        <th> </th>
        <th> Room No </th>
        <th> Amount</th>
    </tr>

    @php
        $tempCredit = 0.0;
    @endphp

    {{-- checkOutOld Section --}}
    @foreach ($reports->sortBy('checkOutOld.created_at') as $key => $report)
        @if(isset($report->checkOutOld) && $report->checkOutOld->payment_method == 3 && \Carbon\Carbon::parse($report->checkOutOld->created_at)->between($FromDate, $ToDate) && ($report->checkOutOld->user_ids_id == $user_ids || $user_ids == 'ALL'))
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                    return rtrim($name, ', ');
                });
                $tempCredit += ceil($report->checkOutOld->balance_amount ?? '0');
            @endphp
            <tr>
                <td>
                    @if(isset($report->houseguest))
                        <span class="inline">M/{{ sprintf("%03d", $report->houseguest->id) }}</span>
                    @else
                        <span class="inline">{{ $report->checkOutOld->bill_no }}</span>
                    @endif
                </td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td> </td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ ceil($report->checkOutOld->balance_amount ?? '0') }}</td>
            </tr>
        @endif
    @endforeach

    {{-- checkOut Section --}}
    @foreach ($reports->sortBy('checkOut.created_at') as $key => $report)
        @if(isset($report->checkOut) && $report->checkOut->payment_method == 3 && \Carbon\Carbon::parse($report->checkOut->created_at)->between($FromDate, $ToDate) && ($report->checkOut->user_ids_id == $user_ids || $user_ids == 'ALL'))
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                    return rtrim($name, ', ');
                });
                $tempCredit += ceil($report->checkOut->balance_amount ?? '0');
            @endphp
            <tr>
                <td>
                    @if(isset($report->houseguest))
                        <span class="inline">M/{{ sprintf("%03d", $report->houseguest->id) }}</span>
                    @else
                        <span class="inline">{{ $report->checkOut->bill_no }}</span>
                    @endif
                </td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td> </td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ ceil($report->checkOut->balance_amount ?? '0') }}</td>
            </tr>
        @endif
    @endforeach

    {{-- Checkout24_25 Section --}}
    @foreach ($reports->sortBy('Checkout24_25.created_at') as $key => $report)
        @if(isset($report->Checkout24_25) && $report->Checkout24_25->payment_method == 3 && \Carbon\Carbon::parse($report->Checkout24_25->created_at)->between($FromDate, $ToDate) && ($report->Checkout24_25->user_ids_id == $user_ids || $user_ids == 'ALL'))
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(function ($name) {
                    return rtrim($name, ', ');
                });
                $tempCredit += ceil($report->Checkout24_25->balance_amount ?? '0');
            @endphp
            <tr>
                <td>
                    @if(isset($report->houseguest))
                        <span class="inline">M/{{ sprintf("%03d", $report->houseguest->id) }}</span>
                    @else
                        <span class="inline">{{ $report->Checkout24_25->bill_no }}</span>
                    @endif
                </td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td> </td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ ceil($report->Checkout24_25->balance_amount ?? '0') }}</td>
            </tr>
        @endif
    @endforeach
    
    {{-- Checkout25_26 Section --}}
    @foreach ($reports->sortBy('Checkout25_26.created_at') as $report)
        @if(isset($report->Checkout25_26) && $report->Checkout25_26->payment_method == 3
            && \Carbon\Carbon::parse($report->Checkout25_26->created_at)->between($FromDate, $ToDate)
            && ($report->Checkout25_26->user_ids_id == $user_ids || $user_ids == 'ALL'))
    
            @php
                $roomNames = $report->select_rooms->pluck('name')->map(fn($name) => rtrim($name, ', '));
                $tempCredit += ceil($report->Checkout25_26->balance_amount ?? 0);
            @endphp
    
            <tr>
                <td>{{ $report->Checkout25_26->bill_no }}</td>
                <td>{{ $report->guest_name ?? '' }}</td>
                <td></td>
                <td>{{ $roomNames->implode(', ') }}</td>
                <td>{{ ceil($report->Checkout25_26->balance_amount ?? 0) }}</td>
            </tr>
        @endif
    @endforeach

    <tr>
        <td> </td>
        <td> </td>
        <td> </td>
        <th> Credit.Amt : </th>
        <td style="border-top: solid 1px; border-bottom: solid 1px;">{{ $tempCredit ?? '' }}</td>
    </tr>
</table>

<hr>

<div>



    <div class="widget widget-4">

        <div style="text-align: right; line-height: 13px; font-weight: bold;">

        <p>Adv.Amt &nbsp; &nbsp;  :</p>

        <p>Set.Amt &nbsp; &nbsp;  :</p>

        <p>Tot.Amt &nbsp; &nbsp;  :</p>

        <p>Ref.Amt &nbsp; &nbsp;  :</p>

        <p>Bank.Amt &nbsp; &nbsp;:</p>

        <p>Cash In Hand :</p>

        </div>



    </div>

@php



 $totamt = $advantotamt + $totalSettlement;

 $bankamt = $advancebycard + $totalSetbycard;

 $cash_in_hand = $totamt -(($totalRefund *-1) + $bankamt) ;

@endphp



    <div class="widget widget-5" style="line-height: 10px;">

        <br>

            <p style="text-align: right; font-weight: bold; margin-right: 1%;">{{ $advantotamt}}</p>





            <p style="text-align: right; font-weight: bold; margin-right: 1%;">{{ $totalSettlement }}</p>

            <p style="margin-top: -22px; text-align: right ">_______________</p>



            <p style="text-align: right; font-weight: bold; margin-right: 1%;">{{ $totamt }}</p>

      <p style="margin-top: -22px;text-align: right ">_______________</p>



            <p style="text-align: right; font-weight: bold; margin-right: 1%;">

                {{ $totalRefund }}

            </p>

            <!--<p style="margin-top: -22px; text-align: right ">_______________</p>-->



            <p style="text-align: right; font-weight: bold; margin-right: 1%;">-{{ $bankamt }}</p>

            <p style="margin-top: -22px; text-align: right">_______________</p>



            <p style="text-align: right; font-weight: bold; margin-right: 1%;">{{ $cash_in_hand }}</p>

            <p style="margin-top: -22px; text-align: right">_______________</p>



    </div>

</div>

<!-- <hr style="border: 0; height: 1px; background-color: red;"> -->

<hr>

<hr>
<div class="row">
            <div style="text-align:center;" id="bckButton" id="back-btn">
                <a href="javascript:location.reload()" class="back-button">Back</a>
            </div>
            <div style="text-align:center;" id="printButton">
                <button class="printButton" onclick="printPage()">Print</button>

            </div>
        </div>


</div>

</div>

</div>


</body>



</html>
