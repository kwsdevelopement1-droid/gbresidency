@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link href="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/css/tempusdominus-bootstrap-4.min.css"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css"
        integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('assets/intl-tel-input-18.2.1/build/css/intlTelInput.css') }}">
    <style type="text/css" media="print">
        @page {
            size: auto;
            /* auto is the initial value */
            margin: 0;
            /* this affects the margin in the printer settings */
        }
    </style>
    <style>
        .printButton {
            cursor: pointer;
            background: #bc1b1b;
            color: #fff;
            width: 100px;
            border: none;
            border-radius: 2px;
            height: 28px;
            font-size: 20px;
        }

        .pdfModalcloseclose {
            font-size: 44px;
            color: #891b17;
            cursor: pointer;
        }

        .modal-content {
            height: 100%;
        }

        .card {
            padding: unset !important;
            border-radius: 25px 26px 0px 0px;
            border: 4px solid #8DD3BB;
        }

        .card-header.text-center {
            border-radius: 20px 20px 0px 0px;
            background: #8DD3BB;
            position: relative;
            bottom: 0;
        }

        .card-header.text-center h3 {
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .iti {
            width: 100%;
        }

        .hide {
            display: none;
        }

        .default-form .selectize-control {
            position: relative;
            width: 250px;
            border-radius: 4px 4px 0px 0px;
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 16px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
        }

        .default-form .selectize-input {
            height: 58px;
        }

        .green-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #009834;
        }

        .color-rooms h3 {
            color: #000;
            font-family: Montserrat;
            font-size: 19px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            white-space: nowrap;
            position: relative;
            left: 39px;
        }

        .color-rooms h4 {
            color: #FFF;
            font-family: Montserrat;
            font-size: 30px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            text-align: center;
            position: relative;
            bottom: 3px;
        }

        .colors {
            max-width: 25%;
        }

        .orange-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FF823C;
        }

        .yellow-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FBB836;
        }

        .blue-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #0C89D0;
        }

        .black-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #000;
        }

        .default-form .input-group-text {

            height: 56px;
        }

        .default-form .fa.fa-calendar {
            font-size: 29px;
        }

        #form2 .input-group-text {

            height: 64px;
        }

        #form2 .fa.fa-calendar {
            font-size: 30px;
        }

        .default-form #no_of_room {
            width: 250px;
            height: 60px;
        }

        .default-form .selectize-input>* {
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 17.039px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
            text-transform: uppercase;
            margin: 12px;
        }

        .default-form .btn-search {
            border-radius: 4.26px;
            background: #8DD3BB;
            border: none;
            width: 55px;
            height: 55px;
        }

        .check-in-form-title {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 33.072px;
            font-style: normal;
            font-weight: 700;
            line-height: 150%;
            /* 49.608px */
        }

        .check_in .form-control {
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;

        }

        .check_in label {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 500;
            line-height: 40px;
        }

        .check_in .selectize-control.single .selectize-input {
            border-color: #b8b8b8;
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;
        }

        .active-btn {
            color: #000 !important;
            font-family: Montserrat !important;
            font-size: 20px !important;
            font-style: normal !important;
            font-weight: 700 !important;
            line-height: normal !important;
            border-radius: 15px !important;
            border: 5px solid #009834 !important;
            background: none !important;
        }

        .btn-save {
            border-radius: 10px;
            background: #8DD3BB;
            width: 672.804px;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            padding: 23.869px 0px 24.213px 0px;
            border: none;
        }

        .black {
            border-radius: 15px;
            background: #000;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .single-color {

            border-radius: 15px;
            background: #FF823C;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .multiple-color {

            border-radius: 15px;
            background: #FBB836;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .recently-vacate-color {

            border-radius: 15px;
            background: #0C89D0;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }


        .main-color {

            border-radius: 15px;
            background: #009834;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }
    </style>
@endsection
<div class="main-class">
    @section('title_nav')
        <div class="row title-card">

            <h2 class="d-flex align-items-center justify-content-center">Check In</h2>
        </div>
    @endsection
    <div class="container">
        <div class="row color-rooms">
            <div class="col-sm">
                <div class="col-sm">
                    <div class="row">
                        <div class="col colors">
                            <div class="green-room rounded container-fluid py-3 mb-3">
                                <h4 id="available_room"></h4>

                            </div>
                        </div>
                        <div class="col">
                            <h3 class="mt-4"> - Available </h3>
                        </div>
                    </div>
                </div>

            </div>
            <div class="col-sm">
                <div class="col-sm">
                    <div class="row">
                        <div class="col colors">
                            <div class="orange-room rounded container-fluid py-3 mb-3">
                                <h4 id="normal_room"></h4>
                            </div>
                        </div>
                        <div class="col">
                            <h3 class="mt-4"> Occupied </h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm">
                <div class="row">
                    <div class="col colors">
                        <div class="blue-room rounded container-fluid py-3 mb-3">
                            <h4 id="recent_room"></h4>
                        </div>
                    </div>
                    <div class="col">
                        <h3 class="mt-4"> - Recent Vacates</h3>
                    </div>
                </div>
            </div>
            <div class="col-sm">
                <div class="row">
                    <div class="col colors">
                        <div class="black-room rounded container-fluid py-3 mb-3">
                            <h4 id="black_room"></h4>
                        </div>
                    </div>
                    <div class="col">
                        <h3 class="mt-4"> - Blocked </h3>
                    </div>
                </div>
            </div>
            <div class="col-sm">
                <div class="col-sm">
                    <div class="row">
                        <div class="col colors">
                            <div class="yellow-room rounded container-fluid py-3 mb-3">
                                <h4 id="total_room"></h4>
                            </div>
                        </div>
                        <div class="col">
                            <h3 class="mt-4"> - Total Rooms</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


    <div class="container mt-4">
        <div class="row">

            <form class="default-form d-flex justify-content-between mt-4" id="form1">
                @csrf
                <input type="hidden" name="max_person">
                <input type="hidden" name="extra_price">
                <input type="hidden" name="extra_price_val">
                <input type="hidden" name="extraPersons">
                
                <input type="hidden" value="{{ $discount->dicount ?? '' }}" name="discount_percentage" id="discount_percentage">
                <input type="hidden" value="" name="discount_ids_id" id="discount_ids_id">
                <input type="hidden" value="{{ $discount->id ?? '' }}" name="discount_percentage_ids" id="discount_percentage_ids">
                
                <input type="hidden" name="old_price" id="old_price">
                <input type="hidden" name="days" id="days">
                <input type="hidden" name="user_ids_id" value="{{ Auth::id() }}">

                <div class="form-row">
                    <div class="form-group col-md-12">
                        <span class="has-float-label">
                            <div class="input-group date" id="datetimepickercheckin" data-target-input="nearest">
                                <input type="text" name="check_in" class="form-control datetimepicker-input"
                                    data-target="#datetimepickercheckin" />
                                <div class="input-group-append" data-target="#datetimepickercheckin"
                                    data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                            <label for="check_in">Check In</label>
                        </span>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-12">
                        <span class="has-float-label">
                            <div class="input-group date" id="datetimepickercheckout" data-target-input="nearest">
                                <input type="text" name="check_out" class="form-control datetimepicker-input"
                                    data-target="#datetimepickercheckout" />
                                <div class="input-group-append" data-target="#datetimepickercheckout"
                                    data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                            <label for="check_out">Check Out</label>
                        </span>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-12">
                        <span class="has-float-label">
                            <select name="room_type_id" id="room_type_id" placeholder="Select Room Type" required>
                                <option value="" selected>Select Room Type</option>
                                @foreach ($floors as $id => $floor)
                                    <option value="{{ $id }}">{{ $floor }}</option>
                                @endforeach
                            </select>

                            <label for="select_room_type">Rooms Type</label>
                    </div>

                </div>
                <div class="form-row d-none">
                    <div class="form-group col-md-12">
                        <span class="has-float-label">
                            <input class="form-control {{ $errors->has('no_of_room') ? 'is-invalid' : '' }}"
                                type="hidden" name="no_fo_room" id="no_of_room" placeholder="No OF Room" required
                                autocomplete="off">
                            <label for="no_of_room">No OF Room</label>
                        </span>
                    </div>
                </div>
                {{-- <button type="button" id="ajax-btn" class="btn-search"><svg xmlns="http://www.w3.org/2000/svg"
                    width="27" height="26" viewBox="0 0 27 26" fill="none">
                    <path
                        d="M18.8339 16.7262L18.8209 16.7435L18.8362 16.7588L23.5326 21.4552C23.7406 21.6881 23.8516 21.9918 23.8429 22.304C23.8341 22.6164 23.7061 22.9135 23.4851 23.1345C23.2641 23.3555 22.9669 23.4835 22.6545 23.4923C22.3424 23.501 22.0387 23.39 21.8058 23.182L17.1094 18.4856L17.0941 18.4703L17.0768 18.4833C15.5757 19.6109 13.7486 20.2196 11.8713 20.2175C7.07584 20.2175 3.17437 16.316 3.17437 11.5206C3.17437 6.72525 7.07584 2.82379 11.8712 2.82379C16.6666 2.82379 20.5681 6.72525 20.5681 11.5206C20.5701 13.398 19.9615 15.2251 18.8339 16.7262ZM5.6164 11.5206V11.5207C5.61839 13.1789 6.27802 14.7687 7.45059 15.9413C8.62316 17.1139 10.2129 17.7735 11.8712 17.7755H11.8712C13.1083 17.7755 14.3176 17.4086 15.3462 16.7213C16.3748 16.0341 17.1765 15.0572 17.6499 13.9143C18.1234 12.7713 18.2472 11.5137 18.0059 10.3004C17.7645 9.08707 17.1688 7.97257 16.2941 7.09781C15.4193 6.22306 14.3048 5.62735 13.0915 5.386C11.8782 5.14466 10.6205 5.26852 9.47761 5.74194C8.33469 6.21535 7.35782 7.01705 6.67053 8.04565C5.98324 9.07425 5.6164 10.2836 5.6164 11.5206Z"
                        fill="#112211" stroke="#112211" stroke-width="0.0499188" />
                </svg></button> --}}
            </form>
            <div id="floor-container">
            </div>
            <div class="d-none" id="check-in-div">
                <div class="row mt-4">
                    <div class="check-in-form-title">
                        <h3>Guest Details</h3>
                    </div>
                    <form class="check_in" id="form2">
                        @csrf
                        <div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required">Guest Type</label>
                                        <select class="{{ $errors->has('guest_type') ? 'is-invalid' : '' }}"
                                            name="guest_type" id="guest_type" required>
                                            <option value="" selected>Guest Type</option>

                                            @foreach (App\Models\Customer::GUEST_TYPE_SELECT as $key => $label)
                                                <option value="{{ $key }}"
                                                    {{ old('guest_type', '') === (string) $key ? 'selected' : '' }}>
                                                    {{ $label }}</option>
                                            @endforeach
                                        </select>
                                        @if ($errors->has('guest_type'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('guest_type') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required" for="phone_number">Phone Number</label>
                                        <input type="hidden" value="91" name="country_code">

                                        <input
                                            class="form-control {{ $errors->has('phone_number') ? 'is-invalid' : '' }}"
                                            type="text" name="phone_number" id="phone_number"
                                            value="{{ old('phone_number', '') }}" required>
                                        <span id="valid-msg" class="hide">✓ Valid</span>
                                        <span id="error-msg" class="hide"></span>
                                        @if ($errors->has('phone_number'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('phone_number') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required" for="guest_name">Guest Name</label>
                                        <input
                                            class="form-control {{ $errors->has('guest_name') ? 'is-invalid' : '' }}"
                                            type="text" name="guest_name" id="guest_name"
                                            value="{{ old('guest_name', '') }}" required>
                                        @if ($errors->has('guest_name'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('guest_name') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email">Email Id</label>
                                        <input class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                                            type="email" name="email" id="email"
                                            value="{{ old('email') }}">
                                            
                                            <!--<input class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"-->
                                            <!--type="email" name="email" id="email"-->
                                            <!--value="{{ old('email') }}">-->
                                        @if ($errors->has('email'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('email') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>

                            </div>
                            <div class="row">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="guest_gstin">Guest GSTIN</label>
                                        <input
                                            class="form-control {{ $errors->has('guest_gstin') ? 'is-invalid' : '' }}"
                                            type="text" name="guest_gstin" id="guest_gstin"
                                            value="{{ old('guest_gstin', '') }}">
                                        @if ($errors->has('guest_gstin'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('guest_gstin') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required">SEG</label>
                                        <select class="{{ $errors->has('seg') ? 'is-invalid' : '' }}" name="seg"
                                            id="seg" required placeholder="Select">
                                            <option value="" selected>Select</option>

                                            @foreach (App\Models\Customer::SEG_SELECT as $key => $label)
                                                <option value="{{ $key }}"
                                                    {{ old('seg', '') === (string) $key ? 'selected' : '' }}>
                                                    {{ $label }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @if ($errors->has('seg'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('seg') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required" for="total_adult">Number Of Adults</label>
                                        <input
                                            class="form-control {{ $errors->has('total_adult') ? 'is-invalid' : '' }}"
                                            type="number" name="total_adult" id="total_adult" value="0"
                                            required>
                                        @if ($errors->has('total_adult'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('total_adult') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required" for="total_child">Number Of Children</label>
                                        <input
                                            class="form-control {{ $errors->has('total_child') ? 'is-invalid' : '' }}"
                                            type="number" name="total_child" id="total_child" value="0"
                                            required>
                                        @if ($errors->has('total_child'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('total_child') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="row">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required" for="country_id">Country</label>
                                        <select class="{{ $errors->has('country') ? 'is-invalid' : '' }}"
                                            name="country_id" id="country_id" placeholder="Select" required>
                                            <option value="" selected>Select</option>

                                            @foreach ($countries as $id => $entry)
                                                <option value="{{ $id }}"
                                                    {{ old('country_id') == $id ? 'selected' : '' }}>
                                                    {{ $entry }}</option>
                                            @endforeach
                                        </select>
                                        @if ($errors->has('country'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('country') }}
                                            </div>
                                        @endif
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required" for="nationality_id">Nationality</label>
                                        <select class="{{ $errors->has('nationality') ? 'is-invalid' : '' }}"
                                            name="nationality_id" id="nationality_id" placeholder="Select" required>
                                            <option value="" selected>Select</option>
                                            @foreach ($nationalities as $id => $entry)
                                                <option value="{{ $id }}"
                                                    {{ old('nationality_id') == $id ? 'selected' : '' }}>
                                                    {{ $entry }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @if ($errors->has('nationality'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('nationality') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="row">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required" for="address">Address</label>
                                        <textarea class="form-control {{ $errors->has('address') ? 'is-invalid' : '' }}" name="address" id="address"
                                            required>{{ old('address') }}</textarea>
                                        @if ($errors->has('address'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('address') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="pincode">Pincode</label>
                                        <input class="form-control {{ $errors->has('pincode') ? 'is-invalid' : '' }}"
                                            type="text" name="pincode" id="pincode"
                                            value="{{ old('pincode', '') }}">
                                        @if ($errors->has('pincode'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('pincode') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="row">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required">ID Proof</label>
                                        <select class="{{ $errors->has('id_proof') ? 'is-invalid' : '' }}"
                                            name="id_proof" id="id_proof" placeholder="Select" required>
                                            <option value="" selected>Select</option>
                                            {{-- <option value disabled {{ old('id_proof', null) === null ? 'selected' : '' }}>
                                            ID Proof</option> --}}
                                            @foreach (App\Models\Customer::ID_PROOF_SELECT as $key => $label)
                                                <option value="{{ $key }}"
                                                    {{ old('id_proof', '') === (string) $key ? 'selected' : '' }}>
                                                    {{ $label }}
                                                </option>
                                            @endforeach
                                        </select>
                                        @if ($errors->has('id_proof'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('id_proof') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required" for="id_proof_number"
                                            id="label_for_id_proof_number">ID Proof Number</label>
                                        <input
                                            class="form-control {{ $errors->has('id_proof_number') ? 'is-invalid' : '' }}"
                                            type="text" name="id_proof_number" id="id_proof_number"
                                            value="{{ old('id_proof_number', '') }}" required>
                                        @if ($errors->has('id_proof_number'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('id_proof_number') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                            </div>


                            <div class="row d-none" id="other_country">

                                <div class="col-md-6">
                                    <label class="required" for="guest_name">P.P.EXP. DATE</label>

                                    <div class="form-group">
                                        <div class="input-group date" id="datetimepickerpr_exp_date"
                                            data-target-input="nearest">
                                            <input type="text" name="pr_exp_date"
                                                class="form-control datetimepicker-input"
                                                data-target="#datetimepickerpr_exp_date" />
                                            <div class="input-group-append" data-target="#datetimepickerpr_exp_date"
                                                data-toggle="datetimepicker">
                                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="required" for="guest_name">VISA,EXP DATE</label>

                                    <div class="form-group">
                                        <div class="input-group date" id="datetimepickervisa_exp_date"
                                            data-target-input="nearest">
                                            <input type="text" name="visa_exp_date"
                                                class="form-control datetimepicker-input"
                                                data-target="#datetimepickervisa_exp_date" />
                                            <div class="input-group-append" data-target="#datetimepickervisa_exp_date"
                                                data-toggle="datetimepicker">
                                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {{-- <div class="row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="advance_amount">Advance Amount</label>
                                    <input
                                        class="form-control {{ $errors->has('advance_amount') ? 'is-invalid' : '' }}"
                                        type="number" name="advance_amount" id="advance_amount"
                                        value="{{ old('advance_amount', '') }}" step="0.01">
                                    @if ($errors->has('advance_amount'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('advance_amount') }}
                                        </div>
                                    @endif

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Payment Method</label>
                                    <select class="{{ $errors->has('payment_method') ? 'is-invalid' : '' }}"
                                        name="payment_method" id="payment_method" placeholder="Select">
                                        <option value="" selected>Select</option>
                                        <option value disabled
                                            {{ old('payment_method', null) === null ? 'selected' : '' }}>
                                            Payment Method</option>
                                        @foreach (App\Models\Customer::PAYMENT_METHOD_SELECT as $key => $label)
                                            <option value="{{ $key }}"
                                                {{ old('payment_method', '') === (string) $key ? 'selected' : '' }}>
                                                {{ $label }}</option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('payment_method'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('payment_method') }}
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div> --}}
                        

                            <div class="row">
                                <div class="{{ (Auth::user()->name == 'Admin' || Auth::user()->name == 'S.Vijay') ? 'col-md-6' : 'col-md-6' }}">
                                    <div class="form-group">
                                        <label>Rate Code</label>
                                        <select class="{{ $errors->has('rate_code') ? 'is-invalid' : '' }}"
                                            name="rate_code" id="rate_code" placeholder="Select">

                                            @foreach (App\Models\Customer::CODE_RATE_SELECT as $key => $label)
                                                <option value="{{ $key }}"
                                                    {{ 1 == $key ? 'selected' : '' }}>
                                                    {{ $label }}
                                                </option>
                                            @endforeach

                                        </select>
                                        @if ($errors->has('rate_code'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('rate_code') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Discount</label>
                                        <!--<input -->
                                        <!--    type="number"-->
                                        <!--    class="form-control {{ $errors->has('discount') ? 'is-invalid' : '' }}"-->
                                        <!--    name="discount"-->
                                        <!--    id="discount"-->
                                        <!--    placeholder="Enter discount %"-->
                                        <!--    min="0"-->
                                        <!--    max="100"-->
                                        <!--    step="0.01"-->
                                        <!--    value="{{ old('discount') }}"-->
                                        
                                        <select class="{{ $errors->has('discount') ? 'is-invalid' : '' }}"
                                            name="discount" id="discount" placeholder="Select">

                                            <option value="1">Yes</option>
                                            <option value="2" selected>No</option>
                                        </select>
                                        @if ($errors->has('discount'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('discount') }}
                                            </div>
                                        @endif
                                    </div>
                                </div>
                                
                            </div>

                            <div class="row">

                                <div class="col-md-6 mx-auto">
                                    <div class="form-group">
                                        <label for="price">Room Price</label>
                                        <input class="form-control {{ $errors->has('price') ? 'is-invalid' : '' }}"
                                            type="text" name="price" id="price"
                                            value="{{ old('price', '') }}" readonly="">
                                        @if ($errors->has('price'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('price') }}
                                            </div>
                                        @endif

                                    </div>
                                </div>
                                <div class="col-md-6 mx-auto">
                                    <div class="form-group">
                                        <label for="price">Extra Price</label>
                                        <input
                                            class="form-control {{ $errors->has('extra_price_val') ? 'is-invalid' : '' }}"
                                            type="text" name="extra_price_val" id="extra_price_val"
                                            value="{{ old('extra_price_val', '') }}" readonly="">
                                        @if ($errors->has('extra_price_val'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('extra_price_val') }}
                                            </div>
                                        @endif

                                    </div>
                                </div>
                            </div>

                            <div id="room_type_container"></div>
                            {{-- <input type="text" name="select_rooms[]" id="room_type" value="" required> --}}

                            <div class="row  mt-4">

                                <div class="col-md-6 mx-auto">
                                    <div class="form-group">
                                        <button class="btn-save" type="submit">
                                            Submit
                                        </button>
                                    </div>
                                </div>
                            </div>

                    </form>

                    <div>
                    </div>

                    {{-- <div class="container">
                    <div class="row mt-4">


                        <div id="pdf-container"></div>

                    </div>
                </div> --}}
                    <!-- Modal -->

                </div>



            </div>
        </div>
    </div>
</div>
</div>
{{-- <div id="pdf-modal" class="modal">
    <span class="d-flex justify-content-center pdfModalcloseclose">&times;</span>
    <div class="modal-content">
        <iframe id="pdf-iframe" style="width: 100%; height: 100%; border: none;"></iframe>
    </div>
</div> --}}

<!-- Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1" role="dialog" aria-labelledby="paymentModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="paymentModalLabel">Payment Details</h5>
                <button type="button" id="paymentModalclose" class="paymentModalclose" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Payment form goes here -->
                <!-- Add an input field to hold the customer ID -->
                <input type="hidden" id="customer_id" name="customer_ids_id">

                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="advance_amount">Advance Amount</label>
                            <input class="form-control" type="number" name="advance_amount" id="advance_amount"
                                step="0.01">
                        </div>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Payment Method</label>
                            <select class="" name="payment_method" id="payment_method">
                                <option value="" selected>Select</option>
                                @foreach (App\Models\Customer::PAYMENT_METHOD_SELECT as $key => $label)
                                    <option value="{{ $key }}">{{ $label }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary paymentModalclose" data-dismiss="modal"
                    id="closeModelBtn">Close</button>
                <!-- Change the type to "submit" to trigger the form submission -->
                <!-- Add data attribute to store route URL -->
                <button type="button" class="btn btn-primary" id="saveChangesBtn"
                    data-route="{{ route('backend.advance') }}">Save changes</button>
            </div>
        </div>
    </div>
</div>

@endsection
@section('scripts')
@parent
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/js/tempusdominus-bootstrap-4.min.js">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
    integrity="sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="{{ asset('assets/intl-tel-input-18.2.1/build/js/intlTelInput.min.js') }}"></script>
<script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>
<script>
    function phone_number() {
        var input_phone = document.querySelector("#phone_number"),
            errorMsg = document.querySelector("#error-msg"),
            validMsg = document.querySelector("#valid-msg");

        // here, the index maps to the error code returned from getValidationError - see readme
        var errorMap = ["Invalid number", "Invalid country code", "Too short", "Too long", "Invalid number"];

        var iti = intlTelInput(input_phone, {
            allowDropdown: true,
            formatOnDisplay: true,
            phoneValidation: true,
            separateDialCode: true,
            enablePlaceholder: true,
            autoPlaceholder: "polite",
            placeholderNumberType: "MOBILE",
            searchCountryPlaceholder: 'Search Country',
            preferredCountries: ["in"],
            hiddenInput: "dialCodes",
            utilsScript: "{{ url('assets/intl-tel-input-18.2.1/build/js/utils.js') }}"
        });

        iti.promise.then(function() {
            var inputValue = input_phone.value.replace(/\s+/g, '');

            // Remove leading zeros
            inputValue = inputValue.replace(/^0+/, '');

            // Set the modified value back to the input field
            input_phone.value = inputValue;
            // console.log("Initialised!");
        });

        $("input[name='country_code'").val(91);
        // $("input[name='dialCode'").val(91);

        var reset_input_phone = function() {
            input_phone.classList.remove("error");
            errorMsg.innerHTML = "";
            errorMsg.classList.add("hide");
            validMsg.classList.add("hide");
        };

        input_phone.addEventListener("countrychange", function() {
            var data_iti = iti.getSelectedCountryData();
            $("input[name='country_code'").val(data_iti.dialCode);
            // $("input[name='dialCode'").val(data_iti.dialCode);

            // console.log("country code " + JSON.stringify(iti.getSelectedCountryData()));
            // console.log("country code " + data_iti.dialCode);
        });

        // on blur: validate
        input_phone.addEventListener('blur', function() {
            // console.log("blur!");
            // console.log($("input[name='dialCodes'").val());
            reset_input_phone();
            if (input_phone.value.trim()) {
                if (iti.isValidNumber()) {
                    validMsg.classList.remove("hide");
                } else {
                    input_phone.classList.add("error");
                    var errorCode = iti.getValidationError();
                    errorMsg.innerHTML = errorMap[errorCode];
                    errorMsg.classList.remove("hide");
                }
            }
        });

        // on keyup / change flag: reset
        input_phone.addEventListener('change', reset_input_phone);
        input_phone.addEventListener('keyup', reset_input_phone);
    }


    function firstpdf(id) {
        $.ajax({
            url: "{{ route('backend.bill-statement.advance-pdf', ':id') }}".replace(':id',
                id), // Replace :id with the actual value of id        method: "GET",
            dataType: 'json',
            success: function(response) {
                // Create an iframe element
                // var iframe = $('<iframe>', {
                //     src: response.pdfUrl,
                //     style: 'width: 100%; height: 500px; border: none;'
                // });
                $('html').html(response.html);

                // var iframe = '<iframe src="' + response.pdfUrl + '"></iframe>';

                // Append the iframe to a container in your HTML (replace '#pdf-container' with the selector of your choice)
                // $('#pdf-container').html(iframe);
                // Open the modal

                // $('#pdf-modal').css('display', 'block');

                // // Set the PDF URL to the iframe source
                // $('#pdf-iframe').attr('src', response.pdfUrl);
                // $('.main-class, .navbar').addClass('d-none');

            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                // Handle errors here
            }
        });
    }

    function printPage() {
        // Hide the print button before printing
        document.getElementById('printButton').style.display = 'none';
        document.getElementById('first-main').style.marginLeft = '8%';
        document.getElementById('back-btn').style.display = 'none';

        // Trigger the print action
        window.print();
    }

    // Listen for the afterprint event
    window.addEventListener('afterprint', function() {
        // Show the print button after the print dialog is closed
        document.getElementById('first-main').style.marginLeft = '31%';

        document.getElementById('printButton').style.display = 'initial';
        document.getElementById('back-btn').style.display = 'initial';

    });
    $(document).ready(function() {
        $("select").selectize();
        //         $('#form2')[0].reset();
        //        var selectize = $('select')[0].selectize;
        //  selectize.clear();

        $('#closeModelBtn').on('click', function() {
            location.reload();
        });
        $('#paymentModalclose').on('click', function() {
            location.reload();
        });



        $(window).keydown(function(event) {
            if (event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });


        $('#saveChangesBtn').on('click', function() {
            var userIdsId = $('input[name="user_ids_id"]').val();
            var days = $('input[name="days"]').val();
            var advance_amount = $('input[name="advance_amount"]').val();
            var payment_method = $('#payment_method').val();
            var customer_ids_id = $('input[name="customer_ids_id"]').val();

            // Remove any existing error messages
            $('.error-message').remove();

            // Validation: Check if advance_amount and payment_method are empty
            if (advance_amount === '') {
                $('#advance_amount').after(
                    '<span class="error-message">Please enter advance amount.</span>');
                return; // Exit function if validation fails
            }

            if (payment_method === '') {
                $('#payment_method').after(
                    '<span class="error-message">Please select payment method.</span>');
                return; // Exit function if validation fails
            }

            // Create formData object
            var formData = {
                customer_ids_id: customer_ids_id,
                advance_amount: advance_amount,
                payment_method: payment_method,
                user_ids_id: userIdsId,
                days: days
            };

            var routeUrl = $(this).data('route');
            var _token = $('meta[name="csrf-token"]').attr('content');

            // Send AJAX POST request
            $.ajax({
                url: routeUrl,
                method: "POST",
                headers: {
                    'x-csrf-token': _token
                },
                data: formData,
                success: function(response) {
                    // Handle success response
                    console.log(response);
                    $('#paymentModal').modal('hide');
                    firstpdf(response.data.customer_ids_id);
                },
                error: function(xhr, status, error) {
                    // Handle error response
                    console.error(xhr.responseText);
                }
            });
        });

        $('#seg').change(function() {
            // Get the selected value
            var selectedValue = $(this).val();
            var selectize; // Declare selectize outside the if block

            if (selectedValue == 1) {
                // Initialize Selectize.js on the country_id select element
                var $countrySelect = $('#country_id').selectize();

                // Get the Selectize.js instance
                selectize = $countrySelect[0].selectize;

                // Set the value of the select element
                selectize.setValue('95');

                // Initialize Selectize.js on the nationality_id select element
                var $nationalitySelect = $('#nationality_id').selectize();

                // Get the Selectize.js instance
                selectize = $nationalitySelect[0].selectize;

                // Set the value of the select element
                selectize.setValue('95');
            } else {
                // Unset the value from both select elements
                selectize = $('#country_id')[0].selectize;
                selectize.clear();

                selectize = $('#nationality_id')[0].selectize;
                selectize.clear();
            }
        });

        $('#country_id').change(function() {
            // Get the selected value
            var selectedValue = $(this).val();

            if (selectedValue == 95) {
                $('#other_country').addClass('d-none'); // Add the 'd-none' class
                $('#label_for_id_proof_number').text('ID Proof Number');
            } else {
                $('#other_country').removeClass('d-none'); // Remove the 'd-none' class
                $('#label_for_id_proof_number').text('PASSPORT NO');

                // If you are using Selectize.js for the id_proof select element, you can set its value like this
                var selectizeid_proof = $('#id_proof')[0].selectize;
                selectizeid_proof.setValue(7);
            }
        });



        var room_type_id = $('#room_type_id')
            .val(); // Assuming you have an input field with id 'room_type_id'

        // Adding click event handler to all buttons with class btn-block

        //               $("#sing-up").submit(function(e) {
        //     e.preventDefault();
        // });
        $('.paymentModalclose').click(function() {
            $('#paymentModal').modal('hide');
            //             $('#form2')[0].reset();
            //        var selectize = $('select')[0].selectize;
            //  selectize.clear();
        });

        $('.pdfModalcloseclose').click(function() {

            window.location.reload();
        });

        $("#form2").validate({
            errorClass: "state-error",
            validClass: "state-success",
            errorElement: "em",
            ignore: ':hidden:not([class~=selectized]),:hidden > .selectized, .selectize-control .selectize-input input',
            rules: {
                guest_type: {
                    required: true
                },
                guest_name: {
                    required: true
                },
                phone_number: {
                    required: true,
                },
                seg: {
                    required: true
                },
                total_adult: {
                    required: true,
                    min: 1,
                },
                total_child: {
                    required: true
                },
                country_id: {
                    required: true
                },
                nationality_id: {
                    required: true
                },
                pr_exp_date: {
                    required: {
                        depends: function(element) {
                            return $("#seg").val() == 2
                        }
                    }
                },
                visa_exp_date: {
                    required: {
                        depends: function(element) {
                            return $("#seg").val() == 2
                        }
                    }
                },

                address: {
                    required: true
                },
                pincode: {
                    required: {
                        depends: function(element) {
                            return $("#seg").val() == 1
                        }
                    }
                },
                price: {
                    required: true
                },
                id_proof: {
                    required: true
                },
                rate_code: {
                    required: true
                },

            },
            highlight: function(element, errorClass, validClass) {
                $(element).closest('.field').addClass(errorClass).removeClass(validClass);
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).closest('.field').removeClass(errorClass).addClass(validClass);
            },
            errorPlacement: function(error, element) {

                // console.log(element);
                if (element.is(":radio") || element.is(":checkbox")) {
                    // console.log(element);
                    element.closest('.checkbox-container').after(
                        error); // Changed from element.closest('label').parent().before(error);
                } else if (element.hasClass('selectized')) {
                    var selectizeControl = element[0].selectize;
                    var $selectizeInput = $(selectizeControl.$control);
                    var $selectizeContainer = $selectizeInput.closest('.selectize-control');

                    // Remove any existing error message
                    $selectizeContainer.prev('.select-error').remove();

                    // Add error class and insert error message before the Selectize container
                    error.addClass('select-error');
                    $selectizeContainer.after(error);

                    // Listen for the change event to remove the error message
                    selectizeControl.on('change', function() {
                        $selectizeContainer.prev('.select-error').remove();
                    });
                } else {

                    error.insertAfter(element);
                }
            },
            submitHandler: function(form) {
                console.log("Form submitted!");
                var error_msg_element = document.querySelector("#error-msg");
                // Check if there are any validation errors before proceeding
                if ($(form).valid() && error_msg_element.classList.length > 0) {
                    console.log("Form is valid, submitting...");
                    var _token = $('meta[name="csrf-token"]').attr('content');

                    var formData1 = new FormData($('#form1')[0]); // Get data from Form 1
                    var formData2 = new FormData($('#form2')[0]); // Get data from Form 2

                    // Append data from Form 2 to Form 1
                    for (var pair of formData2.entries()) {
                        formData1.append(pair[0], pair[1]);
                    }


                    // Perform AJAX form submission
                    $.ajax({
                        url: "{{ route('backend.customers.store') }}",
                        method: "POST",
                        data: formData1,
                        headers: {
                            'x-csrf-token': _token
                        },
                        processData: false,
                        contentType: false,
                        success: function(response) {
                            // Handle successful response
                            console.log("AJAX request successful:", response);
                            Swal.fire({
                                title: response.message,
                                icon: "success"
                            });


                            $('#paymentModal').on('show.bs.modal', function(e) {
                                $(this).find('#customer_id').val(response
                                    .data
                                    .id);
                            });
                            $('#paymentModal').modal('show');
                        },
                        error: function(xhr, status, error) {
                            // Handle AJAX error
                            console.error("AJAX request failed:", xhr.responseText);
                            Swal.fire({
                                title: 'Something Went Wrong',
                                icon: "success"
                            });
                        }
                    });
                } else {
                    console.log("Form is invalid, cannot submit.");
                }
                return false; // Prevent default form submission
            }
        });






        // $('#form2').on('submit', function(e) {
        //     e.preventDefault();
        //     // alert($(this).valid());
        //     if ($(this).valid()) {
        //         var _token = $('meta[name="csrf-token"]').attr('content');

        //         var formData1 = new FormData($('#form1')[0]); // Get data from Form 1
        //         var formData2 = new FormData($('#form2')[0]); // Get data from Form 2

        //         // Append data from Form 2 to Form 1
        //         for (var pair of formData2.entries()) {
        //             formData1.append(pair[0], pair[1]);
        //         }

        //         $.ajax({
        //             url: "{{ route('backend.customers.store') }}",
        //             method: "POST",
        //             data: formData1,
        //             headers: {
        //                 'x-csrf-token': _token
        //             },
        //             processData: false,
        //             contentType: false,
        //             success: function(response) {
        //                 Swal.fire({
        //                     title: response.message,
        //                     icon: "success"
        //                 });
        //                 // firstpdf(response.data.id);
        //                 $('#paymentModal').on('show.bs.modal', function(e) {
        //                     $(this).find('#customer_id').val(response.data.id);
        //                 });

        //                 // Open the modal popup automatically
        //                 $('#paymentModal').modal('show');
        //             },
        //             error: function(xhr, status, error) {
        //                 Swal.fire({
        //                     title: 'Something Went Wrong',
        //                     icon: "success"
        //                 });
        //                 console.error(xhr.responseText);
        //             }
        //         });
        //     }
        // });

        $('#room_type_id').on('change', function(e) {
            e.preventDefault();
            var room_type_id = $(this).val();

            var _token = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                url: "{{ route('backend.ajax_data') }}",
                method: "POST",
                headers: {
                    'x-csrf-token': _token
                },
                data: {
                    room_type_id: room_type_id
                },
                success: function(response) {
                    console.log(response);
                    if (response.data) {
                        $('#floor-container').empty();
                        var floorItem = response.data;
                        var roomStatuses = response.roomStatuses;

                        var blocked_count = 0;
                        var recent_count = 0;
                        var main_count = 0;
                        var single_count = 0;
                        var multiple_count = 0;

                        var roomcontent = floorItem.select_rooms.map(roomItem => {
                            var booked = Array.from(response.booked) || [];
                            var multiple_book = Array.from(response.multiple_book) || [];
                            var className = "";
                            if (roomItem.status == 1) {
                                className = "black";
                                blocked_count++;
                            } else if (typeof booked !== 'undefined' && booked
                                .includes(roomItem.id)) {
                                className = "single-color";
                                single_count++;

                            } else if (typeof multiple_book !== 'undefined' &&
                                multiple_book.includes(roomItem.id)) {
                                className = "multiple-color";
                                multiple_count++;

                            } else if (roomItem.status == 2) {
                                className = "recently-vacate-color";
                                recent_count++;
                            } else {
                                className = "btn-block main-color";
                                main_count++;
                            }
                            return `<div class="col-6 col-sm-4 col-md-3 col-lg-1 mb-3">
                <button class="${className}" data-btn-id="${roomItem.id}">${roomItem.name}</button>
            </div>`;
                        }).join('');

                        var floorHtml = `
    <div class="row mt-4">
        <div class="card">
            <div class="card-header text-center">
                <h3>${floorItem.name} - ${main_count}</h3>
            </div>
            <div class="card-body">
                <div class="row mt-4">
                    ${roomcontent}
                </div>
            </div>
        </div>
    </div>`;
                        var default_price = parseFloat(floorItem.price).toFixed(2);
                        $('#price').val(default_price);
                        $('#old_price').val(default_price);

                        $('input[name="extra_price"]').val(floorItem.extra_price);
                        $('input[name="max_person"]').val(floorItem.max_person);

                        $('#available_room').text(main_count);
                        $('#black_room').text(blocked_count);
                        $('#recent_room').text(recent_count);
                        $('#normal_room').text(single_count + multiple_count);
                        $('#total_room').text(main_count + blocked_count + recent_count +
                            single_count + multiple_count);


                        $('#floor-container').append(floorHtml);

                    } else {
                        console.log('No data received');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });

        $(document).on('click', '#floor-container .btn-block', function() {

            $('#check-in-div').removeClass('d-none');
            phone_number();
            // Toggle active-btn class on the clicked button
            $(this).toggleClass('active-btn');

            // Initialize an array to store selected values
            var selectedValues = [];

            // Remove existing input fields
            $('#room_type_container').empty();

            // Loop through all buttons with class btn-block
            $('.btn-block').each(function() {
                // If the button has active-btn class, add its value to selectedValues array
                if ($(this).hasClass('active-btn')) {
                    selectedValues.push($(this).data('btn-id'));
                    // Create a new input field for each selected value
                    var inputField = $(
                        '<input type="hidden" name="select_rooms[]" class="selected-room" required>'
                    );
                    // Set the value of the input field
                    inputField.val($(this).data('btn-id'));
                    // Append the input field to the container
                    $('#room_type_container').append(inputField);
                }
            });
            var selectedButtonCount = $('.btn-block.active-btn').length;

            // Get the values of check-in and check-out inputs
            // var checkinValue = $('input[name="check_in"]').val();
            // var checkoutValue = $('input[name="check_out"]').val();
            // console.log(checkinValue);
            // // Parse the dates using the Date object
            // var checkinDate = new Date(checkinValue);
            // var checkoutDate = new Date(checkoutValue);

            // // Calculate the difference in milliseconds between the two dates
            // var differenceInMilliseconds = checkoutDate.getTime() - checkinDate.getTime();

            // // Convert milliseconds to days
            // var differenceInDays = Math.round(differenceInMilliseconds / (1000 * 60 * 60 * 24));

            // Get the values of check-in and check-out inputs
            var checkinValue = $('input[name="check_in"]').val();
            var checkoutValue = $('input[name="check_out"]').val();

            // Parse the dates using Moment.js
            var checkinDate = moment(checkinValue, 'DD-MM-YYYY HH:mm');
            var checkoutDate = moment(checkoutValue, 'DD-MM-YYYY HH:mm');

            // Calculate the difference in days
            var differenceInDays = checkoutDate.diff(checkinDate, 'days');
            var TotalDays = '';

            if (isNaN(differenceInDays) || differenceInDays === 0) {
                TotalDays = 1;
            } else {
                TotalDays = differenceInDays;
            }

            // alert(TotalDays);

            $('input[name="days"]').val(TotalDays);
            // alert(selectedButtonCount);
            // Get the default values
            // Get the default values
            var default_price = parseFloat($('#price').val());
            var default_old_price = parseFloat($('#old_price').val());

            // Calculate the new price
            var new_price = (default_old_price * selectedButtonCount * TotalDays).toFixed(2);

            // Update the value of the input field with the new price
            $('#price').val(new_price);


            // $('#old_price').val(default_old_price * selectedButtonCount * TotalDays);
            // Get the selected value
            $('#no_of_room').val(selectedButtonCount);
            price();

        });


        function price() {
            var discountPercentages = parseFloat($('#discount_percentage').val());
            //         var checkinValue = $('input[name="check_in"]').val();
            // var checkoutValue = $('input[name="check_out"]').val();

            // // Parse the dates using the Date object
            // var checkinDate = new Date(checkinValue);
            // var checkoutDate = new Date(checkoutValue);

            // // Calculate the difference in milliseconds between the two dates
            // var differenceInMilliseconds = checkoutDate.getTime() - checkinDate.getTime();

            // // Convert milliseconds to days
            // var differenceInDays = Math.round(differenceInMilliseconds / (1000 * 60 * 60 * 24));
            // var TotalDays = '';
            // if (isNaN(differenceInDays) || differenceInDays === 0) {
            //     TotalDays = 1;
            // } else {
            //     TotalDays = differenceInDays;
            // }

            // Get the values of check-in and check-out inputs
            var checkinValue = $('input[name="check_in"]').val();
            var checkoutValue = $('input[name="check_out"]').val();

            // Parse the dates using Moment.js
            var checkinDate = moment(checkinValue, 'DD-MM-YYYY HH:mm');
            var checkoutDate = moment(checkoutValue, 'DD-MM-YYYY HH:mm');

            // Calculate the difference in days
            var differenceInDays = checkoutDate.diff(checkinDate, 'days');
            var TotalDays = '';

            if (isNaN(differenceInDays) || differenceInDays === 0) {
                TotalDays = 1;
            } else {
                TotalDays = differenceInDays;
            }
            $('input[name="days"]').val(TotalDays);
            var rate_code = $('#rate_code').val();
            var inputValue = $('#total_adult').val();
            var selectedButtonCount = $('.btn-block.active-btn').length;
            var TotalDays = $('input[name="days"]').val(); // Parse to float if it's a numeric value
            var default_old_price = parseFloat($('#old_price').val());
            var price = parseFloat(default_old_price * selectedButtonCount * TotalDays);
            var old_price = parseFloat(default_old_price * selectedButtonCount * TotalDays);
            var discount = $('#discount').val();
            var rate_code = $('#rate_code').val();
            var discountValue = $('#discount').val(); // Assuming this is what you intended to use
            // alert(inputValue);
            var selectedButtonCount = $('.btn-block.active-btn').length;
            console.log('selectedButtonCount' + selectedButtonCount);
            var max_person = parseInt($('input[name="max_person"]').val()) *
                selectedButtonCount; // Convert to integer

            console.log("max_person" + max_person);
            var extra_price = parseFloat($('input[name="extra_price"]').val()); // Convert to float
            if (rate_code == 2) {
                var selectizeDiscount = $('#discount')[0].selectize;
                selectizeDiscount.setValue(2);
                $('#price').val(0);
            } else {

                if (!isNaN(inputValue) && !isNaN(price) && !isNaN(max_person) && !isNaN(extra_price) &&
                    inputValue > 0) {
                    // Check if inputValue exceeds max_person
                    if (parseInt(inputValue) > max_person) {
                        // Calculate extra cost for each person exceeding max_person
                        var extraPersons = parseInt(inputValue) - max_person;
                        var extraCost = extraPersons * extra_price * TotalDays;
                        $('#extra_price_val').val(parseFloat(extraCost).toFixed(2));
                        $('#extraPersons').val(extraPersons);
                        // Update the total price
                        // price += extraCost;
                        // var discountValue = parseFloat($('#discount').val()) || 0;
                        // if (discountValue > 100) discountValue = 100;
                        // if (discountValue < 0) discountValue = 0;
                        // if (discountValue > 0) {
                        //     var discountAmount = (price * discountValue) / 100;
                        //     price -= discountAmount;
                        // }
                        if (!isNaN(discountPercentages) && discountValue == 1) {
                            var discountPercentage = parseFloat($('#discount_percentage').val());
                            var discountAmount = (price * discountPercentage) / 100;
                            price -= discountAmount;
                            $('#discount_ids_id').val($('#discount_percentage_ids').val());
                        } 
                        else {
                            $('#discount_ids_id').val('');
                        }

                        // Set the updated price value to the #price input field
                        $('#price').val(parseFloat(price).toFixed(2));
                    } else {
                        // alert(discountValue);
                        // var discountValue = parseFloat($('#discount').val()) || 0;
                        $('#extra_price_val').val(parseFloat(0).toFixed(2));
                        $('#extra_price_val').val(0);
                        // if (discountValue > 0) {
                        //     var discountAmount = (price * discountValue) / 100;
                        //     price -= discountAmount;
                        // }
                        if (!isNaN(discountPercentages) && discountValue == 1) {

                            var discountPercentage = parseFloat($('#discount_percentage').val());
                            var discountAmount = (price * discountPercentage) / 100;
                            price -= discountAmount;
                            $('#discount_ids_id').val($('#discount_percentage_ids').val());
                        } 
                        else {
                            $('#discount_ids_id').val('');
                        }
                        $('#price').val(parseFloat(price).toFixed(2));

                    }

                } else {
                    // var discountValue = parseFloat($('#discount').val()) || 0;
                    
                    // if (discountValue > 0) {
                    //     var discountAmount = (price * discountValue) / 100;
                    //     price -= discountAmount;
                    // }

                    if (!isNaN(discountPercentages) && discountValue == 1) {

                        var discountPercentage = parseFloat($('#discount_percentage').val());
                        var discountAmount = (price * discountPercentage) / 100;
                        price -= discountAmount;
                        $('#discount_ids_id').val($('#discount_percentage_ids').val());
                    } else {
                        $('#discount_ids_id').val('');
                    }
                    $('#price').val(parseFloat(price).toFixed(2));
                }
            }
        }

        $('#phone_number').on('keyup change blur', function() {

            var _token = $('meta[name="csrf-token"]').attr('content');

            var phone_numbers = $(this).val();
            if (phone_numbers.length != 10)
                return;
            // console.log("phone_numbers" + phone_numbers);
            $.ajax({
                url: "{{ route('backend.phone_number') }}",
                method: "POST",
                headers: {
                    'x-csrf-token': _token
                },
                type: 'POST',
                data: {
                    phone_number: phone_numbers
                },
                dataType: 'json',
                success: function(response) {
                    if (response.data) {

                        //  alert(response.data.price);
                        // Populate the form fields with received data
                        var selectizeguest_type = $('#guest_type')[0].selectize;

                        // Set the selected option for the 'guest_type' Selectize instance
                        selectizeguest_type.setValue(response.data.guest_type);
                        $('#guest_name').val(response.data.guest_name);
                        $('#email').val(response.data.email);
                        $('#phone_number').val('+' + response.data.country_code + ' ' +
                            response.data
                            .phone_number);
                        $('#country_code').val(response.data.country_code);

                        $('#guest_gstin').val(response.data.guest_gstin);
                        // $('#seg').val(response.data.seg);
                        var selectizeseg = $('#seg')[0].selectize;

                        // Set the selected option for the 'guest_type' Selectize instance
                        selectizeseg.setValue(response.data.seg);
                        // $('#total_adult').val(response.data.total_adult);
                        // $('#total_child').val(response.data.total_child);
                        $('#country_id').val(response.data.country_id);
                        $('#nationality_id').val(response.data.nationality_id);
                        var selectizecountry_id = $('#country_id')[0].selectize;

                        // Set the selected option for the 'guest_type' Selectize instance
                        selectizecountry_id.setValue(response.data.country_id);

                        var selectizenationality_id = $('#nationality_id')[0].selectize;

                        // Set the selected option for the 'guest_type' Selectize instance
                        selectizenationality_id.setValue(response.data.nationality_id);
                        $('#address').val(response.data.address);
                        $('#pincode').val(response.data.pincode);
                        // $('#price').val(response.data.price);
                        // $('#old_price').val(response.data.price);

                        // $('#id_proof').val(response.data.id_proof);
                        var selectizeid_proof = $('#id_proof')[0].selectize;

                        // Set the selected option for the 'guest_type' Selectize instance
                        selectizeid_proof.setValue(response.data.id_proof);
                        $('#id_proof_number').val(response.data.id_proof_number);

                        // $('#id_proof').val(response.data.id_proof);
                        var selectizeid_rate_code = $('#rate_code')[0].selectize;

                        // Set the selected option for the 'guest_type' Selectize instance
                        selectizeid_rate_code.setValue(response.data.rate_code);
                        phone_number();

                        price();
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    // Handle errors here
                }
            });
        });




        // price();

        $('#total_adult').on('keyup change blur', function(e) {
            e.preventDefault();
            price();
        });


        $('#discount').on('change', function(e) {
            e.preventDefault();
            price();
        });
        
        // $('#discount').on('keyup change', function() {
        //     let value = parseFloat($(this).val());
        
        //     if (isNaN(value)) {
        //         $(this).val('');
        //         return;
        //     }
        
        //     if (value > 100) {
        //         $(this).val(100);
        //     }
        
        //     if (value < 0) {
        //         $(this).val(0);
        //     }
        
        //     price();
        // });
        $('#rate_code').on('change', function(e) {
            e.preventDefault();
            price();
        });



        $('#datetimepickercheckin').datetimepicker({
            useCurrent: false,
            defaultDate: moment().toDate(), // Set default date to current date
            minDate: moment().toDate() - 1, // Disable previous dates starting from today
            showTodayButton: true,
            showClear: true,
            toolbarPlacement: 'bottom',
            sideBySide: true,
            format: 'DD-MM-YYYY HH:mm', // Set your desired format here
            icons: {
                time: "fa fa-clock",
                date: "fa fa-calendar",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down",
                previous: "fa fa-chevron-left",
                next: "fa fa-chevron-right",
                today: "fa fa-clock",
                clear: "fa fa-trash-alt",
                close: "fa fa-times"
            } // Set default date to current date
        });

        // For checkout date picker
        $('#datetimepickercheckout').datetimepicker({
            useCurrent: false,
            defaultDate: moment().add(1, 'days').toDate(), // Set default date to current date
            minDate: moment().toDate(), // Disable previous dates starting from today
            showTodayButton: true,
            showClear: true,
            toolbarPlacement: 'bottom',
            sideBySide: true,
            format: 'DD-MM-YYYY HH:mm', // Set your desired format here
            icons: {
                time: "fa fa-clock",
                date: "fa fa-calendar",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down",
                previous: "fa fa-chevron-left",
                next: "fa fa-chevron-right",
                today: "fa fa-clock",
                clear: "fa fa-trash-alt",
                close: "fa fa-times"
            } // Set default date to current date

        });


        $('#datetimepickerpr_exp_date').datetimepicker({
            useCurrent: false,
            //    minDate: moment(), // Disable previous dates starting from today
            showTodayButton: true,
            showClear: true,
            toolbarPlacement: 'bottom',
            sideBySide: true,
            format: 'DD-MM-YYYY', // Set your desired format here
            icons: {
                time: "fa fa-clock",
                date: "fa fa-calendar",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down",
                previous: "fa fa-chevron-left",
                next: "fa fa-chevron-right",
                today: "fa fa-clock",
                clear: "fa fa-trash-alt",
                close: "fa fa-times"
            },
            //    defaultDate: moment() // Set default date to current date
        });

        // For checkout date picker
        $('#datetimepickervisa_exp_date').datetimepicker({
            useCurrent: false,
            // minDate: moment(), // Disable previous dates starting from today
            showTodayButton: true,
            showClear: true,
            toolbarPlacement: 'bottom',
            sideBySide: true,
            format: 'DD-MM-YYYY', // Set your desired format here
            icons: {
                time: "fa fa-clock",
                date: "fa fa-calendar",
                up: "fa fa-arrow-up",
                down: "fa fa-arrow-down",
                previous: "fa fa-chevron-left",
                next: "fa fa-chevron-right",
                today: "fa fa-clock",
                clear: "fa fa-trash-alt",
                close: "fa fa-times"
            },
            //   defaultDate: moment() // Set default date to current date

        });

        $("#datetimepickercheckout").on("change.datetimepicker", function({
            date,
            oldDate
        }) {

            price();
        });

    });
</script>

@endsection
