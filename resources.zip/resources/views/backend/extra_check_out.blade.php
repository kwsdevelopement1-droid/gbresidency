@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link href="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css" integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('assets/intl-tel-input-18.2.1/build/css/intlTelInput.css') }}">
    <style type="text/css" media="print">
        @page {
            size: auto;
            margin: 0;
        }
    </style>
    <style>
        .printButton {
            cursor: pointer;
            background: #bc1b1b;
            color: #fff;
            width: 100px;
            border: none;
            border-radius: 2px;
            height: 28px;
            font-size: 20px;
        }

        .iti {
            width: 100%;
        }

        .hide {
            display: none;
        }

        .default-form .selectize-control {
            position: relative;
            width: 250px;
            border-radius: 4px 4px 0px 0px;
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 16px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
        }

        .default-form .selectize-input {
            height: 58px;
        }

        .green-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #009834;
        }

        .color-rooms h3 {
            color: #000;
            font-family: Montserrat;
            font-size: 19px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            white-space: nowrap;
            position: relative;
            left: 39px;
        }

        .color-rooms h4 {
            color: #FFF;
            font-family: Montserrat;
            font-size: 30px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            text-align: center;
            position: relative;
            bottom: 3px;
        }

        .colors {
            max-width: 25%;
        }

        .orange-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FF823C;
        }

        .yellow-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FBB836;
        }

        .blue-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #0C89D0;
        }

        .black-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #000;
        }

        .default-form .input-group-text {
            height: 56px;
        }

        .default-form .fa.fa-calendar {
            font-size: 29px;
        }

        .default-form #no_of_room {
            width: 250px;
            height: 60px;
        }

        .default-form .selectize-input>* {
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 17.039px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
            text-transform: uppercase;
            margin: 12px;
        }

        #bill_no {
            width: 250px !important;
            height: 60px !important;
        }

        #room_no {
            width: 250px !important;
            height: 60px !important;
        }

        .default-form .btn-search {
            border-radius: 4.26px;
            background: #8DD3BB;
            border: none;
            width: 55px;
            height: 55px;
            margin-left: 15px;
        }

        .check-in-form-title {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 33.072px;
            font-style: normal;
            font-weight: 700;
            line-height: 150%;
        }

        .check_in .form-control {
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;
        }

        .check_in label {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 500;
            line-height: 40px;
        }

        .check_in .selectize-control.single .selectize-input {
            border-color: #b8b8b8;
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;
        }

        .active-btn {
            color: #000;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            border-radius: 15px;
            border: 5px solid #009834;
            background: none;
        }

        .btn-save {
            border-radius: 10px;
            background: #8DD3BB;
            width: 672.804px;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            padding: 23.869px 0px 24.213px 0px;
            border: none;
        }

        table {
            width: 100%;
        }

        tr {
            height: 42px;
            border-radius: 21.116px;
            background: #FFF;
            box-shadow: 0px 2.815px 26.747px 0px rgba(141, 211, 187, 0.33);
        }

        th,
        tr {
            color: #000;
            leading-trim: both;
            text-edge: cap;
            font-family: Raleway;
            font-size: 20px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
            letter-spacing: 0.3px;
        }

        td {
            width: 40%;
        }

        .btn-checkout {
            border-radius: 10px;
            background: #901111;
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-cancel {
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            border: 5px solid #8DD3BB;
            color: #8DD3BB;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-extend {
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            background: #8DD3BB;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .black {
            border-radius: 15px;
            background: #000;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .single-color {
            border-radius: 15px;
            background: #FF823C;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .multiple-color {
            border-radius: 15px;
            background: #FBB836;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .recently-vacate-color {
            border-radius: 15px;
            background: #0C89D0;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .main-color {
            border-radius: 15px;
            background: #009834;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .input-group-text {
            height: 64px;
        }

        .fa.fa-calendar {
            font-size: 30px;
        }
    </style>
@endsection
@section('title_nav')
    <div class="row title-card">
        <h2 class="d-flex align-items-center justify-content-center">Extra Bed Check Out</h2>
    </div>
@endsection

<div class="container mt-4">
    <div class="row">
        <form class="default-form d-flex justify-content-between mt-4" id="form1">
            @csrf
            <input type="hidden" name="user_ids_id" value="{{ Auth::id() }}">
            <input type="hidden" name="customer_ids_id">
            <input type="hidden" name="amount">
            <input type="hidden" name="total_amount">
            <input type="hidden" name="advance_amount">
            <input type="hidden" name="cgst">
            <input type="hidden" name="sgst">
            <input type="hidden" name="igst">
            <input type="hidden" name="balance_amount">
            <input type="hidden" name="numDays">
            <input type="hidden" name="tariff">
            <input type="hidden" name="extra_person_cost">
            <input type="hidden" name="tariff">
            <input type="hidden" name="extra_person_cost">
            <input type="hidden" name="daysAmount">
            <input type="hidden" name="gst" value="{{ $gst->gst_percentage ?? 0 }}">

            <div class="form-row" style="margin: 0 auto;">
                <div class="form-group col-md-12">
                    <span class="has-float-label">
                        <input class="form-control {{ $errors->has('bill_no') ? 'is-invalid' : '' }}" type="text"
                               name="bill_no" id="bill_no" placeholder="Advance Bill No" required autocomplete="off">
                        <label for="bill_no">Bill No</label>
                    </span>
                </div>
            </div>
            <div class="form-row" style="margin: 0 auto;">
                <div class="form-group col-md-12">
                    <span class="has-float-label">
                        <input class="form-control {{ $errors->has('room_no') ? 'is-invalid' : '' }}" type="text"
                               name="room_no" id="room_no" placeholder="Room No" required autocomplete="off">
                        <label for="room_no">Room Number</label>
                    </span>
                </div>
            </div>
            <div class="form-row" style="margin: 0 auto;">
                <div class="form-group col-md-12">
                    <span class="has-float-label">
                        <select name="room_type_id" id="room_type_id" placeholder="Select Room Type" required>
                            <option value="" selected>Select Room Type</option>
                            @foreach ($floors as $id => $floor)
                                <option value="{{ $id }}">{{ $floor }}</option>
                            @endforeach
                        </select>
                        <label for="room_type_id">Rooms Type</label>
                    </span>
                </div>
            </div>
        </form>
        <div id="floor-container">            <input type="hidden" name="sgst">

            <!-- Floors will be appended here -->
        </div>
        <div class="d-none" id="check-in-div">
            <div class="row mt-4">
                <div class="check-in-form-title">
                    <h3>Guest Details</h3>
                </div>
                <form class="check_in" id="form2">
                    @csrf
                    <div>
                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <div class="form-group">
                                    <label class="required" for="guest_name">Guest Name</label>
                                    <input class="form-control {{ $errors->has('guest_name') ? 'is-invalid' : '' }}"
                                           type="text" name="guest_name" id="guest_name"
                                           value="{{ old('guest_name', '') }}" required>
                                    @if ($errors->has('guest_name'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('guest_name') }}
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <label class="required" for="check_in">Check In</label>
                                <div class="form-group">
                                    <div class="input-group date" id="datetimepickercheckin" data-target-input="nearest">
                                        <input type="text" name="check_in" class="form-control datetimepicker-input"
                                               data-target="#datetimepickercheckin" />
                                        <div class="input-group-append" data-target="#datetimepickercheckin"
                                             data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="required" for="check_out">Check Out</label>
                                <div class="form-group">
                                    <div class="input-group date" id="datetimepickercheckout" data-target-input="nearest">
                                        <input type="text" name="check_out" class="form-control datetimepicker-input"
                                               data-target="#datetimepickercheckout" />
                                        <div class="input-group-append" data-target="#datetimepickercheckout"
                                             data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mx-auto">
                                <div class="form-group">
                                    <label class="required" for="remining_time">Remaining Time</label>
                                    <input class="form-control" name="remining_time" id="remining_time">
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-6 d-flex align-items-center justify-content-center" id="table_data">
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="required" for="phone_number">Phone Number</label>
                                    <input type="hidden" value="91" name="country_code">
                                    <input class="form-control {{ $errors->has('phone_number') ? 'is-invalid' : '' }}"
                                           type="text" name="phone_number" id="phone_number"
                                           value="{{ old('phone_number', '') }}" required>
                                    <span id="valid-msg" class="hide">✓ Valid</span>
                                    <span id="error-msg" class="hide"></span>
                                    @if ($errors->has('phone_number'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('phone_number') }}
                                        </div>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label>Payment Method</label>
                                    <select class="{{ $errors->has('payment_method') ? 'is-invalid' : '' }}"
                                            name="payment_method" id="payment_method">
                                        @foreach (App\Models\Customer::PAYMENT_METHOD_SELECT as $key => $label)
                                            <option value="{{ $key }}"
                                                    {{ 1 === (string) $key ? 'selected' : '' }}>
                                                {{ $label }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @if ($errors->has('payment_method'))
                                        <div class="invalid-feedback">
                                            {{ $errors->first('payment_method') }}
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4" id="table_extra">
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="required" for="remarks">Remarks</label>
                                    <textarea class="form-control" name="remarks"></textarea>
                                </div>
                            </div>
                            <div id="room_type_container"></div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection
@section('scripts')
    @parent
    <script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js" integrity="sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="{{ asset('assets/intl-tel-input-18.2.1/build/js/intlTelInput.min.js') }}"></script>
    <script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>
    <script>
        var ldays = 1;
        var totalRent = 0.00;

        function callExtraCheckOut(id, days, cost) {
            console.log('callExtraCheckOut called with:', { id, days, cost });
            if (!id || isNaN(days) || days < 0 || isNaN(cost) || cost < 0) {
                console.error('Validation failed:', { id, days, cost });
                Swal.fire({
                    title: 'Invalid Input',
                    text: 'Please provide valid ID, days, and cost values.',
                    icon: 'error'
                });
                return;
            }
        
            var data = { id, days, cost };
            var _token = $('meta[name="csrf-token"]').attr('content');
        
            $.ajax({
                url: "{{ route('backend.extraCheckOut') }}",
                method: "POST",
                data: JSON.stringify(data),
                headers: {
                    'X-CSRF-TOKEN': _token
                },
                processData: false,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function(response) {
                    console.log('AJAX Success:', response);
                    Swal.fire({
                        title: response.message || 'Checkout successful',
                        icon: "success"
                    });
                
                    $('#table_extra').empty();
                    var extraBedData = response.data;
                    if (extraBedData && extraBedData.length > 0) {
                        var extraTable = '<table class="w-100 mt-6"><tbody><tr><th>Check In</th><th>Check Out</th><th>Days</th><th>Price</th><th>Action</th></tr>';
                        var lint = 0;
                        var tempCost = 0;
                        extraBedData.forEach(element => {
                            extraTable += '<tr>';
                            if (element.checkin_status == 0) {
                                var extraDays = getCalculatedTotalDays(element.checkin_date);
                                if (isNaN(extraDays) || extraDays < 0) extraDays = 0;
                                lint += extraDays;
                                var price = parseFloat(element.price) || 0;
                                var extraCost = extraDays * price;
                                tempCost += extraCost;
                
                                var parsedCheckIn = moment(element.checkin_date, 'YYYY-MM-DD HH:mm:ss', true);
                                var formattedCheckIn = parsedCheckIn.isValid() ? parsedCheckIn.format('DD-MM-YYYY HH:mm') : 'Invalid Date';
                
                                extraTable += `
                                    <td>${formattedCheckIn}</td>
                                    <td>Not checked out yet</td>
                                    <td>${extraDays}</td>
                                    <td>${extraCost.toFixed(2)}</td>
                                    <td>
                                        <button class="btn btn-primary btn-sm" 
                                                data-extra-id="${element.id}" 
                                                data-extra-days="${extraDays || 0}" 
                                                data-extra-cost="${extraCost || 0}">Checkout</button>
                                        @if(auth()->user()->roles->contains('title', 'Admin'))
                                        <button type="button" class="btn btn-danger btn-sm delete-extra-bed" data-extra-id="${element.id}"><i class="fas fa-trash"></i> Delete</button>
                                        @endif
                                    </td>`;
                            } else {
                                tempCost += parseFloat(element.totalcost) || 0;
                                lint += element.totaldays;
                
                                var parsedCheckIn = moment(element.checkin_date, 'YYYY-MM-DD HH:mm:ss', true);
                                var formattedCheckIn = parsedCheckIn.isValid() ? parsedCheckIn.format('DD-MM-YYYY HH:mm') : 'Invalid Date';
                
                                extraTable += `
                                    <td>${formattedCheckIn}</td>
                                    <td>Checked out</td>
                                    <td>${element.totaldays}</td>
                                    <td>${parseFloat(element.totalcost).toFixed(2)}</td>
                                    <td>
                                        @if(auth()->user()->roles->contains('title', 'Admin'))
                                        <button type="button" class="btn btn-danger btn-sm delete-extra-bed" data-extra-id="${element.id}"><i class="fas fa-trash"></i> Delete</button>
                                        @endif
                                    </td>`;
                            }
                            extraTable += '</tr>';
                        });
                        extraTable += `<tr><td>Total</td><td></td><td>${lint}</td><td>${tempCost.toFixed(2)}</td><td></td></tr></tbody></table>`;
                        $('#table_extra').append(extraTable);
                
                        // Re-bind checkout buttons
                        $('#table_extra').find('.btn-primary.btn-sm[data-extra-id]').off('click').on('click', function(e) {
                            e.preventDefault();
                            var $button = $(this);
                            var id = $button.data('extra-id');
                            var extraDays = parseFloat($button.data('extra-days')) || 0;
                            var extraCost = parseFloat($button.data('extra-cost')) || 0;
                            
                            if (!id || extraDays < 0 || extraCost < 0) {
                                Swal.fire({
                                    title: 'Invalid Data',
                                    text: 'Invalid ID, days, or cost from button.',
                                    icon: 'error'
                                });
                                return;
                            }
                            
                            $button.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Checking out...');
                            callExtraCheckOut(id, extraDays, extraCost);
                        });
                
                        // Re-bind delete buttons
                        $('#table_extra').find('.delete-extra-bed').off('click').on('click', function() {
                            var extraId = $(this).data('extra-id');
                            $('#deleteExtraBedModal').data('extra-id', extraId);
                            $('#deleteReason').val('');
                            $('#reasonError').hide();
                            $('#deleteReason').removeClass('is-invalid');
                            $('#deleteExtraBedModal').modal('show');
                        });
                    } else {
                        $('#table_extra').append('<p>No extra bed data available.</p>');
                    }
                    // ... rest of your success handler ...
                },
                    
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', { xhr, status, error });
                    let errorMessage = 'Something went wrong';
                    if (xhr.responseJSON) {
                        if (xhr.status === 422) {
                            errorMessage = xhr.responseJSON.message || Object.values(xhr.responseJSON.errors).flat().join(', ');
                        } else if (xhr.responseJSON.message) {
                            errorMessage = xhr.responseJSON.message;
                        }
                    } else if (xhr.status === 403) {
                        errorMessage = 'CSRF token mismatch or permission denied';
                    } else if (xhr.status === 500) {
                        errorMessage = 'Server error, please check logs';
                    }
                    Swal.fire({
                        title: 'Error during checkout',
                        text: errorMessage,
                        icon: "error"
                    });
                },
                complete: function() {
                    $('.btn-primary.btn-sm[data-extra-id]').prop('disabled', false).html('Checkout');
                }
            });
        }
        
       $(document).on('click', '.btn-primary.btn-sm[data-extra-id]', function(e) {
            e.preventDefault();
            var $button = $(this);
            var id = $button.data('extra-id');
            var extraDays = parseFloat($button.data('extra-days')) || 0;
            var extraCost = parseFloat($button.data('extra-cost')) || 0;
        
            console.log('Button clicked:', { id, extraDays, extraCost }); // Debug log
            if (!id || extraDays < 0 || extraCost < 0) {
                Swal.fire({
                    title: 'Invalid Data',
                    text: 'Invalid ID, days, or cost from button. Check console for details.',
                    icon: 'error'
                });
                return;
            }
        
            $button.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Checking out...');
            callExtraCheckOut(id, extraDays, extraCost);
        });

        function getCalculatedTotalDays(checkInTime) {
            var parsedCheckIn = moment(checkInTime, 'YYYY-MM-DD HH:mm:ss', true);
            if (!parsedCheckIn.isValid()) {
                console.warn('Invalid check-in date:', checkInTime);
                return 0;
            }
            var lCheckIn = parsedCheckIn.toDate();
            var lCheckout = new Date(); // 05:34 PM IST, October 14, 2025
            var differenceInHours = Math.ceil((lCheckout - lCheckIn) / (1000 * 60 * 60));
            var tdays = Math.ceil(differenceInHours / 24);
            console.log('Calculated days for', checkInTime, ':', tdays);
            return tdays >= 0 ? tdays : 0;
        }

        function printPage() {
            document.getElementById('printButton').style.display = 'none';
            document.getElementById('back-btn').style.display = 'none';
            window.print();
        }

        window.addEventListener('afterprint', function() {
            document.getElementById('printButton').style.display = 'block';
            document.getElementById('back-btn').style.display = 'initial';
        });

        function phone_number() {
            var input_phone = document.querySelector("#phone_number"),
                errorMsg = document.querySelector("#error-msg"),
                validMsg = document.querySelector("#valid-msg");

            var errorMap = ["Invalid number", "Invalid country code", "Too short", "Too long", "Invalid number"];

            var iti = intlTelInput(input_phone, {
                allowDropdown: true,
                formatOnDisplay: true,
                phoneValidation: true,
                separateDialCode: true,
                enablePlaceholder: true,
                autoPlaceholder: "polite",
                placeholderNumberType: "MOBILE",
                searchCountryPlaceholder: 'Search Country',
                preferredCountries: ["in"],
                hiddenInput: "dialCodes",
                utilsScript: "{{ url('assets/intl-tel-input-18.2.1/build/js/utils.js') }}"
            });

            iti.promise.then(function() {
                var inputValue = input_phone.value.replace(/\s+/g, '');
                inputValue = inputValue.replace(/^0+/, '');
                input_phone.value = inputValue;
            });

            $("input[name='country_code']").val(91);

            var reset_input_phone = function() {
                input_phone.classList.remove("error");
                errorMsg.innerHTML = "";
                errorMsg.classList.add("hide");
                validMsg.classList.add("hide");
            };

            input_phone.addEventListener("countrychange", function() {
                var data_iti = iti.getSelectedCountryData();
                $("input[name='country_code']").val(data_iti.dialCode);
            });

            input_phone.addEventListener('blur', function() {
                reset_input_phone();
                if (input_phone.value.trim()) {
                    if (iti.isValidNumber()) {
                        validMsg.classList.remove("hide");
                    } else {
                        input_phone.classList.add("error");
                        var errorCode = iti.getValidationError();
                        errorMsg.innerHTML = errorMap[errorCode];
                        errorMsg.classList.remove("hide");
                    }
                }
            });

            input_phone.addEventListener('change', reset_input_phone);
            input_phone.addEventListener('keyup', reset_input_phone);
        }

        $(document).ready(function() {
            $("select").selectize();
            $('#form2')[0].reset();
            var selectize = $('#room_type_id')[0].selectize;
            selectize.clear();

            $('#seg').change(function() {
                var selectedValue = $(this).val();
                var selectize;

                if (selectedValue == 1) {
                    var $countrySelect = $('#country_id').selectize();
                    selectize = $countrySelect[0].selectize;
                    selectize.setValue('95');

                    var $nationalitySelect = $('#nationality_id').selectize();
                    selectize = $nationalitySelect[0].selectize;
                    selectize.setValue('95');
                } else {
                    selectize = $('#country_id')[0].selectize;
                    selectize.clear();
                    selectize = $('#nationality_id')[0].selectize;
                    selectize.clear();
                }
            });

            var room_type_id = $('#room_type_id').val();
            var currentUrl = window.location.href;
            var urlParams = new URLSearchParams(currentUrl.split('?')[1]);
            var room = urlParams.get('room');
            var type = urlParams.get('type');

            if (room && type) {
                var selectizeroom_type_id = $('#room_type_id')[0].selectize;
                selectizeroom_type_id.setValue(type);
                setTimeout(function() {
                    $('#ajax-btn').trigger('click');
                }, 1000);
            }

            function ajax_data_box(response) {
                $('#floor-container').empty();
                var floorItem = response.data;
                var roomStatuses = response.roomStatuses;

                var blocked_count = 0;
                var recent_count = 0;
                var main_count = 0;
                var single_count = 0;
                var multiple_count = 0;

                var roomcontent = floorItem.select_rooms.map(roomItem => {
                    var booked = Array.from(response.booked) || [];
                    var multiple_book = response.multiple_book || [];
                    var className = "";
                    if (roomItem.status == 1) {
                        className = "black";
                        blocked_count++;
                    } else if (typeof booked !== 'undefined' && booked.includes(roomItem.id)) {
                        className = "btn-block single-color";
                        single_count++;
                    } else if (typeof multiple_book !== 'undefined' && multiple_book.includes(roomItem.id)) {
                        className = "btn-block multiple-color";
                        multiple_count++;
                    } else if (roomItem.status == 2) {
                        className = "recently-vacate-color";
                        recent_count++;
                    } else {
                        className = "main-color";
                        main_count++;
                    }
                    return `<div class="col-6 col-sm-4 col-md-3 col-lg-1 mb-3">
                        <button class="${className}" data-btn-id="${roomItem.id}">${roomItem.name}</button>
                    </div>`;
                }).join('');

                var floorHtml = `
                    <div class="row mt-4">
                        <div class="card">
                            <div class="card-header text-center">
                                <h3>${floorItem.name} - ${main_count}</h3>
                            </div>
                            <div class="card-body">
                                <div class="row mt-4">
                                    ${roomcontent}
                                </div>
                            </div>
                        </div>
                    </div>`;

                $('#floor-container').append(floorHtml);

                if (response.customers_data && response.customers_data.select_rooms) {
                    var roomIds = response.customers_data.select_rooms.map(room => room.id);
                    $('#floor-container .btn-block').each(function() {
                        if (roomIds.includes($(this).data('btn-id'))) {
                            $(this).trigger('click');
                        }
                    });
                }

                if (room && type) {
                    $('#floor-container .btn-block').each(function() {
                        if ($(this).data('btn-id') == room) {
                            $(this).trigger('click');
                        }
                    });
                }
            }

            $('#room_type_id').on('change', function(e) {
                e.preventDefault();
                var room_type_id = $(this).val();
                var _token = $('meta[name="csrf-token"]').attr('content');

                $.ajax({
                    url: "{{ route('backend.ajax_data') }}",
                    method: "POST",
                    headers: {
                        'x-csrf-token': _token
                    },
                    data: {
                        room_type_id: room_type_id
                    },
                    success: function(response) {
                        if (response.data) {
                            ajax_data_box(response);
                        } else {
                            console.log('No data received');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

            $('#room_no').on('keyup change blur', function(e) {
                if (e.which != 13) {
                    return;
                }
                e.preventDefault();
                var room_no = $(this).val();
                if (room_no.length < 2) return;

                room_no = room_no.toUpperCase();
                var _token = $('meta[name="csrf-token"]').attr('content');

                $.ajax({
                    url: "{{ route('backend.ajax_data_room_no') }}",
                    method: "POST",
                    headers: {
                        'x-csrf-token': _token
                    },
                    data: {
                        room_no: room_no
                    },
                    success: function(response) {
                        if (response.data) {
                            ajax_data_box(response);
                        } else {
                            console.log('No data received');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

            $('#bill_no').on('keyup change blur', function(e) {
                if (e.which != 13) {
                    return;
                }
                e.preventDefault();
                var bill_no = $(this).val();
                var _token = $('meta[name="csrf-token"]').attr('content');

                $.ajax({
                    url: "{{ route('backend.ajax_data_bill_no') }}",
                    method: "POST",
                    headers: {
                        'x-csrf-token': _token
                    },
                    data: {
                        bill_no: bill_no
                    },
                    success: function(response) {
                        if (response.data) {
                            ajax_data_box(response);
                        } else {
                            console.log('No data received');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

            $('.check_in').on('submit', function(e) {
                e.preventDefault();
            });

            $(document).on('click', '#floor-container .btn-block', function() {
                $('#check-in-div').removeClass('d-none');
                $('.btn-block').removeClass('active-btn');
                $(this).addClass('active-btn');
                var selectedValues = [];
                $('#room_type_container').empty();

                $('.btn-block').each(function() {
                    if ($(this).hasClass('active-btn')) {
                        selectedValues.push($(this).data('btn-id'));
                        var inputField = $('<input type="hidden" name="room_ids[]" class="selected-room" required>');
                        inputField.val($(this).data('btn-id'));
                        $('#room_type_container').append(inputField);
                    }
                });

                var select_rooms = $(this).data('btn-id');
                var _token = $('meta[name="csrf-token"]').attr('content');

                $.ajax({
                    url: "{{ route('backend.ajax_data_modification') }}",
                    method: "POST",
                    headers: {
                        'x-csrf-token': _token
                    },
                    data: {
                        select_rooms: select_rooms
                    },
                    dataType: 'json',
                    success: function(response) {
                        $('#table_extra').empty();
                        var customer_data = response.data;
                        var customer_data_modify = response.modificationCheckin;
                        var customerDetails = response.data.customer_detail;
                        var lastCustomerDetail = customerDetails[customerDetails.length - 1];
                        var advance_amount = response.data.advance_amount;
                        var advance_amount_sum = advance_amount.reduce((acc, obj) => acc + parseFloat(obj.advance_amount), 0);

                        $('input[name="customer_ids_id"]').val(customer_data.id);
                        $('#guest_name').val(customer_data.guest_name);
                        $("input[name='country_code']").val(customer_data.country_code);
                        $('#phone_number').val('+' + customer_data.country_code + customer_data.phone_number);

                        var checkInTimestamp = lastCustomerDetail.check_in;
                        var checkOutTimestamp = lastCustomerDetail.check_out;
                        var checkInTime = moment(checkInTimestamp);
                        var checkOutTime = moment(checkOutTimestamp);
                        var formattedCheckIn = checkInTime.format('DD-MM-YYYY HH:mm');
                        var formattedCheckOut = checkOutTime.format('DD-MM-YYYY HH:mm');

                        $('input[name="select_room_name"]').val(customer_data.select_rooms[0].name);
                        $('input[name="select_room"]').val(customer_data.select_rooms[0].id);
                        $('input[name="price"]').val(customer_data.room_type.extra_price);
                        $('input[name="extra_checkin_date"]').val(moment().format('DD-MM-YYYY HH:mm'));

                        var extraBedData = response.data.extra_beds_data;
                        console.log('Extra bed data:', extraBedData);
                        var extraTable = "";
                        if (extraBedData && extraBedData.length > 0) {
                            var extraBedDays = 0;
                            extraTable ='<Table class="w-100 mt-4"><tbody><tr><th>Check In</th><th>Check Out</th><th>Days</th><th>Price</th><th>Action</th></tr>';
                            var lint = 0;
                            var tempCost = 0;
                            extraBedData.forEach(element => {
                                console.log('Processing extra bed:', element.id, 'checkin_status:', element.checkin_status);
                                extraTable += `<tr id="extra-bed-row-${element.id}">`;
                                if (element.checkin_status == 0) {
                                    console.log('Extra bed NOT checked out yet, creating checkout button');
                                    var extraDays = getCalculatedTotalDays(element.checkin_date);
                                    lint += extraDays;
                                    extraBedDays += extraDays;
                                    var extraCost = extraDays * element.price;
                                    tempCost += extraCost;

                                    extraTable += '<td>' + moment(element.checkin_date).format('DD-MM-YYYY HH:mm') + '</td>';
                                    extraTable += '<td>Not checked out yet</td>';
                                    extraTable += '<td>' + extraDays + '</td>';
                                    extraTable += '<td>' + extraCost.toFixed(2) + '</td>';
                                    extraTable += '<td>';
                                    var checkoutBtn = '<button type="button" class="btn btn-primary btn-sm" data-extra-id="' + element.id + '" data-extra-days="' + extraDays + '" data-extra-cost="' + extraCost + '">CheckOut</button> ';
                                    console.log('Creating checkout button:', checkoutBtn);
                                    extraTable += checkoutBtn;
                                    @if(auth()->user()->roles->contains('title', 'Admin'))
                                    extraTable += '<button type="button" class="btn btn-danger btn-sm delete-extra-bed" data-extra-id="' + element.id + '"><i class="fas fa-trash"></i></button>';
                                    @endif
                                    extraTable += '</td>';
                                } else {
                                    console.log('Extra bed ALREADY checked out, no checkout button');
                                    tempCost += parseFloat(element.totalcost) || 0;
                                    var formattedCheckoutDate = 'Not checked out yet';
                                    try {
                                        if (element.checkout_date) {
                                            var checkoutMoment = moment(element.checkout_date, 'DD-MM-YYYY HH:mm');
                                            if (checkoutMoment.isValid()) {
                                                formattedCheckoutDate = checkoutMoment.format('DD-MM-YYYY HH:mm');
                                            } else {
                                                formattedCheckoutDate = 'Invalid Date';
                                            }
                                        }
                                        extraTable += `
                                            <td>${moment(element.checkin_date).format('DD-MM-YYYY HH:mm')}</td>
                                            <td>${formattedCheckoutDate}</td>
                                            <td>${element.totaldays}</td>
                                            <td>${parseFloat(element.totalcost).toFixed(2)}</td>
                                            <td>
                                                <button type="button" class="btn btn-danger btn-sm delete-extra-bed" data-extra-id="${element.id}"><i class="fas fa-trash"></i> Delete</button>
                                            </td>`;
                                        lint += element.totaldays;
                                        extraBedDays += element.totaldays;
                                    } catch (e) {
                                        console.log('Error in date recalculation:', e);
                                        extraTable += `
                                            <td>${moment(element.checkin_date).format('DD-MM-YYYY HH:mm')}</td>
                                            <td>Error</td>
                                            <td>${element.totaldays}</td>
                                            <td>${parseFloat(element.totalcost).toFixed(2)}</td>
                                            <td>
                                                <button type="button" class="btn btn-danger btn-sm delete-extra-bed" data-extra-id="${element.id}"><i class="fas fa-trash"></i> Delete</button>
                                            </td>`;
                                        lint += element.totaldays;
                                        extraBedDays += element.totaldays;
                                    }
                                }
                                extraTable += '</tr>';
                            });
                            extraTable += `<tr><td>Total</td><td></td><td>${lint}</td><td>${tempCost.toFixed(2)}</td><td></td></tr></tbody></table>`;
                            console.log('Final extra table HTML:', extraTable);
                            $('#table_extra').append(extraTable);
                            
                            console.log('Extra table appended, checking for checkout buttons...');
                            console.log('Table extra HTML after append:', $('#table_extra').html());
                            var checkoutButtons = $('#table_extra').find('.btn-primary.btn-sm[data-extra-id]');
                            console.log('Found checkout buttons:', checkoutButtons.length, checkoutButtons);
                            
                            // Re-bind checkout buttons
                            $('#table_extra').find('.btn-primary.btn-sm[data-extra-id]').off('click').on('click', function(e) {
                                e.preventDefault();
                                var $button = $(this);
                                var id = $button.data('extra-id');
                                var extraDays = parseFloat($button.data('extra-days')) || 0;
                                var extraCost = parseFloat($button.data('extra-cost')) || 0;
                                
                                if (!id || extraDays < 0 || extraCost < 0) {
                                    Swal.fire({
                                        title: 'Invalid Data',
                                        text: 'Invalid ID, days, or cost from button.',
                                        icon: 'error'
                                    });
                                    return;
                                }
                                
                                $button.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Checking out...');
                                callExtraCheckOut(id, extraDays, extraCost);
                            });
                            
                            // Re-bind delete buttons
                            $('#table_extra').find('.delete-extra-bed').off('click').on('click', function() {
                                var extraId = $(this).data('extra-id');
                                $('#deleteExtraBedModal').data('extra-id', extraId);
                                $('#deleteReason').val('');
                                $('#reasonError').hide();
                                $('#deleteReason').removeClass('is-invalid');
                                $('#deleteExtraBedModal').modal('show');
                            });
                        }

                        $('input[name="check_in"]').val(formattedCheckIn);
                        $('input[name="check_out"]').val(formattedCheckOut);
                        var currenttime = moment(new Date());
                        var checkInTime = moment(checkInTimestamp);
                        var standardCheckOut = checkInTime.clone().add(24, 'hours');
                        var remainingTime = moment.duration(standardCheckOut.diff(currenttime));
                        var remainingDays = remainingTime.days();
                        var remainingHours = remainingTime.hours();
                        var remainingMinutes = remainingTime.minutes();

                        $('#remining_time').val(remainingDays + ' days ' + remainingHours + ' hrs ' + remainingMinutes + ' min');

                        var diffInHours = currenttime.diff(checkInTime, 'hours');
                        var totalDays = Math.ceil(Math.abs(diffInHours) / 24);
                        var oldrent = parseInt(customer_data.price);
                        var perdayrent = oldrent / parseInt(lastCustomerDetail.days);
                        var rent = perdayrent * totalDays;
                        var percentage = $('input[name="gst"]').val();
                        var percentageDecimal = percentage / 100;
                        var gstAmount = rent * percentageDecimal;
                                
                      
                        var guestGstin = customer_data.guest_gstin || '';
                        var cleanedGstin = guestGstin.trim().toLowerCase();
                        var isIGST = cleanedGstin !== '' && cleanedGstin !== 'nil' && !cleanedGstin.startsWith('33');
                        
                        var cgst = 0, sgst = 0, igst = 0;
                        if (isIGST) {
                            igst = gstAmount; // Full GST as IGST
                        } else {
                            cgst = gstAmount / 2; // Split as CGST + SGST
                            sgst = gstAmount / 2;
                        }
                        
                        // Calculate the total by adding the rent and the GST
                        if (totalDays < 0) {
                            var total = (rent + (rent * totalDays)) + gstAmount;
                        } else {
                            var total = rent + gstAmount;
                        }

                        var total = rent + (rent * percentageDecimal);
                        var advance = advance_amount_sum.toFixed(2);
                        var balance = total - advance;

                        totalRent = rent;
                        $('input[name="amount"]').val(total.toFixed(2));
                        $('input[name="numDays"]').val(totalDays);
                        $('input[name="daysAmount"]').val(rent.toFixed(2));
                        $('input[name="balance_amount"]').val(balance.toFixed(2));
                        $('input[name="advance_amount"]').val(advance);
                        $('input[name="total_amount"]').val(total.toFixed(2));
                        $('input[name="cgst"]').val(cgst.toFixed(2));
                        $('input[name="sgst"]').val(sgst.toFixed(2));
                        $('input[name="igst"]').val(igst.toFixed(2));
                        $('input[name="tariff"]').val(rent);
                        $('input[name="extra_person_cost"]').val(0);

                        var extra_day = totalDays < 0 ? `<tr><th>Extra day</th><td>${totalDays}</td></tr>` : '';

                        $('#table_data').empty();
                        phone_number();
                        var gstRows = '';
                        if (isIGST) {
                            gstRows = '<tr><th>IGST</th><td>' + igst.toFixed(2) + '</td></tr>';
                        } else {
                            gstRows = '<tr><th>CGST</th><td>' + cgst.toFixed(2) + '</td></tr>' +
                                      '<tr><th>SGST</th><td>' + sgst.toFixed(2) + '</td></tr>';
                        }
                        var htmtable = '<table class="w-100 mt-4">' +
                                    '<tbody>' +'<tr>' +'<th>Rent</th>' +'<td>' + rent.toFixed(2) + '</td>' +'</tr>' +
                                    gstRows +
                                    (extra_day ?? '') +
                                    '<tr>' +'<th>Total</th>' +'<td>' + total.toFixed(2) + '</td>' +'</tr>' +
                                    '<tr>' +'<th>Advance</th>' +'<td>' + advance + '</td>' +'</tr>' +
                                    '<tr>' +'<th>Balance</th>' +'<td>' + balance.toFixed(2) + '</td>' +'</tr>' +
                                    '</tbody>' +
                                    '</table>';

                        $('#table_data').append(htmtable);

                        customer_data.select_rooms.forEach(function(room) {
                            var roomId = room.id;
                            var $button = $('#floor-container .btn-block[data-btn-id="' + roomId + '"]');
                            if ($button.length) {
                                $button.addClass('active-btn');
                                var inputField = $('<input type="hidden" name="room_ids[]" class="selected-room" required>');
                                inputField.val(room.id);
                                $('#room_type_container').append(inputField);
                            }
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                    }
                });
            });

            $('#datetimepickercheckin, #datetimepickercheckout').datetimepicker({
                useCurrent: false,
                showTodayButton: true,
                showClear: true,
                toolbarPlacement: 'bottom',
                sideBySide: true,
                format: 'DD-MM-YYYY HH:mm',
                icons: {
                    time: "fa fa-clock",
                    date: "fa fa-calendar",
                    up: "fa fa-arrow-up",
                    down: "fa fa-arrow-down",
                    previous: "fa fa-chevron-left",
                    next: "fa fa-chevron-right",
                    today: "fa fa-clock",
                    clear: "fa fa-trash-alt",
                    close: "fa fa-times"
                }
            });

            $(document).on('click', '.delete-extra-bed', function() {
                var extraId = $(this).data('extra-id');
                $('#deleteExtraBedModal').data('extra-id', extraId);
                $('#deleteReason').val('');
                $('#reasonError').hide();
                $('#deleteReason').removeClass('is-invalid');
                $('#deleteExtraBedModal').modal('show');
            });

            $('#confirmDeleteExtraBed').on('click', function() {
                var extraId = $('#deleteExtraBedModal').data('extra-id');
                var reason = $('#deleteReason').val().trim();

                if (!reason) {
                    $('#deleteReason').addClass('is-invalid');
                    $('#reasonError').show();
                    return;
                }

                $('#deleteReason').removeClass('is-invalid');
                $('#reasonError').hide();

                var $deleteBtn = $(this);
                var originalText = $deleteBtn.html();
                $deleteBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Deleting...');

                $.ajax({
                    url: '{{ route("backend.extra-beds.delete", ["id" => "PLACEHOLDER"]) }}'.replace('PLACEHOLDER', extraId),
                    type: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        reason: reason
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('Extra bed deleted successfully');
                            location.reload();
                        } else {
                            alert(response.message || 'Failed to delete extra bed');
                        }
                    },
                    error: function(xhr) {
                        var errorMessage = 'An error occurred while deleting the extra bed';
                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            errorMessage = xhr.responseJSON.message;
                        }
                        alert(errorMessage);
                    },
                    complete: function() {
                        $('#deleteExtraBedModal').modal('hide');
                        $('#deleteReason').val('');
                        $deleteBtn.prop('disabled', false).html(originalText);
                    }
                });
            });
        });
    </script>
@endsection

<div class="modal fade" id="deleteExtraBedModal" tabindex="-1" role="dialog" aria-labelledby="deleteExtraBedModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteExtraBedModalLabel">Delete Extra Bed</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this extra bed?</p>
                <div class="form-group">
                    <label for="deleteReason">Reason for deletion <span class="text-danger">*</span>:</label>
                    <textarea class="form-control" id="deleteReason" rows="3" placeholder="Please provide a reason for deletion..." required></textarea>
                    <div class="invalid-feedback" id="reasonError" style="display: none;">
                        Please provide a reason for deletion.
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteExtraBed">Delete</button>
            </div>
        </div>
    </div>
</div>