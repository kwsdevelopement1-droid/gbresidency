@section('title', 'Home')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent

    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />

    <style>
        .checkout {
            width: 90px;
            height: 29px;
            border-radius: 14.349px;
            background: #901111;
            color: #FFF;
            font-family: Raleway;
            font-size: 11.905px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 0.179px;
            border: none;
        }

        .checkin {
            width: 90px;
            height: 29px;
            border-radius: 14.349px;
            background: #009834;
            color: #FFF;
            font-family: Raleway;
            font-size: 11.905px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 0.179px;
            border: none;
        }

        .banner {
            height: 563.85px;
            background: linear-gradient(90deg, rgba(0, 35, 77, 0.63) 11.46%, rgba(0, 35, 77, 0.00) 77.37%), url("{{ asset('assets/img/banner.jpeg') }}") lightgray 0px 0px / 100.279% 100% no-repeat;
        }

        table {
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: none;
        }

        .btn.btn-primary {
            width: 512px;
            height: 48px;
            /* padding: 8px 16px; */
            border-radius: 4px;
            background: #901111;
            border: none;
            color: #FFF;
            font-family: Montserrat;
            font-size: 14px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
        }

        .btn.btn-success {
            background-color: #8dd3bb;
            border-color: #8dd3bb;
            font-family: Montserrat;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        th {
            color: #000;
            font-family: Raleway;
            font-size: 17.518px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 0.263px;
            height: 42.232px;

        }

        td {
            color: #000;
            font-family: Raleway;
            font-size: 17.518px;
            font-style: normal;
            font-weight: 500;
            line-height: normal;
            letter-spacing: 0.263px;
            /* border-radius: 21.116px;
                                                          background: #FFF !important;
                                                          box-shadow: 0px 2.815px 26.747px 0px rgba(141, 211, 187, 0.33) !important;
                                                          height: 42.232px; */
        }

        tr {
            border-radius: 21.116px;
            background: #FFF;
            box-shadow: 0px 2.815px 26.747px 0px rgba(141, 211, 187, 0.33);
            height: 42.232px;
        }

        .form-control.form-control-sm {
            height: 25px;
        }

        .table> :not(caption)>*>* {
            box-shadow: none;
        }

        .dt-head-center {
            text-align: center;
        }

        .table thead,
        .table th {
            text-align: center;
        }

        .page-item.active .page-link {
            background-color: #8dd3bb;
            border-color: #8dd3bb;
        }

        .table>thead {
            vertical-align: initial;
            height: 60px;
        }

        .form-control.form-control-sm {
            width: 738.609px !important;
            height: 49.608px;
            border-radius: 20.67px;
            background: #FFF;
            box-shadow: 0px 2.756px 26.182px 0px rgba(141, 211, 187, 0.33);
        }

        .search {
            padding: 8px 11px 0 0;
        }

        .numericCol {
            text-align: right;
        }

        table.dataTable tfoot th {
            text-align: right;
        }

        .home-title h3 {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 33.072px;
            font-style: normal;
            font-weight: 700;
            line-height: 150%;
            /* 49.608px */
        }

        label {
            color: #2D3748;
            font-family: Helvetica;
            font-size: 19.292px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
            letter-spacing: 0.289px;
        }

        #datatable-Customer_wrapper {
            margin-top: 26px;
        }

        .single {
            color: #FFF;
            font-family: Raleway;
            font-size: 11.905px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 1.179px;
            border-radius: 14.349px;
            background: #FF823C;
            width: 88.979px;
            height: 28.699px;
            border: none;
        }

        .group {
            color: #FFF;
            font-family: Raleway;
            font-size: 11.905px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 1.179px;
            border-radius: 14.349px;
            background: #FBB836;
            width: 88.979px;
            height: 28.699px;
            border: none;
        }

        .disc_guest {
            color: #FFF;
            font-family: Raleway;
            font-size: 11.905px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 1.179px;
            border-radius: 14.349px;
            background: #500808;
            width: 88.979px;
            height: 28.699px;
            border: none;
        }

        .house_guest {
            color: #FFF;
            font-family: Raleway;
            font-size: 11.905px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 1.179px;
            border-radius: 14.349px;
            background: #0b5526;
            width: 88.979px;
            height: 28.699px;
            border: none;
        }

        .extent {
            color: #FFF;
            font-family: Raleway;
            font-size: 11.905px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 1.179px;
            border-radius: 14.349px;
            background: #8DD3BB;
            width: 68.979px;
            height: 28.699px;
            border: none;
        }
    </style>
@endsection
@section('title_nav')
    <div class="row banner">
    </div>
@endsection
<div class="container">
    <div class="row">
        <div class="col-md-3 home-title">
            <h3>GUEST LIST </h3>
        </div>

    </div>
    {{-- <div class="col-md-15">
        <label class="d-flex md-12"><span class="search ">Search1: </span>
            <input type="text" class="tablesearch-input" id="custom-search-input"
                data-tablesearch-table="#datatable-Customer" class="form-control form-control-sm" placeholder=""
                aria-controls="DataTables_Table_0"></label>
    </div> --}}
    <div class="row">
        <table
            class="table tablesort tablesearch-table table-bordered table-striped table-hover datatable datatable-Customer"
            id="datatable-Customer">
            <thead>
                <tr>

                    <th data-tablesort-type="int">
                        Room NO
                    </th>
                    <th data-tablesort-type="string">
                        Guest Name
                    </th>
                    <th data-tablesort-type="number">
                        Phone
                    </th>
                    <th>
                        Check In Time
                    </th>

                    <th>
                        Type
                    </th>

                    {{-- <th data-tablesort-type="string">
                        Rem. Time
                    </th> --}}
                    <th data-tablesort-type="int">
                        Days
                    </th>
                    <th data-tablesort-type="int">
                        PAX
                    </th>
                    <th data-tablesort-type="int">
                        Rent
                    </th>
                    <th data-tablesort-type="int" align="center">
                        EP Amount
                    </th>
                    <th data-tablesort-type="int">
                        Disc
                    </th>
                    <th data-tablesort-type="int">
                        GST
                    </th>
                    <th data-tablesort-type="int">
                        Advance
                    </th>

                    <th data-tablesort-type="int" align="right">
                        Balance
                    </th>

                    <th>
                        Status
                    </th>

                </tr>
            </thead>

            <tbody>
                @php
                    $totalVal = 0.0;
                @endphp
                @foreach ($customers as $key => $customer)
                    @foreach ($customer->select_rooms as $keyroom => $item)
                        <tr data-entry-id="{{ $customer->id }}">
                            <td>

                                {{ $item->name }}

                            </td>
                            <td>
                                {{ $customer->guest_name ?? '' }}
                            </td>
                            <td>
                                {{ $customer->phone_number ?? '' }}
                            </td>
                            <td>
                                {{ $customer->customerDetail->last() ? \Carbon\Carbon::parse($customer->customerDetail->last()->check_in)->format('d/m/Y H.i') : '' }}
                            </td>
                            {{-- <td>
                                {{ $customer->customerDetail->last() ? \Carbon\Carbon::parse($customer->customerDetail->last()->check_out)->format('d/m/Y (h.iA)') : '' }}
                            </td> --}}
                            <td>
                                @if ($customer->rate_code == 2)
                                    <button class="house_guest">{{ $customer->room_type->name }}</button>
                                @elseif ($customer->discount_ids_id != null)
                                    <button class="disc_guest">{{ $customer->room_type->name }}</button>
                                @elseif (count($customer->select_rooms) > 1)
                                    <button class="group">{{ $customer->room_type->name }}</button>
                                @else
                                    <button class="single">{{ $customer->room_type->name }}</button>
                                @endif

                            </td>
                            {{-- <td align="right">

                                @php
                                    // $lastCheckIn = \Carbon\Carbon::parse($customer->customerDetail->last()->check_in);
                                    $lastCheckIn = \Carbon\Carbon::now(); //\Carbon\Carbon::parse(moment());
                                    $lastCheckOut = \Carbon\Carbon::parse($customer->customerDetail->last()->check_out);
                                    $hoursDifference = $lastCheckOut->diffInHours($lastCheckIn);
                                    $minutesDifference = $lastCheckOut->diffInMinutes($lastCheckIn) % 60;

                                    $remainingTime = \Carbon\Carbon::now()->diff($lastCheckOut);
                                    $isPastDue = $lastCheckOut->isPast();

                                    $lastCheckIn = Carbon\Carbon::parse($customer->customerDetail->last()->check_in);
                                    $currentDateTime = Carbon\Carbon::now();

                                    // Calculate the difference in minutes between the last check-in and the current time
                                    $minutesDifference = $lastCheckIn->diffInMinutes($currentDateTime);

                                    // Calculate the number of days including the grace period
                                    $daysWithGrace = ceil($minutesDifference / (24 * 60));

                                    // Calculate the remaining time to checkout
                                    $remainingTime = $daysWithGrace * 24 * 60 - $minutesDifference;
                                    $remainingTimeInMinutes = $daysWithGrace * 24 * 60 - $minutesDifference;

                                    // Calculate the remaining hours and remaining minutes
                                    $remainingHours = floor($remainingTimeInMinutes / 60);
                                    $remainingMinutes = $remainingTimeInMinutes % 60;

                                    $formattedRemainingTime = sprintf(
                                        '%02d:%02d',
                                        ($remainingHours + 1) % 24,
                                        $remainingMinutes,
                                    );
                                @endphp
                                <span style="color: {{ $isPastDue ? 'red' : 'black' }}">
                                    {{ $formattedRemainingTime }}
                                </span>

                            </td> --}}

                            @php
                                $checkInTime = \Carbon\Carbon::parse($customer->customerDetail->last()->check_in);
                                $hoursPastCheckIn = Carbon\Carbon::now()->diffInHours($checkInTime) - 1;
                                $roomPrice = $customer->rate_code == 1 ? $customer->room_type->price : 0;
                                if ($hoursPastCheckIn < 25) {
                                    $numDays = 1;
                                } else {
                                    $numDays = ceil($hoursPastCheckIn / 24);
                                }
                                $roomRent = $roomPrice * $numDays;
                                // /{{ $roomPrice }}X {{ $numDays }}= {{ $roomRent }}

                                $tempCost = 0.0;

                                $pax = $customer->total_adult;

                                foreach ($customer->extraBedsData as $extraBed) {
                                    if ($extraBed->checkin_status == 0) {
                                        // console.log(JSON.stringify(element));
                                        $pax += 1;
                                        $hoursPastCheckIn =
                                            Carbon\Carbon::now()->diffInHours($extraBed->checkin_date) - 1;
                                        if ($hoursPastCheckIn < 25) {
                                            $extraDays = 1;
                                        } else {
                                            $extraDays = ceil($hoursPastCheckIn / 24);
                                        }
                                        $extraCost = $extraDays * $extraBed->price;
                                        $tempCost += $extraCost;
                                    } else {
                                        $tempCost += $extraBed->totalcost;
                                    }
                                }
                                $extraBedCost = $tempCost;
                                $tempTotal = $roomRent + $extraBedCost;
                                $discount = $customer->discount_ids_id == null ? 0.0 : $tempTotal * 0.3;
                                $tempTotal -= $discount;

                                $gst = $tempTotal * 0.12;
                                if ($keyroom == 0) {
                                    $advanceAmt = $customer->advanceAmount->sum('advance_amount');
                                } else {
                                    $advanceAmt = 0.00;
                                }
                                $balance = $tempTotal + $gst - $advanceAmt;
                                $totalVal += $balance;
                            @endphp
                            <td align="center">{{ $numDays }}</td>
                            <td align="center">{{ $pax }}</td>
                            <td align="right">{{ number_format((float) $roomRent, 2, '.', '') }}</td>
                            <td align="right">{{ number_format((float) $extraBedCost, 2, '.', '') }}</td>
                           <td align="right">

                                {{ number_format((float) $discount, 2, '.', '') }}
                            </td>
                            <td align="right">{{ number_format((float) $gst, 2, '.', '') }}</td>
                            <td align="right">
                                {{ number_format($advanceAmt, 2, '.', '') }}
                            </td>



                            <td align="right">
                                {{-- {{ $numDays }}
                                {{ $roomRent }}+{{ $extraBedCost }} +
                                {{ $gst }}-{{ $customer->advanceAmount->sum('advance_amount') }}= --}}
                                {{ number_format((float) $balance, 2, '.', '') }}
                            </td>
                            {{-- <td>
                                <button class="extent"
                                    onclick="window.location='{{ route('backend.check-in-modification.index') }}?room={{ $item->id }}&type={{ $customer->room_type_id }}'">Extend</button>
                            </td> --}}
                            <td>
                                @if ($customer->status == 1)
                                    <button class="checkin">CheckIn</button>
                                @else
                                    <button class="checkout">CheckOut</button>
                                @endif
                            </td>

                        </tr>
                    @endforeach
                @endforeach

            </tbody>
            <tfoot>
                <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th>Total</th>
                    <th class="numericCol" align="right"> {{ number_format((float) $totalVal, 2, '.', '') }}</th>
                    <th></th>

                </tr>
            </tfoot>

        </table>

    </div>
    {{-- <div> {{ $customers }}</div> --}}

</div>
@endsection
@section('scripts')
@parent
@parent
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="{{ asset('assets/js/auto-tables.js') }}"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.print.min.js"></script>



<script src="{{ asset('assets/datatable/js/dataTables.bootstrap5.min.js') }}"></script>

<script>
    $(document).ready(function() {
        var table = $('#datatable-Customer').DataTable({
            "pageLength": 20, // Number of records per page
            "lengthMenu": [
                [10, 20, 50, -1],
                [10, 20, 50, "All"]
            ], // Customize the length menu
            "searching": true, // Disable default search feature
            "ordering": true, // Disable sorting
            "aoColumnDefs": [

                {
                    "sClass": "numericCol",
                    "aTargets": [5, 8, 9, 10, 11, 12]
                }
                //You can also set 'sType' to 'numeric' and use the built in css.
            ],
            dom: 'Bfrtip',
            buttons: [{
                    extend: 'pdf',
                    title: 'Guest List',
                    filename: 'guest_list',
                    orientation: 'landscape',
                            pageSize: 'A4',
                }, {
                    extend: 'excel',
                    title: 'Guest List',
                    filename: 'guest_list'
                }, {
                    extend: 'csv',
                    filename: 'guest_list'
                },
                {
                    extend: 'print',
                    footer: true,
                    exportOptions: {
                        orientation: 'landscape'
                    }

                }
            ]
        });



        // $('#custom-search-input').on('keyup', function() {
        //     table.search(this.value).draw();
        // });
    });
</script>
@endsection
