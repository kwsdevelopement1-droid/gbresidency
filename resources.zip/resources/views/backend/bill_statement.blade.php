@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link href="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/css/tempusdominus-bootstrap-4.min.css"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css"
        integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('assets/intl-tel-input-18.2.1/build/css/intlTelInput.css') }}">
    <style>
        .iti {
            width: 100%;
        }

        .hide {
            display: none;
        }

        .default-form .selectize-control {
            position: relative;
            width: 250px;
            border-radius: 4px 4px 0px 0px;
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 16px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
        }

        .default-form .selectize-input {
            height: 58px;
        }

        .green-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #009834;
        }

        .color-rooms h3 {
            color: #000;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .colors {
            max-width: 25%;
        }

        .orange-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FF823C;
        }

        .yellow-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FBB836;
        }

        .blue-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #0C89D0;
        }

        .black-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #000;
        }

        .default-form .input-group-text {

            height: 56px;
        }

        .default-form .fa.fa-calendar {
            font-size: 29px;
        }

        .default-form #no_of_room {
            width: 250px;
            height: 60px;
        }

        .default-form .selectize-input>* {
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 17.039px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
            text-transform: uppercase;
            margin: 12px;
        }

        .default-form .btn-search {
            border-radius: 4.26px;
            background: #8DD3BB;
            border: none;
            width: 55px;
            height: 55px;
            margin-left: 15px;
        }

        .check-in-form-title {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 33.072px;
            font-style: normal;
            font-weight: 700;
            line-height: 150%;
            /* 49.608px */
        }

        .check_in .form-control {
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;

        }

        .check_in label {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 500;
            line-height: 40px;
        }

        .check_in .selectize-control.single .selectize-input {
            border-color: #b8b8b8;
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;
        }

        .active-btn {
            color: #000;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            border-radius: 15px;
            border: 5px solid #009834;
            background: none;
        }

        .btn-save {
            border-radius: 10px;
            background: #8DD3BB;
            width: 672.804px;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            padding: 23.869px 0px 24.213px 0px;
            border: none;
        }

        table {
            width: 100%;
        }

        tr {
            height: 42px;
            border-radius: 21.116px;
            background: #FFF;
            box-shadow: 0px 2.815px 26.747px 0px rgba(141, 211, 187, 0.33);
        }

        th,
        tr {
            color: #000;
            leading-trim: both;
            text-edge: cap;
            font-family: Raleway;
            font-size: 20px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
            letter-spacing: 0.3px;
        }

        td {
            width: 40%;
        }

        .btn-checkout {
            border-radius: 10px;
            background: #901111;
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-cancel {
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            border: 5px solid #8DD3BB;
            color: #8DD3BB;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-extend {
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            border-radius: 10px;
            background: #8DD3BB;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }



        .active-btn {
            color: #000 !important;
            font-family: Montserrat !important;
            font-size: 20px !important;
            font-style: normal !important;
            font-weight: 700 !important;
            line-height: normal !important;
            border-radius: 15px !important;
            border: 5px solid #009834 !important;
            background: none !important;
        }

        .black {
            border-radius: 15px;
            background: #000;
            width: 100px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .single-color {

            border-radius: 15px;
            background: #FF823C;
            width: 100px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .multiple-color {

            border-radius: 15px;
            background: #FBB836;
            width: 100px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .recently-vacate-color {

            border-radius: 15px;
            background: #0C89D0;
            width: 100px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .input-group-text {
            height: 64px;
        }

        .fa.fa-calendar {
            font-size: 30px;
        }

        .main-color {

            border-radius: 15px;
            background: #009834;
            width: 100px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        #bill_no {
            width: 250px !important;
            height: 60px !important;
        }
    </style>
@endsection
@section('title_nav')
    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Duplicate Bill</h2>
    </div>
@endsection

<div class="container mt-4">
    <div class="row">

        <form class="default-form d-flex justify-content-between mt-4" id="form1" method="GET">
    @csrf
    <div class="form-row mx-auto d-flex justify-content-between">
        <div class="form-group col-md-6">
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="reportType" id="oldReport" value="old">
                <label class="form-check-label" for="oldReport">OLD</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="reportType" id="report2425" value="24-25">
                <label class="form-check-label" for="report2425">24-25</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="reportType" id="report2526" value="25-26">
                <label class="form-check-label" for="report2526">25-26</label>
            </div>
        </div>
        <div class="form-group col-md-12">
            <span class="has-float-label">
                <input class="form-control {{ $errors->has('bill_no') ? 'is-invalid' : '' }}" type="text"
                    name="bill_no" id="bill_no" placeholder="Checkout Bill No" required autocomplete="off">
                <label for="bill_no">Bill No</label>
            </span>
        </div>
        <button type="button" onclick="submitForm()" id="ajax-btn" class="btn-search">
            <!-- Your SVG code remains unchanged -->
            <svg xmlns="http://www.w3.org/2000/svg" width="27" height="26" viewBox="0 0 27 26" fill="none">
                <path
                            d="M18.8339 16.7262L18.8209 16.7435L18.8362 16.7588L23.5326 21.4552C23.7406 21.6881 23.8516 21.9918 23.8429 22.304C23.8341 22.6164 23.7061 22.9135 23.4851 23.1345C23.2641 23.3555 22.9669 23.4835 22.6545 23.4923C22.3424 23.501 22.0387 23.39 21.8058 23.182L17.1094 18.4856L17.0941 18.4703L17.0768 18.4833C15.5757 19.6109 13.7486 20.2196 11.8713 20.2175C7.07584 20.2175 3.17437 16.316 3.17437 11.5206C3.17437 6.72525 7.07584 2.82379 11.8712 2.82379C16.6666 2.82379 20.5681 6.72525 20.5681 11.5206C20.5701 13.398 19.9615 15.2251 18.8339 16.7262ZM5.6164 11.5206V11.5207C5.61839 13.1789 6.27802 14.7687 7.45059 15.9413C8.62316 17.1139 10.2129 17.7735 11.8712 17.7755H11.8712C13.1083 17.7755 14.3176 17.4086 15.3462 16.7213C16.3748 16.0341 17.1765 15.0572 17.6499 13.9143C18.1234 12.7713 18.2472 11.5137 18.0059 10.3004C17.7645 9.08707 17.1688 7.97257 16.2941 7.09781C15.4193 6.22306 14.3048 5.62735 13.0915 5.386C11.8782 5.14466 10.6205 5.26852 9.47761 5.74194C8.33469 6.21535 7.35782 7.01705 6.67053 8.04565C5.98324 9.07425 5.6164 10.2836 5.6164 11.5206Z"
                            fill="#112211" stroke="#112211" stroke-width="0.0499188" />
                    </svg>
           
        </button>
    </div>
</form>



    @endsection
    @section('scripts')
        @parent
        <script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/js/tempusdominus-bootstrap-4.min.js">
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
            integrity="sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
            crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script src="{{ asset('assets/intl-tel-input-18.2.1/build/js/intlTelInput.min.js') }}"></script>
        <script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>
        <script>
            $('#bill_no').on('keyup change blur', function(e) {
                e.preventDefault();
                if (e.which == 13) {
                    submitForm();
                }

            });

            function submitForm() {
    var bill_no = $('#bill_no').val();
    var reportType = $('input[name="reportType"]:checked').val();

    if (bill_no) {
        var action = "{{ route('backend.bill-statement.secondtemp-pdf', ':id') }}"; // Default route

        if (reportType === "old") {
            action = "{{ route('backend.bill-statement.secondtemp-pdf-old', ':id') }}"; // Old report route
        }  if (reportType === "24-25") {
            action = "{{ route('backend.bill-statement.secondtemp-pdf-24-25', ':id') }}"; // 24-25 report route
        }
        
        if (reportType === "25-26") {
            action = "{{ route('backend.bill-statement.secondtemp-pdf-25-26', ':id') }}"; // 24-25 report route
        }

        action = action.replace(':id', bill_no); // Replace the placeholder with the bill_no value
        console.log("url: " + action);

        // Submit the form via GET request
        window.location.href = action;
    } else {
        alert('Bill No cannot be empty');
    }
}
        </script>

    @endsection
