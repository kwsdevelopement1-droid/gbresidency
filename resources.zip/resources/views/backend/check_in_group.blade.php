@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent


    <style>
        .green-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #009834;
        }

        .color-rooms h3 {
            color: #000;
            font-family: Montserrat;
            font-size: 19px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            white-space: nowrap;
            position: relative;
            left: 39px;
        }

        .color-rooms h4 {
            color: #FFF;
            font-family: Montserrat;
            font-size: 30px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            text-align: center;
            position: relative;
            bottom: 3px;
        }

        .colors {
            max-width: 25%;
        }

        .orange-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FF823C;
        }

        .yellow-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FBB836;
        }

        .blue-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #0C89D0;
        }

        .black-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #000;
        }

        .black {
            border-radius: 15px;
            background: #000;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .single-color {

            border-radius: 15px;
            background: #FF823C;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .active-btn {
            color: #000 !important;
            font-family: Montserrat !important;
            font-size: 20px !important;
            font-style: normal !important;
            font-weight: 700 !important;
            line-height: normal !important;
            border-radius: 15px !important;
            border: 5px solid #009834 !important;
            background: none !important;
        }

        .multiple-color {

            border-radius: 15px;
            background: #FBB836;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .recently-vacate-color {

            border-radius: 15px;
            background: #0C89D0;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }


        .main-color {

            border-radius: 15px;
            background: #009834;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .card {
            padding: unset !important;
            border-radius: 25px 26px 0px 0px;
            border: 4px solid #8DD3BB;
        }

        .card-header.text-center {
            border-radius: 20px 20px 0px 0px;
            background: #8DD3BB;
            position: relative;
            bottom: 0;
        }

        .card-header.text-center h3 {
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .btn-checkout {
            border-radius: 10px;
            background: #901111;
            display: flex;
            width: 383.54px;
            height: 76.082px;
            transform: rotate(0.265deg);
            padding: 23.627px 0px 24.455px 0px;
            justify-content: center;
            align-items: center;
            color: #F2F2F2;
            text-align: center;
            font-family: Roboto;
            font-size: 23.869px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }
        .check_in .form-control {
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;

        }

        .check_in label {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 500;
            line-height: 40px;
        }
        .check_in .selectize-control.single .selectize-input {
            border-color: #b8b8b8;
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;
        }
        .default-form .selectize-control {
            position: relative;
            width: 250px;
            border-radius: 4px 4px 0px 0px;
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 16px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
        }

        .default-form .selectize-input {
            height: 58px;
        }
         .check_in .selectize-control.single .selectize-input {
            border-color: #b8b8b8;
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;
        }
    </style>
@endsection
@section('title_nav')
    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Rooms Status ( Floor Wise )</h2>
    </div>
@endsection
@php
    $totalrecentRooms = $floors
        ->flatMap(function ($floor) {
            return $floor->select_rooms;
        })
        ->where('status', 2)
        ->count();

    $totalblockedRooms = $floors
        ->flatMap(function ($floor) {
            return $floor->select_rooms;
        })
        ->where('status', 1)
        ->count();

    $totalRemainingRooms = $floors
        ->flatMap(function ($floor) {
            return $floor->select_rooms;
        })
        ->reject(function ($room) use ($booked, $multiple_book) {
            return in_array($room->id, $booked) ||
                in_array($room->id, $multiple_book) ||
                $room->status == 1 ||
                $room->status == 2;
        })
        ->count();

@endphp
<div class="container">
    <div class="row color-rooms">
        <div class="col-sm">
            <div class="col-sm">
                <div class="row">
                    <div class="col colors">
                        <div class="green-room rounded container-fluid py-3 mb-3">
                            <h4 id="available_room">{{ $totalRemainingRooms ?? '' }}</h4>

                        </div>
                    </div>
                    <div class="col">
                        <h3 class="mt-4"> - Available </h3>
                    </div>
                </div>
            </div>

        </div>
        <div class="col-sm">
            <div class="col-sm">
                <div class="row">
                    <div class="col colors">
                        <div class="orange-room rounded container-fluid py-3 mb-3">
                            <h4 id="normal_room">{{ count($booked) + count($multiple_book) }}</h4>
                        </div>
                    </div>
                    <div class="col">
                        <h3 class="mt-4"> Occupied</h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm">
            <div class="row">
                <div class="col colors">


                    <div class="blue-room rounded container-fluid py-3 mb-3">
                        <h4 id="recent_room">{{ $totalrecentRooms ?? '' }}</h4>
                    </div>
                </div>
                <div class="col">
                    <h3 class="mt-4"> - Recent Vacates</h3>
                </div>
            </div>
        </div>
        <div class="col-sm">
            <div class="row">
                <div class="col colors">
                    <div class="black-room rounded container-fluid py-3 mb-3">
                        <h4 id="black_room">{{ $totalblockedRooms ?? '' }}</h4>
                    </div>
                </div>
                <div class="col">
                    <h3 class="mt-4"> - Blocked </h3>
                </div>
            </div>
        </div>
        <div class="col-sm">
            <div class="col-sm">
                <div class="row">
                    <div class="col colors">
                        <div class="yellow-room rounded container-fluid py-3 mb-3">
                            <h4 id="group_room">
                                {{ count($booked) + count($multiple_book) + $totalblockedRooms + $totalrecentRooms + $totalRemainingRooms }}
                            </h4>
                        </div>
                    </div>
                    <div class="col">
                        <h3 class="mt-4"> - Total Rooms</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<div class="container">
    @foreach ($floors as $key => $floor)
        @php

            $main_count = 0;
            $roomcontent = '';
        @endphp

        @foreach ($floor->select_rooms as $item)
            @php
                $booked = $booked ?? [];
                $multiple_book = $multiple_book ?? [];
                $className = '';

                if ($item->status == 1) {
                    $className = 'black';
                } elseif (in_array($item->id, $booked)) {
                    $className = 'single-color btn-fetch';
                } elseif (in_array($item->id, $multiple_book)) {
                    $className = 'multiple-color btn-fetch';
                } elseif ($item->status == 2) {
                    $className = 'recently-vacate-color';
                } else {
                    $className = 'btn-block main-color';
                    $main_count++;
                }

                // Generate HTML content for each room
                $roomcontent .= '<div class="col-6 col-sm-4 col-md-3 col-lg-1 mb-3">';
                $roomcontent .=
                    '<button class="' . $className . '" data-btn-id="' . $item->id . '">' . $item->name . '</button>';
                $roomcontent .= '</div>';
            @endphp
        @endforeach

        <div class="row mt-4">
            <div class="card">
                <div class="card-header text-center">
                    <h3>{{ $floor->name }} - {{ $main_count }}</h3>
                </div>
                <div class="card-body">
                    <div id="floor-container" class="row mt-4">
                        <!-- Output the generated room content -->
                        {!! $roomcontent !!}
                    </div>
                </div>
            </div>
        </div>
    @endforeach

</div>
<div class="d-none" id="check-in-div">
    <div class="row mt-4">

        <form class="check_in" id="form2" method="POST" action="{{ route('backend.checkInGroupPost') }}">
            @csrf

            <div class="row mt-4">

                <div id="room_type_container"></div>

                <div class="row mt-4">
                    <div class="col-sm d-flex justify-content-center mt-4">
                        <!-- Added text-center class to center the content -->
                        <button class="btn btn-checkout" type="submit">
                            <!-- Added btn class and removed extra space -->
                            Continue..
                        </button>
                    </div>
                </div>

        </form>
    </div>
</div>
@endsection
@section('scripts')

@parent
<script>
    $(document).ready(function() {
        $(document).on('click', '#floor-container .btn-fetch', function() {
           var roomId =  $(this).data('btn-id');
        //    alert(roomId);

        });

        $(document).on('click', '#floor-container .btn-block', function() {

            $('#check-in-div').removeClass('d-none');

            // Toggle active-btn class on the clicked button
            $(this).toggleClass('active-btn');

            // Initialize an array to store selected values
            var selectedValues = [];

            // Remove existing input fields
            $('#room_type_container').empty();

            // Loop through all buttons with class btn-block and check for active ones
            $('.btn-block').each(function() {
                if ($(this).hasClass('active-btn')) {
                    // Add the value of active buttons to selectedValues array
                    selectedValues.push($(this).data('btn-id'));

                    // Create a new input field for each selected value
                    var inputField = $(
                        '<input type="hidden" name="room_ids[]" class="selected-room" required>'
                    );
                    // Set the value of the input field
                    inputField.val($(this).data('btn-id'));
                    // Append the input field to the container
                    $('#room_type_container').append(inputField);
                }
            });

            // You can use selectedValues array for further processing if needed
        });
        $('.check_in').on('submit', function(e) {
            var _token = $('meta[name="csrf-token"]').attr('content');
            // alert();
            // e.preventDefault(); // Prevent the default form submission
            var formData1 = new FormData($('#form1')[0]); // Get data from Form 1
            var formData2 = new FormData($('#form2')[0]); // Get data from Form 2

            // Append data from Form 2 to Form 1
            for (var pair of formData2.entries()) {
                formData1.append(pair[0], pair[1]);
            }
            // formData1.append('_method', 'PUT');


        });
    });
</script>

@endsection
