@section('title', 'Company Details')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link href="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/css/tempusdominus-bootstrap-4.min.css"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/css/selectize.default.min.css"
        integrity="sha512-pTaEn+6gF1IeWv3W1+7X7eM60TFu/agjgoHmYhAfLEU8Phuf6JKiiE8YmsNC0aCgQv4192s4Vai8YZ6VNM6vyQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('assets/intl-tel-input-18.2.1/build/css/intlTelInput.css') }}">
    <style type="text/css" media="print">
        @page {
            size: auto;   /* auto is the initial value */
            margin: 0;  /* this affects the margin in the printer settings */
        }
        </style>
    <style>
        .printButton {
            cursor: pointer;
  background: #bc1b1b;
  color: #fff;
  width: 100px;
  border: none;
  border-radius: 2px;
  height: 28px;
  font-size: 20px;
}
        .iti {
            width: 100%;
        }

        .hide {
            display: none;
        }

        .default-form .selectize-control {
            position: relative;
            width: 250px;
            border-radius: 4px 4px 0px 0px;
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 16px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
        }

        .default-form .selectize-input {
            height: 58px;
        }

        .green-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #009834;
        }

        .color-rooms h3 {
            color: #000;
  font-family: Montserrat;
  font-size: 19px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  white-space: nowrap;
  position: relative;
  left: 39px;
        }

        .color-rooms h4 {
  color: #FFF;
  font-family: Montserrat;
  font-size: 30px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
  text-align: center;
  position: relative;
  bottom: 3px;
}


        .colors {
            max-width: 25%;
        }

        .orange-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FF823C;
        }

        .yellow-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #FBB836;
        }

        .blue-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #0C89D0;
        }

        .black-room.rounded {
            width: 100px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            background: #000;
        }

        .default-form .input-group-text {

            height: 56px;
        }

        .default-form .fa.fa-calendar {
            font-size: 29px;
        }

        .default-form #no_of_room {
            width: 250px;
            height: 60px;
        }

        .default-form .selectize-input>* {
            color: #1C1B1F;
            font-family: Montserrat;
            font-size: 17.039px;
            font-style: normal;
            font-weight: 400;
            line-height: normal;
            text-transform: uppercase;
            margin: 12px;
        }
        #bill_no {
  width: 250px !important;
  height: 60px !important;
}
        .default-form .btn-search {
            border-radius: 4.26px;
            background: #8DD3BB;
            border: none;
            width: 55px;
            height: 55px;
            margin-left: 15px;
        }

        .check-in-form-title {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 33.072px;
            font-style: normal;
            font-weight: 700;
            line-height: 150%;
            /* 49.608px */
        }

        .check_in .form-control {
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;

        }

        .check_in label {
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 500;
            line-height: 40px;
        }

        .check_in .selectize-control.single .selectize-input {
            border-color: #b8b8b8;
            border-radius: 10px;
            background: #F5F5FA;
            box-shadow: -2px -2px 4px 0px rgba(141, 211, 187, 0.50) inset, 2px 2px 4px 0px rgba(141, 211, 187, 0.25) inset, 5px 5px 10px 0px rgba(141, 211, 187, 0.50) inset;
            height: 64px;
            color: #8DD3BB;
            font-family: Montserrat;
            font-size: 25px;
            font-style: normal;
            font-weight: 400;
            line-height: 40px;
        }

        .active-btn {
            color: #000;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            border-radius: 15px;
            border: 5px solid #009834;
            background: none;
        }
        .btn-save{
            border-radius: 10px;
background: #8DD3BB;width: 672.804px;
color: #F2F2F2;
text-align: center;
font-family: Roboto;
font-size: 23.869px;
font-style: normal;
font-weight: 700;
line-height: normal;
padding: 23.869px 0px 24.213px 0px;
border: none;
        }
        table{
            width: 100%;
        }
        tr {
  height: 42px;
  border-radius: 21.116px;
  background: #FFF;
  box-shadow: 0px 2.815px 26.747px 0px rgba(141, 211, 187, 0.33);
}
th,tr {
  color: #000;
  leading-trim: both;
  text-edge: cap;
  font-family: Raleway;
  font-size: 20px;
  font-style: normal;
  font-weight: 600;
  line-height: normal;
  letter-spacing: 0.3px;
}
td{
    width: 40%;
}

.btn-checkout {
  border-radius: 10px;
  background: #901111;
  display: flex;
  width: 383.54px;
  height: 76.082px;
  transform: rotate(0.265deg);
  padding: 23.627px 0px 24.455px 0px;
  justify-content: center;
  align-items: center;
  color: #F2F2F2;
  text-align: center;
  font-family: Roboto;
  font-size: 23.869px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
}
.btn-cancel {
  display: flex;
  width: 383.54px;
  height: 76.082px;
  transform: rotate(0.265deg);
  padding: 23.627px 0px 24.455px 0px;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
  border: 5px solid #8DD3BB;
  color: #8DD3BB;
  text-align: center;
  font-family: Roboto;
  font-size: 23.869px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
}
.btn-extend {
  display: flex;
  width: 383.54px;
  height: 76.082px;
  transform: rotate(0.265deg);
  padding: 23.627px 0px 24.455px 0px;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
  background: #8DD3BB;
  color: #F2F2F2;
  text-align: center;
  font-family: Roboto;
  font-size: 23.869px;
  font-style: normal;
  font-weight: 700;
  line-height: normal;
}



.active-btn {
            color: #000 !important;
            font-family: Montserrat !important;
            font-size: 20px !important;
            font-style: normal !important;
            font-weight: 700 !important;
            line-height: normal !important;
            border-radius: 15px !important;
            border: 5px solid #009834 !important;
            background: none !important;
        }

        .black {
            border-radius: 15px;
            background: #000;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .single-color {

            border-radius: 15px;
            background: #FF823C;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .multiple-color {

            border-radius: 15px;
            background: #FBB836;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        .recently-vacate-color {

            border-radius: 15px;
            background: #0C89D0;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }


        .main-color {

            border-radius: 15px;
            background: #009834;
            width: 75px;
            height: 60px;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

.input-group-text {
  height: 64px;
}
.fa.fa-calendar {
  font-size: 30px;
}



    </style>
@endsection
@section('title_nav')
    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Forign Guests List</h2>
    </div>
@endsection
<div class="container mt-4">
    <div class="row">

        <form class="default-form d-flex justify-content-between mt-4" id="form1" method="POST" action="{{ route('backend.forign.report.fillter') }}">
            @csrf

            <div class="form-row">
                <div class="form-group col-md-12">
                    <span class="has-float-label">
                        <div class="input-group date" id="datetimepickercheckin" data-target-input="nearest">
                            <input type="text" name="check_in" class="form-control datetimepicker-input"
                                data-target="#datetimepickercheckin" />
                            <div class="input-group-append" data-target="#datetimepickercheckin"
                                data-toggle="datetimepicker">
                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                            </div>
                        </div>
                        <label for="check_in">From Date</label>
                    </span>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-12">
                    <span class="has-float-label">
                        <div class="input-group date" id="datetimepickercheckout" data-target-input="nearest">
                            <input type="text" name="check_out" class="form-control datetimepicker-input"
                                data-target="#datetimepickercheckout" />
                            <div class="input-group-append" data-target="#datetimepickercheckout"
                                data-toggle="datetimepicker">
                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                            </div>
                        </div>
                        <label for="check_out">To Date</label>
                    </span>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-12">
                    <span class="has-float-label">
                        <select name="country_id" id="country_id" placeholder="Select Country" required>
                            <option value="" selected>Select Country</option>
                            <option value="all">All</option>
                            @foreach ($users as $id => $floor)
                                <option value="{{ $id }}">{{ $floor }}</option>
                            @endforeach
                        </select>

                        <label for="select_room_type">Country</label>
                </div>

            </div>
            <div class="form-row">
                 <button type="submit" style="background-color:#8dd3bb;color:white;width:240px;height:60px;" class="btn">Filter</button>
                </div>

        </form>

    </div>
</div>

            @endsection
            @section('scripts')
                @parent
                <script src="https://cdn.jsdelivr.net/npm/moment@2.29.1/moment.min.js"></script>
                <script src="https://cdn.jsdelivr.net/npm/tempusdominus-bootstrap-4@5.1.2/build/js/tempusdominus-bootstrap-4.min.js">
                </script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
                    integrity="sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
                    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
                <script src="{{ asset('assets/intl-tel-input-18.2.1/build/js/intlTelInput.min.js') }}"></script>
                <script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>

              <script>

                    $(document).ready(function() {
                        $("select").selectize();
                        $('#country_id').on('change', function(e) {
                            var selectedUserId = $(this).val(); // Get the selected value from the select element

    e.preventDefault();
    if (selectedUserId !== '') {
        var _token = $('meta[name="csrf-token"]').attr('content');

        var formData1 = new FormData($('#form1')[0]); // Get data from Form 1

       
    }
});



});

                    // $("select").selectize();

                    $(document).ready(function() {
                        $('#datetimepickercheckin').datetimepicker({
                            useCurrent: false,
                            defaultDate: moment().subtract(1, 'days'),

                            showTodayButton: true,
                            showClear: true,
                            toolbarPlacement: 'bottom',
                            sideBySide: true,
                            format: 'DD-MM-YYYY', // Set your desired format here
                            icons: {
                                time: "fa fa-clock",
                                date: "fa fa-calendar",
                                up: "fa fa-arrow-up",
                                down: "fa fa-arrow-down",
                                previous: "fa fa-chevron-left",
                                next: "fa fa-chevron-right",
                                today: "fa fa-clock",
                                clear: "fa fa-trash-alt",
                                close: "fa fa-times"
                            },

                        });
                         $('#datetimepickercheckout').datetimepicker({
                            useCurrent: false,
                            defaultDate: moment(),

                            showTodayButton: true,
                            showClear: true,
                            toolbarPlacement: 'bottom',
                            sideBySide: true,
                            format: 'DD-MM-YYYY', // Set your desired format here
                            icons: {
                                time: "fa fa-clock",
                                date: "fa fa-calendar",
                                up: "fa fa-arrow-up",
                                down: "fa fa-arrow-down",
                                previous: "fa fa-chevron-left",
                                next: "fa fa-chevron-right",
                                today: "fa fa-clock",
                                clear: "fa fa-trash-alt",
                                close: "fa fa-times"
                            },

                        });
                    });
                </script>

            @endsection
