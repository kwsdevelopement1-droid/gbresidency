@section('title', 'Monthly Guests')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
    <link href="https://cdn.datatables.net/2.0.5/css/dataTables.dataTables.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/3.0.2/css/buttons.dataTables.css" rel="stylesheet" />

    <style>
        table {
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: none;
        }

        #datatable-Customer_wrapper {
            margin-top: 26px;
        }

        .btn.btn-primary {
            width: 512px;
            height: 48px;
            /* padding: 8px 16px; */
            border-radius: 4px;
            background: #901111;
            border: none;
            color: #FFF;
            font-family: Montserrat;
            font-size: 14px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
        }

        .btn.btn-success {
            background-color: #8dd3bb;
            border-color: #8dd3bb;
            font-family: Montserrat;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        th {
            color: #000;
            font-family: Raleway;
            font-size: 17.518px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 0.263px;
        }

        td {
            color: #000;
            font-family: Raleway;
            font-size: 17.518px;
            font-style: normal;
            font-weight: 500;
            line-height: normal;
            letter-spacing: 0.263px;
        }

        td span {
            padding: initial !important;
            color: #000 !important;
            font-family: Raleway !important;
            font-size: 17.518px !important;
            font-style: normal !important;
            font-weight: 500 !important;
            line-height: normal !important;
            letter-spacing: 0.263px !important;
        }

        .form-control.form-control-sm {
            height: 25px;
        }

        .table> :not(caption)>*>* {
            box-shadow: none;
        }

        .page-item.active .page-link {
            background-color: #8dd3bb;
            border-color: #8dd3bb;
        }
    </style>
@endsection

@section('title_nav')

    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Monthly Guest</h2>
    </div>
@endsection
@if (session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
@endif
<div class="row">
    <div class="col-md-3">
        @include('backend.include.sidebar')
    </div>
    <div class="col-md-9">
        @if ($errors->any())
            @foreach ($errors->all() as $error)
                <div class="alert alert-danger">
                    {{ $error }}
                </div>
            @endforeach
        @endif

        <a class="text-dark" href="{{ route('backend.monthly-guests.index') }}">Back to List</a>
        <div class="card">
            <div class="card-body">
                <p style="font-size:20px; font-weight:bold;">Create New Monthly Guest</p>
                <form action="{{ route('backend.monthly-guests.store') }}" class="was-validated" method="POST"
                    novalidate>
                    @csrf
                    <input type="hidden" name="customer_ids_id" id="customer_ids_id"/>
                    <input type="hidden" name="room_id" id="room_id"/>
                    <input type="hidden" name="room_name" id="room_name"/>
                    <div class="row">
                        <div class="col-md-9 form-group has-validation">
                            <label for="roomnumber">Room Number</label>
                            <input type="text" name="roomnumber" id="roomnumber"
                                class="form-control {{ $errors->has('roomnumber') ? 'is-invalid' : '' }} " required
                                value="{{ old('roomnumber') }}">
                            @if ($errors->has('roomnumber'))
                                <span class="invalid-feedback">
                                    <strong>{{ $errors->first('roomnumber') }}</strong>
                                </span>
                            @endif
                        </div>
                        <div class="col-md-3 form-group has-validation mt-4">

                            <label id="searchBtn" type="cancel" class="btn btn-secondary">Search</label>
                        </div>

                    </div>
                    <div class="d-none" id="check-in-div">
                        <table>
                            <tr>
                                <td>Guest Name:</td>
                                <td>
                                    <lable id="guest_name"></lable>
                                </td>
                            </tr>
                            <tr>
                                <td>Check In:</td>
                                <td>
                                    <lable id="check_in"></lable>
                                </td>
                            </tr>
                        </table>

                    </div>


                    <div class="form-group has-validation">
                        <label for="rate">Rate</label>
                        <input type="rate" name="rate" id="rate"
                            class="form-control {{ $errors->has('rate') ? 'is-invalid' : '' }}" required
                            value="{{ old('rate') }}">
                        @if ($errors->has('rate'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('rate') }}</strong>
                            </span>
                        @endif
                    </div>
                    <div class="clear col-md-3"></br></div>

                    <button type="submit" class="btn btn-primary">Create Monthly Guest</button>
                </form>
            </div>
        </div>


    </div>
</div>
@endsection
@section('scripts')
@parent

<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.15.2/js/selectize.min.js"
    integrity="sha512-IOebNkvA/HZjMM7MxL0NYeLYEalloZ8ckak+NDtOViP7oiYzG5vn6WVXyrJDiJPhl4yRdmNAG49iuLmhkUdVsQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>

<script>
    $(document).ready(function() {
        $(window).keydown(function(event) {
            if (event.keyCode == 13) {
                event.preventDefault();
                return false;
            }
        });

        $('#searchBtn').on('click', function() {
            var roomNumber = $('#roomnumber').val();
            console.log('Room number:', roomNumber);
            room_no = roomNumber.toUpperCase();
            if (room_no.length < 2)
                return;

            var _token = $('meta[name="csrf-token"]').attr('content');


            $.ajax({
                url: "{{ route('backend.ajax_data_room_no') }}",
                method: "POST",
                headers: {
                    'x-csrf-token': _token
                },
                data: {
                    room_no: room_no
                },
                success: function(response) {
                    console.log(response);
                    // Handle the response as needed
                    if (response.data) {
                        // ajax_data_box(response);

                        $('input[name="room_id"]').val(response.customers_data.select_rooms[0].id);
                        $('input[name="room_name"]').val(response.customers_data.select_rooms[0].name);
                        $('input[name="customer_ids_id"]').val(response.customers_data.id);

                        $('#check-in-div').removeClass('d-none');
                        var customer_data = response.data;
                        $('#guest_name').text(response.customers_data.guest_name);
                        $('#check_in').text(moment(response.customers_data.created_at)
                            .format('DD/MM/YYYY HH:mm:ss'));


                    } else {
                        console.log('No data received');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    // Handle errors
                }
            });
            // Do something with the room number here
        });
    });
</script>

@endsection
