@section('title', 'Monthly Guests')
@extends('layouts.backend')
@section('content')
@section('styles')
    @parent
    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">
    <link href="{{ asset('assets/datatable/css/dataTables.bootstrap5.min.css') }}" rel="stylesheet" />
    <link href="https://cdn.datatables.net/2.0.5/css/dataTables.dataTables.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/buttons/3.0.2/css/buttons.dataTables.css" rel="stylesheet" />

    <style>
        table {
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: none;
        }

        #datatable-Customer_wrapper {
            margin-top: 26px;
        }

        .btn.btn-primary {
            width: 512px;
            height: 48px;
            /* padding: 8px 16px; */
            border-radius: 4px;
            background: #901111;
            border: none;
            color: #FFF;
            font-family: Montserrat;
            font-size: 14px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
        }

        .btn.btn-success {
            background-color: #8dd3bb;
            border-color: #8dd3bb;
            font-family: Montserrat;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
        }

        th {
            color: #000;
            font-family: Raleway;
            font-size: 17.518px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            letter-spacing: 0.263px;
        }

        td {
            color: #000;
            font-family: Raleway;
            font-size: 17.518px;
            font-style: normal;
            font-weight: 500;
            line-height: normal;
            letter-spacing: 0.263px;
        }

        td span {
            padding: initial !important;
            color: #000 !important;
            font-family: Raleway !important;
            font-size: 17.518px !important;
            font-style: normal !important;
            font-weight: 500 !important;
            line-height: normal !important;
            letter-spacing: 0.263px !important;
        }

        .form-control.form-control-sm {
            height: 25px;
        }

        .table> :not(caption)>*>* {
            box-shadow: none;
        }

        .page-item.active .page-link {
            background-color: #8dd3bb;
            border-color: #8dd3bb;
        }
    </style>
@endsection

@section('title_nav')

    <div class="row title-card">

        <h2 class="d-flex align-items-center justify-content-center">Monthly Guest</h2>
    </div>
@endsection

<div class="row">
    <div class="col-md-3">
        @include('backend.include.sidebar')
    </div>
    <div class="col-md-9">
        @if (session()->has('success'))
            <div class="alert alert-success">
                {{ session()->get('success') }}
            </div>
        @endif
        <div class="card">
            <div class="card-body">
                <strong>Monthly Guests List</strong>
                <a href="{{ route('backend.monthly-guests.create') }}"
                    class="btn btn-secondary btn-xs float-end py-0">Create Monthly Guest ++</a>



                <table class="table table-responsive table-bordered table-stripped" style="margin-top:10px;">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Room #</th>
                            <th>Monthly Rent</th>
                            <th>Check In Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if ($monthlyGuests && count($monthlyGuests) > 0)
                            @foreach ($monthlyGuests as $key => $customer)
                                <tr>
                                    <td>{{ $key + 1 }}</td>
                                    <td>{{ $customer->customer_ids->guest_name }}</td>
                                    <td>{{ $customer->room_name }}</td>
                                    <td>{{ $customer->rate }}</td>
                                    <td>{{ $customer->customer_ids->created_at->format('d-m-Y H:i:s') }}</td>
                                    <td><span type="button"
                                            class="btn {{ $customer->deleted_at == null ? 'btn-success' : 'btn-danger' }} btn-xs py-0">{{ $customer->deleted_at == null ? 'Active' : 'Inactive' }}</span>
                                    </td>
                                    <td>
                                        <div class="d-flex">

                                            <a href="{{ route('backend.monthly-guests.edit', $customer->id) }}"
                                                class="btn btn-warning btn-xs py-0 mx-1">Edit</a>
                                            <form action="{{ route('backend.monthly-guests.destroy', $customer->id) }}"
                                                method="POST">
                                                @method('DELETE')
                                                @csrf
                                                <button type="submit"
                                                    class="btn btn-danger btn-xs py-0">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        @else
                            <tr>
                                <td colspan="7" align="center">No Records Found</td>
                            </tr>
                        @endif
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>
@endsection
