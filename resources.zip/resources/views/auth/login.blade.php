<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="{{ asset('assets/bootstrap-5.0.2-dist/css/bootstrap.min.css') }}">
  
  <style>
    .has-float-label {
      display: block;
      position: relative;
    }
    .has-float-label label, .has-float-label > span {
      position: absolute;
      cursor: text;
      font-size: 75%;
      opacity: 1;
      transition: all 0.2s;
      top: -0.5em;
      left: 0.75rem;
      z-index: 3;
      line-height: 1;
      padding: 0 2px;  
      background: #fff;
    }
    .has-float-label label::after, .has-float-label > span::after {
      content: " ";
      display: block;
      position: absolute;
      background: #fff;
      height: 2px;
      top: 50%;
      left: -0.2em;
      right: -0.2em;
      z-index: -1;
    }
    .has-float-label .form-control::-webkit-input-placeholder {
      opacity: 1;
      transition: all 0.2s;
    }
    .has-float-label .form-control::-moz-placeholder {
      opacity: 1;
      transition: all 0.2s;
    }
    .has-float-label .form-control:-ms-input-placeholder {
      opacity: 1;
      transition: all 0.2s;
    }
    .has-float-label .form-control::placeholder {
      opacity: 1;
      transition: all 0.2s;
    }
    .has-float-label .form-control:placeholder-shown:not(:focus)::-webkit-input-placeholder {
      opacity: 0;
    }
    .has-float-label .form-control:placeholder-shown:not(:focus)::-moz-placeholder {
      opacity: 0;
    }
    .has-float-label .form-control:placeholder-shown:not(:focus):-ms-input-placeholder {
      opacity: 0;
    }
    .has-float-label .form-control:placeholder-shown:not(:focus)::placeholder {
      opacity: 0;
    }
    .has-float-label .form-control:placeholder-shown:not(:focus) + * {
      font-size: 100%;
      color: #6c757d;
      opacity: 1;
      top: 0.3em;
    }
    .input-group .has-float-label {
      flex-grow: 1;
      margin-bottom: 0;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .has-float-label .form-control:placeholder-shown:not(:focus) + * {
      margin-top: 6px;
    }
    .form-control {
  width: 512px;
  height: 56px;
  border-radius: 4px 4px 0px 0px;
  color: #1C1B1F;
  font-family: Montserrat;
  font-size: 16px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
}
    /* Custom CSS for styling */
    .login-container {
      margin-top: 20px;
    }
    .login-form {
      background-color: #fff;
      padding: 20px;
      border-radius: 8px;
      width: 87%;
      /* box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1); */
    }
    .login-form h2 {
      margin-bottom: 20px;
      color: #000;

/* TradeGothic/Bold/40px */
font-family: "TradeGothic LT Extended";
font-size: 40px;
font-style: normal;
font-weight: 700;
line-height: normal;
    }
    .login-form p{
        color: #121;

/* Montserrat/Regular/16px */
font-family: Montserrat;
font-size: 16px;
font-style: normal;
font-weight: 400;
line-height: normal;
opacity: 0.75;
    }
    /* .login-image {
      background-image: url('{{ asset('assets/img/login-banner.jpeg') }}');
      background-size: cover;
      background-position: center;
      width: 616px;
      height: 816px;
      border-radius: 30px;
    } */
    /* Adjustments */
    .form-group {
      margin-bottom: 20px; /* Add gap between form inputs */
    }
    .btn-primary {
      width: 100%; /* Make button full-width */
    }
    .has-float-label label, .has-float-label > span{
        color: #1C1B1F;

/* Montserrat/Regular/14px */
font-family: Montserrat;
font-size: 14px;
font-style: normal;
font-weight: 400;
line-height: normal;
    }
    .img-fluid {
  width: 616px;
  height: 680px;
  border-radius: 30px;
}
.btn.btn-primary {
  width: 512px;
  height: 48px;
  padding: 8px 16px;
  border-radius: 4px;
  background: #901111;
  border: none;
  color: #FFF;
  font-family: Montserrat;
  font-size: 14px;
  font-style: normal;
  font-weight: 600;
  line-height: normal;
}
.form-group.col-md-6.d-flex.justify-content-between.align-items-center .form-check {
    margin-bottom: 0; /* Remove default margin */
}
label[for="rememberMe"] {
    color: #121;
    font-family: Montserrat;
    /* font-size: 14px; */
    font-style: normal;
    font-weight: 500;
    line-height: normal;
}
.forgot-password {
  color: #FF8682;
  /* text-align: right; */
  font-family: Montserrat;
  /* font-size: 14px; */
  font-style: normal;
  font-weight: 500;
  line-height: normal;
  text-decoration: none;
}
.forgot-password:hover {
    color: #FF8682;
}
  </style>
</head>
<body>

<div class="container">
  <div class="row login-container align-items-center"> <!-- Added align-items-center -->
    <!-- Login Form Column -->
    <div class="col-md-6">
      <div class="login-form">
        <h2>Login</h2>
        <p class="">Login to access the G.B Residency</p> 
        <form class="mt-4" method="POST" action="{{ route('login') }}">
            @csrf

          <div class="form-row">
            <div class="form-group col-md-6">
              <span class="has-float-label">
                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" placeholder="Enter Email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                <label for="email">Email</label>
              </span>
              @error('email')
              <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
              </span>
          @enderror
            </div> 
            <div class="form-group col-md-6">
              <span class="has-float-label">
                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password"  placeholder="Enter Password" required autocomplete="current-password">
                <label for="password">Password</label>
              </span>
              @error('password')
              <span class="invalid-feedback" role="alert">
                  <strong>{{ $message }}</strong>
              </span>
          @enderror
            </div> 
            <div class="form-group col-md-12 d-flex justify-content-between align-items-center">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                    <label class="form-check-label" for="rememberMe">
                        Remember Me
                    </label>
                </div>
                @if (Route::has('password.request'))
                <a href="#" class="forgot-password">Forgot Password?</a>
                @endif
             </div>    
          </div>
          <button type="submit" class="btn btn-primary">Login</button>
        </form>
      </div>
    </div>
    <!-- Image Column -->
    <div class="col-md-6 login-image">
<img class="img-fluid" src="{{ asset('assets/img/login-banner.jpeg') }}" alt="login-banner"> 

    </div>
  </div>
</div>

<script src="{{ asset('assets/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js') }}"></script>

</body>
</html>
