<!DOCTYPE html>
<html lang="en">

	<head>
		<title>GBR - Hotel Booking Details</title>
     	@include("customer.head")
     	<link href="../../css/flags.css" rel="stylesheet">
     	<style>
     	    .label_back{
     	    background-color: #901111 !important ;color: #fff;
     	    }


     	    .success-receipt th{
     	        border:solid 1px gray;
     	        width:30%;
     	        padding-left:2%;
     	        background-color:#fafafa;
     	        color:#2c3e50;
     	        font-family: "Nunito", sans-serif;
     	        font-weight: 800;

     	    }
     	    .success-receipt td{
     	        border:solid 1px gray;
     	        width:40%;
     	        padding-left:2%;
     	        font-family: "Heebo", sans-serif;
     	        color:#14141f;
     	        font-weight: 400;

     	    }

     	    .success-receipt td{
     	        margin-top:5px;
     	    }


     	    @media only screen and (max-width: 600px){


     	    .center-table {
            margin-left: auto;
            margin-right: auto;

        }

     	    }

     	    @media only screen and (min-width: 600px){


     	    .center-table {
            margin-left: auto;
            margin-right: auto;
            width:70%;
        }

     	    }


     	   @media print {
    .abc {
        display: none;
    }



    body, .success-receipt {
        display: block !important;
    }
}

     	</style>
	</head>

	<body style="background-color:#fafafa;">
<body style="background-color:#fafafa;">
		<!-- Spinner Start -->
		<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
			<div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
				<span class="sr-only">Loading...</span>
			</div>
		</div>
		<!-- Spinner End -->

		<div class="abc">
	   @include("customer.header")
	   </div>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 col-lg-12 mb-4">
            <div class="card" style="border-radius: 12px; border:none; padding: 24px; box-shadow: 0px 4px 16px 0px #1122110D; ">
                <div class="card-body">

                    <div class="abc">

                    <h5 class="card-title">Payment Success</h5>
                    <p class="card-text">The Reservation Payment of ₹100 for the room type VIP has succeeded.</p>
                    <p class="card-text">You will receive the Reservation Payment Email to the Registered E-mail Id youremailid@gmail.com From orders@ccavenue.com </p>
                    <p class="card-text">Please be available Our team will contact you to make confirm the Reservation to your Registered mobile number </p>
                    <br>
                    <br>
                    </div>

                       <div class="success-receipt" style="align-self: center;">
                            <table class="center-table" >
                            <tbody>

                                <tr>
                                    <th colspan="2" style="text-align:center">APLodging Payment receipt</th>
                                </tr>

                                <tr>
                                    <th><strong>Order ID:</strong></th>
                                    <td>{{$response['order_id']}}</td>
                                </tr>

                                <tr>
                                    <th><strong>Registered Name:</strong></th>
                                    <td>{{$response['billing_name']}}</td>
                                </tr>

                                <tr>
                                    <th><strong>Registered E-mail:</strong></th>
                                    <td>{{$response['billing_email']}}</td>
                                </tr>

                                 <tr>
                                    <th><strong>Registered mobile:</strong></th>
                                    <td>{{$response['billing_tel']}}</td>
                                </tr>

                                <tr>
                                    <th><strong>Payment Status:</strong></th>
                                    <td>Success</td>
                                </tr>
                                <tr>
                                    <th><strong>Amount Paid:</strong></th>
                                    <td>₹{{$detail->reservationcharge}}</td>
                                </tr>

                                 <tr>
                                    <th><strong>Check In Date :</strong></th>
                                    <td>{{$detail->Checkindate}}</td>
                                </tr>

                                <tr>
                                    <th><strong>Check In Time :</strong></th>
                                    <td>{{$detail->checkintime}}</td>
                                </tr>

                                <tr>
                                    <th><strong>Room Type:</strong></th>
                                    <td>{{$detail->roomtype}}</td>
                                </tr>






                            </tbody>
                        </table>

                        </div>

                        <div class="abc" style="align-self: center;">

                            <center>


                        <a href="#" class="btn btn-primary" style="margin:2%; border-radius:10px;" onclick="window.print()">Download </a>

                    <a href="{{route('HomeSakthi.payment_details')}}" class="btn btn-primary" style="margin:2%; border-radius:10px;">Done</a>
                    </center>
            </div>
        </div>
    </div>
</div>


	</div>

	  </div>


	  <div class="abc">

	@include("customer.footer")
@include("customer.foot")
</div>

<script src="../../js/jquery.flagstrap.js"></script>

</body>





		</html>
