<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GBR - Hotel Cancellation Policy</title>
    <!-- Include head section from "customer.head" -->
    @include("customer.head")
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   <style>
        /* Custom Styles */
        body {
            font-family: 'Montserrat', sans-serif;
            color: #333;
            /*background-color: #f0f4f8;*/
            margin: 0;
            padding: 0;
        }
        h1 {
            color: #2c3e50;
            margin-top: 40px;
            text-align: center;
            font-weight: 700;
            font-size: 2.4rem;
        }
        h2 {
            color: #34495e;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            margin-top: 30px;
            font-size: 1.8rem;
        }
        p {
            line-height: 1.7;
            margin-bottom: 20px;
        }
        a {
            color: #3498db;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .r {
            background: #f0f4f8;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            margin-top: 40px;
        }
        .contact-info {
            margin-top: 40px;
            padding: 20px;
            background-color: #ecf0f1;
            border: 1px solid #bdc3c7;
            border-radius: 12px;
        }
        .contact-info h2 {
            color: #2c3e50;
            font-size: 1.6rem;
        }
        .contact-info p {
            margin: 10px 0;
        }
        .contact-info a {
            color: #3498db;
            text-decoration: none;
        }
        .contact-info a:hover {
            text-decoration: underline;
        }
        #spinner {
            background-color: rgba(255, 255, 255, 0.9);
            z-index: 1050;
        }
    </style>
</head>
<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

    <!-- Include header section from "customer.header" -->
    @include("customer.header")

    <!-- Main content section -->
    <div class="container r">
        <h1>Welcome to GBR - Hotel Cancellation Policy</h1>

        <p>This website is dedicated to providing you with the best hotel recommendations and information.</p>

        <h2>Cancellation Policy</h2>
        
    Cancellation Policy
       1. No cancellations are entertained for walk-in Customers. Cancellation / No-Show reservations - The reservation fee is not refundable.

        <p>If you have any questions about this Cancellation Policy, please contact us:</p>
        <ul>
            <li>Email: <a href="mailto:gbresidencymmlr1112@gmail.com">gbresidencymmlr1112@gmail.com</a></li>
            <li>Phone: 044 - 27528450,  9444539691</li>
            <li>Address: HOSPITAL ROAD, MELMARUVATHUR,CHENGALPATTU DIST - 603 319.</li>
        </ul>
    </div>

  
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
  <!-- Include footer section from "customer.footer" -->
    @include("customer.footer")

    <!-- Include foot section from "customer.foot" -->
    @include("customer.foot")

</html>
