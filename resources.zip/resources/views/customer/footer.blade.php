
@include("customer.loginregister")

 <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">

                <div class="col-lg-2 col-md-6" style="align-self: center;">
				    <img class="text-white mb-3" width="80%" src="{{ URL::asset('images/gbr_logo.png') }}">
                </div>
				<div class="col-lg-2 col-md-6"><br><br>
                    <h4 class="text-white mb-3">Our Destination</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>HOSPITAL ROAD, MELMARUVATHUR, <br>CHENGALPATTU DIST - 603 319.</p>
                </div>
                <div class="col-lg-2 col-md-6"><br><br>
                    <h4 class="text-white mb-3">Contact Us</h4>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3">&nbsp;&nbsp; 044 - 27528450,</i><br> <i class="fa fa-mobile-alt me-3"></i>+91 9444539691</p>
                </div>
                <div class="col-lg-3 col-md-6"><br><br>
                    <h4 class="text-white mb-3">E-mail Us</h4>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i><a style="color:#fff" href="mailto:adhiparasakthilodging@gmail.com"> gbresidencymmlr1112@gmail.com</a></p>
                </div>
				<div class="col-lg-2 col-md-6"><br><br>
                    <h4 class="text-white mb-3">Our policies</h4>
                    <a class="btn btn-link" href="{{route('HomeSakthi.terms')}}">Terms & Conditions</a>
                    <a class="btn btn-link" href="{{route('HomeSakthi.privacy')}}">Privacy policy</a>
                    <a class="btn btn-link" href="{{route('HomeSakthi.cancelpolicy')}}">cancellation policy</a>
                    <!--<a class="btn btn-link" href="#">Work with us</a>-->
                </div>
				<div class="col-lg-1 col-md-6"><br><br>
                    <h4 class="text-white mb-3">Followus</h4>
                    <div class="d-flex pt-2">
                        <a href="https://www.youtube.com/results?search_query=melmaruvathur+siddhar+peedam+youtube+channel" target="_blank" class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                        <!--<a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>-->
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-12 text-center text-md-start mb-3 mb-md-0">
					<center>&copy; <a class="border-bottom" href="#">GBResidency</a>, All Right Reserved.

                        <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
					Designed By <a target="_blank" class="border-bottom" href="https://kloudoz.com">Kloudoz Web Solution</a></center>
                    </div>
                    <!--<div class="col-md-6 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="">Home</a>
                            <a href="">Cookies</a>
                            <a href="">Help</a>
                            <a href="">FQAs</a>
                        </div>
                    </div>-->
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
