   <!--Login Modal -->
    <div class="modal fade" id="LoginModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
          
        <div class="modal-content">
            <form id="userlogin" action="{{route('HomeSakthi.login')}}" method="POST">
                @csrf
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">User Login</h5>
            <a type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </a>
          </div>
          <div class="modal-body">
              	<div class="row">
              	    <center><span style="color:red;font-weight:bold;font-size: 16px;" id="LogError"></span></center>
					<div class="col-lg-12 col-md-12">
					    <label>User Email</label>
					    <input type="text" name="email" id="logemail" class="form-control" placeholder="User Email">
					    <span style="color:red;font-weight:bold;font-size: 14px;" id="LogEmailError"></span><br>
					</div>
					<div class="col-lg-12 col-md-12">
					    <label>Password</label>
					    <input type="password" name="password" id="logpassword" class="form-control" placeholder="Password">
					    <span style="color:red;font-weight:bold;font-size: 14px;" id="LogPasswordError"></span>
					</div>
					
               </div>
          </div>
          <div>
            <!--<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>-->
           <center><button type="button" id="user_login" class="btn btn-primary" style="background-color:#901111; color:#fff; border: solid 1px #901111;">Login</button><br><br>
           Already Dont have a account <a data-target="#SignupModal" data-toggle="modal" style="color:#901111;" href="#">Sign Up</a> </center><br>
          </div>
          </form>
        </div>
      </div>
    </div>
    
    <!--Signup Modal -->
    <div class="modal fade" id="SignupModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
           <form id="userregister" action="{{ route('HomeSakthi.register') }}" method="POST">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">User Sign Up</h5>
        <a type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </a>
    </div>
    <div class="modal-body">
        <div class="row">
            @csrf
            <input type="hidden" name="form_name" value="{{ csrf_token('form_name') }}">
            <div class="col-lg-12 col-md-12">
                <label>User Name</label>
                <input type="text" name="name" id="name" class="form-control" placeholder="User Name" required>
                <span style="color:red;font-weight:bold;font-size: 14px;" id="NameError"></span><br>
            </div>
            <div class="col-lg-12 col-md-12">
                <label>User Email</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="User Email" required>
                <span style="color:red;font-weight:bold;font-size: 14px;" id="EmailError"></span><br>
            </div>
            <div class="col-lg-12 col-md-12">
                <label>Mobile No</label>
                <input type="text" name="phone" id="phone" class="form-control" placeholder="Mobile No" required>
                <span style="color:red;font-weight:bold;font-size: 14px;" id="PhoneError"></span><br>
            </div>
            <div class="col-lg-12 col-md-12">
                <label>Password</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
                <span style="color:red;font-weight:bold;font-size: 14px;" id="PasswordError"></span><br>
            </div>
            <div class="col-lg-12 col-md-12">
                <label>Confirm Password</label>
                <input type="password" name="password_confirmation" id="confirmpassword" class="form-control" placeholder="Confirm Password" required>
                <span style="color:red;font-weight:bold;font-size: 14px;" id="confirmpasswordError">Passwords do not match!</span>
            </div>
        </div>
    </div>
    <div>
        <center>
            <button type="submit" class="btn btn-primary" style="background-color:#901111; color:#fff; border: solid 1px #901111;">Register</button><br><br>
        </center>
    </div>
</form>

        </div>
      </div>
    </div>