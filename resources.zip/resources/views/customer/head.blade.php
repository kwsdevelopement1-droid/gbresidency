    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="{{ URL::asset('images/gbr_logo.png') }}" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="{{ URL::asset('lib/animate/animate.min.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('lib/owlcarousel/assets/owl.carousel.min.css') }}" rel="stylesheet">
    <link href="{{ URL::asset('lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css') }}" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="{{ URL::asset('css/bootstrap.min.css') }}" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="{{ URL::asset('css/style.css') }}" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
	<style>
    .dropdown {
	  width: 230px;
	  display: inline-block;
	  margin-right: 10px;
	  position: relative;
	  cursor: pointer;
	}
	.dropdown.toggle > input {
	  display: none;
	  cursor: pointer;
	}
	.dropdown > a, .dropdown.toggle > label {
	  border-radius: 2px;
	  /*box-shadow: 0 6px 5px -5px rgba(0,0,0,0.3);*/
	  cursor: pointer;
	}
	.dropdown > a::after, .dropdown.toggle > label::after {
	  content: "";
	  float: right;
	  margin: 15px 15px 0 0;
	  width: 0;
	  height: 0;
	  border-left: 5px solid transparent;
	  border-right: 5px solid transparent;
	  /*border-top: 10px solid #CCC;*/
	}
	.dropdown ul {
	  list-style-type: none;
	  display: block;
	  margin: 0;
	  padding: 0;
	  position: absolute;
	  width: 130%;
	  box-shadow: 0 6px 5px -5px rgba(0,0,0,0.3);
	  overflow: hidden;
	  cursor: pointer;
	  border-radius: 10px;
	}
	.dropdown a, .dropdown.toggle > label {
	  display: block;
	  padding: 0 0 0 10px;
	  text-decoration: none;
	  line-height: 40px;
	  font-size: 15px;
	  /*text-transform: uppercase;*/
	  font-weight: bold;
	  color: #999;
	  background-color: #FFF;
	}
	.dropdown li {
	  height: 0;
	  overflow: hidden;
	  transition: all 500ms;
	}
	.dropdown.hover li {
	  transition-delay: 300ms;
	}
	.dropdown li:first-child a {
	  border-radius: 2px 2px 0 0;
	}
	.dropdown li:last-child a {
	  border-radius: 0 0 2px 2px;
	}
	.dropdown li:first-child a::before {
	  content: "";
	  display: block;
	  position: absolute;
	  width: 0;
	  height: 0;
	  border-left: 10px solid transparent;
	  border-right: 10px solid transparent;
	  border-bottom: 10px solid #FFF;
	  margin: -10px 0 0 30px;
	}
	.dropdown a:hover, .dropdown.toggle > label:hover, .dropdown.toggle > input:checked ~ label {
	  background-color: #FFF;
	  color: #666;
	}
	.dropdown > a:hover::after, .dropdown.toggle > label:hover::after, .dropdown.toggle > input:checked ~ label::after {
	  border-top-color: #AAA;
	}
	.dropdown li:first-child a:hover::before {
	  border-bottom-color: #EEE;
	}
	.dropdown.hover:hover li, .dropdown.toggle > input:checked ~ ul li {
	  height: 40px;
	}
	.dropdown.hover:hover li:first-child, .dropdown.toggle > input:checked ~ ul li:first-child {
	  padding-top: 15px;
	}
	.footer_mail_box
	{
	    background-color:#F85C5C;
		width: 1270px;
		height: 260px;
		margin-bottom: -135px;
		position: relative;
		border-radius: 28px;
		padding: 25px;
	}
	.mail_box_img
	{
	    margin-top: -70px;
	}
	.img_logo{
	    width:8%;
	}
    @media only screen and (max-width: 600px)
	{
	    .footer_mail_box
		{
			background-color:#F85C5C;
			width: 100%;
			height: 504px;
			margin-bottom: -130px;
			position: relative;
			border-radius: 28px;
			padding: 25px;
		}
		.mail_box_img
		{
			margin-top: -25px;
		}
		.img_logo{
    	width: 30%;
        margin-left: 150px;
        margin-top: -35px;
    	}
		.modal-content {
            position: relative;
            display: flex;
            flex-direction: column;
            width: 100%;
            pointer-events: auto;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid rgba(0, 0, 0, 0.2);
            border-radius: 0.3rem;
            outline: 0;
        }
        .dropdown {
            width: 230px;
            display: inline-block;
            margin-right: 10px;
            position: relative;
            cursor: pointer;
            margin-left: 156px;
            margin-bottom: 140px;
        }
        .dropdown a, .dropdown.toggle > label {
            display: block;
            padding: 0 0 0 10px;
            text-decoration: none;
            line-height: 40px;
            font-size: 15px;
            /* text-transform: uppercase; */
            font-weight: bold;
            color: #999;
            background-color: #FFF;
            /*margin-top: -50px;*/
        }
        .dropup, .dropend, .dropdown, .dropstart {
            /*position: relative;*/
            margin-top: -50px;
        }
        .favorite_top
        {
            	margin-bottom: -120px;
        }
	}
	</style>
