<!-- Navbar & Hero Start -->
<div class="container-fluid position-relative p-0">
    <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
        <a href="{{route('HomeSakthi.index')}}" class="navbar-brand p-0">
            <!--<h5><img src="{{ URL::asset('images/ion_bed.svg') }}"> Find Stays</h5>-->
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        </a>


        <div class="col-lg-8 text-center">
            <a href="{{route('HomeSakthi.index')}}">
            <img class="img_logo" src="{{ URL::asset('images/gbr_logo.png') }}">
            </a>
            </div>
        <div class="col-lg-1 text-center">
            @auth('onlineusers')
            <a href="{{route('HomeSakthi.favorites')}}">
                <img src="{{ URL::asset('images/heart_black_icon.png') }}">
                <span style="color:#000"> Favourites </span>
            </a>
             @else
             <a data-target="#LoginModal" data-toggle="modal">
                 <img src="{{ URL::asset('images/heart_black_icon.png') }}">
                <span style="color:#000"> Favourites </span>
             </a>
             @endauth
        </div>

        @auth('onlineusers')
            <div class="col-lg-3 text-center dropdown toggle">
                <br>
                <input id="t1" type="checkbox">
                <label for="t1">  @if(Auth::guard('onlineusers')->user()->profile == null)
                    <img src="{{ URL::asset('images/user_icon.png') }}" style="width:45px;height:45px;">
                    @else
                     <img src="{{Auth::guard('onlineusers')->user()->profile}}" style="width:45px;height:45px;border-radius:50%;">
                     @endif {{ Auth::guard('onlineusers')->user()->name }}</label>
                <ul>
                    <!--<li><a href="#"><img src="{{ URL::asset('images/user_icon.svg') }}" style="margin-top: -30px;"> {{ Auth::guard('onlineusers')->user()->name }}</a></li>-->
                    <li><a style="margin-top: -10px;" href="#"><img src="{{ URL::asset('images/user.svg') }}"> My account <img style="margin-left: 30px;" src="{{ URL::asset('images/chevron_forward.svg') }}"></a></li>
                    <li><a href="{{ route('HomeSakthi.payment_details') }}"><img src="{{ URL::asset('images/card.svg') }}"> Payments <img style="margin-left: 37px;" src="{{ URL::asset('images/chevron_forward.svg') }}"></a></li>
                    <li><a href="{{ route('HomeSakthi.settings') }}"><img src="{{ URL::asset('images/settings.svg') }}"> Settings <img style="margin-left: 46px;" src="{{ URL::asset('images/chevron_forward.svg') }}"></a></li>
                    <!--<li><a href="#"><img src="{{ URL::asset('images/support.svg') }}"> Support <img style="margin-left: 49px;" src="{{ URL::asset('images/chevron_forward.svg') }}"></a></li>-->
                    <li><a href="{{ route('HomeSakthi.logout') }}"><img src="{{ URL::asset('images/logout.svg') }}"> Logout <img style="margin-left: 52px;" src="{{ URL::asset('images/chevron_forward.svg') }}"></a></li>
                </ul>
            </div>
        @else
            <button data-target="#LoginModal" data-toggle="modal" style="border-radius: 8px; background: #FFF; color:#000; width: 50px; padding: 5px; border: 1px solid #901111;" onclick="toggleHeartIcon()">
              <center>Login</center>
            </button>
        @endauth

        <!--<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="fa fa-bars"></span>
        </button>-->
    </nav>
</div>
<!-- Navbar & Hero End -->
