<!DOCTYPE html>
<html lang="en">
<head>
    <title>APL - Hotel Booking Details</title>
    @include("customer.head")
    <link href="{{ URL::asset('css/flags.css') }}" rel="stylesheet">
    <link rel='stylesheet' href="{{ URL::asset('css/bootstrap-datepicker.min.css') }}">
    <link rel="stylesheet" href="{{ URL::asset('css/flatpickr.min.css') }}">
    <style>
        .label_back {
            background-color: #901111 !important;
            color: #fff;
        }
        .dropdown-menu {
            position: absolute;
            z-index: 1000;
            display: none;
            min-width: 10rem;
            padding: 0.5rem 0;
            margin: 0;
            font-size: 1rem;
            color: #14141f;
            text-align: left;
            list-style: none;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid rgba(0, 0, 0, 0.15);
            border-radius: 0px;
        }
        .flatpickr-day.disabled {
            background: #ffdddd;
            color: #ff0000;
            border-radius: 50%;
            opacity: 1;
            cursor: not-allowed;
        }
        .flatpickr-day.today {
            background: #3279f3;
            color: #032256;
            border-radius: 50%;
        }
    </style>
</head>
<body style="background-color:#fafafa;">
    
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

    @include("customer.header")
    <?php use Carbon\Carbon; ?>

    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-3">
                <p><a href="{{route('HomeSakthi.index')}}" style="color:#FF8682;">Home </a>&nbsp; <img src="../../images/rightarrowicon.png" alt="">&nbsp;<a href="{{ route('HomeSakthi.room_detail', ['room' => $room->id]) }}" style="color:#FF8682;">{{$room->roomname}}&nbsp;</a> <img src="../../images/rightarrowicon.png" alt="">&nbsp;Booking</p>

                <div class="col-lg-7 col-md-8" style="box-shadow: 0px 4px 16px 0px #1122110D; background-color:#ffffff; padding:24px; border-radius:12px;">
                    <table width="100%">
                        <tr>
                            <td width="60%">
                                <p>Room Type : <span style="color:#FF8682">{{$room->roomname}}</span></p>
                            </td>
                            <td width="40%" style="">
                                <p style="color:#FF8682; text-align:right;"><span style="color:#000;">Room Rent : &nbsp;</span>₹{{$room->roomprice}}/night </p>
                            </td>
                        </tr>

                        <tr>
                            <td width="60%">
                                <p> Number Of PAX : <span style="color:#FF8682">{{$room->no_tax}} (Additional charges for guests above 10 years old.)</span></p>
                            </td>
                            <td width="40%" style="">
                                <p style="color:#FF8682; text-align:right;"><span style="color:#000;">Reservation Charge : </span> ₹{{$room->reservationprice}} </p>
                            </td>
                        </tr>
                    </table>

                    <div style="border: solid 1px #901111; border-radius: 10px;">
                        <form action="{{route('HomeSakthi.onlinereservation',['room' => $room->id])}}" method="POST">
                            @csrf
                            <table width="100%">
                                <tr>
                                    <td width="20%" style="text-align:center"> <h6>Note :</h6></td>
                                    <td width="80%" style="padding:10px;">
                                        <h6>Adhiparasakthi Lodging</h6>
                                        <p>Users need to pay only the Reservation Charges right here <span style="color:red; font-weight:600">(Those reservation charges are not included with the room rent)</span> You need to pay the room rent at the APLodging's reception,  After Reservation Our team will contact you and make confirm your Reservation. </p>
                                    </td>
                                </tr>
                            </table>
                    </div>
                    <br>
                    <table width="100%">
                        <tr>
                            <td width="50%" style="padding-bottom: 10px;">
                                <div class="form-group">
                                    <label class="form-control label_back" for="checkinDate">Check-in Date :</label>
                                    <input class="form-control" type="text" id="checkindate" name="Checkindate" required>
                                </div>
                            </td>
                            <td width="50%">
                                <div class="form-group" style="padding-bottom: 10px;">
                                    <label class="form-control label_back" for="checkoutDate" >Check-out Date :</label>
                                    <input class="form-control" type="text" id="checkoutdate" name="checkoutdate"  required>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td width="50%" style="padding-bottom: 10px;">
                                <div class="form-group">
                                    <label class="form-control label_back" for="checkintime">Check-in Time :</label>
                                    <input class="form-control" type="time" id="checkintime" min="" name="checkintime" required>
                                </div>
                            </td>

                            <td width="50%" style="padding-bottom: 10px;">
                                <div class="form-group">
                                    <label class="form-control label_back" for="checkintime">Check-out Time :</label>
                                    <input class="form-control" type="time" id="checkouttime" min="" name="checkouttime" required>
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td width="50%" style="padding-bottom: 10px;">
                                <div class="form-group">
                                    <label class="form-control label_back" for="billingaddress">Billing Address : </label>
                                    <textarea class="form-control" id="billing_address" name="billing_address"></textarea>
                                </div>
                            </td>

                            <td width="50%" style="padding-bottom: 10px;">
                                <div class="form-group">
                                    <label class="form-control label_back" for="billingcity">Billing City :</label>
                                    <input class="form-control" type="text" id="billing_city" name="billing_city">
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <td width="50%" style="padding-bottom: 10px;">
                                <div class="form-group">
                                    <label class="form-control label_back" for="billingstate">Billing State : </label>
                                    <input class="form-control" type="text" id="billing_state" name="billing_state">
                                </div>
                            </td>

                            <td width="50%" style="padding-bottom: 10px;">
                                <div class="form-group">
                                    <label class="form-control label_back" for="billingzip">Billing Zip :</label>
                                    <input class="form-control" type="text" id="billing_zip" name="billing_zip">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td width="50%" style="padding-bottom: 10px;">
                                <div class="form-group">
                                    <label class="form-control label_back" for="billingcountry">Billing Country : </label>
                                    <select id="orderBillCountry" class="form-control" name="billing_country"  aria-required="true" aria-invalid="false">
											<option value="" selected="selected">
												Select Country
											</option>
											
												<option value="Afghanistan">Afghanistan</option>
											
												<option value="Aland Islands">Aland Islands</option>
											
												<option value="Albania">Albania</option>
											
												<option value="Algeria">Algeria</option>
											
												<option value="American Samoa">American Samoa</option>
											
												<option value="Andorra">Andorra</option>
											
												<option value="Angola">Angola</option>
											
												<option value="Anguilla">Anguilla</option>
											
												<option value="Antarctica">Antarctica</option>
											
												<option value="Antigua and Barbuda">Antigua and Barbuda</option>
											
												<option value="Argentina">Argentina</option>
											
												<option value="Armenia">Armenia</option>
											
												<option value="Aruba">Aruba</option>
											
												<option value="Australia">Australia</option>
											
												<option value="Austria">Austria</option>
											
												<option value="Azerbaijan">Azerbaijan</option>
											
												<option value="Bahamas">Bahamas</option>
											
												<option value="Bahrain">Bahrain</option>
											
												<option value="Bangladesh">Bangladesh</option>
											
												<option value="Barbados">Barbados</option>
											
												<option value="Belarus">Belarus</option>
											
												<option value="Belgium">Belgium</option>
											
												<option value="Belize">Belize</option>
											
												<option value="Benin">Benin</option>
											
												<option value="Bermuda">Bermuda</option>
											
												<option value="Bhutan">Bhutan</option>
											
												<option value="Bolivia">Bolivia</option>
											
												<option value="Bonaire">Bonaire</option>
											
												<option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
											
												<option value="Botswana">Botswana</option>
											
												<option value="Bouvet Island">Bouvet Island</option>
											
												<option value="Brazil">Brazil</option>
											
												<option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
											
												<option value="Brunei Darussalam">Brunei Darussalam</option>
											
												<option value="Bulgaria">Bulgaria</option>
											
												<option value="Burkina Faso">Burkina Faso</option>
											
												<option value="Burundi">Burundi</option>
											
												<option value="Cambodia">Cambodia</option>
											
												<option value="Cameroon">Cameroon</option>
											
												<option value="Canada">Canada</option>
											
												<option value="Cape Verde">Cape Verde</option>
											
												<option value="Cayman Islands">Cayman Islands</option>
											
												<option value="Central African Republic">Central African Republic</option>
											
												<option value="Chad">Chad</option>
											
												<option value="Chile">Chile</option>
											
												<option value="China">China</option>
											
												<option value="Christmas Island">Christmas Island</option>
											
												<option value="Cocos Islands">Cocos Islands</option>
											
												<option value="Colombia">Colombia</option>
											
												<option value="Comoros">Comoros</option>
											
												<option value="Congo">Congo</option>
											
												<option value="Democratic Republic of the Congo">Democratic Republic of the Congo</option>
											
												<option value="Cook Islands">Cook Islands</option>
											
												<option value="Costa Rica">Costa Rica</option>
											
												<option value="Cote dIvoire">Cote dIvoire</option>
											
												<option value="Croatia">Croatia</option>
											
												<option value="Cuba">Cuba</option>
											
												<option value="Curacao">Curacao</option>
											
												<option value="Cyprus">Cyprus</option>
											
												<option value="Czech Republic">Czech Republic</option>
											
												<option value="Denmark">Denmark</option>
											
												<option value="Djibouti">Djibouti</option>
											
												<option value="Dominica">Dominica</option>
											
												<option value="Dominican Republic">Dominican Republic</option>
											
												<option value="Ecuador">Ecuador</option>
											
												<option value="Egypt">Egypt</option>
											
												<option value="El Salvador">El Salvador</option>
											
												<option value="Equatorial Guinea">Equatorial Guinea</option>
											
												<option value="Eritrea">Eritrea</option>
											
												<option value="Estonia">Estonia</option>
											
												<option value="Ethiopia">Ethiopia</option>
											
												<option value="Falkland Islands">Falkland Islands</option>
											
												<option value="Faroe Islands">Faroe Islands</option>
											
												<option value="Fiji">Fiji</option>
											
												<option value="Finland">Finland</option>
											
												<option value="France">France</option>
											
												<option value="French Guiana">French Guiana</option>
											
												<option value="French Polynesia">French Polynesia</option>
											
												<option value="French Southern Territories">French Southern Territories</option>
											
												<option value="Gabon">Gabon</option>
											
												<option value="Gambia">Gambia</option>
											
												<option value="Georgia">Georgia</option>
											
												<option value="Germany">Germany</option>
											
												<option value="Ghana">Ghana</option>
											
												<option value="Gibraltar">Gibraltar</option>
											
												<option value="Greece">Greece</option>
											
												<option value="Greenland">Greenland</option>
											
												<option value="Grenada">Grenada</option>
											
												<option value="Guadeloupe">Guadeloupe</option>
											
												<option value="Guam">Guam</option>
											
												<option value="Guatemala">Guatemala</option>
											
												<option value="Guernsey">Guernsey</option>
											
												<option value="Guinea">Guinea</option>
											
												<option value="Guinea Bissau">Guinea Bissau</option>
											
												<option value="Guyana">Guyana</option>
											
												<option value="Haiti">Haiti</option>
											
												<option value="Heard Island and McDonald Islands">Heard Island and McDonald Islands</option>
											
												<option value="Vatican City">Vatican City</option>
											
												<option value="Honduras">Honduras</option>
											
												<option value="Hong Kong">Hong Kong</option>
											
												<option value="Hungary">Hungary</option>
											
												<option value="Iceland">Iceland</option>
											
												<option value="India">India</option>
											
												<option value="Indonesia">Indonesia</option>
											
												<option value="Iran">Iran</option>
											
												<option value="Iraq">Iraq</option>
											
												<option value="Ireland">Ireland</option>
											
												<option value="Isle of Man">Isle of Man</option>
											
												<option value="Israel">Israel</option>
											
												<option value="Italy">Italy</option>
											
												<option value="Jamaica">Jamaica</option>
											
												<option value="Japan">Japan</option>
											
												<option value="Jersey">Jersey</option>
											
												<option value="Jordan">Jordan</option>
											
												<option value="Kazakhstan">Kazakhstan</option>
											
												<option value="Kenya">Kenya</option>
											
												<option value="Kiribati">Kiribati</option>
											
												<option value="North Korea">North Korea</option>
											
												<option value="South Korea">South Korea</option>
											
												<option value="Kuwait">Kuwait</option>
											
												<option value="Kyrgyzstan">Kyrgyzstan</option>
											
												<option value="Laos">Laos</option>
											
												<option value="Latvia">Latvia</option>
											
												<option value="Lebanon">Lebanon</option>
											
												<option value="Lesotho">Lesotho</option>
											
												<option value="Liberia">Liberia</option>
											
												<option value="Libya">Libya</option>
											
												<option value="Liechtenstein">Liechtenstein</option>
											
												<option value="Lithuania">Lithuania</option>
											
												<option value="Luxembourg">Luxembourg</option>
											
												<option value="Macao">Macao</option>
											
												<option value="Republic of Macedonia">Republic of Macedonia</option>
											
												<option value="Madagascar">Madagascar</option>
											
												<option value="Malawi">Malawi</option>
											
												<option value="Malaysia">Malaysia</option>
											
												<option value="Maldives">Maldives</option>
											
												<option value="Mali">Mali</option>
											
												<option value="Malta">Malta</option>
											
												<option value="Marshall Islands">Marshall Islands</option>
											
												<option value="Martinique">Martinique</option>
											
												<option value="Mauritania">Mauritania</option>
											
												<option value="Mauritius">Mauritius</option>
											
												<option value="Mayotte">Mayotte</option>
											
												<option value="Mexico">Mexico</option>
											
												<option value="Federated States of Micronesia">Federated States of Micronesia</option>
											
												<option value="Moldova">Moldova</option>
											
												<option value="Monaco">Monaco</option>
											
												<option value="Mongolia">Mongolia</option>
											
												<option value="Montenegro">Montenegro</option>
											
												<option value="Montserrat">Montserrat</option>
											
												<option value="Morocco">Morocco</option>
											
												<option value="Mozambique">Mozambique</option>
											
												<option value="Myanmar">Myanmar</option>
											
												<option value="Namibia">Namibia</option>
											
												<option value="Nauru">Nauru</option>
											
												<option value="Nepal">Nepal</option>
											
												<option value="Netherlands">Netherlands</option>
											
												<option value="New Caledonia">New Caledonia</option>
											
												<option value="New Zealand">New Zealand</option>
											
												<option value="Nicaragua">Nicaragua</option>
											
												<option value="Niger">Niger</option>
											
												<option value="Nigeria">Nigeria</option>
											
												<option value="Niue">Niue</option>
											
												<option value="Norfolk Island">Norfolk Island</option>
											
												<option value="Northern Mariana Islands">Northern Mariana Islands</option>
											
												<option value="Norway">Norway</option>
											
												<option value="Oman">Oman</option>
											
												<option value="Pakistan">Pakistan</option>
											
												<option value="Palau">Palau</option>
											
												<option value="Palestine">Palestine</option>
											
												<option value="Panama">Panama</option>
											
												<option value="Papua New Guinea">Papua New Guinea</option>
											
												<option value="Paraguay">Paraguay</option>
											
												<option value="Peru">Peru</option>
											
												<option value="Philippines">Philippines</option>
											
												<option value="Pitcairn">Pitcairn</option>
											
												<option value="Poland">Poland</option>
											
												<option value="Portugal">Portugal</option>
											
												<option value="Puerto Rico">Puerto Rico</option>
											
												<option value="Qatar">Qatar</option>
											
												<option value="Reunion">Reunion</option>
											
												<option value="Romania">Romania</option>
											
												<option value="Russian Federation">Russian Federation</option>
											
												<option value="Rwanda">Rwanda</option>
											
												<option value="Saint Barthelemy">Saint Barthelemy</option>
											
												<option value="Saint Helena">Saint Helena</option>
											
												<option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
											
												<option value="Saint Lucia">Saint Lucia</option>
											
												<option value="Saint Martin">Saint Martin</option>
											
												<option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
											<option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
											<option value="Samoa">Samoa</option>
											<option value="San Marino">San Marino</option>
											<option value="Sao Tome and Principe">Sao Tome and Principe</option>
											<option value="Saudi Arabia">Saudi Arabia</option>
											<option value="Senegal">Senegal</option>
											<option value="Serbia">Serbia</option>
											<option value="Seychelles">Seychelles</option>
											<option value="Sierra Leone">Sierra Leone</option>
											<option value="Singapore">Singapore</option>
											<option value="Sint Maarten Dutch part">Sint Maarten Dutch part</option>
											<option value="Slovakia">Slovakia</option>
											<option value="Slovenia">Slovenia</option>
											<option value="Solomon Islands">Solomon Islands</option>
											<option value="Somalia">Somalia</option>
											<option value="South Africa">South Africa</option>
											<option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
											<option value="South Sudan">South Sudan</option>
											<option value="Spain">Spain</option>
											<option value="Sri Lanka">Sri Lanka</option>
											<option value="Sudan">Sudan</option>
											<option value="Suriname">Suriname</option>
											<option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
											<option value="Swaziland">Swaziland</option>
											<option value="Sweden">Sweden</option>
											<option value="Switzerland">Switzerland</option>
											<option value="Syrian Arab Republic">Syrian Arab Republic</option>
											<option value="Taiwan">Taiwan</option>
											<option value="Tajikistan">Tajikistan</option>
											<option value="Tanzania">Tanzania</option>
											<option value="Thailand">Thailand</option>
											<option value="East Timor">East Timor</option>
											<option value="Togo">Togo</option>
											<option value="Tokelau">Tokelau</option>
											<option value="Tonga">Tonga</option>
											<option value="Trinidad and Tobago">Trinidad and Tobago</option>
											<option value="Tunisia">Tunisia</option>
											<option value="Turkey">Turkey</option>
											<option value="Turkmenistan">Turkmenistan</option>
											<option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
											<option value="Tuvalu">Tuvalu</option>
											<option value="Uganda">Uganda</option>
											<option value="Ukraine">Ukraine</option>
											<option value="United Arab Emirates">United Arab Emirates</option>
											<option value="United Kingdom">United Kingdom</option>
											<option value="United States">United States</option>
											<option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
											<option value="Uruguay">Uruguay</option>
											<option value="Uzbekistan">Uzbekistan</option>
											<option value="Vanuatu">Vanuatu</option>
											<option value="Venezuela">Venezuela</option>
											<option value="Viet Nam">Viet Nam</option>
											<option value="British Virgin Islands">British Virgin Islands</option>
											<option value="United States Virgin Islands">United States Virgin Islands</option>
											<option value="Wallis and Futuna">Wallis and Futuna</option>
											<option value="Western Sahara">Western Sahara</option>
											<option value="Yemen">Yemen</option>
											<option value="Zambia">Zambia</option>
											<option value="Zimbabwe">Zimbabwe</option>
											
		</select>
                                </div>
                            </td>
                           <td width="50%" style="padding-bottom: 10px;">
                                <div class="form-group">
                                    <label class="form-control label_back" for="idproof">ID PROOF :</label>
                                    <input class="form-control" type="text" id="idproof" name="idproof" required>
                                </div>
                            </td>
                        </tr>
                    </table>
                    <br>
                    <input type="submit" style="background-color: #901111; color: #fff; border-radius: 10px; padding: 10px; width: 100%; text-align:center;" value="Pay And Reserve">
                </form>
                <br>
                </div>

                <div class="col-lg-1 col-md-8"></div>

                <div class="col-lg-4 col-md-4" style="box-shadow: 0px 4px 16px 0px #1122110D; background-color:#ffffff; padding:24px; border-radius:12px;">
                    <center><h4>Booking Details</h4></center>
                    <table>
                        <tr>
                            <td style="padding: 20px;">
                                <img src="{{ asset('storage/siteimages/'. $room->single_image) }}" style="height:120px; width:120px;" alt="">
                            </td>
                            <td>
                                Adhiparasakthi Lodging<br><br>
                                <h6>Room Type : <span style="color:#FF8682">{{$room->roomname}}</span></h6>
                            </td>
                        </tr>
                    </table>
                    
                    <p><b></b></p>
                    <hr>
                    <h5>Price Details</h5><br>
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            Reservation Charge  :
                        </div>
                        <div class="col-lg-6 col-md-6" align="right">
                            ₹{{$room->reservationprice}}
                        </div><br>
                        <br><hr>
                        <div class="col-lg-6 col-md-6">
                            Total
                        </div>
                        <div class="col-lg-6 col-md-6" align="right">
                            ₹{{$room->reservationprice}}
                        </div>
                    </div>
                    <hr>
                </div>
            </div>
        </div>
    </div>  

    <!-- About End -->
    <!--<div class="container">
        <div class="row footer_mail_box wow fadeInUp" data-wow-delay="0.1s">
            <div class="col-lg-6 col-md-6">
                <h1>Subscribe Newsletter</h1>
                <h5>The Travel</h5>
                <p>Get inspired! Receive travel discounts, tips and behind the scenes stories.</p>
                <div class="row g-3">
                    <div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
                        <div class="form-floating">
                            <input type="text" name="emil" placeholder="Your Email Address" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
                        <button class="btn btn-dark w-100 py-3" type="submit">Subcribe</button>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <center><img class="img-fluid mail_box_img" src="../../images/open_mailbox.png" alt=""></center>
            </div><br><br><br>
        </div>
    </div>-->

    @include("customer.footer")
    @include("customer.foot")
    <script src="{{ URL::asset('js/bootstrap-datepicker.min.js') }}"></script>
    <script src="{{ URL::asset('js/flatpickr.js') }}"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Array of blocked dates in yyyy-mm-dd format
            var blockedDates = [
               @foreach($blockdates as $block)
                '{{ \Carbon\Carbon::parse($block->blockdate)->format('Y-m-d') }}',
            @endforeach
            ];

            // Function to parse dates accurately
            function parseDateString(dateString) {
                const [year, month, day] = dateString.split('-');
                return new Date(year, month - 1, day);
            }

            // Minimum check-in date is 15 days from today 
            var minCheckinDate = new Date();
            minCheckinDate.setDate(minCheckinDate.getDate() + 15);
            
            // Maximum check-out date is 60 days from today 
            var maxCheckinDate = new Date();
            maxCheckinDate.setDate(maxCheckinDate.getDate() + 75);

            // Current date
            var today = new Date();
            today.setHours(0, 0, 0, 0);

            var checkinPicker = flatpickr("#checkindate", {
                disable: blockedDates.map(parseDateString),
                dateFormat: "d-m-Y",
                minDate: minCheckinDate,
                maxDate: maxCheckinDate,
                onDayCreate: function(dObj, dStr, fp, dayElem) {
                    let dateStr = fp.formatDate(dayElem.dateObj, 'd-m-Y');
                    if (blockedDates.includes(dateStr)) {
                        dayElem.classList.add('disabled');
                    }
                    if (dayElem.dateObj.getTime() === today.getTime()) {
                        dayElem.classList.add('today');
                    }
                },
                onChange: function(selectedDates) {
                    var checkinDate = selectedDates[0];
                    if (checkinDate) {
                        checkoutPicker.set("minDate", new Date(checkinDate.getTime() + 24 * 60 * 60 * 1000)); // Checkout date must be at least 1 day after check-in
                    }
                }
            });

            var checkoutPicker = flatpickr("#checkoutdate", {
                dateFormat: "d-m-Y",
                maxDate: maxCheckinDate,
                onDayCreate: function(dObj, dStr, fp, dayElem) {
                    // Highlight current date in checkout calendar
                    if (dayElem.dateObj.getTime() === today.getTime()) {
                        dayElem.classList.add('today');
                    }
                }
            });
        });
    </script>
</body>
</html>
