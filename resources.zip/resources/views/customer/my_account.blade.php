<!DOCTYPE html>
<html lang="en">
	
	<head>
		<title>APL - Hotel Favorites</title>
		@include("customer.head")
	</head>
	
	<body>
		<!-- Spinner Start -->
		<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
			<div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
				<span class="sr-only">Loading...</span>
			</div>
		</div>
		<!-- Spinner End -->
		
		
		@include("customer.header")
	
		
		<!-- About Start -->
		
		
		<div class="container-xxl py-5">
			<div class="container">
	     <h2>MY ACCOUNT</h2>
				
	
			
		
    <div class="table-responsive">
        <table class="table table-bordered">
           
                <tr>  <th class="text-center" scope="col" rowspan="">PROFILE</th>
                <tr>  <th class="text-center" scope="col" rowspan="4"><img width="130px;" src="{{$User->profile}}"></th>
                    <th scope="col">NAME</th>
                      <td>{{$User->name}}</td>
                     
                    </tr>
                     <tr>
                    <th scope="col">EMAIL</th>
                      <td>{{$User->email}}</td>
                      </tr>
                        <tr>
                    <th scope="col">PHONE</th>
                     <td>{{$User->phone}}</td>
                  </tr>
                    <th scope="col">ACTION</th>
                    <td><button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editModal">Edit</button></td>
                </tr>

        </table>
    </div>

		</div>
	</div>	
			<!-- Modal -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form id="editUserForm" action="{{ route('HomeSakthi.my_account_save') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="modal-header">
          <h5 class="modal-title" id="editModalLabel">Edit Profile</h5>
          <a type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </a>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-lg-12 col-md-12">
              <label for="name">Name</label>
              <input type="text" name="name" id="name" class="form-control" value="{{ $User->name }}">
              <span style="color:red;font-weight:bold;font-size: 14px;" id="nameError"></span><br>
            </div>
           
            <div class="col-lg-12 col-md-12">
              <label for="phone">Phone</label>
              <input type="text" name="phone" id="phone" class="form-control" value="{{ $User->phone }}">
              <span style="color:red;font-weight:bold;font-size: 14px;" id="phoneError"></span>
            </div>
            <div class="col-lg-12 col-md-12">
              <label for="profile">Profile Image</label>
              <input type="file" name="profile" id="profile" class="form-control" >
              <span style="color:red;font-weight:bold;font-size: 14px;" id="phoneError"></span>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" style="background-color:#901111; color:#fff; border: solid 1px #901111;">Save changes</button>
        </div>
      </form>
    </div>
  </div>
</div>

	
				
				
				@include("customer.footer")
				
				@include("customer.foot")
				
			</body>
			
		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('.favorite-button').on('click', function() {
        var button = $(this);
        var roomId = button.data('room-id');

        $.ajax({
            url: '{{ route('HomeSakthi.favorites.store') }}',
            type: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                room_id: roomId,
                user_id: '{{ auth("onlineusers")->id() }}'
            },
            success: function(response) {
                console.log('Response:', response); // Log response for debugging

                if (response.success) {
                    var blackHeart = $('#blackHeart-' + roomId);
                    var whiteHeart = $('#whiteHeart-' + roomId);
                    
                    if (response.is_favorite) {
                        blackHeart.show();
                        whiteHeart.hide();
                    } else {
                        blackHeart.hide();
                        whiteHeart.show();
                    }
                } else {
                    alert('An error occurred: ' + response.error); // Display error message
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error); // Log AJAX error to console
                alert('AJAX Error occurred. Check console for details.'); // Alert user about AJAX error
            }
        });
    });
});
</script>

			
		</html>		