<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GBR- Hotel Privacy Policy</title>
    <!-- Include head section from "customer.head" -->
    @include("customer.head")
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Custom Styles */
        body {
            font-family: 'Montserrat', sans-serif;
            color: #333;
            /*background-color: #f0f4f8;*/
            margin: 0;
            padding: 0;
        }
        h1 {
            color: #2c3e50;
            margin-top: 40px;
            text-align: center;
            font-weight: 700;
            font-size: 2.4rem;
        }
        h2 {
            color: #34495e;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            margin-top: 30px;
            font-size: 1.8rem;
        }
        p {
            line-height: 1.7;
            margin-bottom: 20px;
        }
        a {
            color: #3498db;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .r {
            background: #f0f4f8;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            margin-top: 40px;
        }
        .contact-info {
            margin-top: 40px;
            padding: 20px;
            background-color: #ecf0f1;
            border: 1px solid #bdc3c7;
            border-radius: 12px;
        }
        .contact-info h2 {
            color: #2c3e50;
            font-size: 1.6rem;
        }
        .contact-info p {
            margin: 10px 0;
        }
        .contact-info a {
            color: #3498db;
            text-decoration: none;
        }
        .contact-info a:hover {
            text-decoration: underline;
        }
        #spinner {
            background-color: rgba(255, 255, 255, 0.9);
            z-index: 1050;
        }
    </style>
</head>
<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

    <!-- Include header section from "customer.header" -->
    @include("customer.header")

    <!-- Main content section -->
    <div class="container r">
        <h1>Privacy Policy</h1>
        <p><strong>Effective Date:</strong> [01-05-2024]</p>

        <p>Welcome to GB Residency. By using our website, <a href="https://gbresidency.in" target="_blank">https://gbresidency.in</a>, you agree to these terms.</p>

        <p>1. ⁠Information Collection: We collect personal data for booking and providing services, including name, contact information, and payment details</p>
        

        <p>2.⁠ ⁠Use of Information: Your data is used to process bookings, provide customer support, and communicate with you. We do not sell or rent your information to third part</p>
        

        <p>3.⁠ ⁠Data Protection: We implement security measures to protect your data from unauthorized access, alteration, or disclos</p>
        

        <p>4.⁠ ⁠Cookies: Our website uses cookies to enhance your experience. You can manage cookie settings through your browse</p>
        

        <p>5.⁠ ⁠Third-Party Links: Our site may contain links to other websites. We are not responsible for the privacy practices of these external site</p>
        

        <p>6.⁠ ⁠Your Rights: You have the right to access, correct, or delete your personal information. To exercise these rights, please contact us at adhiparasakthilodging@gmail.co</p>
        

        <p>7.⁠ ⁠Changes: We may update this policy periodically. Changes will be posted on our website.</p>
        
        <p>These terms are governed by the laws of Tamil Nadu.</p>

        <div class="contact-info">
            <h2>Contact Us</h2>
            <p>Email: <a href="mailto:gbresidencymmlr1112@gmail.com">gbresidencymmlr1112@gmail.com</a></p>
            <p>Phone: 044 - 27528450,  9444539691</p>
            <p>Address: HOSPITAL ROAD, MELMARUVATHUR,
CHENGALPATTU DIST - 603 319.</p>
        </div>
    </div>
  
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <!-- Include footer section from "customer.footer" -->
    @include("customer.footer")

    <!-- Include foot section from "customer.foot" -->
    @include("customer.foot")
</body>
</html>
