<!DOCTYPE html>
<html lang="en">

	<head>

		<title>GBR - Hotel Booking Details</title>
		@include("customer.head")
	</head>

	<body>
		<!-- Spinner Start -->
		<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
			<div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
				<span class="sr-only">Loading...</span>
			</div>
		</div>
		<!-- Spinner End -->


		@include("customer.header")


		<!-- About Start -->
		<div class="container-xxl py-5">
			<div class="container">


			<div class="row g-3">

			<p><span style="color:#FF8682;">Turkey </span>&nbsp; <img src="../../images/rightarrowicon.png" alt="">&nbsp;<span style="color:#FF8682;">Istanbul&nbsp;</span> <img src="../../images/rightarrowicon.png" alt="">&nbsp;CVK Park Bosphorus Hotel Istanbul</p>




			<div class="col-lg-8 col-md-8">
			<h6>CVK Park Bosphorus Hotel Istanbul</h6>
			<p><img src="../../images/location.png" alt=""> Gümüssuyu Mah. Inönü Cad. No:8, Istanbul 34437</p>
            </div>
			<div class="col-lg-4 col-md-4">
			<table>
			<tr>
			<td>
			<div style="border-radius: 8px;background: #FFF; color:#000;width: 50px;padding: 5px; border: 1px solid #901111;"><center><img class="img-fluid" src="../../images/share.svg" alt=""><center></div> </td><td><button class="btn btn-sm btn-primary" style="background-color:#901111; color:#fff;border-radius:10px;" type="submit">Download</button>
			</td></tr>
			</table>
			</div>
			<div class="col-lg-2 col-md-2">
			Thur, Dec 8<br>
			Check-In
            Fri, Dec 9 <br>
            Check-out
			</div>
			<div class="col-lg-6 col-md-6">
			<table style="background-color: #901111; color: #fff; border-top-right-radius: 10px; padding: 10px; width: 100%;">
			<tr>
			<td><img src="../../images/Ellipse_booking.png" alt=""></td>
			<td>James Doe</td>
			<td>Superior room - 1 double bed or 2 twin beds</td>
            </tr>
			</table>
			<table>
			<tr>
			<td>
			<img src="../../images/time.png" alt="">Check-In time<br>
			12:00pm
			</td>
			<td>
			<img src="../../images/time.png" alt="">Check-out time<br>
			11:30pm
			</td>
			<td>
			<img src="../../images/arrival.png" alt="">Room no<br>
			On arival
			</td></tr>
			<tr>
			<tr>
			<td>
			<img src="../../images/ek.png" alt="">ABC12345<br>

			</td>
			<td></td>
			<td><img src="../../images/barcode.png" style="width: 100%;" alt=""></td>
			</tr>
			</table>
			</div>
			<div class="col-lg-4 col-md-4">
			<img class="img-fluid" src="../../images/apl_logo.png" alt="">
			</div>
			<div class="col-lg-8 col-md-8">
			<h6>Terms and Conditions</h6>
			<p>Payments</p>
			<p>If you are purchasing your ticket using a debit or credit card via the Website, we will process these payments via the automated secure common payment gateway which will be subject to fraud screening purposes.</p>
			<p>If you do not supply the correct card billing address and/or cardholder information, your booking will not be confirmed and the overall cost may increase. We reserve the right to cancel your booking if payment is declined for any reason or if you have supplied incorrect card information. If we become aware of, or is notified of, any fraud or illegal activity associated with the payment for the booking, the booking will be cancelled and you will be liable for all costs and expenses arising from such cancellation, without prejudice to any action that may be taken against us.</p>
			<p>Golobe may require the card holder to provide additional payment verification upon request by either submitting an online form or visiting the nearest Golobe office, or at the airport at the time of check-in. Golobe reserves the right to deny boarding or to collect a guarantee payment (in cash or from another credit card) if the card originally used for the purchase cannot be presented by the cardholder at check-in or when collecting the tickets, or in the case the original payment has been withheld or disputed by the card issuing bank. Credit card details are held in a secured environment and transferred through an internationally accepted system.</p>

			<h6>Contact Us</h6>
			<p>If you have any questions about our Website or our Terms of Use, please contact:
			Golobe Group Q.C.S.C</p>
			<p>Golobe Tower</p>
			<p>P.O. Box: 22550</p>
			<p>Doha, State of Qatar</p>
			<p>Further contact details can be found at golobe.com/help
			</p>
			</div>
			</div>

		</div>
	</div>

		<!-- About End -->

				<div class="container">
					<div class="row footer_mail_box wow fadeInUp" data-wow-delay="0.1s">
						<div class="col-lg-6 col-md-6">
							<h1>Subscribe Newsletter</h1>
							<h5>The Travel</h5>
							<p>Get inspired! Receive travel discounts, tips and behind the scenes stories.</p>
							<div class="row g-3">
								<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
									<div class="form-floating">
										<input type="text" name="emil" placeholder="Your Email Address" class="form-control">
									</div>
								</div>
								<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
									<button class="btn btn-dark w-100 py-3" type="submit">Subcribe</button>
								</div>
							</div>
						</div>
					<div class="col-lg-6 col-md-6">
						<center><img class="img-fluid mail_box_img" src="../../images/open_mailbox.png" alt=""></center>
					</div><br><br><br>
					</div>
				</div>


				@include("customer.footer")

				@include("customer.foot")

			</body>

		</html>
