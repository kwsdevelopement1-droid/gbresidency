<!DOCTYPE html>
<html lang="en">

	<head>
		<title>GBR - Hotel Booking Details</title>
     	@include("customer.head")
     	<link href="../../css/flags.css" rel="stylesheet">
     	<style>
     	    .label_back{
     	    background-color: #901111 !important ;color: #fff;
     	    }
     	</style>
	</head>

	<body style="background-color:#fafafa;">
		<!-- Spinner Start -->
		<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
			<div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
				<span class="sr-only">Loading...</span>
			</div>
		</div>
		<!-- Spinner End -->


	   @include("customer.header")


		<!-- About Start -->
		<div class="container-xxl py-5">
			<div class="container">
			  <!--border: solid 1px #901111;-->
			<p><a href="{{route('HomeSakthi.index')}}" style="color:#FF8682;">Home </a>&nbsp; <img src="{{ URL::asset('images/rightarrowicon.png') }}" alt="">&nbsp;&nbsp;Payment Details</p><br>
			</div>
	</div>

		 @if( $bookings->isEmpty() )
			    <center>
			    <img src="{{ URL::asset('images/no_data_found.webp') }}" width="50%" >
			   </center>
			    @else
			<div class="container mt-1">




			   @foreach($bookings as $booking)

      <div class="row">

         <div class=" col-lg-1" >
         </div>

        <div class="col-md-6 col-lg-10 mb-4">
            <div class="row">
                <div class="card" style="border-radius: 12px; margin:5px; border:none; padding: 0px; box-shadow: 0px 4px 16px 0px #1122110D;">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-4 col-md-6">
                                <img style="width:100%; height:230px;" src="{{ asset('storage/siteimages/'.$booking->roomimage) }}">
                            </div>
                            <div class="col-lg-2"></div>

                            <div class="col-lg-6 col-md-4  mt-2">
                                <table>
                                    <tr>
                                        <td><h5>Order ID &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;</h5></td>
                                        <td><h6>{{$booking->order_id}} </h6></td>
                                    </tr>
                                    <tr>
                                        <td><h5>Amount &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;</h5></td>
                                        <td><h6>{{$booking->reservationcharge}} </h6></td>
                                    </tr>
                                    <tr>
                                        <td><h5>Room Type &nbsp;&nbsp;&nbsp;&nbsp; :&nbsp;</h5></td>
                                        <td><h6>{{$booking->roomtype}}</h6></td>
                                    </tr>
                                    <tr>
                                        <td><h5>Booking Date &nbsp; : &nbsp;</h5></td>
                                        <td><h6>{{$booking->booking_date}} </h6></td>
                                    </tr>

                                     <tr>
                                        <td><h5>Reservation Status &nbsp; : &nbsp;</h5></td>
                                        <td>

                                          @if($booking->status == 2)
                                            <button class="btn-warning" style="border-radius:20px;">Pending</button>
                                            @elseif($booking->status == 1)
                                            <button class="btn-info" style="border-radius:20px;">Waiting</button>
                                            @elseif($booking->status == 4)
                                            <button class="btn-success" style="border-radius:20px;">Confirmed</button>
                                            @else
                                            <button class="btn-danger" style="border-radius:20px;">Rejected</button>
                                            @endif



                                        </td>
                                    </tr>

                                    <tr style="margin-top:10px;">
                                        <td colspan="2" >
                                            @if($booking->status == 1)
                                            <a href="#" class="btn btn-sm btn-primary" style="background-color:#901111; color:#fff; border-radius:10px; width:100%;" type="submit">Waiting for Verification</a>

                                            @elseif($booking->status == 2)

                                           <form action="{{ route('HomeSakthi.ccapayment', ['data' => $booking->id]) }}" method="POST" style="display:inline;">
                                           @csrf
                                           <button class="btn btn-sm btn-primary" style="background-color:#901111; color:#fff; border-radius:10px; width:100%;" type="submit">Pay now</button>
                                           </form>


                                            @elseif($booking->status == 3)
                                            <a href="#" class="btn btn-sm btn-primary" style="background-color:#901111; color:#fff; border-radius:10px; width:100%;" type="submit">Rejected</a>
                                            @else
                                            <form action="{{ route('HomeSakthi.receipt')}}" method="POST">
                                                @csrf
                                                <input type="hidden" value="{{$booking->id}}" name="id">
                                                <button class="btn btn-sm btn-primary" style="background-color:#901111; color:#fff; border-radius:10px; width:100%;" type="submit">View Reservation Receipt</button>
                                            </form>
                                            @endif
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class=" col-lg-1" >
         </div>
    </div>

    @endforeach





</div>

 @endif




		<!-- About End -->

				<!--<div class="container">
					<div class="row footer_mail_box wow fadeInUp" data-wow-delay="0.1s">
						<div class="col-lg-6 col-md-6">
							<h1>Subscribe Newsletter</h1>
							<h5>The Travel</h5>
							<p>Get inspired! Receive travel discounts, tips and behind the scenes stories.</p>
							<div class="row g-3">
								<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
									<div class="form-floating">
										<input type="text" name="emil" placeholder="Your Email Address" class="form-control">
									</div>
								</div>
								<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
									<button class="btn btn-dark w-100 py-3" type="submit">Subcribe</button>
								</div>
							</div>
						</div>
					<div class="col-lg-6 col-md-6">
						<center><img class="img-fluid mail_box_img" src="../../images/open_mailbox.png" alt=""></center>
					</div><br><br><br>
					</div>
				</div>-->







				@include("customer.footer")

				@include("customer.foot")
				<script src="../../js/jquery.flagstrap.js"></script>
				<script>
                $('#bill_country').flagStrap();
				</script>
			</body>





		</html>
