<!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="{{ URL::asset('lib/wow/wow.min.js') }}"></script>
    <script src="{{ URL::asset('lib/easing/easing.min.js') }}"></script>
    <script src="{{ URL::asset('lib/waypoints/waypoints.min.js') }}"></script>
    <script src="{{ URL::asset('lib/owlcarousel/owl.carousel.min.js') }}"></script>
    <script src="{{ URL::asset('lib/tempusdominus/js/moment.min.js') }}"></script>
    <script src="{{ URL::asset('lib/tempusdominus/js/moment-timezone.min.js') }}"></script>
    <script src="{{ URL::asset('lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js') }}"></script>

    <!-- Template Javascript -->
    <script src="{{ URL::asset('js/main.js') }}"></script>
	<script>

	$(document).click(function(event) {
	  if(
		$('.toggle > input').is(':checked') &&
		!$(event.target).parents('.toggle').is('.toggle')
	  ) {
		$('.toggle > input').prop('checked', false);
	  }
	})
	</script>
	<script>
        $(document).ready(function() {
            
            $('#user_login').click(function(event) {
                //e.preventDefault();
        
                $.ajax({
                    url: "{{route('HomeSakthi.login')}}",
                    type: 'POST',
                    data: {
                        email: $('#logemail').val(),
                        password: $('#logpassword').val(),
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.success) {
                            //alert(response.message);
                            //$("#LogError").html("Login successful.");
                            window.location.href = '/';
                            // Redirect or perform actions on success
                        } else {
                            //alert(response.message);
                            //alert('Invalid credentials.');
                            $("#LogError").html("Invalid username or password"); 
                        }
                    },
                    error: function(response) {
                        if (response.status === 401) {
                            var errors = response.responseJSON.errors;
                            var errorMessages = '';
                            $.each(errors, function(key, value) {
                                errorMessages += value[0] + '\n';
                            });
                            //alert("Invalid credentials.");
                            $("#LogError").html("Invalid username or password");
                        } else {
                            //alert('An error occurred. Please try again.');
                            $("#LogError").html("");
                        }
                    }
                });
            });
            
            $('#userlogin').click(function(event) {
                var logemail = $('#logemail').val();
                var logpassword = $('#logpassword').val();
                var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;

                // Basic validation
                if (logemail === '') {
                    $("#LogEmailError").html("Email are required.");
                    event.preventDefault();
                }
                else if (logpassword === '') {
                    $("#LogPasswordError").html("Password are required.");
                    event.preventDefault();
                }
                else if (regex.test(logemail) == false) 
        		{
        			$("#LogEmailError").html("<span style='padding-top:10px;'>Enter Your Right Email ID</span>");
        			//$("#logemail").css("color", "red").val(logemail);
        		}
                else{
                    $("#LogEmailError").html("");
                    $("#LogPasswordError").html("");
                }
            });
            

        $('#confirmpassword').on('keyup', function() {
            var password = $('#password').val();
            var confirmpassword = $('#confirmpassword').val();
            if (password != confirmpassword) {
                $('#confirmpasswordError').show();
                return false;
            }else{ 
                $('#confirmpasswordError').hide();
                return true;
            }
            
        });
            
        $('#userregister').click(function(event) {
            var name   = $('#name').val();
            var email  = $('#email').val();
            var phone  = $('#phone').val();
            var password = $('#password').val();
            var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            
             // Basic validation
            if (name === '') {
                $("#NameError").html("Name are required.");
                event.preventDefault();
            }
            else if (email === '') {
                $("#EmailError").html("Email are required.");
                event.preventDefault();
            }
            else if (password === '') {
                $("#PasswordError").html("Password are required.");
                event.preventDefault();
            }
            else if (phone === '') {
                $("#PhoneError").html("Phone are required.");
                event.preventDefault();
            }
            else if (regex.test(email) == false) 
    		{
    			$("#EmailError").html("<span style='padding-top:10px;'>Enter Your Right Email ID</span>");
    			//$("#email").css("color", "red").val(email);
    		}
            else{
                $("#NameError").html("");
                $("#EmailError").html("");
                $("#PhoneError").html("");
                $("#PasswordError").html("");
            }
        });
        
        $('#email').on('blur', function() {
            var email = $(this).val();
    
            $.ajax({
                url: '{{ route("check.email") }}',
                method: 'POST',
                data: {
                    email: email,
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    //alert(response.exists); 
                    if (response.exists) {
                        //alert('Email already exists.');
                        $("#EmailError").html("Email already exists.");
                        $("#email").val("");
                    } else {
                        $("#EmailError").html("");
                    }
                }
            });
        });
            
        });
    </script>
