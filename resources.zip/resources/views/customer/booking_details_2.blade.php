<!DOCTYPE html>
<html lang="en">

	<head>

		<title>GBR - Hotel Booking Details</title>
		@include("customer.head")
	</head>

	<body>
		<!-- Spinner Start -->
		<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
			<div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
				<span class="sr-only">Loading...</span>
			</div>
		</div>
		<!-- Spinner End -->


		<!-- Topbar Start -->
		<!--<div class="container-fluid bg-dark px-5 d-none d-lg-block">
			<div class="row gx-0">
            <div class="col-lg-8 text-center text-lg-start mb-2 mb-lg-0">
			<div class="d-inline-flex align-items-center" style="height: 45px;">
			<small class="me-3 text-light"><i class="fa fa-map-marker-alt me-2"></i>123 Street, New York, USA</small>
			<small class="me-3 text-light"><i class="fa fa-phone-alt me-2"></i>+012 345 6789</small>
			<small class="text-light"><i class="fa fa-envelope-open me-2"></i>info@example.com</small>
			</div>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
			<div class="d-inline-flex align-items-center" style="height: 45px;">
			<a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href=""><i class="fab fa-twitter fw-normal"></i></a>
			<a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href=""><i class="fab fa-facebook-f fw-normal"></i></a>
			<a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href=""><i class="fab fa-linkedin-in fw-normal"></i></a>
			<a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href=""><i class="fab fa-instagram fw-normal"></i></a>
			<a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle" href=""><i class="fab fa-youtube fw-normal"></i></a>
			</div>
            </div>
			</div>
		</div>-->
		<!-- Topbar End -->


		@include("customer.header")


		<!-- About Start -->
		<div class="container-xxl py-5">
			<div class="container">


			<div class="row g-3">
			<p><span style="color:#FF8682;">Turkey </span>&nbsp; <img src="images/rightarrowicon.png" alt="">&nbsp;<span style="color:#FF8682;">Istanbul&nbsp;</span> <img src="images/rightarrowicon.png" alt="">&nbsp;CVK Park Bosphorus Hotel Istanbul</p>


			<div class="col-lg-8 col-md-8">
			<table>
				<tr>
				<td>
				   <p>Superior room - 1 double bed or 2 twin beds &nbsp;&nbsp;&nbsp;</p></td>
			    <td>
			       <span style="color:#FF8682;">₹240/night <span>&nbsp;&nbsp;&nbsp;</td>
				<td></td></tr>
			</table>
			<table>
			<tr style="border: solid 1px; border-radius: 10px;">
			<td>
			<img src="images/cvk.png" alt="">
			</td>
			<td>
			<h6>CVK Park Bosphorus Hotel Istanbul</h6>
			<p>Gümüssuyu Mah. Inönü Cad. No:8, Istanbul 34437</p></td>
			</tr>
			<tr>
			<td>Thursday, Dec 8<br>Check-In
            </td>
			<td>&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<img src="images/line_left.png" alt="">&nbsp;&nbsp;<img src="images/campanyicon.png" alt="">&nbsp;&nbsp;<img src="images/line_right.png" alt="">
			</td>
			<td>Friday, Dec 9<br>Check-out
            </td>
			</tr>

			</table><br>

			<div style="background-color: #901111; color: #fff; border-radius: 10px; padding: 10px; width: 100%;">Pay in full<br><input style="float:right;" type="radio" name="pacheck" checked>
			Pay the total and you are all set

			</div><br>
			<h6>Pay part now, part later</h6>
			<p>Pay $207.43 now, and the rest ($207.43) will be automatically charged to the same payment method on Nov 14, 2022. No extra fees.</p>

			<h6>Login or Sign up to book<h6>
			<input type="text"  name="phone_number" placeholder="Phone Number" class="form-control">
			<br>
		    <p>We’ll call or text you to confirm your number. Standard message and data rates apply. Privacy Policy</p>
			<div style="background-color: #901111; color: #fff; border-radius: 10px; padding: 10px; width: 100%;text-align:center">continue
			</div><br>
			<center><p>or</p><center>
			<table>
				<tr>
				<td>
				<div style="background-color: #fff; border:solid 1px #901111; color: #fff; border-radius: 10px; padding: 10px; width: 100%;text-align:center"><img src="images/facebook.png" alt="">
			</div>
				</td>
				<td><div style="background-color: #fff; border:solid 1px #901111; color: #fff; border-radius: 10px; padding: 10px; width: 100%;text-align:center"><img src="images/google_icon.png" alt="">
			</div>
				</td>
				<td>
				<div style="background-color: #fff; border:solid 1px #901111; color: #fff; border-radius: 10px; padding: 10px; width: 100%;text-align:center"><img src="images/apple.png" alt="">
			</div>
				</td>
				</tr>
			</table><br>
			<div style="background-color: #fff; border:solid 1px #901111; color: #121; border-radius: 10px; padding: 10px; width: 100%;text-align:center"><img src="images/email.png" alt=""> Continue with email

			</div>
			</div>
			<div class="col-lg-4 col-md-4">
			<table>
				<tr>
				<td>
			    <img src="images/booking_detail_img.png" alt=""></td><td>
				CVK Park Bosphorus...<br>
				<h6>Superior room - 1 double bed or 2 twin beds</h6></td>
				</tr>


            </table>
			<p>Your booking is protected by <b>golobe</b></p>
			<table>
			<tr><td>Price Details</td></tr>
			  <tr>
				<td>Base Fare
				</td>
				<td>₹240

				</td>
			  </tr>
				<tr>
				<td>Discount
				</td>
				<td>₹0
				</td>
				</tr>
				<tr>
				<td>Taxes
				</td>
				<td>₹20

				</td>
				</tr>
				<tr>
				<td>Service Fee

				</td>
				<td>₹5
				</td>
				</tr>
				<tr>
				<td>Total
				</td>
				<td>₹265
				</td>
				</tr>
			</table>
			</div>
			</div>

		</div>
	</div>

		<!-- About End -->

				<div class="container">
					<div class="row footer_mail_box wow fadeInUp" data-wow-delay="0.1s">
						<div class="col-lg-6 col-md-6">
							<h1>Subscribe Newsletter</h1>
							<h5>The Travel</h5>
							<p>Get inspired! Receive travel discounts, tips and behind the scenes stories.</p>
							<div class="row g-3">
								<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
									<div class="form-floating">
										<input type="text" name="emil" placeholder="Your Email Address" class="form-control">
									</div>
								</div>
								<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
									<button class="btn btn-dark w-100 py-3" type="submit">Subcribe</button>
								</div>
							</div>
						</div>
					<div class="col-lg-6 col-md-6">
						<center><img class="img-fluid mail_box_img" src="images/open_mailbox.png" alt=""></center>
					</div><br><br><br>
					</div>
				</div>


				@include("customer.footer")

				@include("customer.foot")

			</body>

		</html>
