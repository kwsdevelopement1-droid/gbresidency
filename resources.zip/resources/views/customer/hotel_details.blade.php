<!DOCTYPE html>

<!--echo url()->current();-->
<html lang="en">

	<head>
		<meta charset="utf-8">
		<title>GBR - Residency Details</title>
		@include("customer.head")
		<style>
		    .img_big
			{
			height: 815px;
			}
			.map_img{
             width:1250px; height:450px;
			}
			.review_card{
        	font-size: 10px;
            border-radius: 8px;
            background: #901111;
            color: #fff;
            width: 115px;
            height: 80px;
            padding: 10px;
			}
			.star_card{
			    font-size:10px;
			    border-radius: 8px;
			    border:solid 1px #901111;
			    background: #fff; color:#000;
			    width: 115px;
			    height: 80px;
			    padding: 10px;
			}
			@media only screen and (max-width: 600px)
			{
    			.img_big
    			{
    			width: 100%;
    			height: auto;
    			}
    			.map_img{
                 width:100%; height:450px;
    			}
    			.review_card{
            	font-size: 10px;
                border-radius: 8px;
                background: #901111;
                color: #fff;
                width: 80px;
                height: 80px;
                padding: 10px;
    			}
    			.star_card{
			    font-size:10px;
			    border-radius: 8px;
			    border:solid 1px #901111;
			    background: #fff; color:#000;
			    width: 80px;
			    height: 80px;
			    padding: 10px;
			}
			}
		</style>
  <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">-->
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

	</head>





	<body>


		<!-- Spinner Start -->
		<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
			<div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
				<span class="sr-only">Loading...</span>
			</div>
		</div>
		<!-- Spinner End -->


		@include("customer.header")


		<!-- About Start -->
		<div class="container-xxl py-5">
			<div class="container">


				<div class="row g-3">
				    <p><a href="{{route('HomeSakthi.index')}}" style="color:#FF8682;">Home </a>&nbsp; <img src="../../images/rightarrowicon.png" alt="">&nbsp;<a href="#" style="color:#000;">{{$room->roomname}}&nbsp;</a> <!--<img src="../../images/rightarrowicon.png" alt="">&nbsp;CVK Park Bosphorus Hotel Istanbul--></p>
					<div class="col-lg-9 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
					    <table>
					        <tr>
						<td><h2>{{$room->roomname}}</h2></td>
						<!--<td><img class="img-fluid" src="../../images/star.svg" alt="">
						<img class="img-fluid" src="../../images/star.svg" alt="">
						<img class="img-fluid" src="../../images/star.svg" alt="">
						<img class="img-fluid" src="../../images/star.svg" alt="">
						<img class="img-fluid" src="../../images/star.svg" alt=""> 5 Star Hotel</td>--></tr>
						</table>
						<p><img class="img-fluid" src="../../images/location.svg" alt=""> HOSPITAL ROAD, MELMARUVATHUR,CHENGALPATTU DIST - 603 319</p>
						 <table>
					        <tr>
						<td>
						<!--<div style="border-radius: 8px;background: #FFF; color:#000;width: 50px;padding: 5px; border: 1px solid #901111;"><center>4.2<center></div></td><td>&nbsp;<strong>Very Good</strong> 31 reviews--></td></tr></table><br><br>
						</div>
						<div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">


						    <h2><span style="color:#FF8682;">₹ {{$room->roomprice}}/night</h2>
						    <table>
						    <tr>
						        <td>



						  @php
						    use App\Models\favourite;
                            $isFavorite = Auth::guard('onlineusers')->check() && favourite::where('user_id', Auth::guard('onlineusers')->id())->where('room_id', $room->id)->exists();
                          @endphp

                          <button id="favorite-button" data-room-id="{{ $room->id }}" style="border-radius: 8px; background: #FFF; color: #000; width: 50px; padding: 10px; border: 1px solid #901111;">
                              <img id="blackHeart" src="{{ asset('images/heart_black_icon.png') }}" alt="Black Heart" style="{{ $isFavorite ? '' : 'display:none;' }}">
                              <img id="whiteHeart" src="{{ asset('images/heart_white_icon.png') }}" alt="White Heart" style="{{ $isFavorite ? 'display:none;' : '' }}">
                          </button>


							    </td>
							 <td>
							  <button style="border-radius: 8px;background: #FFF; color:#000;width: 50px;padding: 10px; border: 1px solid #901111;"><center><img class="img-fluid" src="../../images/share.svg" alt=""><center></button>
							</td>
							<td>

								 @auth('onlineusers')
								 <a href="{{route('HomeSakthi.booking', ['room' => $room->id])}}">

								<button  class="btn btn-sm btn-primary" style="background-color:#901111; color:#fff;border-radius:10px;padding: 10px;" type="submit">Book Now</button>
								</a>

								@else
								<button data-target="#LoginModal" data-toggle="modal" class="btn btn-sm btn-primary" style="background-color:#901111; color:#fff;border-radius:10px;padding: 10px;" >
                                 <center>Book Now</center>
                                </button>

                                @endauth

							</td>
								</tr>
								</table>
						    </div>
									<div class="col-lg-5 col-md-6 wow zoomIn" data-wow-delay="0.7s">

										<img class="img-fluid img_big" src="{{ asset('storage/siteimages/'. $room->galleryimg_1) }}" style="min-height: 350px; border-radius: 12px;" alt="">
									</div>
									<div class="col-lg-7 col-md-6">
										<div class="row g-3">

											<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">

												<a class="position-relative d-block overflow-hidden" href="">
													<img style="width: 100%; height: 400px; border-radius: 12px;" class="img-fluid" src="{{ asset('storage/siteimages/'. $room->galleryimg_2) }}" alt="">
												</a>
											</div>
											<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.5s">

												<a class="position-relative d-block overflow-hidden" href="">
													<img style="width: 100%; height: 400px; border-radius: 12px;" class="img-fluid" src="{{ asset('storage/siteimages/'. $room->galleryimg_3) }}" alt="">
												</a>
											</div>
											<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
												<a class="position-relative d-block overflow-hidden" href="">
													<img style="width: 100%; height: 400px; border-radius: 12px;" class="img-fluid" src="{{ asset('storage/siteimages/'. $room->galleryimg_4) }}" alt="">
												</a>
											</div>
											<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.5s">
												<a class="position-relative d-block overflow-hidden" href="">
													<img style="width: 100%; height: 400px; border-radius: 12px;" class="img-fluid" src="{{ asset('storage/siteimages/'. $room->galleryimg_5) }}" alt="">
												</a>
											</div>
										</div>
									</div>
									<!-- Button trigger modal -->




									<hr>
									<div class="col-lg-12 col-md-12">
										<h2>Overview</h2>
										<p>{{$room->overview}}</p>

									</div>
									</div>
									<!--<div class="row g-3">

										<div class="col-lg-12 col-md-12 wow zoomIn" data-wow-delay="0.3s">
											<table>
												<tr>
													<td>
														<div class="review_card"><font size="3px">4.2</font><br><br>Very Good <br>371 Reviews</div>
													</td>
													<td>&nbsp;</td>
													<td>
														<div class="star_card" style=""><img src="../../images/stars.png" alt=""><br><br>Near Temple </div>
													</td>
													<td>&nbsp;</td>
													<td>
														<div class="star_card"><img src="../../images/stars.png" alt=""><br><br>Near Railway Station </div>
													</td>
													<td>&nbsp;</td>
													<td>
														<div class="star_card"><img src="../../images/stars.png" alt=""><br><br>Near Bus Stop </div>
													</td>
													<td>&nbsp;</td>
													<td>
														<div class="star_card"><img src="../../images/stars.png" alt=""><br><br>Clean Hotel </div>
													</td>
												</tr></table><br>

										</div>
									</div>--><hr>
									<div class="row g-3">
										<h2>Available Rooms</h2>
										<div class="col-lg-12 col-md-12">
											<table style="width: 100%;">

											    @foreach($available_rooms as $available_room)
												<tr style="border-bottom: solid 1px #000;">
													<td style="padding: 10px;">
														<img class="img-fluid" src="{{ asset('storage/siteimages/'. $available_room->single_image) }}" style="width:80px; height:80px;" alt="">
													</td>
													<td>&nbsp;</td>
													<td>
													<p>{{$available_room->roomname}}</p></td>
													<td>
													₹{{$available_room->roomprice}}/night
													</td>

												<td>
												     @auth('onlineusers')
												    <a href="{{route('HomeSakthi.room_detail', ['room' => $available_room->id])}}">

							                         	<button  class="btn btn-sm btn-primary" style="background-color:#901111; color:#fff;border-radius:10px;" type="submit">Book Now</button>
								                    </a>
												    @else

												    <button data-target="#LoginModal" data-toggle="modal" class="btn btn-sm btn-primary" style="background-color:#901111; color:#fff;border-radius:10px;" type="submit">Book Now</button>
												@endauth
												</td>
												</tr>
												@endforeach


												</table>
										</div>
									</div><br><hr>
									<div class="row g-3">
										<h5>Location/Map</h5>
										<div class="col-lg-12 col-md-12">
										    <!--<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3896.293933564767!2d79.8270584846137!3d12.430125795175746!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a531a007a55e09f%3A0x5b5e1eaf011a410f!2sRound%20Building%2C%20Adi%20Parasakthi%20Lodge!5e0!3m2!1sen!2sin!4v1718703958524!5m2!1sen!2sin"   style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>-->
											<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3896.2556669299865!2d79.82541927579014!3d12.432678526463109!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5319ff005bfa8f%3A0x97d44c27eeb38a8e!2sHospital%20Rd%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1720869849225!5m2!1sen!2sin" class="map_img" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
											<!--<img class="img-fluid" src="../../images/map.png" alt="">-->
										</div>
									</div><br><hr>
									<!--<div class="row g-3">
										<h2>Amenitiess</h2>
										<div class="col-lg-12 col-md-12">
											<table>
												<tr>
													<td> <img src="../../images/indoor.png" alt="">Outdoor pool&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
													<td><img src="../../images/fitness.png" alt=""> Fitness center</td>
												</tr>
												<tr>
													<td><img src="../../images/indoor.png" alt=""> Indoor pool</td>
													<td><img src="../../images/bar.png" alt=""> Bar/Lounge</td>
												</tr>
												<tr>
													<td><img src="../../images/spa.png" alt=""> Spa and wellness center</td>
													<td><img src="../../images/wifi.png" alt=""> Free Wi-Fi</td>
												</tr>
												<tr>
													<td><img src="../../images/restaurent.png" alt=""> Restaurant</td>
													<td><img src="../../images/coffeemachine.png" alt=""> Tea/Cofee Machine</td>
												</tr>

											</table>
										</div>
									</div><br><hr>-->

									<!--<div class="row g-3">
										<h2>Reviews</h2>
										<div class="col-lg-12 col-md-12">
											<h5>4.2 Very Good</h5>
											<p>371 Reviews</p>
											<table>
												<tr>
													<td>
														<img class="img-fluid" src="../../images/Ellipse_1.png" alt="">
													</td>
													<td>
														<h5>5.0 Amazing</h5>
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p></td>
												</tr>
												<tr>
													<td>
														<img class="img-fluid" src="../../images/Ellipse_2.png"  alt="">
													</td>
													<td>
														<h5>5.0 Amazing</h5>
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p></td>
												</tr>
												<tr>
													<td>
														<img class="img-fluid" src="../../images/Ellipse_3.png" alt="">
													</td>
													<td>
														<h5>5.0 Amazing</h5>
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p></td>
												</tr>
												<tr>
													<td>
														<img class="img-fluid" src="../../images/Ellipse_4.png" alt="">
													</td>
													<td>
														<h5>5.0 Amazing</h5>
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p></td>
													</tr><tr>
													<td>
    														<img class="img-fluid" src="../../images/Ellipse_5.png" style="width:100px;" alt="">
													</td>
													<td>
														<h5>5.0 Amazing</h5>
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p></td>
												</tr></table>
										</div>
									</div>-->


									<!-- About End -->

									<!--<div class="container">
										<div class="row footer_mail_box wow fadeInUp" data-wow-delay="0.1s">
											<div class="col-lg-6 col-md-6">
												<h1>Subscribe Newsletter</h1>
												<h5>The Travel</h5>
												<p>Get inspired! Receive travel discounts, tips and behind the scenes stories.</p>
												<div class="row g-3">
													<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
														<div class="form-floating">
															<input type="text" name="emil" placeholder="Your Email Address" class="form-control">
														</div>
													</div>
													<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
														<button class="btn btn-dark w-100 py-3" type="submit">Subcribe</button>
													</div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6">
												<center><img class="img-fluid mail_box_img" src="../../images/open_mailbox.png" alt=""></center>
											</div><br><br><br>
										</div>
									</div>-->
			</div>
		</div>



								@include("customer.footer")

								@include("customer.foot")






								</body>
								<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
								<script>
$(document).ready(function() {
    $('#favorite-button').on('click', function() {
        var button = $(this);
        var roomId = button.data('room-id');

        $.ajax({
            url: '{{ route('HomeSakthi.favorites.store') }}',
            type: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                room_id: roomId,
                user_id: '{{ auth("onlineusers")->id() }}'
            },
            success: function(response) {
                if (response.success) {
                    if (response.is_favorite) {
                        button.find('#blackHeart').show();
                        button.find('#whiteHeart').hide();
                    } else {
                        button.find('#blackHeart').hide();
                        button.find('#whiteHeart').show();
                    }
                } else {
                    alert('An error occurred!');
                }
            }
        });
    });
});
</script>

							</html>
