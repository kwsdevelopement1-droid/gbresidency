<!DOCTYPE html>
<html lang="en">

	<head>
		<title>GBR - Hotel Booking Details</title>
     	@include("customer.head")
     	<link href="../../css/flags.css" rel="stylesheet">
     	<style>
     	    .label_back{
     	    background-color: #901111 !important ;color: #fff;
     	    }




     	</style>
	</head>

	<body style="background-color:#fafafa;">
<body style="background-color:#fafafa;">
		<!-- Spinner Start -->
		<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
			<div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
				<span class="sr-only">Loading...</span>
			</div>
		</div>
		<!-- Spinner End -->

		<div class="abc">
	   @include("customer.header")
	   </div>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 col-lg-12 mb-4">
            <div class="card" style="border-radius: 12px; border:none; padding: 24px; box-shadow: 0px 4px 16px 0px #1122110D; ">
                <div class="card-body">



                    <h5 class="card-title" style="text-align:center">Payment Has Been Canceled</h5>
                    <center>
                    <img src="{{ asset('images/payment_cancel.jpg') }}" width="50%" alt="">
                    </center>
                    <p class="card-text" style="text-align:center">The Reservation Payment Has been cancled , Please try again later.</p>


                        <div class="abc" style="align-self: center;">

                            <center>




                    <a href="{{route('HomeSakthi.index')}}" class="btn btn-primary" style="margin:2%; border-radius:10px;">Go To Home</a>
                    </center>
            </div>
        </div>
    </div>
</div>


	</div>

	  </div>


	  <div class="abc">

	@include("customer.footer")
@include("customer.foot")
</div>

<script src="../../js/jquery.flagstrap.js"></script>

</body>





		</html>
