<!DOCTYPE html>
<html lang="en">

	<head>
		<title>GBR - Residency Listing</title>
		@include("customer.head")
	</head>

	<body>
		<!-- Spinner Start -->
		<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
			<div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
				<span class="sr-only">Loading...</span>
			</div>
		</div>
		<!-- Spinner End -->


		@include("customer.header")


		<!-- About Start -->


		<div class="container-xxl py-5">
			<div class="container">
		@php
    use App\Models\favourite;
@endphp

		@foreach($rooms as $room)

		@php

          $isFavorite = Auth::guard('onlineusers')->check() && favourite::where('user_id', Auth::guard('onlineusers')->id())->where('room_id', $room->id)->exists();
        @endphp

			<div class="row" style="border: solid 1px #901111;border-radius: 10px;padding: 10px;">

			<div class="col-lg-3 col-md-3 wow fadeInUp" data-wow-delay="0.1s">
				<div class="team-item">
					<div class="overflow-hidden">
						<img style="width: 100%;height: 235px;" src="{{ asset('storage/siteimages/'. $room->single_image) }}" alt="">


					</div>

				</div>
			</div>

			<div class="col-lg-6 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
				<h2>{{$room->roomname}}</h2><h3 style="color:#fff;" align="right">₹ {{$room->roomprice}}</h3>
				<p style="margin-top: -30px;"><img class="img-fluid" src="../../images/location.svg" alt=""> MELMARUVATHUR</p>
				<img class="img-fluid" src="../../images/star.svg" alt="">
				<img class="img-fluid" src="../../images/star.svg" alt="">
				<img class="img-fluid" src="../../images/star.svg" alt="">
				<img class="img-fluid" src="../../images/star.svg" alt="">
				<img class="img-fluid" src="../../images/star.svg" alt=""> 5 Star Hotel <br><br>
				<table>
				<tr>
				    <td>
				     <button style="border-radius: 8px;background: #FFF; color:#000;width: 50px;padding: 5px; border: 1px solid #901111;"><center>4.2<center></button> 
				    </td>
				    <td><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Very Good</strong> 54 reviews<img class="img-fluid" src="../../images/cafe.svg" alt="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 20+ Aminities</td>

				</tr>
				<tr>
				    <td>


				    @auth('onlineusers')

				    <button id="favorite-button-{{ $room->id }}" data-room-id="{{ $room->id }}" class="favorite-button" style="border-radius: 8px; background: #FFF; color: #000; width: 50px; padding: 5px; border: 1px solid #901111;">
                                    <center>
                                        <img id="blackHeart-{{ $room->id }}" src="{{ asset('images/heart_black_icon.png') }}" alt="Black Heart" style="{{ $isFavorite ? '' : 'display:none;' }}">
                                        <img id="whiteHeart-{{ $room->id }}" src="{{ asset('images/heart_white_icon.png') }}" alt="White Heart" style="{{ $isFavorite ? 'display:none;' : '' }}">
                                    </center>
                    </button>

                    @else

                    <button data-target="#LoginModal" data-toggle="modal"  style="border-radius: 8px; background: #FFF; color: #000; width: 50px; padding: 5px; border: 1px solid #901111;">
                                    <center>
                                        <img src="{{ asset('images/heart_white_icon.png') }}" alt="White Heart" >
                                    </center>
                    </button>

                    @endauth

				    </td>
				    <td style="width: 100%;">
				        <a href="{{ route('HomeSakthi.room_detail', ['room' => $room->id]) }}">
				    <button class="btn w-50" style="background-color:#901111; color:#fff;border-radius:10px; margin-left: 33px;" type="submit">View Place</button>
				    </a>
				    </td>
				</tr>
				</table>

			</div>


			<div class="col-lg-3 col-md-3 wow fadeInUp" data-wow-delay="0.1s">
			   <div align="right"> Start from<h2><span style="color:#FF8682">₹ {{$room->roomprice}}/night</span></h2>excl. tax</div><br>



			</div>
			</div>

			<br>

		@endforeach




		</div>
	</div>

		<!-- About End -->

				<!--<div class="container">
					<div class="row footer_mail_box wow fadeInUp" data-wow-delay="0.1s">
						<div class="col-lg-6 col-md-6">
							<h1>Subscribe Newsletter</h1>
							<h5>The Travel</h5>
							<p>Get inspired! Receive travel discounts, tips and behind the scenes stories.</p>
							<div class="row g-3">
								<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
									<div class="form-floating">
										<input type="text" name="emil" placeholder="Your Email Address" class="form-control">
									</div>
								</div>
								<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
									<button class="btn btn-dark w-100 py-3" type="submit">Subcribe</button>
								</div>
							</div>
						</div>
					<div class="col-lg-6 col-md-6">
						<center><img class="img-fluid mail_box_img" src="../../images/open_mailbox.png" alt=""></center>
					</div><br><br><br>
					</div>
				</div>-->


				@include("customer.footer")

				@include("customer.foot")

			</body>

		<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('.favorite-button').on('click', function() {
        var button = $(this);
        var roomId = button.data('room-id');

        $.ajax({
            url: '{{ route('HomeSakthi.favorites.store') }}',
            type: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                room_id: roomId,
                user_id: '{{ auth("onlineusers")->id() }}'
            },
            success: function(response) {
                console.log('Response:', response); // Log response for debugging

                if (response.success) {
                    var blackHeart = $('#blackHeart-' + roomId);
                    var whiteHeart = $('#whiteHeart-' + roomId);

                    if (response.is_favorite) {
                        blackHeart.show();
                        whiteHeart.hide();
                    } else {
                        blackHeart.hide();
                        whiteHeart.show();
                    }
                } else {
                    alert('An error occurred: ' + response.error); // Display error message
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error); // Log AJAX error to console
                alert('AJAX Error occurred. Check console for details.'); // Alert user about AJAX error
            }
        });
    });
});
</script>


		</html>
