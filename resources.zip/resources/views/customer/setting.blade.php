<!DOCTYPE html>
<html lang="en">

<head>
    <title>APL - Hotel Favorites</title>
    @include("customer.head")
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .form-container {
            max-width: 400px;
            margin: auto;
            padding: 1em;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .password-container {
            position: relative;
            margin-bottom: 15px;
        }

        .password-container input {
            width: 100%;
            padding-right: 30px;
        }

        .password-container .toggle-password {
            position: absolute;
            right: 10px;
            top: 70%;
            transform: translateY(-50%);
            cursor: pointer;
        }

        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        .alert-error {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
        }

        .error-message {
            color: #721c24;
            font-size: 0.875em;
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

    @include("customer.header")

    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <h2>SETTINGS</h2>

            @if(session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
            @endif
               @if(session('error'))
                <div class="alert alert-error">
                    {{ session('error') }}
                </div>
            @endif

            <div class="form-container">
                <form action="{{ route('HomeSakthi.settings_save') }}" method="POST">
                    @csrf
                    <div class="password-container">
                        <label for="old_password">Old Password</label>
                        <input type="password" id="old_password" name="old_password" class="form-control" value="{{ old('old_password') }}" required>
                        <i class="fas fa-eye toggle-password" onclick="togglePassword('old_password')"></i>
                        @error('old_password')
                            <div class="error-message">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="password-container">
                        <label for="new_password">New Password</label>
                        <input type="password" id="new_password" name="new_password" class="form-control" value="{{ old('new_password') }}" required>
                        <i class="fas fa-eye toggle-password" onclick="togglePassword('new_password')"></i>
                        @error('new_password')
                            <div class="error-message">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="password-container">
                        <label for="new_password_confirmation">Confirm New Password</label>
                        <input type="password" id="new_password_confirmation" name="new_password_confirmation" class="form-control" value="{{ old('new_password_confirmation') }}" required>
                        <i class="fas fa-eye toggle-password" onclick="togglePassword('new_password_confirmation')"></i>
                        @error('new_password_confirmation')
                            <div class="error-message">{{ $message }}</div>
                        @enderror
                    </div>

                    <br>
                    <center>
                        <button class="btn btn-primary text-center" type="submit">Update Password</button>
                    </center>
                </form>
            </div>
        </div>
    </div>

    @include("customer.footer")
    @include("customer.foot")

    <script>
        function togglePassword(fieldId) {
            var passwordField = document.getElementById(fieldId);
            var toggleIcon = passwordField.nextElementSibling;
            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
    </script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            $('.favorite-button').on('click', function () {
                var button = $(this);
                var roomId = button.data('room-id');

                $.ajax({
                    url: '{{ route('HomeSakthi.favorites.store') }}',
                    type: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        room_id: roomId,
                        user_id: '{{ auth("onlineusers")->id() }}'
                    },
                    success: function (response) {
                        console.log('Response:', response); // Log response for debugging

                        if (response.success) {
                            var blackHeart = $('#blackHeart-' + roomId);
                            var whiteHeart = $('#whiteHeart-' + roomId);

                            if (response.is_favorite) {
                                blackHeart.show();
                                whiteHeart.hide();
                            } else {
                                blackHeart.hide();
                                whiteHeart.show();
                            }
                        } else {
                            alert('An error occurred: ' + response.error); // Display error message
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error('AJAX Error:', error); // Log AJAX error to console
                        alert('AJAX Error occurred. Check console for details.'); // Alert user about AJAX error
                    }
                });
            });
        });
    </script>

</body>

</html>
