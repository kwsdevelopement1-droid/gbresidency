<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GBR - Hotel Terms & Conditions</title>
    <!-- Include head section from "customer.head" -->
    @include("customer.head")
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
   <style>
        /* Custom Styles */
        body {
            font-family: 'Montserrat', sans-serif;
            color: #333;
            /*background-color: #f0f4f8;*/
            margin: 0;
            padding: 0;
        }
        h1 {
            color: #2c3e50;
            margin-top: 40px;
            text-align: center;
            font-weight: 700;
            font-size: 2.4rem;
        }
        h2 {
            color: #34495e;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            margin-top: 30px;
            font-size: 1.8rem;
        }
        p {
            line-height: 1.7;
            margin-bottom: 20px;
        }
        a {
            color: #3498db;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .r {
            background: #f0f4f8;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            margin-top: 40px;
        }
        .contact-info {
            margin-top: 40px;
            padding: 20px;
            background-color: #ecf0f1;
            border: 1px solid #bdc3c7;
            border-radius: 12px;
        }
        .contact-info h2 {
            color: #2c3e50;
            font-size: 1.6rem;
        }
        .contact-info p {
            margin: 10px 0;
        }
        .contact-info a {
            color: #3498db;
            text-decoration: none;
        }
        .contact-info a:hover {
            text-decoration: underline;
        }
        #spinner {
            background-color: rgba(255, 255, 255, 0.9);
            z-index: 1050;
        }
    </style>
</head>
<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

    <!-- Include header section from "customer.header" -->
    @include("customer.header")

    <!-- Main content section -->
    <div class="container r">
        <h1>Welcome to GB Residency - Hotel Terms & Conditions</h1>

        <p>This website is dedicated to providing you with the best hotel recommendations and information.</p>

        <h2>Terms & Conditions</h2>
        <p>This Terms & Conditions describes how we collect, use, and disclose information, and what choices you have with respect to the information.</p>
        <h2>1. Age Requirement</h2>
        <p>You must be 18 or older to book. We may require age verification upon check-in.</p>

        <h2>2. Alcohol Policy</h2>
        <p>No alcoholic beverages are allowed on our premises. Violations may result in immediate eviction without a refund.</p>

        <h2>3. Booking and Payment</h2>
        <p>Bookings are subject to availability and are confirmed only upon receipt of our confirmation. Additional charges for extra persons may apply.</p>

        <h2>4. Cancellation Policy</h2>
        <p>Cancellation/No-Show: No refund.</p>

        <h2>5. Check-In/Check-Out</h2>
        <p>Check-in is available for 24 hours only. Late check-out may incur charges for the next full day.</p>

        <h2>6. Liability</h2>
        <p>GB Residency is not liable for personal belongings. Guests are responsible for any damage caused to the property.</p>

        <h2>7. Privacy Policy</h2>
        <p>Review our Privacy Policy for details on how we handle your data.</p>

        <h2>8. Conduct</h2>
        <p>Respectful behavior is required. Disruptive conduct may lead to eviction without a refund.</p>

        <h2>9. Changes</h2>
        <p>We may update these terms at any time. Changes will be posted on our website.</p>

        <h2>10. Governing Law</h2>
        <p>These terms are governed by the laws of Tamil Nadu.</p>
        <p>We may collect personal information that you voluntarily provide to us when you:</p>
        <ul>
            <li>Make a reservation or booking</li>
            <li>Use our website </li>
            <!--<li>Sign up for newsletters or promotional emails</li>-->
            <li>Contact us through our customer service or support channels</li>
        </ul>
        <p>The types of personal information we may collect include:</p>
        <ul>
            <li>Name, email address, phone number</li>
            <li>Payment information (credit card details)</li>
            <li>Preferences and interests</li>
            <li>Demographic information such as postcode, preferences, and interests</li>
        </ul>
        <p>We use the information we collect in the following ways:</p>
        <ul>
            <li>To provide and maintain our services</li>
            <li>To improve our services and offerings</li>
            <li>To personalize your experience</li>
            <li>To communicate with you, including for customer service, to provide updates and information relating to your reservation, and for marketing purposes</li>
            <li>To process payments and prevent fraud</li>
            <li>To comply with legal obligations</li>
        </ul>
        <p>We take reasonable measures to protect your personal information from unauthorized access, use, or disclosure.</p>
        <p>You can choose not to provide certain information, but this may limit your ability to use our services or website features.</p>
        <p>We may update our Terms & Conditions from time to time. We will notify you of any changes by posting the new Terms & Conditions on this page.</p>
        <p>If you have any questions about this Terms & Conditions, please contact us:</p>
        
        <ul>
            <li>Email: <a href="mailto:gbresidencymmlr1112@gmail.com">gbresidencymmlr1112@gmail.com</a></li>
            <li>Phone: 044 - 27528450,  9444539691</li>
            <li>Address: HOSPITAL ROAD, MELMARUVATHUR,
CHENGALPATTU DIST - 603 319.</li>
        </ul>
    </div>

  
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
  <!-- Include footer section from "customer.footer" -->
    @include("customer.footer")

    <!-- Include foot section from "customer.foot" -->
    @include("customer.foot")

</html>
