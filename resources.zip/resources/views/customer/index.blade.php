<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>GBR - Home</title>
    @include("customer.head")
     <style>
        .room_card{
            color:#fff; 
            width: 295px; 
            background-color: #0000001a; 
            margin-top: -187px; 
            position: absolute;
        }
        .carousel-indicators li::before {
            position: absolute;
            top: -10px;
            left: 0;
            display: inline-block;
            width: 100%;
            height: 10px;
            content: "";
        }
        *, ::after, ::before {
            box-sizing: border-box;
        }
        *, *::before, *::after {
            box-sizing: border-box;
        }
        .carousel-indicators li {
            position: relative;
            -ms-flex: 0 1 auto;
            flex: 0 1 auto;
            width: 30px;
            height: 3px;
            margin-right: 3px;
            margin-left: 3px;
            text-indent: -999px;
            cursor: pointer;
            background-color: rgba(255, 255, 255, .5);
        }
        .carousel-indicators .active {
            background-color: #fff;
        }
        .img_wdhe{
            width:100%;
            height: 550px;
        }
        @media only screen and (max-width: 600px)
	    {
	        .room_card
	        {
                color:#fff; 
                width: 89%; 
                background-color: #0000001a; 
                margin-top: -174px; 
                position: absolute;
            }
            .img_wdhe {
                width: 100%;
                height: 300px;
            }
	    }
    </style>
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Topbar Start -->
    <!--<div class="container-fluid bg-dark px-5 d-none d-lg-block">
        <div class="row gx-0">
            <div class="col-lg-8 text-center text-lg-start mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <small class="me-3 text-light"><i class="fa fa-map-marker-alt me-2"></i>123 Street, New York, USA</small>
                    <small class="me-3 text-light"><i class="fa fa-phone-alt me-2"></i>+012 345 6789</small>
                    <small class="text-light"><i class="fa fa-envelope-open me-2"></i>info@example.com</small>
                </div>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href=""><i class="fab fa-twitter fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href=""><i class="fab fa-facebook-f fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href=""><i class="fab fa-linkedin-in fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href=""><i class="fab fa-instagram fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle" href=""><i class="fab fa-youtube fw-normal"></i></a>
                </div>
            </div>
        </div>
    </div>-->
    <!-- Topbar End -->

@include("customer.header")

        <!--<div class="container-fluid bg-primary py-5 mb-5 hero-header">
            <div class="container py-5">
                <div class="row justify-content-center py-5">
                    <div class="col-lg-6 pt-lg-5 mt-lg-5 text-center"><br> <br><br><br><br><br><br><br><br><br><br><br><br><br>
				    <h1 class="display-3 text-white mb-3 animated slideInDown">Make your travel whishlist, we’ll do the rest</h1>
					 <p class="fs-4 text-white mb-4 animated slideInDown">Tempor erat elitr rebum at clita diam amet diam et eos erat ipsum lorem sit</p>
                        <div class="position-relative w-75 mx-auto animated slideInDown">
                            <input class="form-control border-0 rounded-pill w-100 py-3 ps-4 pe-5" type="text" placeholder="Eg: Thailand">
                            <button type="button" class="btn btn-primary rounded-pill py-2 px-4 position-absolute top-0 end-0 me-2" style="margin-top: 7px;">Search</button>
					</div>
                    </div>
					 <div class="col-lg-6 pt-lg-5 mt-lg-5 text-center">
					 </div>
                </div>
            </div>
        </div>-->
        
        <div id="carouselExampleIndicators"  class="mobile_slider carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img class="d-block img_wdhe" src="images/home_banner_1.jpg" alt="devbanban">
                    <div class="carousel-caption d-flex align-items-center">
                        
                    </div>
              </div>
              <div class="carousel-item">
                <img class="d-block img_wdhe" src="images/home_banner_2.jpg" alt="devbanban">
                <div class="carousel-caption d-flex align-items-center">
                        
                    </div>
              </div>
              <div class="carousel-item">
                <img class="d-block img_wdhe" src="images/home_banner_3.jpg" alt="devbanban">
                <div class="carousel-caption d-flex align-items-center">
                        
                    </div>
              </div>
              <div class="carousel-item">
                <img class="d-block img_wdhe" src="images/home_banner_4.jpg" alt="devbanban">
                <div class="carousel-caption d-flex align-items-center">
                        
                    </div>
              </div>
              <div class="carousel-item">
                <img class="d-block img_wdhe" src="images/home_banner_5.jpg" alt="devbanban">
                <div class="carousel-caption d-flex align-items-center">
                        
                    </div>
              </div>
                
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
                
            </a>
                
          </div>




    <!-- About Start -->
   <!-- <div class="container-xxl py-5">-->
   <!--     <div class="container">-->

   <!--         <div class="row g-5">-->
			<!--<h5 style="color:#000;">Your Recent Searches</h5>-->
   <!--             <div class="col-lg-1 wow fadeInUp" data-wow-delay="0.1s">-->
   <!--                 <div class="position-relative h-100">-->
   <!--                     <img class="img-fluid" src="images/vip_4_bed.png" alt="" style="object-fit: cover;">-->

   <!--                 </div>-->
   <!--             </div>-->
			<!--	 <div class="col-lg-2 wow fadeInUp" data-wow-delay="0.1s">-->
			<!--	 <p class="mb-4">Vip 4 Bed</p>-->
			<!--	 <p class="mb-4">₹ 2,299</p>-->
			<!--	 </div>-->
   <!--             <div class="col-lg-1 wow fadeInUp" data-wow-delay="0.3s">-->
   <!--                  <img class="img-fluid" src="images/vip_2_bed.png" alt="" style="object-fit: cover;">-->
   <!--             </div>-->
			<!--	<div class="col-lg-2 wow fadeInUp" data-wow-delay="0.1s">-->
			<!--	 <p class="mb-4">Vip 2 Bed</p>-->
			<!--	 <p class="mb-4">₹ 1,699</p>-->
			<!--	 </div>-->
			<!--	<div class="col-lg-1 wow fadeInUp" data-wow-delay="0.3s">-->
   <!--                  <img class="img-fluid" src="images/delux_ac_2_bed.png" alt="" style="object-fit: cover;">-->
   <!--             </div>-->
			<!--	<div class="col-lg-2 wow fadeInUp" data-wow-delay="0.1s">-->
			<!--	 <p class="mb-4">Delux Ac 2 Bed</p>-->
			<!--	 <p class="mb-4">₹ 1,299</p>-->
			<!--	 </div>-->
			<!--	<div class="col-lg-1 wow fadeInUp" data-wow-delay="0.3s">-->
   <!--                  <img class="img-fluid" src="images/ac_4_bed.png" alt="" style="object-fit: cover;">-->
   <!--             </div>-->
			<!--	<div class="col-lg-2 wow fadeInUp" data-wow-delay="0.1s">-->
			<!--	 <p class="mb-4">A/C 4 Bed</p>-->
			<!--	 <p class="mb-4">₹ 1,100</p>-->
			<!--	 </div>-->
   <!--         </div>-->
   <!--     </div>-->
   <!-- </div>-->
    <!-- About End -->


    <!-- Team Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="wow fadeInUp" data-wow-delay="0.1s">
			<!--<h6 class="section-title bg-white text-center text-primary px-3">Travel Guide</h6>-->
			<div class="row g-4">
                <div class="col-lg-11 col-md-11 wow fadeInUp" data-wow-delay="0.1s">
			        <h1 class="mb-5">Types of Rooms</h1>
			        <p>Are you going on a pilgrimage at Adhiparasakthi Siddar Peedam this season? we’ve got the stay arrangements with comfortable rooms..</p>
               </div>
               <div class="col-lg-1 col-md-1 wow fadeInUp" data-wow-delay="0.1s">
               <a  href="{{route('HomeSakthi.seeall')}}">
                   <button style="background-color: #fff; border:solid 1px #901111; color: #000; border-radius: 10px; padding: 10px; width: 100%;text-align:center;margin-bottom: 20px;">See all</button>
                   </a>
               </div>
            </div>

            </div>

            <div class="row g-4">

                @foreach($rooms as $room)
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s" style="margin-bottom: 30px;">
                    <div class="team-item">
                        <div class="overflow-hidden">
                            <img class="img-fluid" style="width: 100%;height:380px;border-radius: 12px;" src="{{ asset('storage/siteimages/'. $room->single_image) }}" alt="">

							<div class="room_card text-center">
							<h4 style="color:#fff; font-size: 17px;">{{$room->roomname}}</h2><h3 style="color:#fff;" align="right">₹ {{$room->roomprice}}</h4>
							<p>An amazing journey</p>

						    <a class="btn btn-outline-light w-100 py-3" href="{{ route('HomeSakthi.room_detail', ['room' => $room->id]) }}">Book Now</a>

							</div>

                        </div>

                    </div>
                </div>
                @endforeach

            </div>
        </div>
    </div>
    <!-- Team End -->


    <!-- Destination Start -->
    <div class="container-xxl py-5 destination">
        <div class="container">
   <!--         <div class="wow fadeInUp" data-wow-delay="0.1s">-->
			<!--<h6 class="section-title bg-white text-center text-primary px-3">Destination</h6>-->
   <!--             <div class="row g-4">-->
   <!--             <div class="col-lg-11 col-md-11 wow fadeInUp" data-wow-delay="0.1s">-->
   <!--                 <h1 class="mb-5">Available Rooms</h1>-->
                    <!--<p>Going somewhere to celebrate this season? Whether you’re going home or somewhere to roam, we’ve got the travel tools to get you to your destination.</p>-->
   <!--             </div>-->
   <!--             <div class="col-lg-1 col-md-1 wow fadeInUp" data-wow-delay="0.1s">-->
   <!--          <a href="{{route('HomeSakthi.seeall')}}">-->
   <!--             <button style="background-color: #fff; border:solid 1px #901111; color: #000; border-radius: 10px; padding: 10px; width: 100%;text-align:center;margin-bottom: 20px;">See all</button>-->
   <!--         </a>-->
   <!--             </div>-->
   <!--         </div>-->
            </div>
            <div class="row g-3">
			    <div class="col-lg-5 col-md-6 wow zoomIn" data-wow-delay="0.7s" style="min-height: 350px;">
                    <a  class="position-relative d-block h-100 overflow-hidden" href="{{route('HomeSakthi.seeall')}}" style="background-color: #901111;border-radius: 20px;padding: 30px;"><br>
					<div class="row g-3">
						<div class="col-lg-10 col-md-12 wow zoomIn" data-wow-delay="0.3s">
						    <h2 style="color:#fff;">Backpacking to Adhiparashakthi </h2>
						</div>
						<div class="col-lg-2 col-md-12 wow zoomIn" data-wow-delay="0.3s">
							<div style="border-radius: 8px;background: #FFF; color:#000;width: 50px;padding: 5px;">From ₹600</div>
						</div>
					</div>
					<p style="color:#fff;">The Holy-shrine Arulmigu Adhiparasakthi Siddhar Peedam is situated at Melmaruvathur, Tamil Nadu, which is 92 kms south of Chennai on the NH-45. This place is being considered as holy for the past 2000 years. In this is place where 21 Siddhars, men and women, have their Jeeva Samadhi. These Siddhars belongs to various religions. This is the Holy Land where AMMA Siddhar resides and blesses.</p><br><br>
                    <button type="button" style="background-color:#fff; color:#000; border-radius: 10px;" class="btn btn-outline-light w-100 py-3" type="submit">Book Now</button>
                    </a>
                </div>
                <div class="col-lg-7 col-md-6">
                    <div class="row g-3">
                        <div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img style="width:100%" src="images/facilities_we_have_1.png" alt="">
                            </a>
                        </div>
                        <div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img style="width:100%" src="images/facilities_we_have_2.png" alt="">
                            </a>
                        </div>
                        <div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img style="width:100%" src="images/facilities_we_have_3.png" alt="">
                            </a>
                        </div>
                        <div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.5s">
                            <a class="position-relative d-block overflow-hidden" href="">
                                <img style="width:100%" src="images/facilities_we_have_4.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Destination Start -->

	<!--<div class="container">
            <div class="row footer_mail_box wow fadeInUp" data-wow-delay="0.1s">
				<div class="col-lg-6 col-md-6">
					<h1>Subscribe Newsletter</h1>
					<h5>The Travel</h5>
					<p>Get inspired! Receive travel discounts, tips and behind the scenes stories.</p>
					<div class="row g-3">
						<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
						<div class="form-floating">
							<input type="text" name="emil" placeholder="Your Email Address" class="form-control">
						</div>
						</div>
						<div class="col-lg-6 col-md-12 wow zoomIn" data-wow-delay="0.3s">
							<button class="btn btn-dark w-100 py-3" type="submit">Subcribe</button>
						</div>
					</div>
				</div>
				<div class="col-lg-6 col-md-6">
					<center><img class="img-fluid mail_box_img" src="images/open_mailbox.png" alt=""></center>
				</div><br><br><br>
			</div>
	</div>-->

  @include("customer.loginregister")

  @include("customer.footer")

  @include("customer.foot")
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>

</body>

</html>
