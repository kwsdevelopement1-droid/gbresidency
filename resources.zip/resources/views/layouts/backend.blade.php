<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!--favicon-->
    <link rel="icon" href="{{ asset('images/gbr_logo.png') }}" type="image/png" />

    <!--<title>@yield('title')</title>-->
    @php
        $currentDomain = request()->getHost();
    @endphp
    <title>{{ Str::contains($currentDomain, 'gbresidency') ? 'GB Residency' : 'AP Lodging' }}</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-5.0.2-dist/css/bootstrap.min.css') }}">
    <link href=" https://cdn.jsdelivr.net/npm/sweetalert2@11.10.6/dist/sweetalert2.min.css " rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/font-awesome-4.7.0/css/font-awesome.min.css') }}">

    <style>
        em,
        .error-msg,
        #error-msg,
        .error-message {
            color: red;
        }

        .logo {
            width: 79px;
            height: 70px;
        }

        .title-card {
            background: #8DD3BB;
        }

        .title-card h2 {
            text-align: center;
            color: #FFF;
            font-family: Montserrat;
            font-size: 20px;
            font-style: normal;
            font-weight: 700;
            line-height: normal;
            height: 60px;

        }

        .default-form .has-float-label {
            display: block;
            position: relative;
        }

        .navbar .dropdown-menu {
            border-radius: 5px;
            background: #8DD3BB;
            color: #000;
            font-family: Montserrat;
            font-size: 14.7px;
            font-style: normal;
            font-weight: 500;
            line-height: normal;
        }

        .default-form .has-float-label label,
        .has-float-label>span {
            position: absolute;
            cursor: text;
            font-size: 75%;
            opacity: 1;
            transition: all 0.2s;
            top: -0.5em;
            left: 0.75rem;
            z-index: 3;
            line-height: 1;
            padding: 0 2px;
            background: #fff;
        }

        .default-form .has-float-label label::after,
        .default-form .has-float-label>span::after {
            content: " ";
            display: block;
            position: absolute;
            background: #fff;
            height: 2px;
            top: 50%;
            left: -0.2em;
            right: -0.2em;
            z-index: -1;
        }

        .default-form .has-float-label .form-control::-webkit-input-placeholder {
            opacity: 1;
            transition: all 0.2s;
        }

        .default-form .has-float-label .form-control::-moz-placeholder {
            opacity: 1;
            transition: all 0.2s;
        }

        .default-form .has-float-label .form-control:-ms-input-placeholder {
            opacity: 1;
            transition: all 0.2s;
        }

        .default-form .has-float-label .form-control::placeholder {
            opacity: 1;
            transition: all 0.2s;
        }

        .default-form .has-float-label .form-control:placeholder-shown:not(:focus)::-webkit-input-placeholder {
            opacity: 0;
        }

        .default-form .has-float-label .form-control:placeholder-shown:not(:focus)::-moz-placeholder {
            opacity: 0;
        }

        .default-form .has-float-label .form-control:placeholder-shown:not(:focus):-ms-input-placeholder {
            opacity: 0;
        }

        .default-form .has-float-label .form-control:placeholder-shown:not(:focus)::placeholder {
            opacity: 0;
        }

        .default-form .has-float-label .form-control:placeholder-shown:not(:focus)+* {
            font-size: 100%;
            color: #6c757d;
            opacity: 1;
            top: 0.3em;
        }

        .default-form .input-group .has-float-label {
            flex-grow: 1;
            margin-bottom: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .default-form .has-float-label .form-control:placeholder-shown:not(:focus)+* {
            margin-top: 6px;
        }

        .card {
            border-radius: 15px;
        }

        .navbar-nav .nav-link {
            padding-right: 0;
            padding-left: 0;
            color: #121;
            font-family: Montserrat;
            font-size: 14.7px;
            font-style: normal;
            font-weight: 600;
            line-height: normal;
        }

        .dropdown-submenu {
            position: relative;
        }

        .dropdown-submenu>.dropdown-menu {
            top: 0;
            left: 100%;
            margin-top: -6px;
            margin-left: -1px;
            -webkit-border-radius: 0 6px 6px 6px;
            -moz-border-radius: 0 6px 6px;
            border-radius: 0 6px 6px 6px;
        }

        .dropdown-submenu:hover>.dropdown-menu {
            display: block;
        }

        .dropdown-submenu>a:after {
            display: block;
            content: " ";
            float: right;
            width: 0;
            height: 0;
            border-color: transparent;
            border-style: solid;
            border-width: 5px 0 5px 5px;
            border-left-color: #ccc;
            margin-top: 5px;
            margin-right: -10px;
        }

        .dropdown-submenu:hover>a:after {
            border-left-color: #fff;
        }

        .dropdown-submenu.pull-left {
            float: none;
        }

        .dropdown-submenu.pull-left>.dropdown-menu {
            left: -100%;
            margin-left: 10px;
            -webkit-border-radius: 6px 0 6px 6px;
            -moz-border-radius: 6px 0 6px 6px;
            border-radius: 6px 0 6px 6px;
        }
    </style>
    @yield('styles')

</head>

<body>
    <div class="container">

        <nav class="navbar navbar-expand-md">
            <div class="container-fluid">
                <div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                aria-haspopup="true" aria-expanded="false">
                                Check In
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="{{ route('backend.floor-wise.index') }}">Rooms Status
                                        ( Floor Wise )</a></li>
                                <li><a class="dropdown-item" href="{{ route('backend.facility-wise.index') }}">Rooms
                                        Status ( Facility Wise )</a></li>
                                <li><a class="dropdown-item" href="{{ route('backend.check-in.index') }}">Check In</a>
                                </li>
                                {{-- <li><a class="dropdown-item" href="{{ route('backend.checkInGroup') }}">Group Check In</a>
                                </li> --}}


                                <li><a class="dropdown-item" href="{{ route('backend.extra-checkin') }}">Extra Bed Check
                                        In</a></li>
                                <li><a class="dropdown-item" href="{{ route('backend.advance-amounts.index') }}">Advance
                                        Amount</a></li>
                                <li><a class="dropdown-item" href="{{ route('backend.room.status.index') }}">Room
                                        Status</a></li>
                                <li><a class="dropdown-item"
                                        href="{{ route('backend.check-in-modification.index') }}">Check In
                                        Modification</a></li>
                                <li><a class="dropdown-item"
                                        href="{{ route('backend.room.transfer.index') }}">Room
                                        Transfer/Promote</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                aria-haspopup="true" aria-expanded="false">
                                Check Out
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="{{ route('backend.check-out.index') }}">Check
                                        Out</a></li>
                                         <li><a class="dropdown-item" href="{{ route('backend.guest.folio.index') }}">
                                        Guest Folio</a></li>
                                <li><a class="dropdown-item" href="{{ route('backend.extra-checkout') }}">Extra Bed
                                        Check Out</a></li>

                                <li><a class="dropdown-item" href="{{ route('backend.bill-statement.index') }}">Duplicate Bill
                                        </a></li>
                            </ul>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                aria-haspopup="true" aria-expanded="false">
                                Reports
                            </a>
                            <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">


                                <li><a class="dropdown-item" href="{{ route('backend.advance.report.index') }}">Advance
                                        Report</a></li>
                                <li><a class="dropdown-item"
                                        href="{{ route('backend.daily.collection.report.index') }}">Daily
                                        CollectionReport</a></li>
                                <li><a class="dropdown-item"
                                        href="{{ route('backend.excel.collection.report.index') }}">Excel Collection
                                        Report</a></li>
                                <li class="dropdown-submenu"><a class="nav-link" href="#"
                                        data-bs-toggle="dropdown">Occupancy Reports</a>
                                    <ul class=" dropdown-menu">
                                        <li><a class="dropdown-item"
                                                href="{{ route('backend.occupancy.report.index') }}">Occupancy
                                                Report</a></li>
                                        <li><a class="dropdown-item"
                                                href="{{ route('backend.checkin.report.index') }}">Check In Report</a>
                                        </li>
                                        <li><a class="dropdown-item"
                                                href="{{ route('backend.checkout.report.index') }}">Check Out
                                                Report</a></li>
                                    </ul>

                                </li>
                                <li class="dropdown-submenu"><a class="nav-link" href="#"
                                        data-bs-toggle="dropdown"> Other Reports </a>
                                    <ul class=" dropdown-menu">

                                        <li><a class="dropdown-item"
                                                href="{{ route('backend.cashier.report.index') }}">Cashier Id Wise
                                                Report</a></li>
                                        <li><a class="dropdown-item"
                                                href="{{ route('backend.foreigners.report.index') }}">Foreigners
                                                GuestList</a></li>
                                        <li><a class="dropdown-item"
                                                href="{{ route('backend.credit.collection.report.index') }}"> Credit
                                                Bill Collection Summary</a></li>
                                        <li><a class="dropdown-item"
                                                href="{{ route('backend.credit.card.collection.report.index') }}">
                                                Credit Card Collection Summary</a></li>
                                        <li><a class="dropdown-item" href="{{ route('backend.room.status.report.index') }}"> Room Status Report </a></li>


                                        <li><a class="dropdown-item" href="{{ route('backend.high.balance.report.index') }}">High Balance Report </a></li>
                                        <li><a class="dropdown-item" href="{{ route('backend.advance.report.index') }}">After checkout advance Report </a></li>


                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('logout') }}"
                                onclick="event.preventDefault();
                                  document.getElementById('logout-form').submit();">Quit</a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                        </li>
                    </ul>
                </div>
                <div class="mx-auto order-0">
                    <a href="{{ route('backend.home') }}"><img src="{{ asset('assets/img/apl-logo.png') }}"
                            class="logo" alt="logo"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target=".dual-collapse2">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                </div>
                <div class="mx-auto order-0 mt-2"><p style="white-space: nowrap;">  @if(auth()->user()) Welcome <b>{{ auth()->user()->name}}</b>! @endif</p></div>
                <div class="navbar-collapse collapse w-100 order-3 dual-collapse2">
                    <ul class="navbar-nav ms-auto">
                        
                        
                         <!--call reservation-->
                        <li class="nav-item dropdown">
                            <a class="nav-link " href="{{route('backend.call_reservation_list')}}" id="navbarDropdown" role="button"
                                aria-haspopup="true" aria-expanded="false">
                                <br>Call Reservation
                            </a>
                            
                        </li>
                        
                        <!--over-->
                        
                        
                        <!--online reservation-->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                aria-haspopup="true" aria-expanded="false">
                                <br>Online Reservation
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="{{route('backend.Roomlistindex')}}">Rooms</a></li>
                                 
                                <li><a class="dropdown-item" href="{{route('backend.OnlinePaymentindex')}}">Reservations</a>
                                </li>
                                
                                <li><a class="dropdown-item" href="{{route('backend.Onlineapprovedlist')}}">Approved list</a>
                                </li>
                                
                                <li><a class="dropdown-item" href="{{route('backend.onlineblockcheckin')}}">Block Checkin Date</a>
                                </li>
                                

                            </ul>
                        </li>
                        
                        <!--over-->
                        
                        
                        
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                aria-haspopup="true" aria-expanded="false">
                                <img src="{{ asset('assets/img/apl-logo.png') }}" class="logo" alt="logo">

                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="{{ route('backend.home') }}">Home</a></li>
                                 {{-- @if(auth()->user() && auth()->user()->roles()->first()->id == 1) --}}
                                <li><a class="dropdown-item" href="{{ route('backend.rooms.index') }}">Setting</a>
                                </li>
                                {{-- @endif --}}

                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

    </div>
    @yield('title_nav')

    <div class="container mt-2">
        <!-- Your content goes here -->

        @yield('content')
    </div>

    <script src="{{ asset('assets/bootstrap-5.0.2-dist/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('assets/js/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>
    <script src=" https://cdn.jsdelivr.net/npm/sweetalert2@11.10.6/dist/sweetalert2.all.min.js "></script>
    <script>
        $(document).ready(function() {

            @if (session('toast'))

                Swal.fire({
                    icon: '{{ session('toast')['type'] }}',
                    title: '{{ session('toast')['message'] }}',
                    showConfirmButton: false,
                    timer: 1500
                });
            @endif

            // Show dropdown on hover
            $('.nav-item.dropdown').hover(function() {
                $(this).find('.dropdown-menu').first().stop(true, true).slideDown(150);
            }, function() {
                $(this).find('.dropdown-menu').first().stop(true, true).slideUp(100);
            });

            // Add class to parent li on hover
            $('.nav-item.dropdown').hover(function() {
                $(this).addClass('show');
            }, function() {
                $(this).removeClass('show');
            });
        });
    </script>
    @yield('scripts')

</body>

</html>
