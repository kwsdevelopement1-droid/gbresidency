<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Add tariff and extra_person_cost to checkouts table
        Schema::table('checkouts', function (Blueprint $table) {
            $table->decimal('tariff', 15, 2)->nullable()->after('payment_method');
            $table->decimal('extra_person_cost', 15, 2)->nullable()->after('tariff');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('checkouts', function (Blueprint $table) {
            $table->dropColumn(['tariff', 'extra_person_cost']);
        });
    }
};
