<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('onlinerooms', function (Blueprint $table) {
            $table->id();
            $table->string('roomname');
            $table->integer('roomprice');
            $table->integer('reservationprice');
            $table->text('overview');
            $table->string('single_image')->nullable();
            $table->string('galleryimg_1')->nullable();
            $table->string('galleryimg_2')->nullable();
            $table->string('galleryimg_3')->nullable();
            $table->string('galleryimg_4')->nullable();
            $table->string('galleryimg_5')->nullable();
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('onlinerooms');
    }
};
