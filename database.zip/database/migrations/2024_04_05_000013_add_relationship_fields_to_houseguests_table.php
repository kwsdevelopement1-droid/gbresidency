<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToHouseguestsTable extends Migration
{
    public function up()
    {
        Schema::table('houseguests', function (Blueprint $table) {
            $table->unsignedBigInteger('customer_ids_id')->nullable();
            $table->foreign('customer_ids_id', 'customer_ids_fk_9665070')->references('id')->on('customers');
        });
    }
}