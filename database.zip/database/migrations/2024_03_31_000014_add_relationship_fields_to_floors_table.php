<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToFloorsTable extends Migration
{
    public function up()
    {
        Schema::table('floors', function (Blueprint $table) {
            $table->unsignedBigInteger('select_room_type_id')->nullable();
            $table->foreign('select_room_type_id', 'select_room_type_fk_9648247')->references('id')->on('roomtypes');
        });
    }
}