<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomerRoomPivotTable extends Migration
{
    public function up()
    {
        Schema::create('customer_room', function (Blueprint $table) {
            $table->unsignedBigInteger('customer_id');
            $table->foreign('customer_id', 'customer_id_fk_9648279')->references('id')->on('customers')->onDelete('cascade');
            $table->unsignedBigInteger('room_id');
            $table->foreign('room_id', 'room_id_fk_9648279')->references('id')->on('rooms')->onDelete('cascade');
        });
    }
}