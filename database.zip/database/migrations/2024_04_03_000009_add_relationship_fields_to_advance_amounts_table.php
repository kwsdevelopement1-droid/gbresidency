<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToAdvanceAmountsTable extends Migration
{
    public function up()
    {
        Schema::table('advance_amounts', function (Blueprint $table) {
            $table->unsignedBigInteger('customer_ids_id')->nullable();
            $table->foreign('customer_ids_id', 'customer_ids_fk_9658323')->references('id')->on('customers');
            $table->unsignedBigInteger('user_ids_id')->nullable();
            $table->foreign('user_ids_id', 'user_ids_fk_9658324')->references('id')->on('users');
            });
    }
}