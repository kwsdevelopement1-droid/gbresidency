<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToCustomerdetailsTable extends Migration
{
    public function up()
    {
        Schema::table('customerdetails', function (Blueprint $table) {
            $table->unsignedBigInteger('customer_ids_id')->nullable();
            $table->foreign('customer_ids_id', 'customer_ids_fk_9648358')->references('id')->on('customers');
            $table->unsignedBigInteger('user_ids_id')->nullable();
            $table->foreign('user_ids_id', 'user_ids_fk_9658883')->references('id')->on('users');

        });
    }
}