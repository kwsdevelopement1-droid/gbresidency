<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddIgstToCheckoutsTables extends Migration
{
    public function up()
    {
        // Add igst column to checkouts table
        Schema::table('checkouts', function (Blueprint $table) {
            $table->decimal('igst', 15, 2)->default(0)->after('sgst');
        });
    }

    public function down()
    {
        Schema::table('checkouts', function (Blueprint $table) {
            $table->dropColumn('igst');
        });
    }
}
