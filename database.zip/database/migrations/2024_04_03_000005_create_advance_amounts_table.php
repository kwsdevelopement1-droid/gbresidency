<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdvanceAmountsTable extends Migration
{
    public function up()
    {
        Schema::create('advance_amounts', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->decimal('advance_amount', 15, 2);
            $table->string('payment_method');
            $table->timestamps();
            $table->softDeletes();
        });
    }
}