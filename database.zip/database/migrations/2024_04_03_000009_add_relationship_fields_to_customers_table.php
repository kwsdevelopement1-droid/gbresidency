<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToCustomersTable extends Migration
{
    public function up()
    {
        Schema::table('customers', function (Blueprint $table) {
            $table->unsignedBigInteger('country_id')->nullable();
            $table->foreign('country_id', 'country_fk_9648267')->references('id')->on('countries');
            $table->unsignedBigInteger('nationality_id')->nullable();
            $table->foreign('nationality_id', 'nationality_fk_9648268')->references('id')->on('countries');
            $table->unsignedBigInteger('room_type_id')->nullable();
            $table->foreign('room_type_id', 'room_type_fk_9648277')->references('id')->on('floors');
            $table->unsignedBigInteger('user_ids_id')->nullable();
            $table->foreign('user_ids_id', 'user_ids_fk_9658882')->references('id')->on('users');
            $table->unsignedBigInteger('discount_ids_id')->nullable();
            $table->foreign('discount_ids_id', 'discount_ids_fk_9659175')->references('id')->on('discounts');
      
        });
    }
}