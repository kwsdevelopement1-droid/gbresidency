<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomersTable extends Migration
{
    public function up()
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('guest_type');
            $table->string('guest_name');
            $table->string('email')->nullable();
            $table->string('country_code');
            $table->string('phone_number');
            $table->string('guest_gstin')->nullable();
            $table->string('seg');
            $table->integer('total_adult');
            $table->integer('total_child');
            $table->longText('address');
            $table->string('pincode')->nullable();
            $table->string('id_proof');
            $table->string('id_proof_number');
            $table->date('pr_exp_date');
            $table->date('visa_exp_date');
            $table->integer('no_fo_room');
            $table->string('rate_code');
            $table->decimal('price', 15, 2)->nullable();
            $table->decimal('total_amount', 15, 2)->nullable();
            $table->integer('status');
            $table->timestamps();
            $table->softDeletes();
        });
    }
}