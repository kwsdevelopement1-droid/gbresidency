<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFloorRoomPivotTable extends Migration
{
    public function up()
    {
        Schema::create('floor_room', function (Blueprint $table) {
            $table->unsignedBigInteger('floor_id');
            $table->foreign('floor_id', 'floor_id_fk_9648243')->references('id')->on('floors')->onDelete('cascade');
            $table->unsignedBigInteger('room_id');
            $table->foreign('room_id', 'room_id_fk_9648243')->references('id')->on('rooms')->onDelete('cascade');
        });
    }
}