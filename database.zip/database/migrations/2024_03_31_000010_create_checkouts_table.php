<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCheckoutsTable extends Migration
{
    public function up()
    {
        Schema::create('checkouts', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('remining_time')->nullable();
            $table->longText('remarks')->nullable();
            $table->string('payment_method')->nullable();
            $table->decimal('cgst', 15, 2);
            $table->decimal('sgst', 15, 2);
            $table->decimal('total_amount', 15, 2);
            $table->decimal('advance_amount', 15, 2);
            $table->decimal('balance_amount', 15, 2);
            $table->timestamps();
            $table->softDeletes();
        });
    }
}