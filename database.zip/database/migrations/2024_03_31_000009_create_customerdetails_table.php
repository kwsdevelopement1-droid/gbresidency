<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomerdetailsTable extends Migration
{
    public function up()
    {
        Schema::create('customerdetails', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->datetime('check_in');
            $table->datetime('check_out');
            $table->integer('days');
            $table->timestamps();
            $table->softDeletes();
        });
    }
}