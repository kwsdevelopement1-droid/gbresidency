<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRelationshipFieldsToRefuntamountsTable extends Migration
{
    public function up()
    {
        Schema::table('refuntamounts', function (Blueprint $table) {
            $table->unsignedBigInteger('user_ids_id')->nullable();
            $table->foreign('user_ids_id', 'user_ids_fk_9669024')->references('id')->on('users');
            $table->unsignedBigInteger('customers_ids_id')->nullable();
            $table->foreign('customers_ids_id', 'customers_ids_fk_9669025')->references('id')->on('customers');
        });
    }
}