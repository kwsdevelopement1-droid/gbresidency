<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGstsTable extends Migration
{
    public function up()
    {
        Schema::create('gsts', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('gst_percentage')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }
}