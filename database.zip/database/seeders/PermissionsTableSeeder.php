<?php

namespace Database\Seeders;

use App\Models\Permission;
use Illuminate\Database\Seeder;

class PermissionsTableSeeder extends Seeder
{
    public function run()
    {
        $permissions = [
            [
                'id'    => 1,
                'title' => 'user_management_access',
            ],
            [
                'id'    => 2,
                'title' => 'permission_create',
            ],
            [
                'id'    => 3,
                'title' => 'permission_edit',
            ],
            [
                'id'    => 4,
                'title' => 'permission_show',
            ],
            [
                'id'    => 5,
                'title' => 'permission_delete',
            ],
            [
                'id'    => 6,
                'title' => 'permission_access',
            ],
            [
                'id'    => 7,
                'title' => 'role_create',
            ],
            [
                'id'    => 8,
                'title' => 'role_edit',
            ],
            [
                'id'    => 9,
                'title' => 'role_show',
            ],
            [
                'id'    => 10,
                'title' => 'role_delete',
            ],
            [
                'id'    => 11,
                'title' => 'role_access',
            ],
            [
                'id'    => 12,
                'title' => 'user_create',
            ],
            [
                'id'    => 13,
                'title' => 'user_edit',
            ],
            [
                'id'    => 14,
                'title' => 'user_show',
            ],
            [
                'id'    => 15,
                'title' => 'user_delete',
            ],
            [
                'id'    => 16,
                'title' => 'user_access',
            ],
            [
                'id'    => 17,
                'title' => 'room_create',
            ],
            [
                'id'    => 18,
                'title' => 'room_edit',
            ],
            [
                'id'    => 19,
                'title' => 'room_show',
            ],
            [
                'id'    => 20,
                'title' => 'room_delete',
            ],
            [
                'id'    => 21,
                'title' => 'room_access',
            ],
            [
                'id'    => 22,
                'title' => 'roomtype_create',
            ],
            [
                'id'    => 23,
                'title' => 'roomtype_edit',
            ],
            [
                'id'    => 24,
                'title' => 'roomtype_show',
            ],
            [
                'id'    => 25,
                'title' => 'roomtype_delete',
            ],
            [
                'id'    => 26,
                'title' => 'roomtype_access',
            ],
            [
                'id'    => 27,
                'title' => 'floor_create',
            ],
            [
                'id'    => 28,
                'title' => 'floor_edit',
            ],
            [
                'id'    => 29,
                'title' => 'floor_show',
            ],
            [
                'id'    => 30,
                'title' => 'floor_delete',
            ],
            [
                'id'    => 31,
                'title' => 'floor_access',
            ],
            [
                'id'    => 32,
                'title' => 'country_create',
            ],
            [
                'id'    => 33,
                'title' => 'country_edit',
            ],
            [
                'id'    => 34,
                'title' => 'country_show',
            ],
            [
                'id'    => 35,
                'title' => 'country_delete',
            ],
            [
                'id'    => 36,
                'title' => 'country_access',
            ],
            [
                'id'    => 37,
                'title' => 'customer_create',
            ],
            [
                'id'    => 38,
                'title' => 'customer_edit',
            ],
            [
                'id'    => 39,
                'title' => 'customer_show',
            ],
            [
                'id'    => 40,
                'title' => 'customer_delete',
            ],
            [
                'id'    => 41,
                'title' => 'customer_access',
            ],
            [
                'id'    => 42,
                'title' => 'customerdetail_create',
            ],
            [
                'id'    => 43,
                'title' => 'customerdetail_edit',
            ],
            [
                'id'    => 44,
                'title' => 'customerdetail_show',
            ],
            [
                'id'    => 45,
                'title' => 'customerdetail_delete',
            ],
            [
                'id'    => 46,
                'title' => 'customerdetail_access',
            ],
            [
                'id'    => 47,
                'title' => 'checkout_create',
            ],
            [
                'id'    => 48,
                'title' => 'checkout_edit',
            ],
            [
                'id'    => 49,
                'title' => 'checkout_show',
            ],
            [
                'id'    => 50,
                'title' => 'checkout_delete',
            ],
            [
                'id'    => 51,
                'title' => 'checkout_access',
            ],
            [
                'id'    => 52,
                'title' => 'profile_password_edit',
            ],

            [
                'id'    => 53,
                'title' => 'advance_amount_create',
            ],
            [
                'id'    => 54,
                'title' => 'advance_amount_edit',
            ],
            [
                'id'    => 55,
                'title' => 'advance_amount_show',
            ],
            [
                'id'    => 56,
                'title' => 'advance_amount_delete',
            ],
            [
                'id'    => 57,
                'title' => 'gst_create',
            ],
            [
                'id'    => 58,
                'title' => 'gst_edit',
            ],
            [
                'id'    => 59,
                'title' => 'gst_show',
            ],
            [
                'id'    => 60,
                'title' => 'gst_delete',
            ],
            [
                'id'    => 61,
                'title' => 'gst_access',
            ],
            [
                'id'    => 62,
                'title' => 'advance_amount_access',
            ],
        ];

        Permission::insert($permissions);
    }
}